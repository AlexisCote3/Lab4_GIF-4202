-- Copyright 1986-2018 Xilinx, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2018.2.1 (win64) Build 2288692 Thu Jul 26 18:24:02 MDT 2018
-- Date        : Mon Nov 23 17:05:48 2026
-- Host        : pcetu-136 running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode funcsim -rename_top decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix -prefix
--               decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_ HDMI_bd_FSM_0_3_sim_netlist.vhdl
-- Design      : HDMI_bd_FSM_0_3
-- Purpose     : This VHDL netlist is a functional simulation representation of the design and should not be modified or
--               synthesized. This netlist cannot be used for SDF annotated simulation.
-- Device      : xc7z020clg400-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_game_state is
  port (
    \out\ : out STD_LOGIC_VECTOR ( 2 downto 0 );
    \sec_reg_reg[3]\ : out STD_LOGIC;
    \score_courant_sig_reg[2]\ : out STD_LOGIC;
    \sec_reg_reg[0]\ : out STD_LOGIC;
    \record_perso_sig_reg[0]\ : out STD_LOGIC;
    E : out STD_LOGIC_VECTOR ( 0 to 0 );
    \clk_reg_reg[27]\ : out STD_LOGIC_VECTOR ( 0 to 0 );
    D : out STD_LOGIC_VECTOR ( 0 to 0 );
    \clk_reg_reg[27]_0\ : out STD_LOGIC_VECTOR ( 0 to 0 );
    \score_dernier_sig_reg[3]\ : out STD_LOGIC_VECTOR ( 0 to 0 );
    mode_ui : out STD_LOGIC_VECTOR ( 2 downto 0 );
    \sec_reg_reg[1]\ : out STD_LOGIC;
    \score_courant_sig_reg[3]\ : out STD_LOGIC_VECTOR ( 0 to 0 );
    \sec_reg_reg[3]_0\ : out STD_LOGIC_VECTOR ( 2 downto 0 );
    \diff_out[0]\ : out STD_LOGIC;
    \diff_out[1]\ : out STD_LOGIC;
    new_round : out STD_LOGIC;
    decompte_ui : out STD_LOGIC_VECTOR ( 3 downto 0 );
    flash_on : out STD_LOGIC;
    \FSM_sequential_etat_courant_reg[0]_0\ : out STD_LOGIC;
    run : in STD_LOGIC;
    clk : in STD_LOGIC;
    reset : in STD_LOGIC;
    pause : in STD_LOGIC;
    quit : in STD_LOGIC;
    q_pass : in STD_LOGIC;
    \clk_reg_reg[12]\ : in STD_LOGIC;
    \sec_reg_reg[3]_1\ : in STD_LOGIC;
    Q : in STD_LOGIC_VECTOR ( 3 downto 0 );
    \clk_reg_reg[26]\ : in STD_LOGIC;
    \clk_reg_reg[26]_0\ : in STD_LOGIC;
    \sec_reg_reg[3]_2\ : in STD_LOGIC_VECTOR ( 2 downto 0 );
    \sec_reg_reg[2]\ : in STD_LOGIC;
    \sec_reg_reg[3]_3\ : in STD_LOGIC;
    \clk_reg_reg[26]_1\ : in STD_LOGIC;
    difficulty : in STD_LOGIC_VECTOR ( 1 downto 0 )
  );
end decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_game_state;

architecture STRUCTURE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_game_state is
  signal \FSM_sequential_etat_courant[0]_i_2_n_0\ : STD_LOGIC;
  signal \FSM_sequential_etat_courant[1]_i_2_n_0\ : STD_LOGIC;
  signal \FSM_sequential_etat_courant[3]_i_2_n_0\ : STD_LOGIC;
  signal \FSM_sequential_etat_courant[3]_i_3_n_0\ : STD_LOGIC;
  signal \FSM_sequential_etat_courant[4]_i_10_n_0\ : STD_LOGIC;
  signal \FSM_sequential_etat_courant[4]_i_11_n_0\ : STD_LOGIC;
  signal \FSM_sequential_etat_courant[4]_i_1_n_0\ : STD_LOGIC;
  signal \FSM_sequential_etat_courant[4]_i_5_n_0\ : STD_LOGIC;
  signal \FSM_sequential_etat_courant[4]_i_6_n_0\ : STD_LOGIC;
  signal \FSM_sequential_etat_courant[4]_i_9_n_0\ : STD_LOGIC;
  signal \^clk_reg_reg[27]\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal \^diff_out[0]\ : STD_LOGIC;
  signal \^diff_out[1]\ : STD_LOGIC;
  signal \difficulte_mem[0]_i_1_n_0\ : STD_LOGIC;
  signal \difficulte_mem[1]_i_1_n_0\ : STD_LOGIC;
  signal \difficulte_mem[1]_i_2_n_0\ : STD_LOGIC;
  signal \difficulte_mem[1]_i_3_n_0\ : STD_LOGIC;
  signal etat_courant : STD_LOGIC_VECTOR ( 4 downto 0 );
  attribute RTL_KEEP : string;
  attribute RTL_KEEP of etat_courant : signal is "yes";
  signal \etat_suivant__0\ : STD_LOGIC_VECTOR ( 4 downto 0 );
  signal \^out\ : STD_LOGIC_VECTOR ( 2 downto 0 );
  attribute RTL_KEEP of \^out\ : signal is "yes";
  signal pass_meta : STD_LOGIC;
  signal pass_sync : STD_LOGIC;
  signal pause_meta : STD_LOGIC;
  signal pause_prev : STD_LOGIC;
  signal pause_sync : STD_LOGIC;
  signal quit_meta : STD_LOGIC;
  signal quit_sync : STD_LOGIC;
  signal run_meta : STD_LOGIC;
  signal run_prev : STD_LOGIC;
  signal run_sync : STD_LOGIC;
  signal \^score_dernier_sig_reg[3]\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal \^sec_reg_reg[0]\ : STD_LOGIC;
  signal \^sec_reg_reg[3]\ : STD_LOGIC;
  attribute FSM_ENCODED_STATES : string;
  attribute FSM_ENCODED_STATES of \FSM_sequential_etat_courant_reg[0]\ : label is "echec_charge:01110,reussi_flash:01101,reussi_charge:01100,start_go_charge:00011,fin_partie:10001,start_compte:00010,sauver_score:10000,start_charge:00001,reprise_go:01011,menu:00000,reprise_go_charge:01010,pause_state:00111,jeu:00110,reprise_compte:01001,reprise_charge:01000,init_mur:00101,start_go:00100,echec_flash:01111";
  attribute KEEP : string;
  attribute KEEP of \FSM_sequential_etat_courant_reg[0]\ : label is "yes";
  attribute FSM_ENCODED_STATES of \FSM_sequential_etat_courant_reg[1]\ : label is "echec_charge:01110,reussi_flash:01101,reussi_charge:01100,start_go_charge:00011,fin_partie:10001,start_compte:00010,sauver_score:10000,start_charge:00001,reprise_go:01011,menu:00000,reprise_go_charge:01010,pause_state:00111,jeu:00110,reprise_compte:01001,reprise_charge:01000,init_mur:00101,start_go:00100,echec_flash:01111";
  attribute KEEP of \FSM_sequential_etat_courant_reg[1]\ : label is "yes";
  attribute FSM_ENCODED_STATES of \FSM_sequential_etat_courant_reg[2]\ : label is "echec_charge:01110,reussi_flash:01101,reussi_charge:01100,start_go_charge:00011,fin_partie:10001,start_compte:00010,sauver_score:10000,start_charge:00001,reprise_go:01011,menu:00000,reprise_go_charge:01010,pause_state:00111,jeu:00110,reprise_compte:01001,reprise_charge:01000,init_mur:00101,start_go:00100,echec_flash:01111";
  attribute KEEP of \FSM_sequential_etat_courant_reg[2]\ : label is "yes";
  attribute FSM_ENCODED_STATES of \FSM_sequential_etat_courant_reg[3]\ : label is "echec_charge:01110,reussi_flash:01101,reussi_charge:01100,start_go_charge:00011,fin_partie:10001,start_compte:00010,sauver_score:10000,start_charge:00001,reprise_go:01011,menu:00000,reprise_go_charge:01010,pause_state:00111,jeu:00110,reprise_compte:01001,reprise_charge:01000,init_mur:00101,start_go:00100,echec_flash:01111";
  attribute KEEP of \FSM_sequential_etat_courant_reg[3]\ : label is "yes";
  attribute FSM_ENCODED_STATES of \FSM_sequential_etat_courant_reg[4]\ : label is "echec_charge:01110,reussi_flash:01101,reussi_charge:01100,start_go_charge:00011,fin_partie:10001,start_compte:00010,sauver_score:10000,start_charge:00001,reprise_go:01011,menu:00000,reprise_go_charge:01010,pause_state:00111,jeu:00110,reprise_compte:01001,reprise_charge:01000,init_mur:00101,start_go:00100,echec_flash:01111";
  attribute KEEP of \FSM_sequential_etat_courant_reg[4]\ : label is "yes";
  attribute SOFT_HLUTNM : string;
  attribute SOFT_HLUTNM of \sec_reg[0]_i_1__0\ : label is "soft_lutpair0";
  attribute SOFT_HLUTNM of \sec_reg[1]_i_1__0\ : label is "soft_lutpair0";
begin
  \clk_reg_reg[27]\(0) <= \^clk_reg_reg[27]\(0);
  \diff_out[0]\ <= \^diff_out[0]\;
  \diff_out[1]\ <= \^diff_out[1]\;
  \out\(2 downto 0) <= \^out\(2 downto 0);
  \score_dernier_sig_reg[3]\(0) <= \^score_dernier_sig_reg[3]\(0);
  \sec_reg_reg[0]\ <= \^sec_reg_reg[0]\;
  \sec_reg_reg[3]\ <= \^sec_reg_reg[3]\;
\FSM_sequential_etat_courant[0]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000337070707"
    )
        port map (
      I0 => \FSM_sequential_etat_courant[0]_i_2_n_0\,
      I1 => \^out\(0),
      I2 => etat_courant(0),
      I3 => \^out\(1),
      I4 => \^out\(2),
      I5 => etat_courant(4),
      O => \etat_suivant__0\(0)
    );
\FSM_sequential_etat_courant[0]_i_2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"00A2"
    )
        port map (
      I0 => \^out\(1),
      I1 => pause_sync,
      I2 => pause_prev,
      I3 => \^out\(2),
      O => \FSM_sequential_etat_courant[0]_i_2_n_0\
    );
\FSM_sequential_etat_courant[1]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000047F000004740"
    )
        port map (
      I0 => \^out\(1),
      I1 => \^out\(2),
      I2 => \^out\(0),
      I3 => etat_courant(0),
      I4 => etat_courant(4),
      I5 => \FSM_sequential_etat_courant[1]_i_2_n_0\,
      O => \etat_suivant__0\(1)
    );
\FSM_sequential_etat_courant[1]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"DFDDFFFF"
    )
        port map (
      I0 => pass_sync,
      I1 => \^out\(2),
      I2 => pause_prev,
      I3 => pause_sync,
      I4 => \^out\(1),
      O => \FSM_sequential_etat_courant[1]_i_2_n_0\
    );
\FSM_sequential_etat_courant[2]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"006A"
    )
        port map (
      I0 => \^out\(1),
      I1 => etat_courant(0),
      I2 => \^out\(0),
      I3 => etat_courant(4),
      O => \etat_suivant__0\(2)
    );
\FSM_sequential_etat_courant[3]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"000000EA"
    )
        port map (
      I0 => \^out\(2),
      I1 => \^out\(0),
      I2 => \^out\(1),
      I3 => etat_courant(4),
      I4 => \FSM_sequential_etat_courant[3]_i_2_n_0\,
      O => \etat_suivant__0\(3)
    );
\FSM_sequential_etat_courant[3]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000FF04F004"
    )
        port map (
      I0 => pause_prev,
      I1 => pause_sync,
      I2 => \^out\(2),
      I3 => etat_courant(0),
      I4 => quit_sync,
      I5 => \FSM_sequential_etat_courant[3]_i_3_n_0\,
      O => \FSM_sequential_etat_courant[3]_i_2_n_0\
    );
\FSM_sequential_etat_courant[3]_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \^out\(1),
      I1 => \^out\(0),
      O => \FSM_sequential_etat_courant[3]_i_3_n_0\
    );
\FSM_sequential_etat_courant[4]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFF0000FFF1"
    )
        port map (
      I0 => \clk_reg_reg[26]\,
      I1 => \^out\(2),
      I2 => \clk_reg_reg[26]_0\,
      I3 => \FSM_sequential_etat_courant[4]_i_5_n_0\,
      I4 => etat_courant(4),
      I5 => \FSM_sequential_etat_courant[4]_i_6_n_0\,
      O => \FSM_sequential_etat_courant[4]_i_1_n_0\
    );
\FSM_sequential_etat_courant[4]_i_10\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \^out\(1),
      I1 => \^out\(0),
      O => \FSM_sequential_etat_courant[4]_i_10_n_0\
    );
\FSM_sequential_etat_courant[4]_i_11\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFAE"
    )
        port map (
      I0 => \sec_reg_reg[3]_3\,
      I1 => pause_sync,
      I2 => pause_prev,
      I3 => \^out\(2),
      O => \FSM_sequential_etat_courant[4]_i_11_n_0\
    );
\FSM_sequential_etat_courant[4]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"40000002"
    )
        port map (
      I0 => etat_courant(4),
      I1 => \^out\(2),
      I2 => etat_courant(0),
      I3 => \^out\(0),
      I4 => \^out\(1),
      O => \etat_suivant__0\(4)
    );
\FSM_sequential_etat_courant[4]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0F0FDFF00000D0F0"
    )
        port map (
      I0 => \FSM_sequential_etat_courant[4]_i_9_n_0\,
      I1 => quit_sync,
      I2 => etat_courant(0),
      I3 => \FSM_sequential_etat_courant[4]_i_10_n_0\,
      I4 => \^out\(2),
      I5 => \FSM_sequential_etat_courant[4]_i_11_n_0\,
      O => \FSM_sequential_etat_courant[4]_i_5_n_0\
    );
\FSM_sequential_etat_courant[4]_i_6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFF8B880000"
    )
        port map (
      I0 => quit_sync,
      I1 => etat_courant(0),
      I2 => run_prev,
      I3 => run_sync,
      I4 => \difficulte_mem[1]_i_2_n_0\,
      I5 => \^score_dernier_sig_reg[3]\(0),
      O => \FSM_sequential_etat_courant[4]_i_6_n_0\
    );
\FSM_sequential_etat_courant[4]_i_8\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"B"
    )
        port map (
      I0 => \^out\(1),
      I1 => \^out\(0),
      O => \FSM_sequential_etat_courant_reg[0]_0\
    );
\FSM_sequential_etat_courant[4]_i_9\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"B"
    )
        port map (
      I0 => run_prev,
      I1 => run_sync,
      O => \FSM_sequential_etat_courant[4]_i_9_n_0\
    );
\FSM_sequential_etat_courant_reg[0]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => \FSM_sequential_etat_courant[4]_i_1_n_0\,
      CLR => reset,
      D => \etat_suivant__0\(0),
      Q => etat_courant(0)
    );
\FSM_sequential_etat_courant_reg[1]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => \FSM_sequential_etat_courant[4]_i_1_n_0\,
      CLR => reset,
      D => \etat_suivant__0\(1),
      Q => \^out\(0)
    );
\FSM_sequential_etat_courant_reg[2]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => \FSM_sequential_etat_courant[4]_i_1_n_0\,
      CLR => reset,
      D => \etat_suivant__0\(2),
      Q => \^out\(1)
    );
\FSM_sequential_etat_courant_reg[3]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => \FSM_sequential_etat_courant[4]_i_1_n_0\,
      CLR => reset,
      D => \etat_suivant__0\(3),
      Q => \^out\(2)
    );
\FSM_sequential_etat_courant_reg[4]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => \FSM_sequential_etat_courant[4]_i_1_n_0\,
      CLR => reset,
      D => \etat_suivant__0\(4),
      Q => etat_courant(4)
    );
\clk_reg[27]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"01000000"
    )
        port map (
      I0 => etat_courant(0),
      I1 => etat_courant(4),
      I2 => \^out\(2),
      I3 => \^out\(1),
      I4 => \^out\(0),
      O => \clk_reg_reg[27]_0\(0)
    );
\clk_reg[27]_i_2__0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"22220110"
    )
        port map (
      I0 => etat_courant(0),
      I1 => etat_courant(4),
      I2 => \^out\(1),
      I3 => \^out\(0),
      I4 => \^out\(2),
      O => \^clk_reg_reg[27]\(0)
    );
\clk_reg[27]_i_4__0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"54545551"
    )
        port map (
      I0 => reset,
      I1 => etat_courant(0),
      I2 => etat_courant(4),
      I3 => \^out\(1),
      I4 => \^out\(2),
      O => \^sec_reg_reg[3]\
    );
\decompte_ui[0]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000101100101100"
    )
        port map (
      I0 => etat_courant(4),
      I1 => \^out\(1),
      I2 => Q(0),
      I3 => \^out\(2),
      I4 => \^out\(0),
      I5 => etat_courant(0),
      O => decompte_ui(0)
    );
\decompte_ui[1]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000101100101100"
    )
        port map (
      I0 => etat_courant(4),
      I1 => \^out\(1),
      I2 => Q(1),
      I3 => \^out\(2),
      I4 => \^out\(0),
      I5 => etat_courant(0),
      O => decompte_ui(1)
    );
\decompte_ui[2]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000002400000000"
    )
        port map (
      I0 => \^out\(2),
      I1 => \^out\(0),
      I2 => etat_courant(0),
      I3 => \^out\(1),
      I4 => etat_courant(4),
      I5 => Q(2),
      O => decompte_ui(2)
    );
\decompte_ui[3]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000002400000000"
    )
        port map (
      I0 => \^out\(2),
      I1 => \^out\(0),
      I2 => etat_courant(0),
      I3 => \^out\(1),
      I4 => etat_courant(4),
      I5 => Q(3),
      O => decompte_ui(3)
    );
\difficulte_mem[0]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFBFFFFF00800000"
    )
        port map (
      I0 => difficulty(0),
      I1 => \difficulte_mem[1]_i_2_n_0\,
      I2 => \difficulte_mem[1]_i_3_n_0\,
      I3 => run_prev,
      I4 => run_sync,
      I5 => \^diff_out[0]\,
      O => \difficulte_mem[0]_i_1_n_0\
    );
\difficulte_mem[1]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFBFFFFF00800000"
    )
        port map (
      I0 => difficulty(1),
      I1 => \difficulte_mem[1]_i_2_n_0\,
      I2 => \difficulte_mem[1]_i_3_n_0\,
      I3 => run_prev,
      I4 => run_sync,
      I5 => \^diff_out[1]\,
      O => \difficulte_mem[1]_i_1_n_0\
    );
\difficulte_mem[1]_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"01"
    )
        port map (
      I0 => \^out\(2),
      I1 => \^out\(1),
      I2 => \^out\(0),
      O => \difficulte_mem[1]_i_2_n_0\
    );
\difficulte_mem[1]_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => etat_courant(4),
      I1 => etat_courant(0),
      O => \difficulte_mem[1]_i_3_n_0\
    );
\difficulte_mem_reg[0]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => '1',
      CLR => reset,
      D => \difficulte_mem[0]_i_1_n_0\,
      Q => \^diff_out[0]\
    );
\difficulte_mem_reg[1]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => '1',
      CLR => reset,
      D => \difficulte_mem[1]_i_1_n_0\,
      Q => \^diff_out[1]\
    );
flash_on_INST_0: unisim.vcomponents.LUT5
    generic map(
      INIT => X"08000808"
    )
        port map (
      I0 => \^out\(1),
      I1 => \^out\(2),
      I2 => etat_courant(4),
      I3 => \clk_reg_reg[26]_1\,
      I4 => etat_courant(0),
      O => flash_on
    );
\mode_ui[0]_INST_0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"0000FF3E"
    )
        port map (
      I0 => etat_courant(0),
      I1 => \^out\(0),
      I2 => \^out\(1),
      I3 => \^out\(2),
      I4 => etat_courant(4),
      O => mode_ui(0)
    );
\mode_ui[1]_INST_0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0060"
    )
        port map (
      I0 => \^out\(0),
      I1 => \^out\(2),
      I2 => \^out\(1),
      I3 => etat_courant(4),
      O => mode_ui(1)
    );
\mode_ui[2]_INST_0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"50400202"
    )
        port map (
      I0 => etat_courant(4),
      I1 => \^out\(2),
      I2 => \^out\(0),
      I3 => etat_courant(0),
      I4 => \^out\(1),
      O => mode_ui(2)
    );
new_round_INST_0: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00000400"
    )
        port map (
      I0 => etat_courant(4),
      I1 => etat_courant(0),
      I2 => \^out\(2),
      I3 => \^out\(1),
      I4 => \^out\(0),
      O => new_round
    );
pass_meta_reg: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => '1',
      CLR => reset,
      D => q_pass,
      Q => pass_meta
    );
pass_sync_reg: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => '1',
      CLR => reset,
      D => pass_meta,
      Q => pass_sync
    );
pause_meta_reg: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => '1',
      CLR => reset,
      D => pause,
      Q => pause_meta
    );
pause_prev_reg: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => '1',
      CLR => reset,
      D => pause_sync,
      Q => pause_prev
    );
pause_sync_reg: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => '1',
      CLR => reset,
      D => pause_meta,
      Q => pause_sync
    );
quit_meta_reg: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => '1',
      CLR => reset,
      D => quit,
      Q => quit_meta
    );
quit_sync_reg: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => '1',
      CLR => reset,
      D => quit_meta,
      Q => quit_sync
    );
\record_perso_sig[3]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFEFFFFFFFFFF"
    )
        port map (
      I0 => reset,
      I1 => etat_courant(0),
      I2 => etat_courant(4),
      I3 => \^out\(1),
      I4 => \^out\(0),
      I5 => \^out\(2),
      O => \record_perso_sig_reg[0]\
    );
run_meta_reg: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => '1',
      CLR => reset,
      D => run,
      Q => run_meta
    );
run_prev_reg: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => '1',
      CLR => reset,
      D => run_sync,
      Q => run_prev
    );
run_sync_reg: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => '1',
      CLR => reset,
      D => run_meta,
      Q => run_sync
    );
\score_courant_sig[3]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00000120"
    )
        port map (
      I0 => \^out\(1),
      I1 => \^out\(0),
      I2 => \^out\(2),
      I3 => etat_courant(0),
      I4 => etat_courant(4),
      O => \score_courant_sig_reg[3]\(0)
    );
\score_courant_sig[3]_i_3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00000004"
    )
        port map (
      I0 => etat_courant(4),
      I1 => etat_courant(0),
      I2 => \^out\(2),
      I3 => \^out\(0),
      I4 => \^out\(1),
      O => \score_courant_sig_reg[2]\
    );
\score_dernier_sig[3]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00000002"
    )
        port map (
      I0 => etat_courant(4),
      I1 => etat_courant(0),
      I2 => \^out\(0),
      I3 => \^out\(1),
      I4 => \^out\(2),
      O => \^score_dernier_sig_reg[3]\(0)
    );
\sec_reg[0]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"4444444777777777"
    )
        port map (
      I0 => Q(0),
      I1 => \^sec_reg_reg[3]\,
      I2 => \^out\(0),
      I3 => \^out\(1),
      I4 => \^out\(2),
      I5 => etat_courant(4),
      O => D(0)
    );
\sec_reg[0]_i_1__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0EFE"
    )
        port map (
      I0 => \^diff_out[0]\,
      I1 => \^diff_out[1]\,
      I2 => \^sec_reg_reg[0]\,
      I3 => \sec_reg_reg[3]_2\(0),
      O => \sec_reg_reg[3]_0\(0)
    );
\sec_reg[1]_i_1__0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"9F909F9F"
    )
        port map (
      I0 => \sec_reg_reg[3]_2\(0),
      I1 => \sec_reg_reg[3]_2\(1),
      I2 => \^sec_reg_reg[0]\,
      I3 => \^diff_out[0]\,
      I4 => \^diff_out[1]\,
      O => \sec_reg_reg[3]_0\(1)
    );
\sec_reg[1]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"0003FBF7"
    )
        port map (
      I0 => etat_courant(0),
      I1 => \^out\(0),
      I2 => \^out\(1),
      I3 => \^out\(2),
      I4 => etat_courant(4),
      O => \sec_reg_reg[1]\
    );
\sec_reg[3]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"5D55"
    )
        port map (
      I0 => \^sec_reg_reg[3]\,
      I1 => \clk_reg_reg[12]\,
      I2 => \sec_reg_reg[3]_1\,
      I3 => \^clk_reg_reg[27]\(0),
      O => E(0)
    );
\sec_reg[3]_i_2__0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"9090909F"
    )
        port map (
      I0 => \sec_reg_reg[2]\,
      I1 => \sec_reg_reg[3]_2\(2),
      I2 => \^sec_reg_reg[0]\,
      I3 => \^diff_out[0]\,
      I4 => \^diff_out[1]\,
      O => \sec_reg_reg[3]_0\(2)
    );
\sec_reg[3]_i_3__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"5555555555455555"
    )
        port map (
      I0 => reset,
      I1 => \^out\(0),
      I2 => \^out\(1),
      I3 => \^out\(2),
      I4 => etat_courant(0),
      I5 => etat_courant(4),
      O => \^sec_reg_reg[0]\
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_score is
  port (
    Q : out STD_LOGIC_VECTOR ( 3 downto 0 );
    record_perso : out STD_LOGIC_VECTOR ( 3 downto 0 );
    score_dernier : out STD_LOGIC_VECTOR ( 3 downto 0 );
    \FSM_sequential_etat_courant_reg[4]\ : in STD_LOGIC;
    \FSM_sequential_etat_courant_reg[0]\ : in STD_LOGIC;
    E : in STD_LOGIC_VECTOR ( 0 to 0 );
    clk : in STD_LOGIC;
    reset : in STD_LOGIC;
    \FSM_sequential_etat_courant_reg[4]_0\ : in STD_LOGIC_VECTOR ( 0 to 0 )
  );
end decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_score;

architecture STRUCTURE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_score is
  signal \^q\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \^record_perso\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal record_perso_sig : STD_LOGIC;
  signal \record_perso_sig[3]_i_3_n_0\ : STD_LOGIC;
  signal \record_perso_sig[3]_i_4_n_0\ : STD_LOGIC;
  signal \record_perso_sig[3]_i_6_n_0\ : STD_LOGIC;
  signal \score_courant_sig[0]_i_1_n_0\ : STD_LOGIC;
  signal \score_courant_sig[1]_i_1_n_0\ : STD_LOGIC;
  signal \score_courant_sig[2]_i_1_n_0\ : STD_LOGIC;
  signal \score_courant_sig[3]_i_2_n_0\ : STD_LOGIC;
  signal score_suivant : STD_LOGIC_VECTOR ( 3 downto 0 );
  attribute SOFT_HLUTNM : string;
  attribute SOFT_HLUTNM of \record_perso_sig[0]_i_1\ : label is "soft_lutpair5";
  attribute SOFT_HLUTNM of \record_perso_sig[1]_i_1\ : label is "soft_lutpair5";
  attribute SOFT_HLUTNM of \record_perso_sig[2]_i_1\ : label is "soft_lutpair3";
  attribute SOFT_HLUTNM of \record_perso_sig[3]_i_2\ : label is "soft_lutpair4";
  attribute SOFT_HLUTNM of \record_perso_sig[3]_i_3\ : label is "soft_lutpair4";
  attribute SOFT_HLUTNM of \record_perso_sig[3]_i_6\ : label is "soft_lutpair3";
  attribute SOFT_HLUTNM of \score_courant_sig[0]_i_1\ : label is "soft_lutpair2";
  attribute SOFT_HLUTNM of \score_courant_sig[1]_i_1\ : label is "soft_lutpair1";
  attribute SOFT_HLUTNM of \score_courant_sig[2]_i_1\ : label is "soft_lutpair1";
  attribute SOFT_HLUTNM of \score_courant_sig[3]_i_2\ : label is "soft_lutpair2";
begin
  Q(3 downto 0) <= \^q\(3 downto 0);
  record_perso(3 downto 0) <= \^record_perso\(3 downto 0);
\record_perso_sig[0]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"B333"
    )
        port map (
      I0 => \^q\(1),
      I1 => \^q\(0),
      I2 => \^q\(2),
      I3 => \^q\(3),
      O => score_suivant(0)
    );
\record_perso_sig[1]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"8FF0"
    )
        port map (
      I0 => \^q\(3),
      I1 => \^q\(2),
      I2 => \^q\(0),
      I3 => \^q\(1),
      O => score_suivant(1)
    );
\record_perso_sig[2]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"F878"
    )
        port map (
      I0 => \^q\(1),
      I1 => \^q\(0),
      I2 => \^q\(2),
      I3 => \^q\(3),
      O => score_suivant(2)
    );
\record_perso_sig[3]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000071007100FF"
    )
        port map (
      I0 => \record_perso_sig[3]_i_3_n_0\,
      I1 => \^record_perso\(2),
      I2 => \record_perso_sig[3]_i_4_n_0\,
      I3 => \FSM_sequential_etat_courant_reg[0]\,
      I4 => \^record_perso\(3),
      I5 => \record_perso_sig[3]_i_6_n_0\,
      O => record_perso_sig
    );
\record_perso_sig[3]_i_2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FF80"
    )
        port map (
      I0 => \^q\(2),
      I1 => \^q\(0),
      I2 => \^q\(1),
      I3 => \^q\(3),
      O => score_suivant(3)
    );
\record_perso_sig[3]_i_3\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"4333"
    )
        port map (
      I0 => \^q\(3),
      I1 => \^q\(2),
      I2 => \^q\(0),
      I3 => \^q\(1),
      O => \record_perso_sig[3]_i_3_n_0\
    );
\record_perso_sig[3]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"44040404FD3D3D3D"
    )
        port map (
      I0 => \^record_perso\(0),
      I1 => \^q\(1),
      I2 => \^q\(0),
      I3 => \^q\(2),
      I4 => \^q\(3),
      I5 => \^record_perso\(1),
      O => \record_perso_sig[3]_i_4_n_0\
    );
\record_perso_sig[3]_i_6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"1555"
    )
        port map (
      I0 => \^q\(3),
      I1 => \^q\(1),
      I2 => \^q\(0),
      I3 => \^q\(2),
      O => \record_perso_sig[3]_i_6_n_0\
    );
\record_perso_sig_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => record_perso_sig,
      D => score_suivant(0),
      Q => \^record_perso\(0),
      R => '0'
    );
\record_perso_sig_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => record_perso_sig,
      D => score_suivant(1),
      Q => \^record_perso\(1),
      R => '0'
    );
\record_perso_sig_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => record_perso_sig,
      D => score_suivant(2),
      Q => \^record_perso\(2),
      R => '0'
    );
\record_perso_sig_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => record_perso_sig,
      D => score_suivant(3),
      Q => \^record_perso\(3),
      R => '0'
    );
\score_courant_sig[0]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"45050505"
    )
        port map (
      I0 => \FSM_sequential_etat_courant_reg[4]\,
      I1 => \^q\(1),
      I2 => \^q\(0),
      I3 => \^q\(2),
      I4 => \^q\(3),
      O => \score_courant_sig[0]_i_1_n_0\
    );
\score_courant_sig[1]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"0000E666"
    )
        port map (
      I0 => \^q\(1),
      I1 => \^q\(0),
      I2 => \^q\(2),
      I3 => \^q\(3),
      I4 => \FSM_sequential_etat_courant_reg[4]\,
      O => \score_courant_sig[1]_i_1_n_0\
    );
\score_courant_sig[2]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"55401540"
    )
        port map (
      I0 => \FSM_sequential_etat_courant_reg[4]\,
      I1 => \^q\(1),
      I2 => \^q\(0),
      I3 => \^q\(2),
      I4 => \^q\(3),
      O => \score_courant_sig[2]_i_1_n_0\
    );
\score_courant_sig[3]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"55554000"
    )
        port map (
      I0 => \FSM_sequential_etat_courant_reg[4]\,
      I1 => \^q\(2),
      I2 => \^q\(0),
      I3 => \^q\(1),
      I4 => \^q\(3),
      O => \score_courant_sig[3]_i_2_n_0\
    );
\score_courant_sig_reg[0]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => E(0),
      CLR => reset,
      D => \score_courant_sig[0]_i_1_n_0\,
      Q => \^q\(0)
    );
\score_courant_sig_reg[1]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => E(0),
      CLR => reset,
      D => \score_courant_sig[1]_i_1_n_0\,
      Q => \^q\(1)
    );
\score_courant_sig_reg[2]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => E(0),
      CLR => reset,
      D => \score_courant_sig[2]_i_1_n_0\,
      Q => \^q\(2)
    );
\score_courant_sig_reg[3]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => E(0),
      CLR => reset,
      D => \score_courant_sig[3]_i_2_n_0\,
      Q => \^q\(3)
    );
\score_dernier_sig_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => \FSM_sequential_etat_courant_reg[4]_0\(0),
      D => \^q\(0),
      Q => score_dernier(0),
      R => '0'
    );
\score_dernier_sig_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => \FSM_sequential_etat_courant_reg[4]_0\(0),
      D => \^q\(1),
      Q => score_dernier(1),
      R => '0'
    );
\score_dernier_sig_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => \FSM_sequential_etat_courant_reg[4]_0\(0),
      D => \^q\(2),
      Q => score_dernier(2),
      R => '0'
    );
\score_dernier_sig_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => \FSM_sequential_etat_courant_reg[4]_0\(0),
      D => \^q\(3),
      Q => score_dernier(3),
      R => '0'
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_sec_counter is
  port (
    Q : out STD_LOGIC_VECTOR ( 3 downto 0 );
    \sec_reg_reg[0]_0\ : out STD_LOGIC;
    \sec_reg_reg[3]_0\ : out STD_LOGIC;
    E : in STD_LOGIC_VECTOR ( 0 to 0 );
    \FSM_sequential_etat_courant_reg[1]\ : in STD_LOGIC;
    D : in STD_LOGIC_VECTOR ( 2 downto 0 );
    \difficulte_mem_reg[0]\ : in STD_LOGIC;
    \difficulte_mem_reg[1]\ : in STD_LOGIC;
    clk : in STD_LOGIC
  );
end decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_sec_counter;

architecture STRUCTURE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_sec_counter is
  signal \^q\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal clk_reg : STD_LOGIC_VECTOR ( 27 downto 0 );
  signal \clk_reg0_carry__0_n_0\ : STD_LOGIC;
  signal \clk_reg0_carry__0_n_1\ : STD_LOGIC;
  signal \clk_reg0_carry__0_n_2\ : STD_LOGIC;
  signal \clk_reg0_carry__0_n_3\ : STD_LOGIC;
  signal \clk_reg0_carry__1_n_0\ : STD_LOGIC;
  signal \clk_reg0_carry__1_n_1\ : STD_LOGIC;
  signal \clk_reg0_carry__1_n_2\ : STD_LOGIC;
  signal \clk_reg0_carry__1_n_3\ : STD_LOGIC;
  signal \clk_reg0_carry__2_n_0\ : STD_LOGIC;
  signal \clk_reg0_carry__2_n_1\ : STD_LOGIC;
  signal \clk_reg0_carry__2_n_2\ : STD_LOGIC;
  signal \clk_reg0_carry__2_n_3\ : STD_LOGIC;
  signal \clk_reg0_carry__3_n_0\ : STD_LOGIC;
  signal \clk_reg0_carry__3_n_1\ : STD_LOGIC;
  signal \clk_reg0_carry__3_n_2\ : STD_LOGIC;
  signal \clk_reg0_carry__3_n_3\ : STD_LOGIC;
  signal \clk_reg0_carry__4_n_0\ : STD_LOGIC;
  signal \clk_reg0_carry__4_n_1\ : STD_LOGIC;
  signal \clk_reg0_carry__4_n_2\ : STD_LOGIC;
  signal \clk_reg0_carry__4_n_3\ : STD_LOGIC;
  signal \clk_reg0_carry__5_n_2\ : STD_LOGIC;
  signal \clk_reg0_carry__5_n_3\ : STD_LOGIC;
  signal clk_reg0_carry_n_0 : STD_LOGIC;
  signal clk_reg0_carry_n_1 : STD_LOGIC;
  signal clk_reg0_carry_n_2 : STD_LOGIC;
  signal clk_reg0_carry_n_3 : STD_LOGIC;
  signal \clk_reg[27]_i_10_n_0\ : STD_LOGIC;
  signal \clk_reg[27]_i_1__0_n_0\ : STD_LOGIC;
  signal \clk_reg[27]_i_4_n_0\ : STD_LOGIC;
  signal \clk_reg[27]_i_5__0_n_0\ : STD_LOGIC;
  signal \clk_reg[27]_i_6_n_0\ : STD_LOGIC;
  signal \clk_reg[27]_i_7__0_n_0\ : STD_LOGIC;
  signal \clk_reg[27]_i_8__0_n_0\ : STD_LOGIC;
  signal \clk_reg[27]_i_9__0_n_0\ : STD_LOGIC;
  signal clk_reg_0 : STD_LOGIC_VECTOR ( 27 downto 0 );
  signal data0 : STD_LOGIC_VECTOR ( 27 downto 1 );
  signal p_0_in : STD_LOGIC_VECTOR ( 2 to 2 );
  signal \sec_reg[3]_i_10_n_0\ : STD_LOGIC;
  signal \sec_reg[3]_i_11_n_0\ : STD_LOGIC;
  signal \sec_reg[3]_i_12_n_0\ : STD_LOGIC;
  signal \sec_reg[3]_i_1__0_n_0\ : STD_LOGIC;
  signal \sec_reg[3]_i_5_n_0\ : STD_LOGIC;
  signal \sec_reg[3]_i_6_n_0\ : STD_LOGIC;
  signal \sec_reg[3]_i_7_n_0\ : STD_LOGIC;
  signal \sec_reg[3]_i_9_n_0\ : STD_LOGIC;
  signal \^sec_reg_reg[0]_0\ : STD_LOGIC;
  signal \NLW_clk_reg0_carry__5_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_clk_reg0_carry__5_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  attribute SOFT_HLUTNM : string;
  attribute SOFT_HLUTNM of \clk_reg[0]_i_1__0\ : label is "soft_lutpair6";
  attribute SOFT_HLUTNM of \clk_reg[10]_i_1\ : label is "soft_lutpair12";
  attribute SOFT_HLUTNM of \clk_reg[11]_i_1\ : label is "soft_lutpair13";
  attribute SOFT_HLUTNM of \clk_reg[12]_i_1\ : label is "soft_lutpair13";
  attribute SOFT_HLUTNM of \clk_reg[13]_i_1\ : label is "soft_lutpair14";
  attribute SOFT_HLUTNM of \clk_reg[14]_i_1\ : label is "soft_lutpair15";
  attribute SOFT_HLUTNM of \clk_reg[15]_i_1\ : label is "soft_lutpair14";
  attribute SOFT_HLUTNM of \clk_reg[16]_i_1\ : label is "soft_lutpair15";
  attribute SOFT_HLUTNM of \clk_reg[17]_i_1\ : label is "soft_lutpair16";
  attribute SOFT_HLUTNM of \clk_reg[18]_i_1\ : label is "soft_lutpair16";
  attribute SOFT_HLUTNM of \clk_reg[19]_i_1\ : label is "soft_lutpair17";
  attribute SOFT_HLUTNM of \clk_reg[1]_i_1\ : label is "soft_lutpair7";
  attribute SOFT_HLUTNM of \clk_reg[20]_i_1\ : label is "soft_lutpair17";
  attribute SOFT_HLUTNM of \clk_reg[21]_i_1\ : label is "soft_lutpair18";
  attribute SOFT_HLUTNM of \clk_reg[22]_i_1\ : label is "soft_lutpair18";
  attribute SOFT_HLUTNM of \clk_reg[23]_i_1\ : label is "soft_lutpair19";
  attribute SOFT_HLUTNM of \clk_reg[24]_i_1\ : label is "soft_lutpair19";
  attribute SOFT_HLUTNM of \clk_reg[25]_i_1\ : label is "soft_lutpair20";
  attribute SOFT_HLUTNM of \clk_reg[26]_i_1\ : label is "soft_lutpair20";
  attribute SOFT_HLUTNM of \clk_reg[27]_i_9__0\ : label is "soft_lutpair9";
  attribute SOFT_HLUTNM of \clk_reg[2]_i_1\ : label is "soft_lutpair8";
  attribute SOFT_HLUTNM of \clk_reg[3]_i_1\ : label is "soft_lutpair8";
  attribute SOFT_HLUTNM of \clk_reg[4]_i_1\ : label is "soft_lutpair7";
  attribute SOFT_HLUTNM of \clk_reg[5]_i_1\ : label is "soft_lutpair10";
  attribute SOFT_HLUTNM of \clk_reg[6]_i_1\ : label is "soft_lutpair11";
  attribute SOFT_HLUTNM of \clk_reg[7]_i_1\ : label is "soft_lutpair12";
  attribute SOFT_HLUTNM of \clk_reg[8]_i_1\ : label is "soft_lutpair10";
  attribute SOFT_HLUTNM of \clk_reg[9]_i_1\ : label is "soft_lutpair11";
  attribute SOFT_HLUTNM of \sec_reg[3]_i_10\ : label is "soft_lutpair9";
  attribute SOFT_HLUTNM of \sec_reg[3]_i_4\ : label is "soft_lutpair21";
  attribute SOFT_HLUTNM of \sec_reg[3]_i_6\ : label is "soft_lutpair6";
  attribute SOFT_HLUTNM of \sec_reg[3]_i_8\ : label is "soft_lutpair21";
begin
  Q(3 downto 0) <= \^q\(3 downto 0);
  \sec_reg_reg[0]_0\ <= \^sec_reg_reg[0]_0\;
clk_reg0_carry: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => clk_reg0_carry_n_0,
      CO(2) => clk_reg0_carry_n_1,
      CO(1) => clk_reg0_carry_n_2,
      CO(0) => clk_reg0_carry_n_3,
      CYINIT => clk_reg(0),
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => data0(4 downto 1),
      S(3 downto 0) => clk_reg(4 downto 1)
    );
\clk_reg0_carry__0\: unisim.vcomponents.CARRY4
     port map (
      CI => clk_reg0_carry_n_0,
      CO(3) => \clk_reg0_carry__0_n_0\,
      CO(2) => \clk_reg0_carry__0_n_1\,
      CO(1) => \clk_reg0_carry__0_n_2\,
      CO(0) => \clk_reg0_carry__0_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => data0(8 downto 5),
      S(3 downto 0) => clk_reg(8 downto 5)
    );
\clk_reg0_carry__1\: unisim.vcomponents.CARRY4
     port map (
      CI => \clk_reg0_carry__0_n_0\,
      CO(3) => \clk_reg0_carry__1_n_0\,
      CO(2) => \clk_reg0_carry__1_n_1\,
      CO(1) => \clk_reg0_carry__1_n_2\,
      CO(0) => \clk_reg0_carry__1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => data0(12 downto 9),
      S(3 downto 0) => clk_reg(12 downto 9)
    );
\clk_reg0_carry__2\: unisim.vcomponents.CARRY4
     port map (
      CI => \clk_reg0_carry__1_n_0\,
      CO(3) => \clk_reg0_carry__2_n_0\,
      CO(2) => \clk_reg0_carry__2_n_1\,
      CO(1) => \clk_reg0_carry__2_n_2\,
      CO(0) => \clk_reg0_carry__2_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => data0(16 downto 13),
      S(3 downto 0) => clk_reg(16 downto 13)
    );
\clk_reg0_carry__3\: unisim.vcomponents.CARRY4
     port map (
      CI => \clk_reg0_carry__2_n_0\,
      CO(3) => \clk_reg0_carry__3_n_0\,
      CO(2) => \clk_reg0_carry__3_n_1\,
      CO(1) => \clk_reg0_carry__3_n_2\,
      CO(0) => \clk_reg0_carry__3_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => data0(20 downto 17),
      S(3 downto 0) => clk_reg(20 downto 17)
    );
\clk_reg0_carry__4\: unisim.vcomponents.CARRY4
     port map (
      CI => \clk_reg0_carry__3_n_0\,
      CO(3) => \clk_reg0_carry__4_n_0\,
      CO(2) => \clk_reg0_carry__4_n_1\,
      CO(1) => \clk_reg0_carry__4_n_2\,
      CO(0) => \clk_reg0_carry__4_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => data0(24 downto 21),
      S(3 downto 0) => clk_reg(24 downto 21)
    );
\clk_reg0_carry__5\: unisim.vcomponents.CARRY4
     port map (
      CI => \clk_reg0_carry__4_n_0\,
      CO(3 downto 2) => \NLW_clk_reg0_carry__5_CO_UNCONNECTED\(3 downto 2),
      CO(1) => \clk_reg0_carry__5_n_2\,
      CO(0) => \clk_reg0_carry__5_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \NLW_clk_reg0_carry__5_O_UNCONNECTED\(3),
      O(2 downto 0) => data0(27 downto 25),
      S(3) => '0',
      S(2 downto 0) => clk_reg(27 downto 25)
    );
\clk_reg[0]_i_1__0\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => clk_reg(0),
      O => clk_reg_0(0)
    );
\clk_reg[10]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"AA8A"
    )
        port map (
      I0 => data0(10),
      I1 => \clk_reg[27]_i_4_n_0\,
      I2 => \clk_reg[27]_i_5__0_n_0\,
      I3 => \clk_reg[27]_i_6_n_0\,
      O => clk_reg_0(10)
    );
\clk_reg[11]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"AA8A"
    )
        port map (
      I0 => data0(11),
      I1 => \clk_reg[27]_i_4_n_0\,
      I2 => \clk_reg[27]_i_5__0_n_0\,
      I3 => \clk_reg[27]_i_6_n_0\,
      O => clk_reg_0(11)
    );
\clk_reg[12]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"AA8A"
    )
        port map (
      I0 => data0(12),
      I1 => \clk_reg[27]_i_4_n_0\,
      I2 => \clk_reg[27]_i_5__0_n_0\,
      I3 => \clk_reg[27]_i_6_n_0\,
      O => clk_reg_0(12)
    );
\clk_reg[13]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"AA8A"
    )
        port map (
      I0 => data0(13),
      I1 => \clk_reg[27]_i_4_n_0\,
      I2 => \clk_reg[27]_i_5__0_n_0\,
      I3 => \clk_reg[27]_i_6_n_0\,
      O => clk_reg_0(13)
    );
\clk_reg[14]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"AA8A"
    )
        port map (
      I0 => data0(14),
      I1 => \clk_reg[27]_i_4_n_0\,
      I2 => \clk_reg[27]_i_5__0_n_0\,
      I3 => \clk_reg[27]_i_6_n_0\,
      O => clk_reg_0(14)
    );
\clk_reg[15]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"AA8A"
    )
        port map (
      I0 => data0(15),
      I1 => \clk_reg[27]_i_4_n_0\,
      I2 => \clk_reg[27]_i_5__0_n_0\,
      I3 => \clk_reg[27]_i_6_n_0\,
      O => clk_reg_0(15)
    );
\clk_reg[16]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"AA8A"
    )
        port map (
      I0 => data0(16),
      I1 => \clk_reg[27]_i_4_n_0\,
      I2 => \clk_reg[27]_i_5__0_n_0\,
      I3 => \clk_reg[27]_i_6_n_0\,
      O => clk_reg_0(16)
    );
\clk_reg[17]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"AA8A"
    )
        port map (
      I0 => data0(17),
      I1 => \clk_reg[27]_i_4_n_0\,
      I2 => \clk_reg[27]_i_5__0_n_0\,
      I3 => \clk_reg[27]_i_6_n_0\,
      O => clk_reg_0(17)
    );
\clk_reg[18]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"AA8A"
    )
        port map (
      I0 => data0(18),
      I1 => \clk_reg[27]_i_4_n_0\,
      I2 => \clk_reg[27]_i_5__0_n_0\,
      I3 => \clk_reg[27]_i_6_n_0\,
      O => clk_reg_0(18)
    );
\clk_reg[19]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"AA8A"
    )
        port map (
      I0 => data0(19),
      I1 => \clk_reg[27]_i_4_n_0\,
      I2 => \clk_reg[27]_i_5__0_n_0\,
      I3 => \clk_reg[27]_i_6_n_0\,
      O => clk_reg_0(19)
    );
\clk_reg[1]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"AA8A"
    )
        port map (
      I0 => data0(1),
      I1 => \clk_reg[27]_i_4_n_0\,
      I2 => \clk_reg[27]_i_5__0_n_0\,
      I3 => \clk_reg[27]_i_6_n_0\,
      O => clk_reg_0(1)
    );
\clk_reg[20]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"AA8A"
    )
        port map (
      I0 => data0(20),
      I1 => \clk_reg[27]_i_4_n_0\,
      I2 => \clk_reg[27]_i_5__0_n_0\,
      I3 => \clk_reg[27]_i_6_n_0\,
      O => clk_reg_0(20)
    );
\clk_reg[21]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"AA8A"
    )
        port map (
      I0 => data0(21),
      I1 => \clk_reg[27]_i_4_n_0\,
      I2 => \clk_reg[27]_i_5__0_n_0\,
      I3 => \clk_reg[27]_i_6_n_0\,
      O => clk_reg_0(21)
    );
\clk_reg[22]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"AA8A"
    )
        port map (
      I0 => data0(22),
      I1 => \clk_reg[27]_i_4_n_0\,
      I2 => \clk_reg[27]_i_5__0_n_0\,
      I3 => \clk_reg[27]_i_6_n_0\,
      O => clk_reg_0(22)
    );
\clk_reg[23]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"AA8A"
    )
        port map (
      I0 => data0(23),
      I1 => \clk_reg[27]_i_4_n_0\,
      I2 => \clk_reg[27]_i_5__0_n_0\,
      I3 => \clk_reg[27]_i_6_n_0\,
      O => clk_reg_0(23)
    );
\clk_reg[24]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"AA8A"
    )
        port map (
      I0 => data0(24),
      I1 => \clk_reg[27]_i_4_n_0\,
      I2 => \clk_reg[27]_i_5__0_n_0\,
      I3 => \clk_reg[27]_i_6_n_0\,
      O => clk_reg_0(24)
    );
\clk_reg[25]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"AA8A"
    )
        port map (
      I0 => data0(25),
      I1 => \clk_reg[27]_i_4_n_0\,
      I2 => \clk_reg[27]_i_5__0_n_0\,
      I3 => \clk_reg[27]_i_6_n_0\,
      O => clk_reg_0(25)
    );
\clk_reg[26]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"AA8A"
    )
        port map (
      I0 => data0(26),
      I1 => \clk_reg[27]_i_4_n_0\,
      I2 => \clk_reg[27]_i_5__0_n_0\,
      I3 => \clk_reg[27]_i_6_n_0\,
      O => clk_reg_0(26)
    );
\clk_reg[27]_i_10\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"7FFF"
    )
        port map (
      I0 => clk_reg(2),
      I1 => clk_reg(3),
      I2 => clk_reg(15),
      I3 => clk_reg(14),
      O => \clk_reg[27]_i_10_n_0\
    );
\clk_reg[27]_i_1__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00010000FFFFFFFF"
    )
        port map (
      I0 => \^q\(3),
      I1 => \^q\(0),
      I2 => \^q\(1),
      I3 => \^q\(2),
      I4 => E(0),
      I5 => \FSM_sequential_etat_courant_reg[1]\,
      O => \clk_reg[27]_i_1__0_n_0\
    );
\clk_reg[27]_i_3\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"AA8A"
    )
        port map (
      I0 => data0(27),
      I1 => \clk_reg[27]_i_4_n_0\,
      I2 => \clk_reg[27]_i_5__0_n_0\,
      I3 => \clk_reg[27]_i_6_n_0\,
      O => clk_reg_0(27)
    );
\clk_reg[27]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFBFFFFFFF"
    )
        port map (
      I0 => \clk_reg[27]_i_7__0_n_0\,
      I1 => clk_reg(17),
      I2 => clk_reg(16),
      I3 => clk_reg(19),
      I4 => clk_reg(1),
      I5 => \clk_reg[27]_i_8__0_n_0\,
      O => \clk_reg[27]_i_4_n_0\
    );
\clk_reg[27]_i_5__0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00000001"
    )
        port map (
      I0 => clk_reg(13),
      I1 => clk_reg(12),
      I2 => clk_reg(20),
      I3 => clk_reg(18),
      I4 => \clk_reg[27]_i_9__0_n_0\,
      O => \clk_reg[27]_i_5__0_n_0\
    );
\clk_reg[27]_i_6\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFF7FFF"
    )
        port map (
      I0 => clk_reg(5),
      I1 => clk_reg(4),
      I2 => clk_reg(8),
      I3 => clk_reg(6),
      I4 => \clk_reg[27]_i_10_n_0\,
      O => \clk_reg[27]_i_6_n_0\
    );
\clk_reg[27]_i_7__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"7FFF"
    )
        port map (
      I0 => clk_reg(21),
      I1 => clk_reg(0),
      I2 => clk_reg(23),
      I3 => clk_reg(22),
      O => \clk_reg[27]_i_7__0_n_0\
    );
\clk_reg[27]_i_8__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"7FFF"
    )
        port map (
      I0 => clk_reg(25),
      I1 => clk_reg(24),
      I2 => clk_reg(7),
      I3 => clk_reg(27),
      O => \clk_reg[27]_i_8__0_n_0\
    );
\clk_reg[27]_i_9__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFFE"
    )
        port map (
      I0 => clk_reg(10),
      I1 => clk_reg(11),
      I2 => clk_reg(26),
      I3 => clk_reg(9),
      O => \clk_reg[27]_i_9__0_n_0\
    );
\clk_reg[2]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"AA8A"
    )
        port map (
      I0 => data0(2),
      I1 => \clk_reg[27]_i_4_n_0\,
      I2 => \clk_reg[27]_i_5__0_n_0\,
      I3 => \clk_reg[27]_i_6_n_0\,
      O => clk_reg_0(2)
    );
\clk_reg[3]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"AA8A"
    )
        port map (
      I0 => data0(3),
      I1 => \clk_reg[27]_i_4_n_0\,
      I2 => \clk_reg[27]_i_5__0_n_0\,
      I3 => \clk_reg[27]_i_6_n_0\,
      O => clk_reg_0(3)
    );
\clk_reg[4]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"AA8A"
    )
        port map (
      I0 => data0(4),
      I1 => \clk_reg[27]_i_4_n_0\,
      I2 => \clk_reg[27]_i_5__0_n_0\,
      I3 => \clk_reg[27]_i_6_n_0\,
      O => clk_reg_0(4)
    );
\clk_reg[5]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"AA8A"
    )
        port map (
      I0 => data0(5),
      I1 => \clk_reg[27]_i_4_n_0\,
      I2 => \clk_reg[27]_i_5__0_n_0\,
      I3 => \clk_reg[27]_i_6_n_0\,
      O => clk_reg_0(5)
    );
\clk_reg[6]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"AA8A"
    )
        port map (
      I0 => data0(6),
      I1 => \clk_reg[27]_i_4_n_0\,
      I2 => \clk_reg[27]_i_5__0_n_0\,
      I3 => \clk_reg[27]_i_6_n_0\,
      O => clk_reg_0(6)
    );
\clk_reg[7]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"AA8A"
    )
        port map (
      I0 => data0(7),
      I1 => \clk_reg[27]_i_4_n_0\,
      I2 => \clk_reg[27]_i_5__0_n_0\,
      I3 => \clk_reg[27]_i_6_n_0\,
      O => clk_reg_0(7)
    );
\clk_reg[8]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"AA8A"
    )
        port map (
      I0 => data0(8),
      I1 => \clk_reg[27]_i_4_n_0\,
      I2 => \clk_reg[27]_i_5__0_n_0\,
      I3 => \clk_reg[27]_i_6_n_0\,
      O => clk_reg_0(8)
    );
\clk_reg[9]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"AA8A"
    )
        port map (
      I0 => data0(9),
      I1 => \clk_reg[27]_i_4_n_0\,
      I2 => \clk_reg[27]_i_5__0_n_0\,
      I3 => \clk_reg[27]_i_6_n_0\,
      O => clk_reg_0(9)
    );
\clk_reg_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => E(0),
      D => clk_reg_0(0),
      Q => clk_reg(0),
      R => \clk_reg[27]_i_1__0_n_0\
    );
\clk_reg_reg[10]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => E(0),
      D => clk_reg_0(10),
      Q => clk_reg(10),
      R => \clk_reg[27]_i_1__0_n_0\
    );
\clk_reg_reg[11]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => E(0),
      D => clk_reg_0(11),
      Q => clk_reg(11),
      R => \clk_reg[27]_i_1__0_n_0\
    );
\clk_reg_reg[12]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => E(0),
      D => clk_reg_0(12),
      Q => clk_reg(12),
      R => \clk_reg[27]_i_1__0_n_0\
    );
\clk_reg_reg[13]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => E(0),
      D => clk_reg_0(13),
      Q => clk_reg(13),
      R => \clk_reg[27]_i_1__0_n_0\
    );
\clk_reg_reg[14]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => E(0),
      D => clk_reg_0(14),
      Q => clk_reg(14),
      R => \clk_reg[27]_i_1__0_n_0\
    );
\clk_reg_reg[15]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => E(0),
      D => clk_reg_0(15),
      Q => clk_reg(15),
      R => \clk_reg[27]_i_1__0_n_0\
    );
\clk_reg_reg[16]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => E(0),
      D => clk_reg_0(16),
      Q => clk_reg(16),
      R => \clk_reg[27]_i_1__0_n_0\
    );
\clk_reg_reg[17]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => E(0),
      D => clk_reg_0(17),
      Q => clk_reg(17),
      R => \clk_reg[27]_i_1__0_n_0\
    );
\clk_reg_reg[18]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => E(0),
      D => clk_reg_0(18),
      Q => clk_reg(18),
      R => \clk_reg[27]_i_1__0_n_0\
    );
\clk_reg_reg[19]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => E(0),
      D => clk_reg_0(19),
      Q => clk_reg(19),
      R => \clk_reg[27]_i_1__0_n_0\
    );
\clk_reg_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => E(0),
      D => clk_reg_0(1),
      Q => clk_reg(1),
      R => \clk_reg[27]_i_1__0_n_0\
    );
\clk_reg_reg[20]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => E(0),
      D => clk_reg_0(20),
      Q => clk_reg(20),
      R => \clk_reg[27]_i_1__0_n_0\
    );
\clk_reg_reg[21]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => E(0),
      D => clk_reg_0(21),
      Q => clk_reg(21),
      R => \clk_reg[27]_i_1__0_n_0\
    );
\clk_reg_reg[22]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => E(0),
      D => clk_reg_0(22),
      Q => clk_reg(22),
      R => \clk_reg[27]_i_1__0_n_0\
    );
\clk_reg_reg[23]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => E(0),
      D => clk_reg_0(23),
      Q => clk_reg(23),
      R => \clk_reg[27]_i_1__0_n_0\
    );
\clk_reg_reg[24]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => E(0),
      D => clk_reg_0(24),
      Q => clk_reg(24),
      R => \clk_reg[27]_i_1__0_n_0\
    );
\clk_reg_reg[25]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => E(0),
      D => clk_reg_0(25),
      Q => clk_reg(25),
      R => \clk_reg[27]_i_1__0_n_0\
    );
\clk_reg_reg[26]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => E(0),
      D => clk_reg_0(26),
      Q => clk_reg(26),
      R => \clk_reg[27]_i_1__0_n_0\
    );
\clk_reg_reg[27]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => E(0),
      D => clk_reg_0(27),
      Q => clk_reg(27),
      R => \clk_reg[27]_i_1__0_n_0\
    );
\clk_reg_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => E(0),
      D => clk_reg_0(2),
      Q => clk_reg(2),
      R => \clk_reg[27]_i_1__0_n_0\
    );
\clk_reg_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => E(0),
      D => clk_reg_0(3),
      Q => clk_reg(3),
      R => \clk_reg[27]_i_1__0_n_0\
    );
\clk_reg_reg[4]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => E(0),
      D => clk_reg_0(4),
      Q => clk_reg(4),
      R => \clk_reg[27]_i_1__0_n_0\
    );
\clk_reg_reg[5]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => E(0),
      D => clk_reg_0(5),
      Q => clk_reg(5),
      R => \clk_reg[27]_i_1__0_n_0\
    );
\clk_reg_reg[6]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => E(0),
      D => clk_reg_0(6),
      Q => clk_reg(6),
      R => \clk_reg[27]_i_1__0_n_0\
    );
\clk_reg_reg[7]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => E(0),
      D => clk_reg_0(7),
      Q => clk_reg(7),
      R => \clk_reg[27]_i_1__0_n_0\
    );
\clk_reg_reg[8]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => E(0),
      D => clk_reg_0(8),
      Q => clk_reg(8),
      R => \clk_reg[27]_i_1__0_n_0\
    );
\clk_reg_reg[9]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => E(0),
      D => clk_reg_0(9),
      Q => clk_reg(9),
      R => \clk_reg[27]_i_1__0_n_0\
    );
\sec_reg[2]_i_1__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"E100E1FFE1FFE100"
    )
        port map (
      I0 => \^q\(0),
      I1 => \^q\(1),
      I2 => \^q\(2),
      I3 => \FSM_sequential_etat_courant_reg[1]\,
      I4 => \difficulte_mem_reg[0]\,
      I5 => \difficulte_mem_reg[1]\,
      O => p_0_in(2)
    );
\sec_reg[3]_i_10\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFFE"
    )
        port map (
      I0 => clk_reg(9),
      I1 => clk_reg(10),
      I2 => clk_reg(26),
      I3 => clk_reg(18),
      O => \sec_reg[3]_i_10_n_0\
    );
\sec_reg[3]_i_11\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"7FFF"
    )
        port map (
      I0 => clk_reg(4),
      I1 => clk_reg(5),
      I2 => clk_reg(7),
      I3 => clk_reg(6),
      O => \sec_reg[3]_i_11_n_0\
    );
\sec_reg[3]_i_12\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"7FFF"
    )
        port map (
      I0 => clk_reg(22),
      I1 => clk_reg(21),
      I2 => clk_reg(15),
      I3 => clk_reg(14),
      O => \sec_reg[3]_i_12_n_0\
    );
\sec_reg[3]_i_1__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"555555555555555D"
    )
        port map (
      I0 => \FSM_sequential_etat_courant_reg[1]\,
      I1 => E(0),
      I2 => \^sec_reg_reg[0]_0\,
      I3 => \sec_reg[3]_i_5_n_0\,
      I4 => \sec_reg[3]_i_6_n_0\,
      I5 => \sec_reg[3]_i_7_n_0\,
      O => \sec_reg[3]_i_1__0_n_0\
    );
\sec_reg[3]_i_4\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0001"
    )
        port map (
      I0 => \^q\(3),
      I1 => \^q\(0),
      I2 => \^q\(1),
      I3 => \^q\(2),
      O => \^sec_reg_reg[0]_0\
    );
\sec_reg[3]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFBFFFFFFF"
    )
        port map (
      I0 => \sec_reg[3]_i_9_n_0\,
      I1 => clk_reg(17),
      I2 => clk_reg(16),
      I3 => clk_reg(27),
      I4 => clk_reg(19),
      I5 => \sec_reg[3]_i_10_n_0\,
      O => \sec_reg[3]_i_5_n_0\
    );
\sec_reg[3]_i_6\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFF7FFF"
    )
        port map (
      I0 => clk_reg(3),
      I1 => clk_reg(2),
      I2 => clk_reg(0),
      I3 => clk_reg(1),
      I4 => \sec_reg[3]_i_11_n_0\,
      O => \sec_reg[3]_i_6_n_0\
    );
\sec_reg[3]_i_7\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFF7FFF"
    )
        port map (
      I0 => clk_reg(23),
      I1 => clk_reg(24),
      I2 => clk_reg(8),
      I3 => clk_reg(25),
      I4 => \sec_reg[3]_i_12_n_0\,
      O => \sec_reg[3]_i_7_n_0\
    );
\sec_reg[3]_i_8\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"FE"
    )
        port map (
      I0 => \^q\(2),
      I1 => \^q\(1),
      I2 => \^q\(0),
      O => \sec_reg_reg[3]_0\
    );
\sec_reg[3]_i_9\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFFE"
    )
        port map (
      I0 => clk_reg(13),
      I1 => clk_reg(20),
      I2 => clk_reg(11),
      I3 => clk_reg(12),
      O => \sec_reg[3]_i_9_n_0\
    );
\sec_reg_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => \sec_reg[3]_i_1__0_n_0\,
      D => D(0),
      Q => \^q\(0),
      R => '0'
    );
\sec_reg_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => \sec_reg[3]_i_1__0_n_0\,
      D => D(1),
      Q => \^q\(1),
      R => '0'
    );
\sec_reg_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => \sec_reg[3]_i_1__0_n_0\,
      D => p_0_in(2),
      Q => \^q\(2),
      R => '0'
    );
\sec_reg_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => \sec_reg[3]_i_1__0_n_0\,
      D => D(2),
      Q => \^q\(3),
      R => '0'
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_sec_counter_0 is
  port (
    Q : out STD_LOGIC_VECTOR ( 3 downto 0 );
    \FSM_sequential_etat_courant_reg[0]\ : out STD_LOGIC;
    \sec_reg_reg[3]_0\ : out STD_LOGIC;
    \FSM_sequential_etat_courant_reg[0]_0\ : out STD_LOGIC;
    \clk_reg_reg[1]_0\ : out STD_LOGIC;
    flash_on : out STD_LOGIC;
    E : in STD_LOGIC_VECTOR ( 0 to 0 );
    \FSM_sequential_etat_courant_reg[0]_1\ : in STD_LOGIC;
    D : in STD_LOGIC_VECTOR ( 0 to 0 );
    \FSM_sequential_etat_courant_reg[0]_2\ : in STD_LOGIC;
    \out\ : in STD_LOGIC_VECTOR ( 2 downto 0 );
    \FSM_sequential_etat_courant_reg[2]\ : in STD_LOGIC;
    clk : in STD_LOGIC;
    \FSM_sequential_etat_courant_reg[0]_3\ : in STD_LOGIC_VECTOR ( 0 to 0 )
  );
  attribute ORIG_REF_NAME : string;
  attribute ORIG_REF_NAME of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_sec_counter_0 : entity is "sec_counter";
end decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_sec_counter_0;

architecture STRUCTURE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_sec_counter_0 is
  signal \FSM_sequential_etat_courant[4]_i_12_n_0\ : STD_LOGIC;
  signal \FSM_sequential_etat_courant[4]_i_13_n_0\ : STD_LOGIC;
  signal \FSM_sequential_etat_courant[4]_i_14_n_0\ : STD_LOGIC;
  signal \FSM_sequential_etat_courant[4]_i_7_n_0\ : STD_LOGIC;
  signal \^q\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal clk_reg : STD_LOGIC_VECTOR ( 27 downto 0 );
  signal \clk_reg0_carry__0_n_0\ : STD_LOGIC;
  signal \clk_reg0_carry__0_n_1\ : STD_LOGIC;
  signal \clk_reg0_carry__0_n_2\ : STD_LOGIC;
  signal \clk_reg0_carry__0_n_3\ : STD_LOGIC;
  signal \clk_reg0_carry__0_n_4\ : STD_LOGIC;
  signal \clk_reg0_carry__0_n_5\ : STD_LOGIC;
  signal \clk_reg0_carry__0_n_6\ : STD_LOGIC;
  signal \clk_reg0_carry__0_n_7\ : STD_LOGIC;
  signal \clk_reg0_carry__1_n_0\ : STD_LOGIC;
  signal \clk_reg0_carry__1_n_1\ : STD_LOGIC;
  signal \clk_reg0_carry__1_n_2\ : STD_LOGIC;
  signal \clk_reg0_carry__1_n_3\ : STD_LOGIC;
  signal \clk_reg0_carry__1_n_4\ : STD_LOGIC;
  signal \clk_reg0_carry__1_n_5\ : STD_LOGIC;
  signal \clk_reg0_carry__1_n_6\ : STD_LOGIC;
  signal \clk_reg0_carry__1_n_7\ : STD_LOGIC;
  signal \clk_reg0_carry__2_n_0\ : STD_LOGIC;
  signal \clk_reg0_carry__2_n_1\ : STD_LOGIC;
  signal \clk_reg0_carry__2_n_2\ : STD_LOGIC;
  signal \clk_reg0_carry__2_n_3\ : STD_LOGIC;
  signal \clk_reg0_carry__2_n_4\ : STD_LOGIC;
  signal \clk_reg0_carry__2_n_5\ : STD_LOGIC;
  signal \clk_reg0_carry__2_n_6\ : STD_LOGIC;
  signal \clk_reg0_carry__2_n_7\ : STD_LOGIC;
  signal \clk_reg0_carry__3_n_0\ : STD_LOGIC;
  signal \clk_reg0_carry__3_n_1\ : STD_LOGIC;
  signal \clk_reg0_carry__3_n_2\ : STD_LOGIC;
  signal \clk_reg0_carry__3_n_3\ : STD_LOGIC;
  signal \clk_reg0_carry__3_n_4\ : STD_LOGIC;
  signal \clk_reg0_carry__3_n_5\ : STD_LOGIC;
  signal \clk_reg0_carry__3_n_6\ : STD_LOGIC;
  signal \clk_reg0_carry__3_n_7\ : STD_LOGIC;
  signal \clk_reg0_carry__4_n_0\ : STD_LOGIC;
  signal \clk_reg0_carry__4_n_1\ : STD_LOGIC;
  signal \clk_reg0_carry__4_n_2\ : STD_LOGIC;
  signal \clk_reg0_carry__4_n_3\ : STD_LOGIC;
  signal \clk_reg0_carry__4_n_4\ : STD_LOGIC;
  signal \clk_reg0_carry__4_n_5\ : STD_LOGIC;
  signal \clk_reg0_carry__4_n_6\ : STD_LOGIC;
  signal \clk_reg0_carry__4_n_7\ : STD_LOGIC;
  signal \clk_reg0_carry__5_n_2\ : STD_LOGIC;
  signal \clk_reg0_carry__5_n_3\ : STD_LOGIC;
  signal \clk_reg0_carry__5_n_5\ : STD_LOGIC;
  signal \clk_reg0_carry__5_n_6\ : STD_LOGIC;
  signal \clk_reg0_carry__5_n_7\ : STD_LOGIC;
  signal clk_reg0_carry_n_0 : STD_LOGIC;
  signal clk_reg0_carry_n_1 : STD_LOGIC;
  signal clk_reg0_carry_n_2 : STD_LOGIC;
  signal clk_reg0_carry_n_3 : STD_LOGIC;
  signal clk_reg0_carry_n_4 : STD_LOGIC;
  signal clk_reg0_carry_n_5 : STD_LOGIC;
  signal clk_reg0_carry_n_6 : STD_LOGIC;
  signal clk_reg0_carry_n_7 : STD_LOGIC;
  signal \clk_reg[27]_i_10__0_n_0\ : STD_LOGIC;
  signal \clk_reg[27]_i_11_n_0\ : STD_LOGIC;
  signal \clk_reg[27]_i_1_n_0\ : STD_LOGIC;
  signal \clk_reg[27]_i_6__0_n_0\ : STD_LOGIC;
  signal \clk_reg[27]_i_7_n_0\ : STD_LOGIC;
  signal \clk_reg[27]_i_8_n_0\ : STD_LOGIC;
  signal \clk_reg[27]_i_9_n_0\ : STD_LOGIC;
  signal \^clk_reg_reg[1]_0\ : STD_LOGIC;
  signal \clk_reg_reg_n_0_[0]\ : STD_LOGIC;
  signal \clk_reg_reg_n_0_[10]\ : STD_LOGIC;
  signal \clk_reg_reg_n_0_[11]\ : STD_LOGIC;
  signal \clk_reg_reg_n_0_[12]\ : STD_LOGIC;
  signal \clk_reg_reg_n_0_[13]\ : STD_LOGIC;
  signal \clk_reg_reg_n_0_[14]\ : STD_LOGIC;
  signal \clk_reg_reg_n_0_[15]\ : STD_LOGIC;
  signal \clk_reg_reg_n_0_[16]\ : STD_LOGIC;
  signal \clk_reg_reg_n_0_[17]\ : STD_LOGIC;
  signal \clk_reg_reg_n_0_[18]\ : STD_LOGIC;
  signal \clk_reg_reg_n_0_[19]\ : STD_LOGIC;
  signal \clk_reg_reg_n_0_[1]\ : STD_LOGIC;
  signal \clk_reg_reg_n_0_[20]\ : STD_LOGIC;
  signal \clk_reg_reg_n_0_[21]\ : STD_LOGIC;
  signal \clk_reg_reg_n_0_[22]\ : STD_LOGIC;
  signal \clk_reg_reg_n_0_[23]\ : STD_LOGIC;
  signal \clk_reg_reg_n_0_[24]\ : STD_LOGIC;
  signal \clk_reg_reg_n_0_[25]\ : STD_LOGIC;
  signal \clk_reg_reg_n_0_[26]\ : STD_LOGIC;
  signal \clk_reg_reg_n_0_[27]\ : STD_LOGIC;
  signal \clk_reg_reg_n_0_[2]\ : STD_LOGIC;
  signal \clk_reg_reg_n_0_[3]\ : STD_LOGIC;
  signal \clk_reg_reg_n_0_[4]\ : STD_LOGIC;
  signal \clk_reg_reg_n_0_[5]\ : STD_LOGIC;
  signal \clk_reg_reg_n_0_[6]\ : STD_LOGIC;
  signal \clk_reg_reg_n_0_[7]\ : STD_LOGIC;
  signal \clk_reg_reg_n_0_[8]\ : STD_LOGIC;
  signal \clk_reg_reg_n_0_[9]\ : STD_LOGIC;
  signal flash_on_INST_0_i_2_n_0 : STD_LOGIC;
  signal flash_on_INST_0_i_3_n_0 : STD_LOGIC;
  signal flash_on_INST_0_i_4_n_0 : STD_LOGIC;
  signal flash_on_INST_0_i_5_n_0 : STD_LOGIC;
  signal flash_on_INST_0_i_6_n_0 : STD_LOGIC;
  signal flash_on_INST_0_i_7_n_0 : STD_LOGIC;
  signal \p_0_in__0\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \^sec_reg_reg[3]_0\ : STD_LOGIC;
  signal \NLW_clk_reg0_carry__5_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_clk_reg0_carry__5_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  attribute SOFT_HLUTNM : string;
  attribute SOFT_HLUTNM of \FSM_sequential_etat_courant[4]_i_12\ : label is "soft_lutpair24";
  attribute SOFT_HLUTNM of \FSM_sequential_etat_courant[4]_i_14\ : label is "soft_lutpair22";
  attribute SOFT_HLUTNM of \clk_reg[0]_i_1\ : label is "soft_lutpair25";
  attribute SOFT_HLUTNM of \clk_reg[10]_i_1__0\ : label is "soft_lutpair35";
  attribute SOFT_HLUTNM of \clk_reg[11]_i_1__0\ : label is "soft_lutpair36";
  attribute SOFT_HLUTNM of \clk_reg[12]_i_1__0\ : label is "soft_lutpair36";
  attribute SOFT_HLUTNM of \clk_reg[13]_i_1__0\ : label is "soft_lutpair33";
  attribute SOFT_HLUTNM of \clk_reg[14]_i_1__0\ : label is "soft_lutpair31";
  attribute SOFT_HLUTNM of \clk_reg[15]_i_1__0\ : label is "soft_lutpair29";
  attribute SOFT_HLUTNM of \clk_reg[16]_i_1__0\ : label is "soft_lutpair30";
  attribute SOFT_HLUTNM of \clk_reg[17]_i_1__0\ : label is "soft_lutpair27";
  attribute SOFT_HLUTNM of \clk_reg[18]_i_1__0\ : label is "soft_lutpair28";
  attribute SOFT_HLUTNM of \clk_reg[19]_i_1__0\ : label is "soft_lutpair26";
  attribute SOFT_HLUTNM of \clk_reg[1]_i_1__0\ : label is "soft_lutpair26";
  attribute SOFT_HLUTNM of \clk_reg[20]_i_1__0\ : label is "soft_lutpair37";
  attribute SOFT_HLUTNM of \clk_reg[21]_i_1__0\ : label is "soft_lutpair38";
  attribute SOFT_HLUTNM of \clk_reg[22]_i_1__0\ : label is "soft_lutpair35";
  attribute SOFT_HLUTNM of \clk_reg[23]_i_1__0\ : label is "soft_lutpair32";
  attribute SOFT_HLUTNM of \clk_reg[24]_i_1__0\ : label is "soft_lutpair37";
  attribute SOFT_HLUTNM of \clk_reg[25]_i_1__0\ : label is "soft_lutpair34";
  attribute SOFT_HLUTNM of \clk_reg[26]_i_1__0\ : label is "soft_lutpair38";
  attribute SOFT_HLUTNM of \clk_reg[27]_i_10__0\ : label is "soft_lutpair25";
  attribute SOFT_HLUTNM of \clk_reg[2]_i_1__0\ : label is "soft_lutpair27";
  attribute SOFT_HLUTNM of \clk_reg[3]_i_1__0\ : label is "soft_lutpair28";
  attribute SOFT_HLUTNM of \clk_reg[4]_i_1__0\ : label is "soft_lutpair29";
  attribute SOFT_HLUTNM of \clk_reg[5]_i_1__0\ : label is "soft_lutpair30";
  attribute SOFT_HLUTNM of \clk_reg[6]_i_1__0\ : label is "soft_lutpair31";
  attribute SOFT_HLUTNM of \clk_reg[7]_i_1__0\ : label is "soft_lutpair32";
  attribute SOFT_HLUTNM of \clk_reg[8]_i_1__0\ : label is "soft_lutpair33";
  attribute SOFT_HLUTNM of \clk_reg[9]_i_1__0\ : label is "soft_lutpair34";
  attribute SOFT_HLUTNM of flash_on_INST_0_i_4 : label is "soft_lutpair24";
  attribute SOFT_HLUTNM of flash_on_INST_0_i_5 : label is "soft_lutpair22";
  attribute SOFT_HLUTNM of \sec_reg[2]_i_1\ : label is "soft_lutpair23";
  attribute SOFT_HLUTNM of \sec_reg[3]_i_2\ : label is "soft_lutpair23";
begin
  Q(3 downto 0) <= \^q\(3 downto 0);
  \clk_reg_reg[1]_0\ <= \^clk_reg_reg[1]_0\;
  \sec_reg_reg[3]_0\ <= \^sec_reg_reg[3]_0\;
\FSM_sequential_etat_courant[4]_i_12\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"7FFFFFFF"
    )
        port map (
      I0 => \clk_reg_reg_n_0_[24]\,
      I1 => \clk_reg_reg_n_0_[23]\,
      I2 => \clk_reg_reg_n_0_[20]\,
      I3 => \clk_reg_reg_n_0_[21]\,
      I4 => \clk_reg_reg_n_0_[22]\,
      O => \FSM_sequential_etat_courant[4]_i_12_n_0\
    );
\FSM_sequential_etat_courant[4]_i_13\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"EA"
    )
        port map (
      I0 => \clk_reg_reg_n_0_[19]\,
      I1 => \clk_reg_reg_n_0_[18]\,
      I2 => \clk_reg_reg_n_0_[17]\,
      O => \FSM_sequential_etat_courant[4]_i_13_n_0\
    );
\FSM_sequential_etat_courant[4]_i_14\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFFFFFE"
    )
        port map (
      I0 => \clk_reg_reg_n_0_[11]\,
      I1 => \clk_reg_reg_n_0_[12]\,
      I2 => \clk_reg_reg_n_0_[10]\,
      I3 => \clk_reg_reg_n_0_[8]\,
      I4 => \clk_reg_reg_n_0_[9]\,
      O => \FSM_sequential_etat_courant[4]_i_14_n_0\
    );
\FSM_sequential_etat_courant[4]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FF000DFFFFFF0DFF"
    )
        port map (
      I0 => \clk_reg_reg_n_0_[26]\,
      I1 => \FSM_sequential_etat_courant[4]_i_7_n_0\,
      I2 => \clk_reg_reg_n_0_[27]\,
      I3 => \out\(1),
      I4 => \out\(0),
      I5 => \^sec_reg_reg[3]_0\,
      O => \FSM_sequential_etat_courant_reg[0]\
    );
\FSM_sequential_etat_courant[4]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FF00F2000000F200"
    )
        port map (
      I0 => \clk_reg_reg_n_0_[26]\,
      I1 => \FSM_sequential_etat_courant[4]_i_7_n_0\,
      I2 => \clk_reg_reg_n_0_[27]\,
      I3 => \out\(2),
      I4 => \FSM_sequential_etat_courant_reg[2]\,
      I5 => \^sec_reg_reg[3]_0\,
      O => \FSM_sequential_etat_courant_reg[0]_0\
    );
\FSM_sequential_etat_courant[4]_i_7\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"4545450045454545"
    )
        port map (
      I0 => \clk_reg_reg_n_0_[25]\,
      I1 => \FSM_sequential_etat_courant[4]_i_12_n_0\,
      I2 => \FSM_sequential_etat_courant[4]_i_13_n_0\,
      I3 => flash_on_INST_0_i_7_n_0,
      I4 => flash_on_INST_0_i_6_n_0,
      I5 => \FSM_sequential_etat_courant[4]_i_14_n_0\,
      O => \FSM_sequential_etat_courant[4]_i_7_n_0\
    );
clk_reg0_carry: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => clk_reg0_carry_n_0,
      CO(2) => clk_reg0_carry_n_1,
      CO(1) => clk_reg0_carry_n_2,
      CO(0) => clk_reg0_carry_n_3,
      CYINIT => \clk_reg_reg_n_0_[0]\,
      DI(3 downto 0) => B"0000",
      O(3) => clk_reg0_carry_n_4,
      O(2) => clk_reg0_carry_n_5,
      O(1) => clk_reg0_carry_n_6,
      O(0) => clk_reg0_carry_n_7,
      S(3) => \clk_reg_reg_n_0_[4]\,
      S(2) => \clk_reg_reg_n_0_[3]\,
      S(1) => \clk_reg_reg_n_0_[2]\,
      S(0) => \clk_reg_reg_n_0_[1]\
    );
\clk_reg0_carry__0\: unisim.vcomponents.CARRY4
     port map (
      CI => clk_reg0_carry_n_0,
      CO(3) => \clk_reg0_carry__0_n_0\,
      CO(2) => \clk_reg0_carry__0_n_1\,
      CO(1) => \clk_reg0_carry__0_n_2\,
      CO(0) => \clk_reg0_carry__0_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \clk_reg0_carry__0_n_4\,
      O(2) => \clk_reg0_carry__0_n_5\,
      O(1) => \clk_reg0_carry__0_n_6\,
      O(0) => \clk_reg0_carry__0_n_7\,
      S(3) => \clk_reg_reg_n_0_[8]\,
      S(2) => \clk_reg_reg_n_0_[7]\,
      S(1) => \clk_reg_reg_n_0_[6]\,
      S(0) => \clk_reg_reg_n_0_[5]\
    );
\clk_reg0_carry__1\: unisim.vcomponents.CARRY4
     port map (
      CI => \clk_reg0_carry__0_n_0\,
      CO(3) => \clk_reg0_carry__1_n_0\,
      CO(2) => \clk_reg0_carry__1_n_1\,
      CO(1) => \clk_reg0_carry__1_n_2\,
      CO(0) => \clk_reg0_carry__1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \clk_reg0_carry__1_n_4\,
      O(2) => \clk_reg0_carry__1_n_5\,
      O(1) => \clk_reg0_carry__1_n_6\,
      O(0) => \clk_reg0_carry__1_n_7\,
      S(3) => \clk_reg_reg_n_0_[12]\,
      S(2) => \clk_reg_reg_n_0_[11]\,
      S(1) => \clk_reg_reg_n_0_[10]\,
      S(0) => \clk_reg_reg_n_0_[9]\
    );
\clk_reg0_carry__2\: unisim.vcomponents.CARRY4
     port map (
      CI => \clk_reg0_carry__1_n_0\,
      CO(3) => \clk_reg0_carry__2_n_0\,
      CO(2) => \clk_reg0_carry__2_n_1\,
      CO(1) => \clk_reg0_carry__2_n_2\,
      CO(0) => \clk_reg0_carry__2_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \clk_reg0_carry__2_n_4\,
      O(2) => \clk_reg0_carry__2_n_5\,
      O(1) => \clk_reg0_carry__2_n_6\,
      O(0) => \clk_reg0_carry__2_n_7\,
      S(3) => \clk_reg_reg_n_0_[16]\,
      S(2) => \clk_reg_reg_n_0_[15]\,
      S(1) => \clk_reg_reg_n_0_[14]\,
      S(0) => \clk_reg_reg_n_0_[13]\
    );
\clk_reg0_carry__3\: unisim.vcomponents.CARRY4
     port map (
      CI => \clk_reg0_carry__2_n_0\,
      CO(3) => \clk_reg0_carry__3_n_0\,
      CO(2) => \clk_reg0_carry__3_n_1\,
      CO(1) => \clk_reg0_carry__3_n_2\,
      CO(0) => \clk_reg0_carry__3_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \clk_reg0_carry__3_n_4\,
      O(2) => \clk_reg0_carry__3_n_5\,
      O(1) => \clk_reg0_carry__3_n_6\,
      O(0) => \clk_reg0_carry__3_n_7\,
      S(3) => \clk_reg_reg_n_0_[20]\,
      S(2) => \clk_reg_reg_n_0_[19]\,
      S(1) => \clk_reg_reg_n_0_[18]\,
      S(0) => \clk_reg_reg_n_0_[17]\
    );
\clk_reg0_carry__4\: unisim.vcomponents.CARRY4
     port map (
      CI => \clk_reg0_carry__3_n_0\,
      CO(3) => \clk_reg0_carry__4_n_0\,
      CO(2) => \clk_reg0_carry__4_n_1\,
      CO(1) => \clk_reg0_carry__4_n_2\,
      CO(0) => \clk_reg0_carry__4_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \clk_reg0_carry__4_n_4\,
      O(2) => \clk_reg0_carry__4_n_5\,
      O(1) => \clk_reg0_carry__4_n_6\,
      O(0) => \clk_reg0_carry__4_n_7\,
      S(3) => \clk_reg_reg_n_0_[24]\,
      S(2) => \clk_reg_reg_n_0_[23]\,
      S(1) => \clk_reg_reg_n_0_[22]\,
      S(0) => \clk_reg_reg_n_0_[21]\
    );
\clk_reg0_carry__5\: unisim.vcomponents.CARRY4
     port map (
      CI => \clk_reg0_carry__4_n_0\,
      CO(3 downto 2) => \NLW_clk_reg0_carry__5_CO_UNCONNECTED\(3 downto 2),
      CO(1) => \clk_reg0_carry__5_n_2\,
      CO(0) => \clk_reg0_carry__5_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \NLW_clk_reg0_carry__5_O_UNCONNECTED\(3),
      O(2) => \clk_reg0_carry__5_n_5\,
      O(1) => \clk_reg0_carry__5_n_6\,
      O(0) => \clk_reg0_carry__5_n_7\,
      S(3) => '0',
      S(2) => \clk_reg_reg_n_0_[27]\,
      S(1) => \clk_reg_reg_n_0_[26]\,
      S(0) => \clk_reg_reg_n_0_[25]\
    );
\clk_reg[0]_i_1\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \clk_reg_reg_n_0_[0]\,
      O => clk_reg(0)
    );
\clk_reg[10]_i_1__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \clk_reg0_carry__1_n_6\,
      I1 => \^clk_reg_reg[1]_0\,
      O => clk_reg(10)
    );
\clk_reg[11]_i_1__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \clk_reg0_carry__1_n_5\,
      I1 => \^clk_reg_reg[1]_0\,
      O => clk_reg(11)
    );
\clk_reg[12]_i_1__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \clk_reg0_carry__1_n_4\,
      I1 => \^clk_reg_reg[1]_0\,
      O => clk_reg(12)
    );
\clk_reg[13]_i_1__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \clk_reg0_carry__2_n_7\,
      I1 => \^clk_reg_reg[1]_0\,
      O => clk_reg(13)
    );
\clk_reg[14]_i_1__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \clk_reg0_carry__2_n_6\,
      I1 => \^clk_reg_reg[1]_0\,
      O => clk_reg(14)
    );
\clk_reg[15]_i_1__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \clk_reg0_carry__2_n_5\,
      I1 => \^clk_reg_reg[1]_0\,
      O => clk_reg(15)
    );
\clk_reg[16]_i_1__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \clk_reg0_carry__2_n_4\,
      I1 => \^clk_reg_reg[1]_0\,
      O => clk_reg(16)
    );
\clk_reg[17]_i_1__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \clk_reg0_carry__3_n_7\,
      I1 => \^clk_reg_reg[1]_0\,
      O => clk_reg(17)
    );
\clk_reg[18]_i_1__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \clk_reg0_carry__3_n_6\,
      I1 => \^clk_reg_reg[1]_0\,
      O => clk_reg(18)
    );
\clk_reg[19]_i_1__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \clk_reg0_carry__3_n_5\,
      I1 => \^clk_reg_reg[1]_0\,
      O => clk_reg(19)
    );
\clk_reg[1]_i_1__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => clk_reg0_carry_n_7,
      I1 => \^clk_reg_reg[1]_0\,
      O => clk_reg(1)
    );
\clk_reg[20]_i_1__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \clk_reg0_carry__3_n_4\,
      I1 => \^clk_reg_reg[1]_0\,
      O => clk_reg(20)
    );
\clk_reg[21]_i_1__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \clk_reg0_carry__4_n_7\,
      I1 => \^clk_reg_reg[1]_0\,
      O => clk_reg(21)
    );
\clk_reg[22]_i_1__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \clk_reg0_carry__4_n_6\,
      I1 => \^clk_reg_reg[1]_0\,
      O => clk_reg(22)
    );
\clk_reg[23]_i_1__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \clk_reg0_carry__4_n_5\,
      I1 => \^clk_reg_reg[1]_0\,
      O => clk_reg(23)
    );
\clk_reg[24]_i_1__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \clk_reg0_carry__4_n_4\,
      I1 => \^clk_reg_reg[1]_0\,
      O => clk_reg(24)
    );
\clk_reg[25]_i_1__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \clk_reg0_carry__5_n_7\,
      I1 => \^clk_reg_reg[1]_0\,
      O => clk_reg(25)
    );
\clk_reg[26]_i_1__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \clk_reg0_carry__5_n_6\,
      I1 => \^clk_reg_reg[1]_0\,
      O => clk_reg(26)
    );
\clk_reg[27]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00010000FFFFFFFF"
    )
        port map (
      I0 => \^q\(3),
      I1 => \^q\(0),
      I2 => \^q\(1),
      I3 => \^q\(2),
      I4 => E(0),
      I5 => \FSM_sequential_etat_courant_reg[0]_1\,
      O => \clk_reg[27]_i_1_n_0\
    );
\clk_reg[27]_i_10__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FF7F"
    )
        port map (
      I0 => \clk_reg_reg_n_0_[27]\,
      I1 => \clk_reg_reg_n_0_[0]\,
      I2 => \clk_reg_reg_n_0_[16]\,
      I3 => \clk_reg_reg_n_0_[10]\,
      O => \clk_reg[27]_i_10__0_n_0\
    );
\clk_reg[27]_i_11\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFDF"
    )
        port map (
      I0 => \clk_reg_reg_n_0_[5]\,
      I1 => \clk_reg_reg_n_0_[9]\,
      I2 => \clk_reg_reg_n_0_[17]\,
      I3 => \clk_reg_reg_n_0_[26]\,
      O => \clk_reg[27]_i_11_n_0\
    );
\clk_reg[27]_i_3__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \clk_reg0_carry__5_n_5\,
      I1 => \^clk_reg_reg[1]_0\,
      O => clk_reg(27)
    );
\clk_reg[27]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000000002"
    )
        port map (
      I0 => \clk_reg[27]_i_6__0_n_0\,
      I1 => \clk_reg[27]_i_7_n_0\,
      I2 => \clk_reg[27]_i_8_n_0\,
      I3 => \clk_reg[27]_i_9_n_0\,
      I4 => \clk_reg_reg_n_0_[12]\,
      I5 => \clk_reg_reg_n_0_[11]\,
      O => \^clk_reg_reg[1]_0\
    );
\clk_reg[27]_i_6__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000004000"
    )
        port map (
      I0 => \clk_reg[27]_i_10__0_n_0\,
      I1 => \clk_reg_reg_n_0_[6]\,
      I2 => \clk_reg_reg_n_0_[8]\,
      I3 => \clk_reg_reg_n_0_[2]\,
      I4 => \clk_reg_reg_n_0_[13]\,
      I5 => flash_on_INST_0_i_7_n_0,
      O => \clk_reg[27]_i_6__0_n_0\
    );
\clk_reg[27]_i_7\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFFBFFF"
    )
        port map (
      I0 => \clk_reg_reg_n_0_[18]\,
      I1 => \clk_reg_reg_n_0_[25]\,
      I2 => \clk_reg_reg_n_0_[4]\,
      I3 => \clk_reg_reg_n_0_[1]\,
      I4 => \clk_reg[27]_i_11_n_0\,
      O => \clk_reg[27]_i_7_n_0\
    );
\clk_reg[27]_i_8\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FF7F"
    )
        port map (
      I0 => \clk_reg_reg_n_0_[7]\,
      I1 => \clk_reg_reg_n_0_[3]\,
      I2 => \clk_reg_reg_n_0_[19]\,
      I3 => \clk_reg_reg_n_0_[20]\,
      O => \clk_reg[27]_i_8_n_0\
    );
\clk_reg[27]_i_9\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"7"
    )
        port map (
      I0 => \clk_reg_reg_n_0_[21]\,
      I1 => \clk_reg_reg_n_0_[22]\,
      O => \clk_reg[27]_i_9_n_0\
    );
\clk_reg[2]_i_1__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => clk_reg0_carry_n_6,
      I1 => \^clk_reg_reg[1]_0\,
      O => clk_reg(2)
    );
\clk_reg[3]_i_1__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => clk_reg0_carry_n_5,
      I1 => \^clk_reg_reg[1]_0\,
      O => clk_reg(3)
    );
\clk_reg[4]_i_1__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => clk_reg0_carry_n_4,
      I1 => \^clk_reg_reg[1]_0\,
      O => clk_reg(4)
    );
\clk_reg[5]_i_1__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \clk_reg0_carry__0_n_7\,
      I1 => \^clk_reg_reg[1]_0\,
      O => clk_reg(5)
    );
\clk_reg[6]_i_1__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \clk_reg0_carry__0_n_6\,
      I1 => \^clk_reg_reg[1]_0\,
      O => clk_reg(6)
    );
\clk_reg[7]_i_1__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \clk_reg0_carry__0_n_5\,
      I1 => \^clk_reg_reg[1]_0\,
      O => clk_reg(7)
    );
\clk_reg[8]_i_1__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \clk_reg0_carry__0_n_4\,
      I1 => \^clk_reg_reg[1]_0\,
      O => clk_reg(8)
    );
\clk_reg[9]_i_1__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \clk_reg0_carry__1_n_7\,
      I1 => \^clk_reg_reg[1]_0\,
      O => clk_reg(9)
    );
\clk_reg_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => E(0),
      D => clk_reg(0),
      Q => \clk_reg_reg_n_0_[0]\,
      R => \clk_reg[27]_i_1_n_0\
    );
\clk_reg_reg[10]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => E(0),
      D => clk_reg(10),
      Q => \clk_reg_reg_n_0_[10]\,
      R => \clk_reg[27]_i_1_n_0\
    );
\clk_reg_reg[11]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => E(0),
      D => clk_reg(11),
      Q => \clk_reg_reg_n_0_[11]\,
      R => \clk_reg[27]_i_1_n_0\
    );
\clk_reg_reg[12]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => E(0),
      D => clk_reg(12),
      Q => \clk_reg_reg_n_0_[12]\,
      R => \clk_reg[27]_i_1_n_0\
    );
\clk_reg_reg[13]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => E(0),
      D => clk_reg(13),
      Q => \clk_reg_reg_n_0_[13]\,
      R => \clk_reg[27]_i_1_n_0\
    );
\clk_reg_reg[14]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => E(0),
      D => clk_reg(14),
      Q => \clk_reg_reg_n_0_[14]\,
      R => \clk_reg[27]_i_1_n_0\
    );
\clk_reg_reg[15]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => E(0),
      D => clk_reg(15),
      Q => \clk_reg_reg_n_0_[15]\,
      R => \clk_reg[27]_i_1_n_0\
    );
\clk_reg_reg[16]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => E(0),
      D => clk_reg(16),
      Q => \clk_reg_reg_n_0_[16]\,
      R => \clk_reg[27]_i_1_n_0\
    );
\clk_reg_reg[17]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => E(0),
      D => clk_reg(17),
      Q => \clk_reg_reg_n_0_[17]\,
      R => \clk_reg[27]_i_1_n_0\
    );
\clk_reg_reg[18]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => E(0),
      D => clk_reg(18),
      Q => \clk_reg_reg_n_0_[18]\,
      R => \clk_reg[27]_i_1_n_0\
    );
\clk_reg_reg[19]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => E(0),
      D => clk_reg(19),
      Q => \clk_reg_reg_n_0_[19]\,
      R => \clk_reg[27]_i_1_n_0\
    );
\clk_reg_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => E(0),
      D => clk_reg(1),
      Q => \clk_reg_reg_n_0_[1]\,
      R => \clk_reg[27]_i_1_n_0\
    );
\clk_reg_reg[20]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => E(0),
      D => clk_reg(20),
      Q => \clk_reg_reg_n_0_[20]\,
      R => \clk_reg[27]_i_1_n_0\
    );
\clk_reg_reg[21]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => E(0),
      D => clk_reg(21),
      Q => \clk_reg_reg_n_0_[21]\,
      R => \clk_reg[27]_i_1_n_0\
    );
\clk_reg_reg[22]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => E(0),
      D => clk_reg(22),
      Q => \clk_reg_reg_n_0_[22]\,
      R => \clk_reg[27]_i_1_n_0\
    );
\clk_reg_reg[23]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => E(0),
      D => clk_reg(23),
      Q => \clk_reg_reg_n_0_[23]\,
      R => \clk_reg[27]_i_1_n_0\
    );
\clk_reg_reg[24]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => E(0),
      D => clk_reg(24),
      Q => \clk_reg_reg_n_0_[24]\,
      R => \clk_reg[27]_i_1_n_0\
    );
\clk_reg_reg[25]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => E(0),
      D => clk_reg(25),
      Q => \clk_reg_reg_n_0_[25]\,
      R => \clk_reg[27]_i_1_n_0\
    );
\clk_reg_reg[26]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => E(0),
      D => clk_reg(26),
      Q => \clk_reg_reg_n_0_[26]\,
      R => \clk_reg[27]_i_1_n_0\
    );
\clk_reg_reg[27]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => E(0),
      D => clk_reg(27),
      Q => \clk_reg_reg_n_0_[27]\,
      R => \clk_reg[27]_i_1_n_0\
    );
\clk_reg_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => E(0),
      D => clk_reg(2),
      Q => \clk_reg_reg_n_0_[2]\,
      R => \clk_reg[27]_i_1_n_0\
    );
\clk_reg_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => E(0),
      D => clk_reg(3),
      Q => \clk_reg_reg_n_0_[3]\,
      R => \clk_reg[27]_i_1_n_0\
    );
\clk_reg_reg[4]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => E(0),
      D => clk_reg(4),
      Q => \clk_reg_reg_n_0_[4]\,
      R => \clk_reg[27]_i_1_n_0\
    );
\clk_reg_reg[5]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => E(0),
      D => clk_reg(5),
      Q => \clk_reg_reg_n_0_[5]\,
      R => \clk_reg[27]_i_1_n_0\
    );
\clk_reg_reg[6]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => E(0),
      D => clk_reg(6),
      Q => \clk_reg_reg_n_0_[6]\,
      R => \clk_reg[27]_i_1_n_0\
    );
\clk_reg_reg[7]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => E(0),
      D => clk_reg(7),
      Q => \clk_reg_reg_n_0_[7]\,
      R => \clk_reg[27]_i_1_n_0\
    );
\clk_reg_reg[8]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => E(0),
      D => clk_reg(8),
      Q => \clk_reg_reg_n_0_[8]\,
      R => \clk_reg[27]_i_1_n_0\
    );
\clk_reg_reg[9]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => E(0),
      D => clk_reg(9),
      Q => \clk_reg_reg_n_0_[9]\,
      R => \clk_reg[27]_i_1_n_0\
    );
flash_on_INST_0_i_1: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00005575"
    )
        port map (
      I0 => \clk_reg_reg_n_0_[26]\,
      I1 => \clk_reg_reg_n_0_[25]\,
      I2 => flash_on_INST_0_i_2_n_0,
      I3 => flash_on_INST_0_i_3_n_0,
      I4 => \clk_reg_reg_n_0_[27]\,
      O => flash_on
    );
flash_on_INST_0_i_2: unisim.vcomponents.LUT6
    generic map(
      INIT => X"BFBFBFBFBFFFFFFF"
    )
        port map (
      I0 => flash_on_INST_0_i_4_n_0,
      I1 => \clk_reg_reg_n_0_[23]\,
      I2 => \clk_reg_reg_n_0_[24]\,
      I3 => \clk_reg_reg_n_0_[17]\,
      I4 => \clk_reg_reg_n_0_[18]\,
      I5 => \clk_reg_reg_n_0_[19]\,
      O => flash_on_INST_0_i_2_n_0
    );
flash_on_INST_0_i_3: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000000000000FFFE"
    )
        port map (
      I0 => \clk_reg_reg_n_0_[9]\,
      I1 => \clk_reg_reg_n_0_[8]\,
      I2 => \clk_reg_reg_n_0_[10]\,
      I3 => flash_on_INST_0_i_5_n_0,
      I4 => flash_on_INST_0_i_6_n_0,
      I5 => flash_on_INST_0_i_7_n_0,
      O => flash_on_INST_0_i_3_n_0
    );
flash_on_INST_0_i_4: unisim.vcomponents.LUT3
    generic map(
      INIT => X"7F"
    )
        port map (
      I0 => \clk_reg_reg_n_0_[22]\,
      I1 => \clk_reg_reg_n_0_[21]\,
      I2 => \clk_reg_reg_n_0_[20]\,
      O => flash_on_INST_0_i_4_n_0
    );
flash_on_INST_0_i_5: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \clk_reg_reg_n_0_[12]\,
      I1 => \clk_reg_reg_n_0_[11]\,
      O => flash_on_INST_0_i_5_n_0
    );
flash_on_INST_0_i_6: unisim.vcomponents.LUT6
    generic map(
      INIT => X"7FFFFFFFFFFFFFFF"
    )
        port map (
      I0 => \clk_reg_reg_n_0_[20]\,
      I1 => \clk_reg_reg_n_0_[21]\,
      I2 => \clk_reg_reg_n_0_[22]\,
      I3 => \clk_reg_reg_n_0_[16]\,
      I4 => \clk_reg_reg_n_0_[18]\,
      I5 => \clk_reg_reg_n_0_[13]\,
      O => flash_on_INST_0_i_6_n_0
    );
flash_on_INST_0_i_7: unisim.vcomponents.LUT4
    generic map(
      INIT => X"7FFF"
    )
        port map (
      I0 => \clk_reg_reg_n_0_[24]\,
      I1 => \clk_reg_reg_n_0_[23]\,
      I2 => \clk_reg_reg_n_0_[15]\,
      I3 => \clk_reg_reg_n_0_[14]\,
      O => flash_on_INST_0_i_7_n_0
    );
\sec_reg[1]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9F90"
    )
        port map (
      I0 => \^q\(0),
      I1 => \^q\(1),
      I2 => \FSM_sequential_etat_courant_reg[0]_1\,
      I3 => \FSM_sequential_etat_courant_reg[0]_2\,
      O => \p_0_in__0\(1)
    );
\sec_reg[2]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"A802"
    )
        port map (
      I0 => \FSM_sequential_etat_courant_reg[0]_1\,
      I1 => \^q\(0),
      I2 => \^q\(1),
      I3 => \^q\(2),
      O => \p_0_in__0\(2)
    );
\sec_reg[3]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"AAA80002"
    )
        port map (
      I0 => \FSM_sequential_etat_courant_reg[0]_1\,
      I1 => \^q\(2),
      I2 => \^q\(1),
      I3 => \^q\(0),
      I4 => \^q\(3),
      O => \p_0_in__0\(3)
    );
\sec_reg[3]_i_3\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0001"
    )
        port map (
      I0 => \^q\(3),
      I1 => \^q\(0),
      I2 => \^q\(1),
      I3 => \^q\(2),
      O => \^sec_reg_reg[3]_0\
    );
\sec_reg_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => \FSM_sequential_etat_courant_reg[0]_3\(0),
      D => D(0),
      Q => \^q\(0),
      R => '0'
    );
\sec_reg_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => \FSM_sequential_etat_courant_reg[0]_3\(0),
      D => \p_0_in__0\(1),
      Q => \^q\(1),
      R => '0'
    );
\sec_reg_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => \FSM_sequential_etat_courant_reg[0]_3\(0),
      D => \p_0_in__0\(2),
      Q => \^q\(2),
      R => '0'
    );
\sec_reg_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => \FSM_sequential_etat_courant_reg[0]_3\(0),
      D => \p_0_in__0\(3),
      Q => \^q\(3),
      R => '0'
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_FSM is
  port (
    Q : out STD_LOGIC_VECTOR ( 3 downto 0 );
    \diff_out[1]\ : out STD_LOGIC;
    \diff_out[0]\ : out STD_LOGIC;
    score_dernier : out STD_LOGIC_VECTOR ( 3 downto 0 );
    record_perso : out STD_LOGIC_VECTOR ( 3 downto 0 );
    sec : out STD_LOGIC_VECTOR ( 3 downto 0 );
    mode_ui : out STD_LOGIC_VECTOR ( 2 downto 0 );
    new_round : out STD_LOGIC;
    decompte_ui : out STD_LOGIC_VECTOR ( 3 downto 0 );
    flash_on : out STD_LOGIC;
    reset : in STD_LOGIC;
    clk : in STD_LOGIC;
    run : in STD_LOGIC;
    pause : in STD_LOGIC;
    quit : in STD_LOGIC;
    q_pass : in STD_LOGIC;
    difficulty : in STD_LOGIC_VECTOR ( 1 downto 0 )
  );
end decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_FSM;

architecture STRUCTURE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_FSM is
  signal actif_jeu_sig : STD_LOGIC;
  signal actif_phase_sig : STD_LOGIC;
  signal \^diff_out[0]\ : STD_LOGIC;
  signal \^diff_out[1]\ : STD_LOGIC;
  signal p_0_in : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \p_0_in__0\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal save_score_sig : STD_LOGIC;
  signal \^sec\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal sec_phase_sig : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal u_game_state_n_0 : STD_LOGIC;
  signal u_game_state_n_1 : STD_LOGIC;
  signal u_game_state_n_15 : STD_LOGIC;
  signal u_game_state_n_16 : STD_LOGIC;
  signal u_game_state_n_2 : STD_LOGIC;
  signal u_game_state_n_28 : STD_LOGIC;
  signal u_game_state_n_3 : STD_LOGIC;
  signal u_game_state_n_4 : STD_LOGIC;
  signal u_game_state_n_5 : STD_LOGIC;
  signal u_game_state_n_6 : STD_LOGIC;
  signal u_game_state_n_7 : STD_LOGIC;
  signal u_sec_jeu_n_4 : STD_LOGIC;
  signal u_sec_jeu_n_5 : STD_LOGIC;
  signal u_sec_phase_n_4 : STD_LOGIC;
  signal u_sec_phase_n_5 : STD_LOGIC;
  signal u_sec_phase_n_6 : STD_LOGIC;
  signal u_sec_phase_n_7 : STD_LOGIC;
  signal u_sec_phase_n_8 : STD_LOGIC;
begin
  \diff_out[0]\ <= \^diff_out[0]\;
  \diff_out[1]\ <= \^diff_out[1]\;
  sec(3 downto 0) <= \^sec\(3 downto 0);
u_game_state: entity work.decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_game_state
     port map (
      D(0) => \p_0_in__0\(0),
      E(0) => u_game_state_n_7,
      \FSM_sequential_etat_courant_reg[0]_0\ => u_game_state_n_28,
      Q(3 downto 0) => sec_phase_sig(3 downto 0),
      clk => clk,
      \clk_reg_reg[12]\ => u_sec_phase_n_7,
      \clk_reg_reg[26]\ => u_sec_phase_n_4,
      \clk_reg_reg[26]_0\ => u_sec_phase_n_6,
      \clk_reg_reg[26]_1\ => u_sec_phase_n_8,
      \clk_reg_reg[27]\(0) => actif_phase_sig,
      \clk_reg_reg[27]_0\(0) => actif_jeu_sig,
      decompte_ui(3 downto 0) => decompte_ui(3 downto 0),
      \diff_out[0]\ => \^diff_out[0]\,
      \diff_out[1]\ => \^diff_out[1]\,
      difficulty(1 downto 0) => difficulty(1 downto 0),
      flash_on => flash_on,
      mode_ui(2 downto 0) => mode_ui(2 downto 0),
      new_round => new_round,
      \out\(2) => u_game_state_n_0,
      \out\(1) => u_game_state_n_1,
      \out\(0) => u_game_state_n_2,
      pause => pause,
      q_pass => q_pass,
      quit => quit,
      \record_perso_sig_reg[0]\ => u_game_state_n_6,
      reset => reset,
      run => run,
      \score_courant_sig_reg[2]\ => u_game_state_n_4,
      \score_courant_sig_reg[3]\(0) => u_game_state_n_16,
      \score_dernier_sig_reg[3]\(0) => save_score_sig,
      \sec_reg_reg[0]\ => u_game_state_n_5,
      \sec_reg_reg[1]\ => u_game_state_n_15,
      \sec_reg_reg[2]\ => u_sec_jeu_n_5,
      \sec_reg_reg[3]\ => u_game_state_n_3,
      \sec_reg_reg[3]_0\(2) => p_0_in(3),
      \sec_reg_reg[3]_0\(1 downto 0) => p_0_in(1 downto 0),
      \sec_reg_reg[3]_1\ => u_sec_phase_n_5,
      \sec_reg_reg[3]_2\(2) => \^sec\(3),
      \sec_reg_reg[3]_2\(1 downto 0) => \^sec\(1 downto 0),
      \sec_reg_reg[3]_3\ => u_sec_jeu_n_4
    );
u_score: entity work.decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_score
     port map (
      E(0) => u_game_state_n_16,
      \FSM_sequential_etat_courant_reg[0]\ => u_game_state_n_6,
      \FSM_sequential_etat_courant_reg[4]\ => u_game_state_n_4,
      \FSM_sequential_etat_courant_reg[4]_0\(0) => save_score_sig,
      Q(3 downto 0) => Q(3 downto 0),
      clk => clk,
      record_perso(3 downto 0) => record_perso(3 downto 0),
      reset => reset,
      score_dernier(3 downto 0) => score_dernier(3 downto 0)
    );
u_sec_jeu: entity work.decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_sec_counter
     port map (
      D(2) => p_0_in(3),
      D(1 downto 0) => p_0_in(1 downto 0),
      E(0) => actif_jeu_sig,
      \FSM_sequential_etat_courant_reg[1]\ => u_game_state_n_5,
      Q(3 downto 0) => \^sec\(3 downto 0),
      clk => clk,
      \difficulte_mem_reg[0]\ => \^diff_out[0]\,
      \difficulte_mem_reg[1]\ => \^diff_out[1]\,
      \sec_reg_reg[0]_0\ => u_sec_jeu_n_4,
      \sec_reg_reg[3]_0\ => u_sec_jeu_n_5
    );
u_sec_phase: entity work.decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_sec_counter_0
     port map (
      D(0) => \p_0_in__0\(0),
      E(0) => actif_phase_sig,
      \FSM_sequential_etat_courant_reg[0]\ => u_sec_phase_n_4,
      \FSM_sequential_etat_courant_reg[0]_0\ => u_sec_phase_n_6,
      \FSM_sequential_etat_courant_reg[0]_1\ => u_game_state_n_3,
      \FSM_sequential_etat_courant_reg[0]_2\ => u_game_state_n_15,
      \FSM_sequential_etat_courant_reg[0]_3\(0) => u_game_state_n_7,
      \FSM_sequential_etat_courant_reg[2]\ => u_game_state_n_28,
      Q(3 downto 0) => sec_phase_sig(3 downto 0),
      clk => clk,
      \clk_reg_reg[1]_0\ => u_sec_phase_n_7,
      flash_on => u_sec_phase_n_8,
      \out\(2) => u_game_state_n_0,
      \out\(1) => u_game_state_n_1,
      \out\(0) => u_game_state_n_2,
      \sec_reg_reg[3]_0\ => u_sec_phase_n_5
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix is
  port (
    clk : in STD_LOGIC;
    reset : in STD_LOGIC;
    run : in STD_LOGIC;
    pause : in STD_LOGIC;
    quit : in STD_LOGIC;
    difficulty : in STD_LOGIC_VECTOR ( 1 downto 0 );
    q_pass : in STD_LOGIC;
    new_round : out STD_LOGIC;
    diff_out : out STD_LOGIC_VECTOR ( 1 downto 0 );
    mode_ui : out STD_LOGIC_VECTOR ( 2 downto 0 );
    sec : out STD_LOGIC_VECTOR ( 3 downto 0 );
    decompte_ui : out STD_LOGIC_VECTOR ( 3 downto 0 );
    flash_on : out STD_LOGIC;
    score_courant : out STD_LOGIC_VECTOR ( 3 downto 0 );
    score_dernier : out STD_LOGIC_VECTOR ( 3 downto 0 );
    record_perso : out STD_LOGIC_VECTOR ( 3 downto 0 )
  );
  attribute NotValidForBitStream : boolean;
  attribute NotValidForBitStream of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is true;
  attribute CHECK_LICENSE_TYPE : string;
  attribute CHECK_LICENSE_TYPE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is "HDMI_bd_FSM_0_3,FSM,{}";
  attribute downgradeipidentifiedwarnings : string;
  attribute downgradeipidentifiedwarnings of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is "yes";
  attribute ip_definition_source : string;
  attribute ip_definition_source of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is "module_ref";
  attribute x_core_info : string;
  attribute x_core_info of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is "FSM,Vivado 2018.2.1";
end decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix;

architecture STRUCTURE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix is
  attribute x_interface_info : string;
  attribute x_interface_info of clk : signal is "xilinx.com:signal:clock:1.0 clk CLK";
  attribute x_interface_parameter : string;
  attribute x_interface_parameter of clk : signal is "XIL_INTERFACENAME clk, ASSOCIATED_RESET reset, FREQ_HZ 200000000, PHASE 0.0, CLK_DOMAIN /clk_wiz_0_clk_out1";
  attribute x_interface_info of reset : signal is "xilinx.com:signal:reset:1.0 reset RST";
  attribute x_interface_parameter of reset : signal is "XIL_INTERFACENAME reset, POLARITY ACTIVE_HIGH";
begin
U0: entity work.decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_FSM
     port map (
      Q(3 downto 0) => score_courant(3 downto 0),
      clk => clk,
      decompte_ui(3 downto 0) => decompte_ui(3 downto 0),
      \diff_out[0]\ => diff_out(0),
      \diff_out[1]\ => diff_out(1),
      difficulty(1 downto 0) => difficulty(1 downto 0),
      flash_on => flash_on,
      mode_ui(2 downto 0) => mode_ui(2 downto 0),
      new_round => new_round,
      pause => pause,
      q_pass => q_pass,
      quit => quit,
      record_perso(3 downto 0) => record_perso(3 downto 0),
      reset => reset,
      run => run,
      score_dernier(3 downto 0) => score_dernier(3 downto 0),
      sec(3 downto 0) => sec(3 downto 0)
    );
end STRUCTURE;
