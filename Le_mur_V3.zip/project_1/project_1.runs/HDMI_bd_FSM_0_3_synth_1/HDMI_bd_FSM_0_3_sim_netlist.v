// Copyright 1986-2018 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2018.2.1 (win64) Build 2288692 Thu Jul 26 18:24:02 MDT 2018
// Date        : Mon Nov 23 17:05:48 2026
// Host        : pcetu-136 running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode funcsim -rename_top decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix -prefix
//               decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_ HDMI_bd_FSM_0_3_sim_netlist.v
// Design      : HDMI_bd_FSM_0_3
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7z020clg400-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_FSM
   (Q,
    \diff_out[1] ,
    \diff_out[0] ,
    score_dernier,
    record_perso,
    sec,
    mode_ui,
    new_round,
    decompte_ui,
    flash_on,
    reset,
    clk,
    run,
    pause,
    quit,
    q_pass,
    difficulty);
  output [3:0]Q;
  output \diff_out[1] ;
  output \diff_out[0] ;
  output [3:0]score_dernier;
  output [3:0]record_perso;
  output [3:0]sec;
  output [2:0]mode_ui;
  output new_round;
  output [3:0]decompte_ui;
  output flash_on;
  input reset;
  input clk;
  input run;
  input pause;
  input quit;
  input q_pass;
  input [1:0]difficulty;

  wire [3:0]Q;
  wire actif_jeu_sig;
  wire actif_phase_sig;
  wire clk;
  wire [3:0]decompte_ui;
  wire \diff_out[0] ;
  wire \diff_out[1] ;
  wire [1:0]difficulty;
  wire flash_on;
  wire [2:0]mode_ui;
  wire new_round;
  wire [3:0]p_0_in;
  wire [0:0]p_0_in__0;
  wire pause;
  wire q_pass;
  wire quit;
  wire [3:0]record_perso;
  wire reset;
  wire run;
  wire save_score_sig;
  wire [3:0]score_dernier;
  wire [3:0]sec;
  wire [3:0]sec_phase_sig;
  wire u_game_state_n_0;
  wire u_game_state_n_1;
  wire u_game_state_n_15;
  wire u_game_state_n_16;
  wire u_game_state_n_2;
  wire u_game_state_n_28;
  wire u_game_state_n_3;
  wire u_game_state_n_4;
  wire u_game_state_n_5;
  wire u_game_state_n_6;
  wire u_game_state_n_7;
  wire u_sec_jeu_n_4;
  wire u_sec_jeu_n_5;
  wire u_sec_phase_n_4;
  wire u_sec_phase_n_5;
  wire u_sec_phase_n_6;
  wire u_sec_phase_n_7;
  wire u_sec_phase_n_8;

  decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_game_state u_game_state
       (.D(p_0_in__0),
        .E(u_game_state_n_7),
        .\FSM_sequential_etat_courant_reg[0]_0 (u_game_state_n_28),
        .Q(sec_phase_sig),
        .clk(clk),
        .\clk_reg_reg[12] (u_sec_phase_n_7),
        .\clk_reg_reg[26] (u_sec_phase_n_4),
        .\clk_reg_reg[26]_0 (u_sec_phase_n_6),
        .\clk_reg_reg[26]_1 (u_sec_phase_n_8),
        .\clk_reg_reg[27] (actif_phase_sig),
        .\clk_reg_reg[27]_0 (actif_jeu_sig),
        .decompte_ui(decompte_ui),
        .\diff_out[0] (\diff_out[0] ),
        .\diff_out[1] (\diff_out[1] ),
        .difficulty(difficulty),
        .flash_on(flash_on),
        .mode_ui(mode_ui),
        .new_round(new_round),
        .out({u_game_state_n_0,u_game_state_n_1,u_game_state_n_2}),
        .pause(pause),
        .q_pass(q_pass),
        .quit(quit),
        .\record_perso_sig_reg[0] (u_game_state_n_6),
        .reset(reset),
        .run(run),
        .\score_courant_sig_reg[2] (u_game_state_n_4),
        .\score_courant_sig_reg[3] (u_game_state_n_16),
        .\score_dernier_sig_reg[3] (save_score_sig),
        .\sec_reg_reg[0] (u_game_state_n_5),
        .\sec_reg_reg[1] (u_game_state_n_15),
        .\sec_reg_reg[2] (u_sec_jeu_n_5),
        .\sec_reg_reg[3] (u_game_state_n_3),
        .\sec_reg_reg[3]_0 ({p_0_in[3],p_0_in[1:0]}),
        .\sec_reg_reg[3]_1 (u_sec_phase_n_5),
        .\sec_reg_reg[3]_2 ({sec[3],sec[1:0]}),
        .\sec_reg_reg[3]_3 (u_sec_jeu_n_4));
  decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_score u_score
       (.E(u_game_state_n_16),
        .\FSM_sequential_etat_courant_reg[0] (u_game_state_n_6),
        .\FSM_sequential_etat_courant_reg[4] (u_game_state_n_4),
        .\FSM_sequential_etat_courant_reg[4]_0 (save_score_sig),
        .Q(Q),
        .clk(clk),
        .record_perso(record_perso),
        .reset(reset),
        .score_dernier(score_dernier));
  decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_sec_counter u_sec_jeu
       (.D({p_0_in[3],p_0_in[1:0]}),
        .E(actif_jeu_sig),
        .\FSM_sequential_etat_courant_reg[1] (u_game_state_n_5),
        .Q(sec),
        .clk(clk),
        .\difficulte_mem_reg[0] (\diff_out[0] ),
        .\difficulte_mem_reg[1] (\diff_out[1] ),
        .\sec_reg_reg[0]_0 (u_sec_jeu_n_4),
        .\sec_reg_reg[3]_0 (u_sec_jeu_n_5));
  decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_sec_counter_0 u_sec_phase
       (.D(p_0_in__0),
        .E(actif_phase_sig),
        .\FSM_sequential_etat_courant_reg[0] (u_sec_phase_n_4),
        .\FSM_sequential_etat_courant_reg[0]_0 (u_sec_phase_n_6),
        .\FSM_sequential_etat_courant_reg[0]_1 (u_game_state_n_3),
        .\FSM_sequential_etat_courant_reg[0]_2 (u_game_state_n_15),
        .\FSM_sequential_etat_courant_reg[0]_3 (u_game_state_n_7),
        .\FSM_sequential_etat_courant_reg[2] (u_game_state_n_28),
        .Q(sec_phase_sig),
        .clk(clk),
        .\clk_reg_reg[1]_0 (u_sec_phase_n_7),
        .flash_on(u_sec_phase_n_8),
        .out({u_game_state_n_0,u_game_state_n_1,u_game_state_n_2}),
        .\sec_reg_reg[3]_0 (u_sec_phase_n_5));
endmodule

(* CHECK_LICENSE_TYPE = "HDMI_bd_FSM_0_3,FSM,{}" *) (* downgradeipidentifiedwarnings = "yes" *) (* ip_definition_source = "module_ref" *) 
(* x_core_info = "FSM,Vivado 2018.2.1" *) 
(* NotValidForBitStream *)
module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix
   (clk,
    reset,
    run,
    pause,
    quit,
    difficulty,
    q_pass,
    new_round,
    diff_out,
    mode_ui,
    sec,
    decompte_ui,
    flash_on,
    score_courant,
    score_dernier,
    record_perso);
  (* x_interface_info = "xilinx.com:signal:clock:1.0 clk CLK" *) (* x_interface_parameter = "XIL_INTERFACENAME clk, ASSOCIATED_RESET reset, FREQ_HZ 200000000, PHASE 0.0, CLK_DOMAIN /clk_wiz_0_clk_out1" *) input clk;
  (* x_interface_info = "xilinx.com:signal:reset:1.0 reset RST" *) (* x_interface_parameter = "XIL_INTERFACENAME reset, POLARITY ACTIVE_HIGH" *) input reset;
  input run;
  input pause;
  input quit;
  input [1:0]difficulty;
  input q_pass;
  output new_round;
  output [1:0]diff_out;
  output [2:0]mode_ui;
  output [3:0]sec;
  output [3:0]decompte_ui;
  output flash_on;
  output [3:0]score_courant;
  output [3:0]score_dernier;
  output [3:0]record_perso;

  wire clk;
  wire [3:0]decompte_ui;
  wire [1:0]diff_out;
  wire [1:0]difficulty;
  wire flash_on;
  wire [2:0]mode_ui;
  wire new_round;
  wire pause;
  wire q_pass;
  wire quit;
  wire [3:0]record_perso;
  wire reset;
  wire run;
  wire [3:0]score_courant;
  wire [3:0]score_dernier;
  wire [3:0]sec;

  decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_FSM U0
       (.Q(score_courant),
        .clk(clk),
        .decompte_ui(decompte_ui),
        .\diff_out[0] (diff_out[0]),
        .\diff_out[1] (diff_out[1]),
        .difficulty(difficulty),
        .flash_on(flash_on),
        .mode_ui(mode_ui),
        .new_round(new_round),
        .pause(pause),
        .q_pass(q_pass),
        .quit(quit),
        .record_perso(record_perso),
        .reset(reset),
        .run(run),
        .score_dernier(score_dernier),
        .sec(sec));
endmodule

module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_game_state
   (out,
    \sec_reg_reg[3] ,
    \score_courant_sig_reg[2] ,
    \sec_reg_reg[0] ,
    \record_perso_sig_reg[0] ,
    E,
    \clk_reg_reg[27] ,
    D,
    \clk_reg_reg[27]_0 ,
    \score_dernier_sig_reg[3] ,
    mode_ui,
    \sec_reg_reg[1] ,
    \score_courant_sig_reg[3] ,
    \sec_reg_reg[3]_0 ,
    \diff_out[0] ,
    \diff_out[1] ,
    new_round,
    decompte_ui,
    flash_on,
    \FSM_sequential_etat_courant_reg[0]_0 ,
    run,
    clk,
    reset,
    pause,
    quit,
    q_pass,
    \clk_reg_reg[12] ,
    \sec_reg_reg[3]_1 ,
    Q,
    \clk_reg_reg[26] ,
    \clk_reg_reg[26]_0 ,
    \sec_reg_reg[3]_2 ,
    \sec_reg_reg[2] ,
    \sec_reg_reg[3]_3 ,
    \clk_reg_reg[26]_1 ,
    difficulty);
  output [2:0]out;
  output \sec_reg_reg[3] ;
  output \score_courant_sig_reg[2] ;
  output \sec_reg_reg[0] ;
  output \record_perso_sig_reg[0] ;
  output [0:0]E;
  output [0:0]\clk_reg_reg[27] ;
  output [0:0]D;
  output [0:0]\clk_reg_reg[27]_0 ;
  output [0:0]\score_dernier_sig_reg[3] ;
  output [2:0]mode_ui;
  output \sec_reg_reg[1] ;
  output [0:0]\score_courant_sig_reg[3] ;
  output [2:0]\sec_reg_reg[3]_0 ;
  output \diff_out[0] ;
  output \diff_out[1] ;
  output new_round;
  output [3:0]decompte_ui;
  output flash_on;
  output \FSM_sequential_etat_courant_reg[0]_0 ;
  input run;
  input clk;
  input reset;
  input pause;
  input quit;
  input q_pass;
  input \clk_reg_reg[12] ;
  input \sec_reg_reg[3]_1 ;
  input [3:0]Q;
  input \clk_reg_reg[26] ;
  input \clk_reg_reg[26]_0 ;
  input [2:0]\sec_reg_reg[3]_2 ;
  input \sec_reg_reg[2] ;
  input \sec_reg_reg[3]_3 ;
  input \clk_reg_reg[26]_1 ;
  input [1:0]difficulty;

  wire [0:0]D;
  wire [0:0]E;
  wire \FSM_sequential_etat_courant[0]_i_2_n_0 ;
  wire \FSM_sequential_etat_courant[1]_i_2_n_0 ;
  wire \FSM_sequential_etat_courant[3]_i_2_n_0 ;
  wire \FSM_sequential_etat_courant[3]_i_3_n_0 ;
  wire \FSM_sequential_etat_courant[4]_i_10_n_0 ;
  wire \FSM_sequential_etat_courant[4]_i_11_n_0 ;
  wire \FSM_sequential_etat_courant[4]_i_1_n_0 ;
  wire \FSM_sequential_etat_courant[4]_i_5_n_0 ;
  wire \FSM_sequential_etat_courant[4]_i_6_n_0 ;
  wire \FSM_sequential_etat_courant[4]_i_9_n_0 ;
  wire \FSM_sequential_etat_courant_reg[0]_0 ;
  wire [3:0]Q;
  wire clk;
  wire \clk_reg_reg[12] ;
  wire \clk_reg_reg[26] ;
  wire \clk_reg_reg[26]_0 ;
  wire \clk_reg_reg[26]_1 ;
  wire [0:0]\clk_reg_reg[27] ;
  wire [0:0]\clk_reg_reg[27]_0 ;
  wire [3:0]decompte_ui;
  wire \diff_out[0] ;
  wire \diff_out[1] ;
  wire \difficulte_mem[0]_i_1_n_0 ;
  wire \difficulte_mem[1]_i_1_n_0 ;
  wire \difficulte_mem[1]_i_2_n_0 ;
  wire \difficulte_mem[1]_i_3_n_0 ;
  wire [1:0]difficulty;
  (* RTL_KEEP = "yes" *) wire [4:0]etat_courant;
  wire [4:0]etat_suivant__0;
  wire flash_on;
  wire [2:0]mode_ui;
  wire new_round;
  (* RTL_KEEP = "yes" *) wire [2:0]out;
  wire pass_meta;
  wire pass_sync;
  wire pause;
  wire pause_meta;
  wire pause_prev;
  wire pause_sync;
  wire q_pass;
  wire quit;
  wire quit_meta;
  wire quit_sync;
  wire \record_perso_sig_reg[0] ;
  wire reset;
  wire run;
  wire run_meta;
  wire run_prev;
  wire run_sync;
  wire \score_courant_sig_reg[2] ;
  wire [0:0]\score_courant_sig_reg[3] ;
  wire [0:0]\score_dernier_sig_reg[3] ;
  wire \sec_reg_reg[0] ;
  wire \sec_reg_reg[1] ;
  wire \sec_reg_reg[2] ;
  wire \sec_reg_reg[3] ;
  wire [2:0]\sec_reg_reg[3]_0 ;
  wire \sec_reg_reg[3]_1 ;
  wire [2:0]\sec_reg_reg[3]_2 ;
  wire \sec_reg_reg[3]_3 ;

  LUT6 #(
    .INIT(64'h0000000337070707)) 
    \FSM_sequential_etat_courant[0]_i_1 
       (.I0(\FSM_sequential_etat_courant[0]_i_2_n_0 ),
        .I1(out[0]),
        .I2(etat_courant[0]),
        .I3(out[1]),
        .I4(out[2]),
        .I5(etat_courant[4]),
        .O(etat_suivant__0[0]));
  LUT4 #(
    .INIT(16'h00A2)) 
    \FSM_sequential_etat_courant[0]_i_2 
       (.I0(out[1]),
        .I1(pause_sync),
        .I2(pause_prev),
        .I3(out[2]),
        .O(\FSM_sequential_etat_courant[0]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h000047F000004740)) 
    \FSM_sequential_etat_courant[1]_i_1 
       (.I0(out[1]),
        .I1(out[2]),
        .I2(out[0]),
        .I3(etat_courant[0]),
        .I4(etat_courant[4]),
        .I5(\FSM_sequential_etat_courant[1]_i_2_n_0 ),
        .O(etat_suivant__0[1]));
  LUT5 #(
    .INIT(32'hDFDDFFFF)) 
    \FSM_sequential_etat_courant[1]_i_2 
       (.I0(pass_sync),
        .I1(out[2]),
        .I2(pause_prev),
        .I3(pause_sync),
        .I4(out[1]),
        .O(\FSM_sequential_etat_courant[1]_i_2_n_0 ));
  LUT4 #(
    .INIT(16'h006A)) 
    \FSM_sequential_etat_courant[2]_i_1 
       (.I0(out[1]),
        .I1(etat_courant[0]),
        .I2(out[0]),
        .I3(etat_courant[4]),
        .O(etat_suivant__0[2]));
  LUT5 #(
    .INIT(32'h000000EA)) 
    \FSM_sequential_etat_courant[3]_i_1 
       (.I0(out[2]),
        .I1(out[0]),
        .I2(out[1]),
        .I3(etat_courant[4]),
        .I4(\FSM_sequential_etat_courant[3]_i_2_n_0 ),
        .O(etat_suivant__0[3]));
  LUT6 #(
    .INIT(64'h00000000FF04F004)) 
    \FSM_sequential_etat_courant[3]_i_2 
       (.I0(pause_prev),
        .I1(pause_sync),
        .I2(out[2]),
        .I3(etat_courant[0]),
        .I4(quit_sync),
        .I5(\FSM_sequential_etat_courant[3]_i_3_n_0 ),
        .O(\FSM_sequential_etat_courant[3]_i_2_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \FSM_sequential_etat_courant[3]_i_3 
       (.I0(out[1]),
        .I1(out[0]),
        .O(\FSM_sequential_etat_courant[3]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFF0000FFF1)) 
    \FSM_sequential_etat_courant[4]_i_1 
       (.I0(\clk_reg_reg[26] ),
        .I1(out[2]),
        .I2(\clk_reg_reg[26]_0 ),
        .I3(\FSM_sequential_etat_courant[4]_i_5_n_0 ),
        .I4(etat_courant[4]),
        .I5(\FSM_sequential_etat_courant[4]_i_6_n_0 ),
        .O(\FSM_sequential_etat_courant[4]_i_1_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \FSM_sequential_etat_courant[4]_i_10 
       (.I0(out[1]),
        .I1(out[0]),
        .O(\FSM_sequential_etat_courant[4]_i_10_n_0 ));
  LUT4 #(
    .INIT(16'hFFAE)) 
    \FSM_sequential_etat_courant[4]_i_11 
       (.I0(\sec_reg_reg[3]_3 ),
        .I1(pause_sync),
        .I2(pause_prev),
        .I3(out[2]),
        .O(\FSM_sequential_etat_courant[4]_i_11_n_0 ));
  LUT5 #(
    .INIT(32'h40000002)) 
    \FSM_sequential_etat_courant[4]_i_2 
       (.I0(etat_courant[4]),
        .I1(out[2]),
        .I2(etat_courant[0]),
        .I3(out[0]),
        .I4(out[1]),
        .O(etat_suivant__0[4]));
  LUT6 #(
    .INIT(64'h0F0FDFF00000D0F0)) 
    \FSM_sequential_etat_courant[4]_i_5 
       (.I0(\FSM_sequential_etat_courant[4]_i_9_n_0 ),
        .I1(quit_sync),
        .I2(etat_courant[0]),
        .I3(\FSM_sequential_etat_courant[4]_i_10_n_0 ),
        .I4(out[2]),
        .I5(\FSM_sequential_etat_courant[4]_i_11_n_0 ),
        .O(\FSM_sequential_etat_courant[4]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFF8B880000)) 
    \FSM_sequential_etat_courant[4]_i_6 
       (.I0(quit_sync),
        .I1(etat_courant[0]),
        .I2(run_prev),
        .I3(run_sync),
        .I4(\difficulte_mem[1]_i_2_n_0 ),
        .I5(\score_dernier_sig_reg[3] ),
        .O(\FSM_sequential_etat_courant[4]_i_6_n_0 ));
  LUT2 #(
    .INIT(4'hB)) 
    \FSM_sequential_etat_courant[4]_i_8 
       (.I0(out[1]),
        .I1(out[0]),
        .O(\FSM_sequential_etat_courant_reg[0]_0 ));
  LUT2 #(
    .INIT(4'hB)) 
    \FSM_sequential_etat_courant[4]_i_9 
       (.I0(run_prev),
        .I1(run_sync),
        .O(\FSM_sequential_etat_courant[4]_i_9_n_0 ));
  (* FSM_ENCODED_STATES = "echec_charge:01110,reussi_flash:01101,reussi_charge:01100,start_go_charge:00011,fin_partie:10001,start_compte:00010,sauver_score:10000,start_charge:00001,reprise_go:01011,menu:00000,reprise_go_charge:01010,pause_state:00111,jeu:00110,reprise_compte:01001,reprise_charge:01000,init_mur:00101,start_go:00100,echec_flash:01111" *) 
  (* KEEP = "yes" *) 
  FDCE #(
    .INIT(1'b0)) 
    \FSM_sequential_etat_courant_reg[0] 
       (.C(clk),
        .CE(\FSM_sequential_etat_courant[4]_i_1_n_0 ),
        .CLR(reset),
        .D(etat_suivant__0[0]),
        .Q(etat_courant[0]));
  (* FSM_ENCODED_STATES = "echec_charge:01110,reussi_flash:01101,reussi_charge:01100,start_go_charge:00011,fin_partie:10001,start_compte:00010,sauver_score:10000,start_charge:00001,reprise_go:01011,menu:00000,reprise_go_charge:01010,pause_state:00111,jeu:00110,reprise_compte:01001,reprise_charge:01000,init_mur:00101,start_go:00100,echec_flash:01111" *) 
  (* KEEP = "yes" *) 
  FDCE #(
    .INIT(1'b0)) 
    \FSM_sequential_etat_courant_reg[1] 
       (.C(clk),
        .CE(\FSM_sequential_etat_courant[4]_i_1_n_0 ),
        .CLR(reset),
        .D(etat_suivant__0[1]),
        .Q(out[0]));
  (* FSM_ENCODED_STATES = "echec_charge:01110,reussi_flash:01101,reussi_charge:01100,start_go_charge:00011,fin_partie:10001,start_compte:00010,sauver_score:10000,start_charge:00001,reprise_go:01011,menu:00000,reprise_go_charge:01010,pause_state:00111,jeu:00110,reprise_compte:01001,reprise_charge:01000,init_mur:00101,start_go:00100,echec_flash:01111" *) 
  (* KEEP = "yes" *) 
  FDCE #(
    .INIT(1'b0)) 
    \FSM_sequential_etat_courant_reg[2] 
       (.C(clk),
        .CE(\FSM_sequential_etat_courant[4]_i_1_n_0 ),
        .CLR(reset),
        .D(etat_suivant__0[2]),
        .Q(out[1]));
  (* FSM_ENCODED_STATES = "echec_charge:01110,reussi_flash:01101,reussi_charge:01100,start_go_charge:00011,fin_partie:10001,start_compte:00010,sauver_score:10000,start_charge:00001,reprise_go:01011,menu:00000,reprise_go_charge:01010,pause_state:00111,jeu:00110,reprise_compte:01001,reprise_charge:01000,init_mur:00101,start_go:00100,echec_flash:01111" *) 
  (* KEEP = "yes" *) 
  FDCE #(
    .INIT(1'b0)) 
    \FSM_sequential_etat_courant_reg[3] 
       (.C(clk),
        .CE(\FSM_sequential_etat_courant[4]_i_1_n_0 ),
        .CLR(reset),
        .D(etat_suivant__0[3]),
        .Q(out[2]));
  (* FSM_ENCODED_STATES = "echec_charge:01110,reussi_flash:01101,reussi_charge:01100,start_go_charge:00011,fin_partie:10001,start_compte:00010,sauver_score:10000,start_charge:00001,reprise_go:01011,menu:00000,reprise_go_charge:01010,pause_state:00111,jeu:00110,reprise_compte:01001,reprise_charge:01000,init_mur:00101,start_go:00100,echec_flash:01111" *) 
  (* KEEP = "yes" *) 
  FDCE #(
    .INIT(1'b0)) 
    \FSM_sequential_etat_courant_reg[4] 
       (.C(clk),
        .CE(\FSM_sequential_etat_courant[4]_i_1_n_0 ),
        .CLR(reset),
        .D(etat_suivant__0[4]),
        .Q(etat_courant[4]));
  LUT5 #(
    .INIT(32'h01000000)) 
    \clk_reg[27]_i_2 
       (.I0(etat_courant[0]),
        .I1(etat_courant[4]),
        .I2(out[2]),
        .I3(out[1]),
        .I4(out[0]),
        .O(\clk_reg_reg[27]_0 ));
  LUT5 #(
    .INIT(32'h22220110)) 
    \clk_reg[27]_i_2__0 
       (.I0(etat_courant[0]),
        .I1(etat_courant[4]),
        .I2(out[1]),
        .I3(out[0]),
        .I4(out[2]),
        .O(\clk_reg_reg[27] ));
  LUT5 #(
    .INIT(32'h54545551)) 
    \clk_reg[27]_i_4__0 
       (.I0(reset),
        .I1(etat_courant[0]),
        .I2(etat_courant[4]),
        .I3(out[1]),
        .I4(out[2]),
        .O(\sec_reg_reg[3] ));
  LUT6 #(
    .INIT(64'h0000101100101100)) 
    \decompte_ui[0]_INST_0 
       (.I0(etat_courant[4]),
        .I1(out[1]),
        .I2(Q[0]),
        .I3(out[2]),
        .I4(out[0]),
        .I5(etat_courant[0]),
        .O(decompte_ui[0]));
  LUT6 #(
    .INIT(64'h0000101100101100)) 
    \decompte_ui[1]_INST_0 
       (.I0(etat_courant[4]),
        .I1(out[1]),
        .I2(Q[1]),
        .I3(out[2]),
        .I4(out[0]),
        .I5(etat_courant[0]),
        .O(decompte_ui[1]));
  LUT6 #(
    .INIT(64'h0000002400000000)) 
    \decompte_ui[2]_INST_0 
       (.I0(out[2]),
        .I1(out[0]),
        .I2(etat_courant[0]),
        .I3(out[1]),
        .I4(etat_courant[4]),
        .I5(Q[2]),
        .O(decompte_ui[2]));
  LUT6 #(
    .INIT(64'h0000002400000000)) 
    \decompte_ui[3]_INST_0 
       (.I0(out[2]),
        .I1(out[0]),
        .I2(etat_courant[0]),
        .I3(out[1]),
        .I4(etat_courant[4]),
        .I5(Q[3]),
        .O(decompte_ui[3]));
  LUT6 #(
    .INIT(64'hFFBFFFFF00800000)) 
    \difficulte_mem[0]_i_1 
       (.I0(difficulty[0]),
        .I1(\difficulte_mem[1]_i_2_n_0 ),
        .I2(\difficulte_mem[1]_i_3_n_0 ),
        .I3(run_prev),
        .I4(run_sync),
        .I5(\diff_out[0] ),
        .O(\difficulte_mem[0]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hFFBFFFFF00800000)) 
    \difficulte_mem[1]_i_1 
       (.I0(difficulty[1]),
        .I1(\difficulte_mem[1]_i_2_n_0 ),
        .I2(\difficulte_mem[1]_i_3_n_0 ),
        .I3(run_prev),
        .I4(run_sync),
        .I5(\diff_out[1] ),
        .O(\difficulte_mem[1]_i_1_n_0 ));
  LUT3 #(
    .INIT(8'h01)) 
    \difficulte_mem[1]_i_2 
       (.I0(out[2]),
        .I1(out[1]),
        .I2(out[0]),
        .O(\difficulte_mem[1]_i_2_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \difficulte_mem[1]_i_3 
       (.I0(etat_courant[4]),
        .I1(etat_courant[0]),
        .O(\difficulte_mem[1]_i_3_n_0 ));
  FDCE #(
    .INIT(1'b0)) 
    \difficulte_mem_reg[0] 
       (.C(clk),
        .CE(1'b1),
        .CLR(reset),
        .D(\difficulte_mem[0]_i_1_n_0 ),
        .Q(\diff_out[0] ));
  FDCE #(
    .INIT(1'b0)) 
    \difficulte_mem_reg[1] 
       (.C(clk),
        .CE(1'b1),
        .CLR(reset),
        .D(\difficulte_mem[1]_i_1_n_0 ),
        .Q(\diff_out[1] ));
  LUT5 #(
    .INIT(32'h08000808)) 
    flash_on_INST_0
       (.I0(out[1]),
        .I1(out[2]),
        .I2(etat_courant[4]),
        .I3(\clk_reg_reg[26]_1 ),
        .I4(etat_courant[0]),
        .O(flash_on));
  LUT5 #(
    .INIT(32'h0000FF3E)) 
    \mode_ui[0]_INST_0 
       (.I0(etat_courant[0]),
        .I1(out[0]),
        .I2(out[1]),
        .I3(out[2]),
        .I4(etat_courant[4]),
        .O(mode_ui[0]));
  LUT4 #(
    .INIT(16'h0060)) 
    \mode_ui[1]_INST_0 
       (.I0(out[0]),
        .I1(out[2]),
        .I2(out[1]),
        .I3(etat_courant[4]),
        .O(mode_ui[1]));
  LUT5 #(
    .INIT(32'h50400202)) 
    \mode_ui[2]_INST_0 
       (.I0(etat_courant[4]),
        .I1(out[2]),
        .I2(out[0]),
        .I3(etat_courant[0]),
        .I4(out[1]),
        .O(mode_ui[2]));
  LUT5 #(
    .INIT(32'h00000400)) 
    new_round_INST_0
       (.I0(etat_courant[4]),
        .I1(etat_courant[0]),
        .I2(out[2]),
        .I3(out[1]),
        .I4(out[0]),
        .O(new_round));
  FDCE #(
    .INIT(1'b0)) 
    pass_meta_reg
       (.C(clk),
        .CE(1'b1),
        .CLR(reset),
        .D(q_pass),
        .Q(pass_meta));
  FDCE #(
    .INIT(1'b0)) 
    pass_sync_reg
       (.C(clk),
        .CE(1'b1),
        .CLR(reset),
        .D(pass_meta),
        .Q(pass_sync));
  FDCE #(
    .INIT(1'b0)) 
    pause_meta_reg
       (.C(clk),
        .CE(1'b1),
        .CLR(reset),
        .D(pause),
        .Q(pause_meta));
  FDCE #(
    .INIT(1'b0)) 
    pause_prev_reg
       (.C(clk),
        .CE(1'b1),
        .CLR(reset),
        .D(pause_sync),
        .Q(pause_prev));
  FDCE #(
    .INIT(1'b0)) 
    pause_sync_reg
       (.C(clk),
        .CE(1'b1),
        .CLR(reset),
        .D(pause_meta),
        .Q(pause_sync));
  FDCE #(
    .INIT(1'b0)) 
    quit_meta_reg
       (.C(clk),
        .CE(1'b1),
        .CLR(reset),
        .D(quit),
        .Q(quit_meta));
  FDCE #(
    .INIT(1'b0)) 
    quit_sync_reg
       (.C(clk),
        .CE(1'b1),
        .CLR(reset),
        .D(quit_meta),
        .Q(quit_sync));
  LUT6 #(
    .INIT(64'hFFFFFEFFFFFFFFFF)) 
    \record_perso_sig[3]_i_5 
       (.I0(reset),
        .I1(etat_courant[0]),
        .I2(etat_courant[4]),
        .I3(out[1]),
        .I4(out[0]),
        .I5(out[2]),
        .O(\record_perso_sig_reg[0] ));
  FDCE #(
    .INIT(1'b0)) 
    run_meta_reg
       (.C(clk),
        .CE(1'b1),
        .CLR(reset),
        .D(run),
        .Q(run_meta));
  FDCE #(
    .INIT(1'b0)) 
    run_prev_reg
       (.C(clk),
        .CE(1'b1),
        .CLR(reset),
        .D(run_sync),
        .Q(run_prev));
  FDCE #(
    .INIT(1'b0)) 
    run_sync_reg
       (.C(clk),
        .CE(1'b1),
        .CLR(reset),
        .D(run_meta),
        .Q(run_sync));
  LUT5 #(
    .INIT(32'h00000120)) 
    \score_courant_sig[3]_i_1 
       (.I0(out[1]),
        .I1(out[0]),
        .I2(out[2]),
        .I3(etat_courant[0]),
        .I4(etat_courant[4]),
        .O(\score_courant_sig_reg[3] ));
  LUT5 #(
    .INIT(32'h00000004)) 
    \score_courant_sig[3]_i_3 
       (.I0(etat_courant[4]),
        .I1(etat_courant[0]),
        .I2(out[2]),
        .I3(out[0]),
        .I4(out[1]),
        .O(\score_courant_sig_reg[2] ));
  LUT5 #(
    .INIT(32'h00000002)) 
    \score_dernier_sig[3]_i_1 
       (.I0(etat_courant[4]),
        .I1(etat_courant[0]),
        .I2(out[0]),
        .I3(out[1]),
        .I4(out[2]),
        .O(\score_dernier_sig_reg[3] ));
  LUT6 #(
    .INIT(64'h4444444777777777)) 
    \sec_reg[0]_i_1 
       (.I0(Q[0]),
        .I1(\sec_reg_reg[3] ),
        .I2(out[0]),
        .I3(out[1]),
        .I4(out[2]),
        .I5(etat_courant[4]),
        .O(D));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT4 #(
    .INIT(16'h0EFE)) 
    \sec_reg[0]_i_1__0 
       (.I0(\diff_out[0] ),
        .I1(\diff_out[1] ),
        .I2(\sec_reg_reg[0] ),
        .I3(\sec_reg_reg[3]_2 [0]),
        .O(\sec_reg_reg[3]_0 [0]));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT5 #(
    .INIT(32'h9F909F9F)) 
    \sec_reg[1]_i_1__0 
       (.I0(\sec_reg_reg[3]_2 [0]),
        .I1(\sec_reg_reg[3]_2 [1]),
        .I2(\sec_reg_reg[0] ),
        .I3(\diff_out[0] ),
        .I4(\diff_out[1] ),
        .O(\sec_reg_reg[3]_0 [1]));
  LUT5 #(
    .INIT(32'h0003FBF7)) 
    \sec_reg[1]_i_2 
       (.I0(etat_courant[0]),
        .I1(out[0]),
        .I2(out[1]),
        .I3(out[2]),
        .I4(etat_courant[4]),
        .O(\sec_reg_reg[1] ));
  LUT4 #(
    .INIT(16'h5D55)) 
    \sec_reg[3]_i_1 
       (.I0(\sec_reg_reg[3] ),
        .I1(\clk_reg_reg[12] ),
        .I2(\sec_reg_reg[3]_1 ),
        .I3(\clk_reg_reg[27] ),
        .O(E));
  LUT5 #(
    .INIT(32'h9090909F)) 
    \sec_reg[3]_i_2__0 
       (.I0(\sec_reg_reg[2] ),
        .I1(\sec_reg_reg[3]_2 [2]),
        .I2(\sec_reg_reg[0] ),
        .I3(\diff_out[0] ),
        .I4(\diff_out[1] ),
        .O(\sec_reg_reg[3]_0 [2]));
  LUT6 #(
    .INIT(64'h5555555555455555)) 
    \sec_reg[3]_i_3__0 
       (.I0(reset),
        .I1(out[0]),
        .I2(out[1]),
        .I3(out[2]),
        .I4(etat_courant[0]),
        .I5(etat_courant[4]),
        .O(\sec_reg_reg[0] ));
endmodule

module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_score
   (Q,
    record_perso,
    score_dernier,
    \FSM_sequential_etat_courant_reg[4] ,
    \FSM_sequential_etat_courant_reg[0] ,
    E,
    clk,
    reset,
    \FSM_sequential_etat_courant_reg[4]_0 );
  output [3:0]Q;
  output [3:0]record_perso;
  output [3:0]score_dernier;
  input \FSM_sequential_etat_courant_reg[4] ;
  input \FSM_sequential_etat_courant_reg[0] ;
  input [0:0]E;
  input clk;
  input reset;
  input [0:0]\FSM_sequential_etat_courant_reg[4]_0 ;

  wire [0:0]E;
  wire \FSM_sequential_etat_courant_reg[0] ;
  wire \FSM_sequential_etat_courant_reg[4] ;
  wire [0:0]\FSM_sequential_etat_courant_reg[4]_0 ;
  wire [3:0]Q;
  wire clk;
  wire [3:0]record_perso;
  wire record_perso_sig;
  wire \record_perso_sig[3]_i_3_n_0 ;
  wire \record_perso_sig[3]_i_4_n_0 ;
  wire \record_perso_sig[3]_i_6_n_0 ;
  wire reset;
  wire \score_courant_sig[0]_i_1_n_0 ;
  wire \score_courant_sig[1]_i_1_n_0 ;
  wire \score_courant_sig[2]_i_1_n_0 ;
  wire \score_courant_sig[3]_i_2_n_0 ;
  wire [3:0]score_dernier;
  wire [3:0]score_suivant;

  (* SOFT_HLUTNM = "soft_lutpair5" *) 
  LUT4 #(
    .INIT(16'hB333)) 
    \record_perso_sig[0]_i_1 
       (.I0(Q[1]),
        .I1(Q[0]),
        .I2(Q[2]),
        .I3(Q[3]),
        .O(score_suivant[0]));
  (* SOFT_HLUTNM = "soft_lutpair5" *) 
  LUT4 #(
    .INIT(16'h8FF0)) 
    \record_perso_sig[1]_i_1 
       (.I0(Q[3]),
        .I1(Q[2]),
        .I2(Q[0]),
        .I3(Q[1]),
        .O(score_suivant[1]));
  (* SOFT_HLUTNM = "soft_lutpair3" *) 
  LUT4 #(
    .INIT(16'hF878)) 
    \record_perso_sig[2]_i_1 
       (.I0(Q[1]),
        .I1(Q[0]),
        .I2(Q[2]),
        .I3(Q[3]),
        .O(score_suivant[2]));
  LUT6 #(
    .INIT(64'h00000071007100FF)) 
    \record_perso_sig[3]_i_1 
       (.I0(\record_perso_sig[3]_i_3_n_0 ),
        .I1(record_perso[2]),
        .I2(\record_perso_sig[3]_i_4_n_0 ),
        .I3(\FSM_sequential_etat_courant_reg[0] ),
        .I4(record_perso[3]),
        .I5(\record_perso_sig[3]_i_6_n_0 ),
        .O(record_perso_sig));
  (* SOFT_HLUTNM = "soft_lutpair4" *) 
  LUT4 #(
    .INIT(16'hFF80)) 
    \record_perso_sig[3]_i_2 
       (.I0(Q[2]),
        .I1(Q[0]),
        .I2(Q[1]),
        .I3(Q[3]),
        .O(score_suivant[3]));
  (* SOFT_HLUTNM = "soft_lutpair4" *) 
  LUT4 #(
    .INIT(16'h4333)) 
    \record_perso_sig[3]_i_3 
       (.I0(Q[3]),
        .I1(Q[2]),
        .I2(Q[0]),
        .I3(Q[1]),
        .O(\record_perso_sig[3]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h44040404FD3D3D3D)) 
    \record_perso_sig[3]_i_4 
       (.I0(record_perso[0]),
        .I1(Q[1]),
        .I2(Q[0]),
        .I3(Q[2]),
        .I4(Q[3]),
        .I5(record_perso[1]),
        .O(\record_perso_sig[3]_i_4_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair3" *) 
  LUT4 #(
    .INIT(16'h1555)) 
    \record_perso_sig[3]_i_6 
       (.I0(Q[3]),
        .I1(Q[1]),
        .I2(Q[0]),
        .I3(Q[2]),
        .O(\record_perso_sig[3]_i_6_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \record_perso_sig_reg[0] 
       (.C(clk),
        .CE(record_perso_sig),
        .D(score_suivant[0]),
        .Q(record_perso[0]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \record_perso_sig_reg[1] 
       (.C(clk),
        .CE(record_perso_sig),
        .D(score_suivant[1]),
        .Q(record_perso[1]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \record_perso_sig_reg[2] 
       (.C(clk),
        .CE(record_perso_sig),
        .D(score_suivant[2]),
        .Q(record_perso[2]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \record_perso_sig_reg[3] 
       (.C(clk),
        .CE(record_perso_sig),
        .D(score_suivant[3]),
        .Q(record_perso[3]),
        .R(1'b0));
  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT5 #(
    .INIT(32'h45050505)) 
    \score_courant_sig[0]_i_1 
       (.I0(\FSM_sequential_etat_courant_reg[4] ),
        .I1(Q[1]),
        .I2(Q[0]),
        .I3(Q[2]),
        .I4(Q[3]),
        .O(\score_courant_sig[0]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT5 #(
    .INIT(32'h0000E666)) 
    \score_courant_sig[1]_i_1 
       (.I0(Q[1]),
        .I1(Q[0]),
        .I2(Q[2]),
        .I3(Q[3]),
        .I4(\FSM_sequential_etat_courant_reg[4] ),
        .O(\score_courant_sig[1]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT5 #(
    .INIT(32'h55401540)) 
    \score_courant_sig[2]_i_1 
       (.I0(\FSM_sequential_etat_courant_reg[4] ),
        .I1(Q[1]),
        .I2(Q[0]),
        .I3(Q[2]),
        .I4(Q[3]),
        .O(\score_courant_sig[2]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT5 #(
    .INIT(32'h55554000)) 
    \score_courant_sig[3]_i_2 
       (.I0(\FSM_sequential_etat_courant_reg[4] ),
        .I1(Q[2]),
        .I2(Q[0]),
        .I3(Q[1]),
        .I4(Q[3]),
        .O(\score_courant_sig[3]_i_2_n_0 ));
  FDCE #(
    .INIT(1'b0)) 
    \score_courant_sig_reg[0] 
       (.C(clk),
        .CE(E),
        .CLR(reset),
        .D(\score_courant_sig[0]_i_1_n_0 ),
        .Q(Q[0]));
  FDCE #(
    .INIT(1'b0)) 
    \score_courant_sig_reg[1] 
       (.C(clk),
        .CE(E),
        .CLR(reset),
        .D(\score_courant_sig[1]_i_1_n_0 ),
        .Q(Q[1]));
  FDCE #(
    .INIT(1'b0)) 
    \score_courant_sig_reg[2] 
       (.C(clk),
        .CE(E),
        .CLR(reset),
        .D(\score_courant_sig[2]_i_1_n_0 ),
        .Q(Q[2]));
  FDCE #(
    .INIT(1'b0)) 
    \score_courant_sig_reg[3] 
       (.C(clk),
        .CE(E),
        .CLR(reset),
        .D(\score_courant_sig[3]_i_2_n_0 ),
        .Q(Q[3]));
  FDRE #(
    .INIT(1'b0)) 
    \score_dernier_sig_reg[0] 
       (.C(clk),
        .CE(\FSM_sequential_etat_courant_reg[4]_0 ),
        .D(Q[0]),
        .Q(score_dernier[0]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \score_dernier_sig_reg[1] 
       (.C(clk),
        .CE(\FSM_sequential_etat_courant_reg[4]_0 ),
        .D(Q[1]),
        .Q(score_dernier[1]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \score_dernier_sig_reg[2] 
       (.C(clk),
        .CE(\FSM_sequential_etat_courant_reg[4]_0 ),
        .D(Q[2]),
        .Q(score_dernier[2]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \score_dernier_sig_reg[3] 
       (.C(clk),
        .CE(\FSM_sequential_etat_courant_reg[4]_0 ),
        .D(Q[3]),
        .Q(score_dernier[3]),
        .R(1'b0));
endmodule

module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_sec_counter
   (Q,
    \sec_reg_reg[0]_0 ,
    \sec_reg_reg[3]_0 ,
    E,
    \FSM_sequential_etat_courant_reg[1] ,
    D,
    \difficulte_mem_reg[0] ,
    \difficulte_mem_reg[1] ,
    clk);
  output [3:0]Q;
  output \sec_reg_reg[0]_0 ;
  output \sec_reg_reg[3]_0 ;
  input [0:0]E;
  input \FSM_sequential_etat_courant_reg[1] ;
  input [2:0]D;
  input \difficulte_mem_reg[0] ;
  input \difficulte_mem_reg[1] ;
  input clk;

  wire [2:0]D;
  wire [0:0]E;
  wire \FSM_sequential_etat_courant_reg[1] ;
  wire [3:0]Q;
  wire clk;
  wire [27:0]clk_reg;
  wire clk_reg0_carry__0_n_0;
  wire clk_reg0_carry__0_n_1;
  wire clk_reg0_carry__0_n_2;
  wire clk_reg0_carry__0_n_3;
  wire clk_reg0_carry__1_n_0;
  wire clk_reg0_carry__1_n_1;
  wire clk_reg0_carry__1_n_2;
  wire clk_reg0_carry__1_n_3;
  wire clk_reg0_carry__2_n_0;
  wire clk_reg0_carry__2_n_1;
  wire clk_reg0_carry__2_n_2;
  wire clk_reg0_carry__2_n_3;
  wire clk_reg0_carry__3_n_0;
  wire clk_reg0_carry__3_n_1;
  wire clk_reg0_carry__3_n_2;
  wire clk_reg0_carry__3_n_3;
  wire clk_reg0_carry__4_n_0;
  wire clk_reg0_carry__4_n_1;
  wire clk_reg0_carry__4_n_2;
  wire clk_reg0_carry__4_n_3;
  wire clk_reg0_carry__5_n_2;
  wire clk_reg0_carry__5_n_3;
  wire clk_reg0_carry_n_0;
  wire clk_reg0_carry_n_1;
  wire clk_reg0_carry_n_2;
  wire clk_reg0_carry_n_3;
  wire \clk_reg[27]_i_10_n_0 ;
  wire \clk_reg[27]_i_1__0_n_0 ;
  wire \clk_reg[27]_i_4_n_0 ;
  wire \clk_reg[27]_i_5__0_n_0 ;
  wire \clk_reg[27]_i_6_n_0 ;
  wire \clk_reg[27]_i_7__0_n_0 ;
  wire \clk_reg[27]_i_8__0_n_0 ;
  wire \clk_reg[27]_i_9__0_n_0 ;
  wire [27:0]clk_reg_0;
  wire [27:1]data0;
  wire \difficulte_mem_reg[0] ;
  wire \difficulte_mem_reg[1] ;
  wire [2:2]p_0_in;
  wire \sec_reg[3]_i_10_n_0 ;
  wire \sec_reg[3]_i_11_n_0 ;
  wire \sec_reg[3]_i_12_n_0 ;
  wire \sec_reg[3]_i_1__0_n_0 ;
  wire \sec_reg[3]_i_5_n_0 ;
  wire \sec_reg[3]_i_6_n_0 ;
  wire \sec_reg[3]_i_7_n_0 ;
  wire \sec_reg[3]_i_9_n_0 ;
  wire \sec_reg_reg[0]_0 ;
  wire \sec_reg_reg[3]_0 ;
  wire [3:2]NLW_clk_reg0_carry__5_CO_UNCONNECTED;
  wire [3:3]NLW_clk_reg0_carry__5_O_UNCONNECTED;

  CARRY4 clk_reg0_carry
       (.CI(1'b0),
        .CO({clk_reg0_carry_n_0,clk_reg0_carry_n_1,clk_reg0_carry_n_2,clk_reg0_carry_n_3}),
        .CYINIT(clk_reg[0]),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(data0[4:1]),
        .S(clk_reg[4:1]));
  CARRY4 clk_reg0_carry__0
       (.CI(clk_reg0_carry_n_0),
        .CO({clk_reg0_carry__0_n_0,clk_reg0_carry__0_n_1,clk_reg0_carry__0_n_2,clk_reg0_carry__0_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(data0[8:5]),
        .S(clk_reg[8:5]));
  CARRY4 clk_reg0_carry__1
       (.CI(clk_reg0_carry__0_n_0),
        .CO({clk_reg0_carry__1_n_0,clk_reg0_carry__1_n_1,clk_reg0_carry__1_n_2,clk_reg0_carry__1_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(data0[12:9]),
        .S(clk_reg[12:9]));
  CARRY4 clk_reg0_carry__2
       (.CI(clk_reg0_carry__1_n_0),
        .CO({clk_reg0_carry__2_n_0,clk_reg0_carry__2_n_1,clk_reg0_carry__2_n_2,clk_reg0_carry__2_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(data0[16:13]),
        .S(clk_reg[16:13]));
  CARRY4 clk_reg0_carry__3
       (.CI(clk_reg0_carry__2_n_0),
        .CO({clk_reg0_carry__3_n_0,clk_reg0_carry__3_n_1,clk_reg0_carry__3_n_2,clk_reg0_carry__3_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(data0[20:17]),
        .S(clk_reg[20:17]));
  CARRY4 clk_reg0_carry__4
       (.CI(clk_reg0_carry__3_n_0),
        .CO({clk_reg0_carry__4_n_0,clk_reg0_carry__4_n_1,clk_reg0_carry__4_n_2,clk_reg0_carry__4_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(data0[24:21]),
        .S(clk_reg[24:21]));
  CARRY4 clk_reg0_carry__5
       (.CI(clk_reg0_carry__4_n_0),
        .CO({NLW_clk_reg0_carry__5_CO_UNCONNECTED[3:2],clk_reg0_carry__5_n_2,clk_reg0_carry__5_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({NLW_clk_reg0_carry__5_O_UNCONNECTED[3],data0[27:25]}),
        .S({1'b0,clk_reg[27:25]}));
  (* SOFT_HLUTNM = "soft_lutpair6" *) 
  LUT1 #(
    .INIT(2'h1)) 
    \clk_reg[0]_i_1__0 
       (.I0(clk_reg[0]),
        .O(clk_reg_0[0]));
  (* SOFT_HLUTNM = "soft_lutpair12" *) 
  LUT4 #(
    .INIT(16'hAA8A)) 
    \clk_reg[10]_i_1 
       (.I0(data0[10]),
        .I1(\clk_reg[27]_i_4_n_0 ),
        .I2(\clk_reg[27]_i_5__0_n_0 ),
        .I3(\clk_reg[27]_i_6_n_0 ),
        .O(clk_reg_0[10]));
  (* SOFT_HLUTNM = "soft_lutpair13" *) 
  LUT4 #(
    .INIT(16'hAA8A)) 
    \clk_reg[11]_i_1 
       (.I0(data0[11]),
        .I1(\clk_reg[27]_i_4_n_0 ),
        .I2(\clk_reg[27]_i_5__0_n_0 ),
        .I3(\clk_reg[27]_i_6_n_0 ),
        .O(clk_reg_0[11]));
  (* SOFT_HLUTNM = "soft_lutpair13" *) 
  LUT4 #(
    .INIT(16'hAA8A)) 
    \clk_reg[12]_i_1 
       (.I0(data0[12]),
        .I1(\clk_reg[27]_i_4_n_0 ),
        .I2(\clk_reg[27]_i_5__0_n_0 ),
        .I3(\clk_reg[27]_i_6_n_0 ),
        .O(clk_reg_0[12]));
  (* SOFT_HLUTNM = "soft_lutpair14" *) 
  LUT4 #(
    .INIT(16'hAA8A)) 
    \clk_reg[13]_i_1 
       (.I0(data0[13]),
        .I1(\clk_reg[27]_i_4_n_0 ),
        .I2(\clk_reg[27]_i_5__0_n_0 ),
        .I3(\clk_reg[27]_i_6_n_0 ),
        .O(clk_reg_0[13]));
  (* SOFT_HLUTNM = "soft_lutpair15" *) 
  LUT4 #(
    .INIT(16'hAA8A)) 
    \clk_reg[14]_i_1 
       (.I0(data0[14]),
        .I1(\clk_reg[27]_i_4_n_0 ),
        .I2(\clk_reg[27]_i_5__0_n_0 ),
        .I3(\clk_reg[27]_i_6_n_0 ),
        .O(clk_reg_0[14]));
  (* SOFT_HLUTNM = "soft_lutpair14" *) 
  LUT4 #(
    .INIT(16'hAA8A)) 
    \clk_reg[15]_i_1 
       (.I0(data0[15]),
        .I1(\clk_reg[27]_i_4_n_0 ),
        .I2(\clk_reg[27]_i_5__0_n_0 ),
        .I3(\clk_reg[27]_i_6_n_0 ),
        .O(clk_reg_0[15]));
  (* SOFT_HLUTNM = "soft_lutpair15" *) 
  LUT4 #(
    .INIT(16'hAA8A)) 
    \clk_reg[16]_i_1 
       (.I0(data0[16]),
        .I1(\clk_reg[27]_i_4_n_0 ),
        .I2(\clk_reg[27]_i_5__0_n_0 ),
        .I3(\clk_reg[27]_i_6_n_0 ),
        .O(clk_reg_0[16]));
  (* SOFT_HLUTNM = "soft_lutpair16" *) 
  LUT4 #(
    .INIT(16'hAA8A)) 
    \clk_reg[17]_i_1 
       (.I0(data0[17]),
        .I1(\clk_reg[27]_i_4_n_0 ),
        .I2(\clk_reg[27]_i_5__0_n_0 ),
        .I3(\clk_reg[27]_i_6_n_0 ),
        .O(clk_reg_0[17]));
  (* SOFT_HLUTNM = "soft_lutpair16" *) 
  LUT4 #(
    .INIT(16'hAA8A)) 
    \clk_reg[18]_i_1 
       (.I0(data0[18]),
        .I1(\clk_reg[27]_i_4_n_0 ),
        .I2(\clk_reg[27]_i_5__0_n_0 ),
        .I3(\clk_reg[27]_i_6_n_0 ),
        .O(clk_reg_0[18]));
  (* SOFT_HLUTNM = "soft_lutpair17" *) 
  LUT4 #(
    .INIT(16'hAA8A)) 
    \clk_reg[19]_i_1 
       (.I0(data0[19]),
        .I1(\clk_reg[27]_i_4_n_0 ),
        .I2(\clk_reg[27]_i_5__0_n_0 ),
        .I3(\clk_reg[27]_i_6_n_0 ),
        .O(clk_reg_0[19]));
  (* SOFT_HLUTNM = "soft_lutpair7" *) 
  LUT4 #(
    .INIT(16'hAA8A)) 
    \clk_reg[1]_i_1 
       (.I0(data0[1]),
        .I1(\clk_reg[27]_i_4_n_0 ),
        .I2(\clk_reg[27]_i_5__0_n_0 ),
        .I3(\clk_reg[27]_i_6_n_0 ),
        .O(clk_reg_0[1]));
  (* SOFT_HLUTNM = "soft_lutpair17" *) 
  LUT4 #(
    .INIT(16'hAA8A)) 
    \clk_reg[20]_i_1 
       (.I0(data0[20]),
        .I1(\clk_reg[27]_i_4_n_0 ),
        .I2(\clk_reg[27]_i_5__0_n_0 ),
        .I3(\clk_reg[27]_i_6_n_0 ),
        .O(clk_reg_0[20]));
  (* SOFT_HLUTNM = "soft_lutpair18" *) 
  LUT4 #(
    .INIT(16'hAA8A)) 
    \clk_reg[21]_i_1 
       (.I0(data0[21]),
        .I1(\clk_reg[27]_i_4_n_0 ),
        .I2(\clk_reg[27]_i_5__0_n_0 ),
        .I3(\clk_reg[27]_i_6_n_0 ),
        .O(clk_reg_0[21]));
  (* SOFT_HLUTNM = "soft_lutpair18" *) 
  LUT4 #(
    .INIT(16'hAA8A)) 
    \clk_reg[22]_i_1 
       (.I0(data0[22]),
        .I1(\clk_reg[27]_i_4_n_0 ),
        .I2(\clk_reg[27]_i_5__0_n_0 ),
        .I3(\clk_reg[27]_i_6_n_0 ),
        .O(clk_reg_0[22]));
  (* SOFT_HLUTNM = "soft_lutpair19" *) 
  LUT4 #(
    .INIT(16'hAA8A)) 
    \clk_reg[23]_i_1 
       (.I0(data0[23]),
        .I1(\clk_reg[27]_i_4_n_0 ),
        .I2(\clk_reg[27]_i_5__0_n_0 ),
        .I3(\clk_reg[27]_i_6_n_0 ),
        .O(clk_reg_0[23]));
  (* SOFT_HLUTNM = "soft_lutpair19" *) 
  LUT4 #(
    .INIT(16'hAA8A)) 
    \clk_reg[24]_i_1 
       (.I0(data0[24]),
        .I1(\clk_reg[27]_i_4_n_0 ),
        .I2(\clk_reg[27]_i_5__0_n_0 ),
        .I3(\clk_reg[27]_i_6_n_0 ),
        .O(clk_reg_0[24]));
  (* SOFT_HLUTNM = "soft_lutpair20" *) 
  LUT4 #(
    .INIT(16'hAA8A)) 
    \clk_reg[25]_i_1 
       (.I0(data0[25]),
        .I1(\clk_reg[27]_i_4_n_0 ),
        .I2(\clk_reg[27]_i_5__0_n_0 ),
        .I3(\clk_reg[27]_i_6_n_0 ),
        .O(clk_reg_0[25]));
  (* SOFT_HLUTNM = "soft_lutpair20" *) 
  LUT4 #(
    .INIT(16'hAA8A)) 
    \clk_reg[26]_i_1 
       (.I0(data0[26]),
        .I1(\clk_reg[27]_i_4_n_0 ),
        .I2(\clk_reg[27]_i_5__0_n_0 ),
        .I3(\clk_reg[27]_i_6_n_0 ),
        .O(clk_reg_0[26]));
  LUT4 #(
    .INIT(16'h7FFF)) 
    \clk_reg[27]_i_10 
       (.I0(clk_reg[2]),
        .I1(clk_reg[3]),
        .I2(clk_reg[15]),
        .I3(clk_reg[14]),
        .O(\clk_reg[27]_i_10_n_0 ));
  LUT6 #(
    .INIT(64'h00010000FFFFFFFF)) 
    \clk_reg[27]_i_1__0 
       (.I0(Q[3]),
        .I1(Q[0]),
        .I2(Q[1]),
        .I3(Q[2]),
        .I4(E),
        .I5(\FSM_sequential_etat_courant_reg[1] ),
        .O(\clk_reg[27]_i_1__0_n_0 ));
  LUT4 #(
    .INIT(16'hAA8A)) 
    \clk_reg[27]_i_3 
       (.I0(data0[27]),
        .I1(\clk_reg[27]_i_4_n_0 ),
        .I2(\clk_reg[27]_i_5__0_n_0 ),
        .I3(\clk_reg[27]_i_6_n_0 ),
        .O(clk_reg_0[27]));
  LUT6 #(
    .INIT(64'hFFFFFFFFBFFFFFFF)) 
    \clk_reg[27]_i_4 
       (.I0(\clk_reg[27]_i_7__0_n_0 ),
        .I1(clk_reg[17]),
        .I2(clk_reg[16]),
        .I3(clk_reg[19]),
        .I4(clk_reg[1]),
        .I5(\clk_reg[27]_i_8__0_n_0 ),
        .O(\clk_reg[27]_i_4_n_0 ));
  LUT5 #(
    .INIT(32'h00000001)) 
    \clk_reg[27]_i_5__0 
       (.I0(clk_reg[13]),
        .I1(clk_reg[12]),
        .I2(clk_reg[20]),
        .I3(clk_reg[18]),
        .I4(\clk_reg[27]_i_9__0_n_0 ),
        .O(\clk_reg[27]_i_5__0_n_0 ));
  LUT5 #(
    .INIT(32'hFFFF7FFF)) 
    \clk_reg[27]_i_6 
       (.I0(clk_reg[5]),
        .I1(clk_reg[4]),
        .I2(clk_reg[8]),
        .I3(clk_reg[6]),
        .I4(\clk_reg[27]_i_10_n_0 ),
        .O(\clk_reg[27]_i_6_n_0 ));
  LUT4 #(
    .INIT(16'h7FFF)) 
    \clk_reg[27]_i_7__0 
       (.I0(clk_reg[21]),
        .I1(clk_reg[0]),
        .I2(clk_reg[23]),
        .I3(clk_reg[22]),
        .O(\clk_reg[27]_i_7__0_n_0 ));
  LUT4 #(
    .INIT(16'h7FFF)) 
    \clk_reg[27]_i_8__0 
       (.I0(clk_reg[25]),
        .I1(clk_reg[24]),
        .I2(clk_reg[7]),
        .I3(clk_reg[27]),
        .O(\clk_reg[27]_i_8__0_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair9" *) 
  LUT4 #(
    .INIT(16'hFFFE)) 
    \clk_reg[27]_i_9__0 
       (.I0(clk_reg[10]),
        .I1(clk_reg[11]),
        .I2(clk_reg[26]),
        .I3(clk_reg[9]),
        .O(\clk_reg[27]_i_9__0_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair8" *) 
  LUT4 #(
    .INIT(16'hAA8A)) 
    \clk_reg[2]_i_1 
       (.I0(data0[2]),
        .I1(\clk_reg[27]_i_4_n_0 ),
        .I2(\clk_reg[27]_i_5__0_n_0 ),
        .I3(\clk_reg[27]_i_6_n_0 ),
        .O(clk_reg_0[2]));
  (* SOFT_HLUTNM = "soft_lutpair8" *) 
  LUT4 #(
    .INIT(16'hAA8A)) 
    \clk_reg[3]_i_1 
       (.I0(data0[3]),
        .I1(\clk_reg[27]_i_4_n_0 ),
        .I2(\clk_reg[27]_i_5__0_n_0 ),
        .I3(\clk_reg[27]_i_6_n_0 ),
        .O(clk_reg_0[3]));
  (* SOFT_HLUTNM = "soft_lutpair7" *) 
  LUT4 #(
    .INIT(16'hAA8A)) 
    \clk_reg[4]_i_1 
       (.I0(data0[4]),
        .I1(\clk_reg[27]_i_4_n_0 ),
        .I2(\clk_reg[27]_i_5__0_n_0 ),
        .I3(\clk_reg[27]_i_6_n_0 ),
        .O(clk_reg_0[4]));
  (* SOFT_HLUTNM = "soft_lutpair10" *) 
  LUT4 #(
    .INIT(16'hAA8A)) 
    \clk_reg[5]_i_1 
       (.I0(data0[5]),
        .I1(\clk_reg[27]_i_4_n_0 ),
        .I2(\clk_reg[27]_i_5__0_n_0 ),
        .I3(\clk_reg[27]_i_6_n_0 ),
        .O(clk_reg_0[5]));
  (* SOFT_HLUTNM = "soft_lutpair11" *) 
  LUT4 #(
    .INIT(16'hAA8A)) 
    \clk_reg[6]_i_1 
       (.I0(data0[6]),
        .I1(\clk_reg[27]_i_4_n_0 ),
        .I2(\clk_reg[27]_i_5__0_n_0 ),
        .I3(\clk_reg[27]_i_6_n_0 ),
        .O(clk_reg_0[6]));
  (* SOFT_HLUTNM = "soft_lutpair12" *) 
  LUT4 #(
    .INIT(16'hAA8A)) 
    \clk_reg[7]_i_1 
       (.I0(data0[7]),
        .I1(\clk_reg[27]_i_4_n_0 ),
        .I2(\clk_reg[27]_i_5__0_n_0 ),
        .I3(\clk_reg[27]_i_6_n_0 ),
        .O(clk_reg_0[7]));
  (* SOFT_HLUTNM = "soft_lutpair10" *) 
  LUT4 #(
    .INIT(16'hAA8A)) 
    \clk_reg[8]_i_1 
       (.I0(data0[8]),
        .I1(\clk_reg[27]_i_4_n_0 ),
        .I2(\clk_reg[27]_i_5__0_n_0 ),
        .I3(\clk_reg[27]_i_6_n_0 ),
        .O(clk_reg_0[8]));
  (* SOFT_HLUTNM = "soft_lutpair11" *) 
  LUT4 #(
    .INIT(16'hAA8A)) 
    \clk_reg[9]_i_1 
       (.I0(data0[9]),
        .I1(\clk_reg[27]_i_4_n_0 ),
        .I2(\clk_reg[27]_i_5__0_n_0 ),
        .I3(\clk_reg[27]_i_6_n_0 ),
        .O(clk_reg_0[9]));
  FDRE #(
    .INIT(1'b0)) 
    \clk_reg_reg[0] 
       (.C(clk),
        .CE(E),
        .D(clk_reg_0[0]),
        .Q(clk_reg[0]),
        .R(\clk_reg[27]_i_1__0_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \clk_reg_reg[10] 
       (.C(clk),
        .CE(E),
        .D(clk_reg_0[10]),
        .Q(clk_reg[10]),
        .R(\clk_reg[27]_i_1__0_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \clk_reg_reg[11] 
       (.C(clk),
        .CE(E),
        .D(clk_reg_0[11]),
        .Q(clk_reg[11]),
        .R(\clk_reg[27]_i_1__0_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \clk_reg_reg[12] 
       (.C(clk),
        .CE(E),
        .D(clk_reg_0[12]),
        .Q(clk_reg[12]),
        .R(\clk_reg[27]_i_1__0_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \clk_reg_reg[13] 
       (.C(clk),
        .CE(E),
        .D(clk_reg_0[13]),
        .Q(clk_reg[13]),
        .R(\clk_reg[27]_i_1__0_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \clk_reg_reg[14] 
       (.C(clk),
        .CE(E),
        .D(clk_reg_0[14]),
        .Q(clk_reg[14]),
        .R(\clk_reg[27]_i_1__0_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \clk_reg_reg[15] 
       (.C(clk),
        .CE(E),
        .D(clk_reg_0[15]),
        .Q(clk_reg[15]),
        .R(\clk_reg[27]_i_1__0_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \clk_reg_reg[16] 
       (.C(clk),
        .CE(E),
        .D(clk_reg_0[16]),
        .Q(clk_reg[16]),
        .R(\clk_reg[27]_i_1__0_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \clk_reg_reg[17] 
       (.C(clk),
        .CE(E),
        .D(clk_reg_0[17]),
        .Q(clk_reg[17]),
        .R(\clk_reg[27]_i_1__0_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \clk_reg_reg[18] 
       (.C(clk),
        .CE(E),
        .D(clk_reg_0[18]),
        .Q(clk_reg[18]),
        .R(\clk_reg[27]_i_1__0_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \clk_reg_reg[19] 
       (.C(clk),
        .CE(E),
        .D(clk_reg_0[19]),
        .Q(clk_reg[19]),
        .R(\clk_reg[27]_i_1__0_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \clk_reg_reg[1] 
       (.C(clk),
        .CE(E),
        .D(clk_reg_0[1]),
        .Q(clk_reg[1]),
        .R(\clk_reg[27]_i_1__0_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \clk_reg_reg[20] 
       (.C(clk),
        .CE(E),
        .D(clk_reg_0[20]),
        .Q(clk_reg[20]),
        .R(\clk_reg[27]_i_1__0_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \clk_reg_reg[21] 
       (.C(clk),
        .CE(E),
        .D(clk_reg_0[21]),
        .Q(clk_reg[21]),
        .R(\clk_reg[27]_i_1__0_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \clk_reg_reg[22] 
       (.C(clk),
        .CE(E),
        .D(clk_reg_0[22]),
        .Q(clk_reg[22]),
        .R(\clk_reg[27]_i_1__0_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \clk_reg_reg[23] 
       (.C(clk),
        .CE(E),
        .D(clk_reg_0[23]),
        .Q(clk_reg[23]),
        .R(\clk_reg[27]_i_1__0_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \clk_reg_reg[24] 
       (.C(clk),
        .CE(E),
        .D(clk_reg_0[24]),
        .Q(clk_reg[24]),
        .R(\clk_reg[27]_i_1__0_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \clk_reg_reg[25] 
       (.C(clk),
        .CE(E),
        .D(clk_reg_0[25]),
        .Q(clk_reg[25]),
        .R(\clk_reg[27]_i_1__0_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \clk_reg_reg[26] 
       (.C(clk),
        .CE(E),
        .D(clk_reg_0[26]),
        .Q(clk_reg[26]),
        .R(\clk_reg[27]_i_1__0_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \clk_reg_reg[27] 
       (.C(clk),
        .CE(E),
        .D(clk_reg_0[27]),
        .Q(clk_reg[27]),
        .R(\clk_reg[27]_i_1__0_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \clk_reg_reg[2] 
       (.C(clk),
        .CE(E),
        .D(clk_reg_0[2]),
        .Q(clk_reg[2]),
        .R(\clk_reg[27]_i_1__0_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \clk_reg_reg[3] 
       (.C(clk),
        .CE(E),
        .D(clk_reg_0[3]),
        .Q(clk_reg[3]),
        .R(\clk_reg[27]_i_1__0_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \clk_reg_reg[4] 
       (.C(clk),
        .CE(E),
        .D(clk_reg_0[4]),
        .Q(clk_reg[4]),
        .R(\clk_reg[27]_i_1__0_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \clk_reg_reg[5] 
       (.C(clk),
        .CE(E),
        .D(clk_reg_0[5]),
        .Q(clk_reg[5]),
        .R(\clk_reg[27]_i_1__0_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \clk_reg_reg[6] 
       (.C(clk),
        .CE(E),
        .D(clk_reg_0[6]),
        .Q(clk_reg[6]),
        .R(\clk_reg[27]_i_1__0_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \clk_reg_reg[7] 
       (.C(clk),
        .CE(E),
        .D(clk_reg_0[7]),
        .Q(clk_reg[7]),
        .R(\clk_reg[27]_i_1__0_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \clk_reg_reg[8] 
       (.C(clk),
        .CE(E),
        .D(clk_reg_0[8]),
        .Q(clk_reg[8]),
        .R(\clk_reg[27]_i_1__0_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \clk_reg_reg[9] 
       (.C(clk),
        .CE(E),
        .D(clk_reg_0[9]),
        .Q(clk_reg[9]),
        .R(\clk_reg[27]_i_1__0_n_0 ));
  LUT6 #(
    .INIT(64'hE100E1FFE1FFE100)) 
    \sec_reg[2]_i_1__0 
       (.I0(Q[0]),
        .I1(Q[1]),
        .I2(Q[2]),
        .I3(\FSM_sequential_etat_courant_reg[1] ),
        .I4(\difficulte_mem_reg[0] ),
        .I5(\difficulte_mem_reg[1] ),
        .O(p_0_in));
  (* SOFT_HLUTNM = "soft_lutpair9" *) 
  LUT4 #(
    .INIT(16'hFFFE)) 
    \sec_reg[3]_i_10 
       (.I0(clk_reg[9]),
        .I1(clk_reg[10]),
        .I2(clk_reg[26]),
        .I3(clk_reg[18]),
        .O(\sec_reg[3]_i_10_n_0 ));
  LUT4 #(
    .INIT(16'h7FFF)) 
    \sec_reg[3]_i_11 
       (.I0(clk_reg[4]),
        .I1(clk_reg[5]),
        .I2(clk_reg[7]),
        .I3(clk_reg[6]),
        .O(\sec_reg[3]_i_11_n_0 ));
  LUT4 #(
    .INIT(16'h7FFF)) 
    \sec_reg[3]_i_12 
       (.I0(clk_reg[22]),
        .I1(clk_reg[21]),
        .I2(clk_reg[15]),
        .I3(clk_reg[14]),
        .O(\sec_reg[3]_i_12_n_0 ));
  LUT6 #(
    .INIT(64'h555555555555555D)) 
    \sec_reg[3]_i_1__0 
       (.I0(\FSM_sequential_etat_courant_reg[1] ),
        .I1(E),
        .I2(\sec_reg_reg[0]_0 ),
        .I3(\sec_reg[3]_i_5_n_0 ),
        .I4(\sec_reg[3]_i_6_n_0 ),
        .I5(\sec_reg[3]_i_7_n_0 ),
        .O(\sec_reg[3]_i_1__0_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair21" *) 
  LUT4 #(
    .INIT(16'h0001)) 
    \sec_reg[3]_i_4 
       (.I0(Q[3]),
        .I1(Q[0]),
        .I2(Q[1]),
        .I3(Q[2]),
        .O(\sec_reg_reg[0]_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFBFFFFFFF)) 
    \sec_reg[3]_i_5 
       (.I0(\sec_reg[3]_i_9_n_0 ),
        .I1(clk_reg[17]),
        .I2(clk_reg[16]),
        .I3(clk_reg[27]),
        .I4(clk_reg[19]),
        .I5(\sec_reg[3]_i_10_n_0 ),
        .O(\sec_reg[3]_i_5_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair6" *) 
  LUT5 #(
    .INIT(32'hFFFF7FFF)) 
    \sec_reg[3]_i_6 
       (.I0(clk_reg[3]),
        .I1(clk_reg[2]),
        .I2(clk_reg[0]),
        .I3(clk_reg[1]),
        .I4(\sec_reg[3]_i_11_n_0 ),
        .O(\sec_reg[3]_i_6_n_0 ));
  LUT5 #(
    .INIT(32'hFFFF7FFF)) 
    \sec_reg[3]_i_7 
       (.I0(clk_reg[23]),
        .I1(clk_reg[24]),
        .I2(clk_reg[8]),
        .I3(clk_reg[25]),
        .I4(\sec_reg[3]_i_12_n_0 ),
        .O(\sec_reg[3]_i_7_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair21" *) 
  LUT3 #(
    .INIT(8'hFE)) 
    \sec_reg[3]_i_8 
       (.I0(Q[2]),
        .I1(Q[1]),
        .I2(Q[0]),
        .O(\sec_reg_reg[3]_0 ));
  LUT4 #(
    .INIT(16'hFFFE)) 
    \sec_reg[3]_i_9 
       (.I0(clk_reg[13]),
        .I1(clk_reg[20]),
        .I2(clk_reg[11]),
        .I3(clk_reg[12]),
        .O(\sec_reg[3]_i_9_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \sec_reg_reg[0] 
       (.C(clk),
        .CE(\sec_reg[3]_i_1__0_n_0 ),
        .D(D[0]),
        .Q(Q[0]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \sec_reg_reg[1] 
       (.C(clk),
        .CE(\sec_reg[3]_i_1__0_n_0 ),
        .D(D[1]),
        .Q(Q[1]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \sec_reg_reg[2] 
       (.C(clk),
        .CE(\sec_reg[3]_i_1__0_n_0 ),
        .D(p_0_in),
        .Q(Q[2]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \sec_reg_reg[3] 
       (.C(clk),
        .CE(\sec_reg[3]_i_1__0_n_0 ),
        .D(D[2]),
        .Q(Q[3]),
        .R(1'b0));
endmodule

(* ORIG_REF_NAME = "sec_counter" *) 
module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_sec_counter_0
   (Q,
    \FSM_sequential_etat_courant_reg[0] ,
    \sec_reg_reg[3]_0 ,
    \FSM_sequential_etat_courant_reg[0]_0 ,
    \clk_reg_reg[1]_0 ,
    flash_on,
    E,
    \FSM_sequential_etat_courant_reg[0]_1 ,
    D,
    \FSM_sequential_etat_courant_reg[0]_2 ,
    out,
    \FSM_sequential_etat_courant_reg[2] ,
    clk,
    \FSM_sequential_etat_courant_reg[0]_3 );
  output [3:0]Q;
  output \FSM_sequential_etat_courant_reg[0] ;
  output \sec_reg_reg[3]_0 ;
  output \FSM_sequential_etat_courant_reg[0]_0 ;
  output \clk_reg_reg[1]_0 ;
  output flash_on;
  input [0:0]E;
  input \FSM_sequential_etat_courant_reg[0]_1 ;
  input [0:0]D;
  input \FSM_sequential_etat_courant_reg[0]_2 ;
  input [2:0]out;
  input \FSM_sequential_etat_courant_reg[2] ;
  input clk;
  input [0:0]\FSM_sequential_etat_courant_reg[0]_3 ;

  wire [0:0]D;
  wire [0:0]E;
  wire \FSM_sequential_etat_courant[4]_i_12_n_0 ;
  wire \FSM_sequential_etat_courant[4]_i_13_n_0 ;
  wire \FSM_sequential_etat_courant[4]_i_14_n_0 ;
  wire \FSM_sequential_etat_courant[4]_i_7_n_0 ;
  wire \FSM_sequential_etat_courant_reg[0] ;
  wire \FSM_sequential_etat_courant_reg[0]_0 ;
  wire \FSM_sequential_etat_courant_reg[0]_1 ;
  wire \FSM_sequential_etat_courant_reg[0]_2 ;
  wire [0:0]\FSM_sequential_etat_courant_reg[0]_3 ;
  wire \FSM_sequential_etat_courant_reg[2] ;
  wire [3:0]Q;
  wire clk;
  wire [27:0]clk_reg;
  wire clk_reg0_carry__0_n_0;
  wire clk_reg0_carry__0_n_1;
  wire clk_reg0_carry__0_n_2;
  wire clk_reg0_carry__0_n_3;
  wire clk_reg0_carry__0_n_4;
  wire clk_reg0_carry__0_n_5;
  wire clk_reg0_carry__0_n_6;
  wire clk_reg0_carry__0_n_7;
  wire clk_reg0_carry__1_n_0;
  wire clk_reg0_carry__1_n_1;
  wire clk_reg0_carry__1_n_2;
  wire clk_reg0_carry__1_n_3;
  wire clk_reg0_carry__1_n_4;
  wire clk_reg0_carry__1_n_5;
  wire clk_reg0_carry__1_n_6;
  wire clk_reg0_carry__1_n_7;
  wire clk_reg0_carry__2_n_0;
  wire clk_reg0_carry__2_n_1;
  wire clk_reg0_carry__2_n_2;
  wire clk_reg0_carry__2_n_3;
  wire clk_reg0_carry__2_n_4;
  wire clk_reg0_carry__2_n_5;
  wire clk_reg0_carry__2_n_6;
  wire clk_reg0_carry__2_n_7;
  wire clk_reg0_carry__3_n_0;
  wire clk_reg0_carry__3_n_1;
  wire clk_reg0_carry__3_n_2;
  wire clk_reg0_carry__3_n_3;
  wire clk_reg0_carry__3_n_4;
  wire clk_reg0_carry__3_n_5;
  wire clk_reg0_carry__3_n_6;
  wire clk_reg0_carry__3_n_7;
  wire clk_reg0_carry__4_n_0;
  wire clk_reg0_carry__4_n_1;
  wire clk_reg0_carry__4_n_2;
  wire clk_reg0_carry__4_n_3;
  wire clk_reg0_carry__4_n_4;
  wire clk_reg0_carry__4_n_5;
  wire clk_reg0_carry__4_n_6;
  wire clk_reg0_carry__4_n_7;
  wire clk_reg0_carry__5_n_2;
  wire clk_reg0_carry__5_n_3;
  wire clk_reg0_carry__5_n_5;
  wire clk_reg0_carry__5_n_6;
  wire clk_reg0_carry__5_n_7;
  wire clk_reg0_carry_n_0;
  wire clk_reg0_carry_n_1;
  wire clk_reg0_carry_n_2;
  wire clk_reg0_carry_n_3;
  wire clk_reg0_carry_n_4;
  wire clk_reg0_carry_n_5;
  wire clk_reg0_carry_n_6;
  wire clk_reg0_carry_n_7;
  wire \clk_reg[27]_i_10__0_n_0 ;
  wire \clk_reg[27]_i_11_n_0 ;
  wire \clk_reg[27]_i_1_n_0 ;
  wire \clk_reg[27]_i_6__0_n_0 ;
  wire \clk_reg[27]_i_7_n_0 ;
  wire \clk_reg[27]_i_8_n_0 ;
  wire \clk_reg[27]_i_9_n_0 ;
  wire \clk_reg_reg[1]_0 ;
  wire \clk_reg_reg_n_0_[0] ;
  wire \clk_reg_reg_n_0_[10] ;
  wire \clk_reg_reg_n_0_[11] ;
  wire \clk_reg_reg_n_0_[12] ;
  wire \clk_reg_reg_n_0_[13] ;
  wire \clk_reg_reg_n_0_[14] ;
  wire \clk_reg_reg_n_0_[15] ;
  wire \clk_reg_reg_n_0_[16] ;
  wire \clk_reg_reg_n_0_[17] ;
  wire \clk_reg_reg_n_0_[18] ;
  wire \clk_reg_reg_n_0_[19] ;
  wire \clk_reg_reg_n_0_[1] ;
  wire \clk_reg_reg_n_0_[20] ;
  wire \clk_reg_reg_n_0_[21] ;
  wire \clk_reg_reg_n_0_[22] ;
  wire \clk_reg_reg_n_0_[23] ;
  wire \clk_reg_reg_n_0_[24] ;
  wire \clk_reg_reg_n_0_[25] ;
  wire \clk_reg_reg_n_0_[26] ;
  wire \clk_reg_reg_n_0_[27] ;
  wire \clk_reg_reg_n_0_[2] ;
  wire \clk_reg_reg_n_0_[3] ;
  wire \clk_reg_reg_n_0_[4] ;
  wire \clk_reg_reg_n_0_[5] ;
  wire \clk_reg_reg_n_0_[6] ;
  wire \clk_reg_reg_n_0_[7] ;
  wire \clk_reg_reg_n_0_[8] ;
  wire \clk_reg_reg_n_0_[9] ;
  wire flash_on;
  wire flash_on_INST_0_i_2_n_0;
  wire flash_on_INST_0_i_3_n_0;
  wire flash_on_INST_0_i_4_n_0;
  wire flash_on_INST_0_i_5_n_0;
  wire flash_on_INST_0_i_6_n_0;
  wire flash_on_INST_0_i_7_n_0;
  wire [2:0]out;
  wire [3:1]p_0_in__0;
  wire \sec_reg_reg[3]_0 ;
  wire [3:2]NLW_clk_reg0_carry__5_CO_UNCONNECTED;
  wire [3:3]NLW_clk_reg0_carry__5_O_UNCONNECTED;

  (* SOFT_HLUTNM = "soft_lutpair24" *) 
  LUT5 #(
    .INIT(32'h7FFFFFFF)) 
    \FSM_sequential_etat_courant[4]_i_12 
       (.I0(\clk_reg_reg_n_0_[24] ),
        .I1(\clk_reg_reg_n_0_[23] ),
        .I2(\clk_reg_reg_n_0_[20] ),
        .I3(\clk_reg_reg_n_0_[21] ),
        .I4(\clk_reg_reg_n_0_[22] ),
        .O(\FSM_sequential_etat_courant[4]_i_12_n_0 ));
  LUT3 #(
    .INIT(8'hEA)) 
    \FSM_sequential_etat_courant[4]_i_13 
       (.I0(\clk_reg_reg_n_0_[19] ),
        .I1(\clk_reg_reg_n_0_[18] ),
        .I2(\clk_reg_reg_n_0_[17] ),
        .O(\FSM_sequential_etat_courant[4]_i_13_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair22" *) 
  LUT5 #(
    .INIT(32'hFFFFFFFE)) 
    \FSM_sequential_etat_courant[4]_i_14 
       (.I0(\clk_reg_reg_n_0_[11] ),
        .I1(\clk_reg_reg_n_0_[12] ),
        .I2(\clk_reg_reg_n_0_[10] ),
        .I3(\clk_reg_reg_n_0_[8] ),
        .I4(\clk_reg_reg_n_0_[9] ),
        .O(\FSM_sequential_etat_courant[4]_i_14_n_0 ));
  LUT6 #(
    .INIT(64'hFF000DFFFFFF0DFF)) 
    \FSM_sequential_etat_courant[4]_i_3 
       (.I0(\clk_reg_reg_n_0_[26] ),
        .I1(\FSM_sequential_etat_courant[4]_i_7_n_0 ),
        .I2(\clk_reg_reg_n_0_[27] ),
        .I3(out[1]),
        .I4(out[0]),
        .I5(\sec_reg_reg[3]_0 ),
        .O(\FSM_sequential_etat_courant_reg[0] ));
  LUT6 #(
    .INIT(64'hFF00F2000000F200)) 
    \FSM_sequential_etat_courant[4]_i_4 
       (.I0(\clk_reg_reg_n_0_[26] ),
        .I1(\FSM_sequential_etat_courant[4]_i_7_n_0 ),
        .I2(\clk_reg_reg_n_0_[27] ),
        .I3(out[2]),
        .I4(\FSM_sequential_etat_courant_reg[2] ),
        .I5(\sec_reg_reg[3]_0 ),
        .O(\FSM_sequential_etat_courant_reg[0]_0 ));
  LUT6 #(
    .INIT(64'h4545450045454545)) 
    \FSM_sequential_etat_courant[4]_i_7 
       (.I0(\clk_reg_reg_n_0_[25] ),
        .I1(\FSM_sequential_etat_courant[4]_i_12_n_0 ),
        .I2(\FSM_sequential_etat_courant[4]_i_13_n_0 ),
        .I3(flash_on_INST_0_i_7_n_0),
        .I4(flash_on_INST_0_i_6_n_0),
        .I5(\FSM_sequential_etat_courant[4]_i_14_n_0 ),
        .O(\FSM_sequential_etat_courant[4]_i_7_n_0 ));
  CARRY4 clk_reg0_carry
       (.CI(1'b0),
        .CO({clk_reg0_carry_n_0,clk_reg0_carry_n_1,clk_reg0_carry_n_2,clk_reg0_carry_n_3}),
        .CYINIT(\clk_reg_reg_n_0_[0] ),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({clk_reg0_carry_n_4,clk_reg0_carry_n_5,clk_reg0_carry_n_6,clk_reg0_carry_n_7}),
        .S({\clk_reg_reg_n_0_[4] ,\clk_reg_reg_n_0_[3] ,\clk_reg_reg_n_0_[2] ,\clk_reg_reg_n_0_[1] }));
  CARRY4 clk_reg0_carry__0
       (.CI(clk_reg0_carry_n_0),
        .CO({clk_reg0_carry__0_n_0,clk_reg0_carry__0_n_1,clk_reg0_carry__0_n_2,clk_reg0_carry__0_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({clk_reg0_carry__0_n_4,clk_reg0_carry__0_n_5,clk_reg0_carry__0_n_6,clk_reg0_carry__0_n_7}),
        .S({\clk_reg_reg_n_0_[8] ,\clk_reg_reg_n_0_[7] ,\clk_reg_reg_n_0_[6] ,\clk_reg_reg_n_0_[5] }));
  CARRY4 clk_reg0_carry__1
       (.CI(clk_reg0_carry__0_n_0),
        .CO({clk_reg0_carry__1_n_0,clk_reg0_carry__1_n_1,clk_reg0_carry__1_n_2,clk_reg0_carry__1_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({clk_reg0_carry__1_n_4,clk_reg0_carry__1_n_5,clk_reg0_carry__1_n_6,clk_reg0_carry__1_n_7}),
        .S({\clk_reg_reg_n_0_[12] ,\clk_reg_reg_n_0_[11] ,\clk_reg_reg_n_0_[10] ,\clk_reg_reg_n_0_[9] }));
  CARRY4 clk_reg0_carry__2
       (.CI(clk_reg0_carry__1_n_0),
        .CO({clk_reg0_carry__2_n_0,clk_reg0_carry__2_n_1,clk_reg0_carry__2_n_2,clk_reg0_carry__2_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({clk_reg0_carry__2_n_4,clk_reg0_carry__2_n_5,clk_reg0_carry__2_n_6,clk_reg0_carry__2_n_7}),
        .S({\clk_reg_reg_n_0_[16] ,\clk_reg_reg_n_0_[15] ,\clk_reg_reg_n_0_[14] ,\clk_reg_reg_n_0_[13] }));
  CARRY4 clk_reg0_carry__3
       (.CI(clk_reg0_carry__2_n_0),
        .CO({clk_reg0_carry__3_n_0,clk_reg0_carry__3_n_1,clk_reg0_carry__3_n_2,clk_reg0_carry__3_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({clk_reg0_carry__3_n_4,clk_reg0_carry__3_n_5,clk_reg0_carry__3_n_6,clk_reg0_carry__3_n_7}),
        .S({\clk_reg_reg_n_0_[20] ,\clk_reg_reg_n_0_[19] ,\clk_reg_reg_n_0_[18] ,\clk_reg_reg_n_0_[17] }));
  CARRY4 clk_reg0_carry__4
       (.CI(clk_reg0_carry__3_n_0),
        .CO({clk_reg0_carry__4_n_0,clk_reg0_carry__4_n_1,clk_reg0_carry__4_n_2,clk_reg0_carry__4_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({clk_reg0_carry__4_n_4,clk_reg0_carry__4_n_5,clk_reg0_carry__4_n_6,clk_reg0_carry__4_n_7}),
        .S({\clk_reg_reg_n_0_[24] ,\clk_reg_reg_n_0_[23] ,\clk_reg_reg_n_0_[22] ,\clk_reg_reg_n_0_[21] }));
  CARRY4 clk_reg0_carry__5
       (.CI(clk_reg0_carry__4_n_0),
        .CO({NLW_clk_reg0_carry__5_CO_UNCONNECTED[3:2],clk_reg0_carry__5_n_2,clk_reg0_carry__5_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({NLW_clk_reg0_carry__5_O_UNCONNECTED[3],clk_reg0_carry__5_n_5,clk_reg0_carry__5_n_6,clk_reg0_carry__5_n_7}),
        .S({1'b0,\clk_reg_reg_n_0_[27] ,\clk_reg_reg_n_0_[26] ,\clk_reg_reg_n_0_[25] }));
  (* SOFT_HLUTNM = "soft_lutpair25" *) 
  LUT1 #(
    .INIT(2'h1)) 
    \clk_reg[0]_i_1 
       (.I0(\clk_reg_reg_n_0_[0] ),
        .O(clk_reg[0]));
  (* SOFT_HLUTNM = "soft_lutpair35" *) 
  LUT2 #(
    .INIT(4'h2)) 
    \clk_reg[10]_i_1__0 
       (.I0(clk_reg0_carry__1_n_6),
        .I1(\clk_reg_reg[1]_0 ),
        .O(clk_reg[10]));
  (* SOFT_HLUTNM = "soft_lutpair36" *) 
  LUT2 #(
    .INIT(4'h2)) 
    \clk_reg[11]_i_1__0 
       (.I0(clk_reg0_carry__1_n_5),
        .I1(\clk_reg_reg[1]_0 ),
        .O(clk_reg[11]));
  (* SOFT_HLUTNM = "soft_lutpair36" *) 
  LUT2 #(
    .INIT(4'h2)) 
    \clk_reg[12]_i_1__0 
       (.I0(clk_reg0_carry__1_n_4),
        .I1(\clk_reg_reg[1]_0 ),
        .O(clk_reg[12]));
  (* SOFT_HLUTNM = "soft_lutpair33" *) 
  LUT2 #(
    .INIT(4'h2)) 
    \clk_reg[13]_i_1__0 
       (.I0(clk_reg0_carry__2_n_7),
        .I1(\clk_reg_reg[1]_0 ),
        .O(clk_reg[13]));
  (* SOFT_HLUTNM = "soft_lutpair31" *) 
  LUT2 #(
    .INIT(4'h2)) 
    \clk_reg[14]_i_1__0 
       (.I0(clk_reg0_carry__2_n_6),
        .I1(\clk_reg_reg[1]_0 ),
        .O(clk_reg[14]));
  (* SOFT_HLUTNM = "soft_lutpair29" *) 
  LUT2 #(
    .INIT(4'h2)) 
    \clk_reg[15]_i_1__0 
       (.I0(clk_reg0_carry__2_n_5),
        .I1(\clk_reg_reg[1]_0 ),
        .O(clk_reg[15]));
  (* SOFT_HLUTNM = "soft_lutpair30" *) 
  LUT2 #(
    .INIT(4'h2)) 
    \clk_reg[16]_i_1__0 
       (.I0(clk_reg0_carry__2_n_4),
        .I1(\clk_reg_reg[1]_0 ),
        .O(clk_reg[16]));
  (* SOFT_HLUTNM = "soft_lutpair27" *) 
  LUT2 #(
    .INIT(4'h2)) 
    \clk_reg[17]_i_1__0 
       (.I0(clk_reg0_carry__3_n_7),
        .I1(\clk_reg_reg[1]_0 ),
        .O(clk_reg[17]));
  (* SOFT_HLUTNM = "soft_lutpair28" *) 
  LUT2 #(
    .INIT(4'h2)) 
    \clk_reg[18]_i_1__0 
       (.I0(clk_reg0_carry__3_n_6),
        .I1(\clk_reg_reg[1]_0 ),
        .O(clk_reg[18]));
  (* SOFT_HLUTNM = "soft_lutpair26" *) 
  LUT2 #(
    .INIT(4'h2)) 
    \clk_reg[19]_i_1__0 
       (.I0(clk_reg0_carry__3_n_5),
        .I1(\clk_reg_reg[1]_0 ),
        .O(clk_reg[19]));
  (* SOFT_HLUTNM = "soft_lutpair26" *) 
  LUT2 #(
    .INIT(4'h2)) 
    \clk_reg[1]_i_1__0 
       (.I0(clk_reg0_carry_n_7),
        .I1(\clk_reg_reg[1]_0 ),
        .O(clk_reg[1]));
  (* SOFT_HLUTNM = "soft_lutpair37" *) 
  LUT2 #(
    .INIT(4'h2)) 
    \clk_reg[20]_i_1__0 
       (.I0(clk_reg0_carry__3_n_4),
        .I1(\clk_reg_reg[1]_0 ),
        .O(clk_reg[20]));
  (* SOFT_HLUTNM = "soft_lutpair38" *) 
  LUT2 #(
    .INIT(4'h2)) 
    \clk_reg[21]_i_1__0 
       (.I0(clk_reg0_carry__4_n_7),
        .I1(\clk_reg_reg[1]_0 ),
        .O(clk_reg[21]));
  (* SOFT_HLUTNM = "soft_lutpair35" *) 
  LUT2 #(
    .INIT(4'h2)) 
    \clk_reg[22]_i_1__0 
       (.I0(clk_reg0_carry__4_n_6),
        .I1(\clk_reg_reg[1]_0 ),
        .O(clk_reg[22]));
  (* SOFT_HLUTNM = "soft_lutpair32" *) 
  LUT2 #(
    .INIT(4'h2)) 
    \clk_reg[23]_i_1__0 
       (.I0(clk_reg0_carry__4_n_5),
        .I1(\clk_reg_reg[1]_0 ),
        .O(clk_reg[23]));
  (* SOFT_HLUTNM = "soft_lutpair37" *) 
  LUT2 #(
    .INIT(4'h2)) 
    \clk_reg[24]_i_1__0 
       (.I0(clk_reg0_carry__4_n_4),
        .I1(\clk_reg_reg[1]_0 ),
        .O(clk_reg[24]));
  (* SOFT_HLUTNM = "soft_lutpair34" *) 
  LUT2 #(
    .INIT(4'h2)) 
    \clk_reg[25]_i_1__0 
       (.I0(clk_reg0_carry__5_n_7),
        .I1(\clk_reg_reg[1]_0 ),
        .O(clk_reg[25]));
  (* SOFT_HLUTNM = "soft_lutpair38" *) 
  LUT2 #(
    .INIT(4'h2)) 
    \clk_reg[26]_i_1__0 
       (.I0(clk_reg0_carry__5_n_6),
        .I1(\clk_reg_reg[1]_0 ),
        .O(clk_reg[26]));
  LUT6 #(
    .INIT(64'h00010000FFFFFFFF)) 
    \clk_reg[27]_i_1 
       (.I0(Q[3]),
        .I1(Q[0]),
        .I2(Q[1]),
        .I3(Q[2]),
        .I4(E),
        .I5(\FSM_sequential_etat_courant_reg[0]_1 ),
        .O(\clk_reg[27]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair25" *) 
  LUT4 #(
    .INIT(16'hFF7F)) 
    \clk_reg[27]_i_10__0 
       (.I0(\clk_reg_reg_n_0_[27] ),
        .I1(\clk_reg_reg_n_0_[0] ),
        .I2(\clk_reg_reg_n_0_[16] ),
        .I3(\clk_reg_reg_n_0_[10] ),
        .O(\clk_reg[27]_i_10__0_n_0 ));
  LUT4 #(
    .INIT(16'hFFDF)) 
    \clk_reg[27]_i_11 
       (.I0(\clk_reg_reg_n_0_[5] ),
        .I1(\clk_reg_reg_n_0_[9] ),
        .I2(\clk_reg_reg_n_0_[17] ),
        .I3(\clk_reg_reg_n_0_[26] ),
        .O(\clk_reg[27]_i_11_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \clk_reg[27]_i_3__0 
       (.I0(clk_reg0_carry__5_n_5),
        .I1(\clk_reg_reg[1]_0 ),
        .O(clk_reg[27]));
  LUT6 #(
    .INIT(64'h0000000000000002)) 
    \clk_reg[27]_i_5 
       (.I0(\clk_reg[27]_i_6__0_n_0 ),
        .I1(\clk_reg[27]_i_7_n_0 ),
        .I2(\clk_reg[27]_i_8_n_0 ),
        .I3(\clk_reg[27]_i_9_n_0 ),
        .I4(\clk_reg_reg_n_0_[12] ),
        .I5(\clk_reg_reg_n_0_[11] ),
        .O(\clk_reg_reg[1]_0 ));
  LUT6 #(
    .INIT(64'h0000000000004000)) 
    \clk_reg[27]_i_6__0 
       (.I0(\clk_reg[27]_i_10__0_n_0 ),
        .I1(\clk_reg_reg_n_0_[6] ),
        .I2(\clk_reg_reg_n_0_[8] ),
        .I3(\clk_reg_reg_n_0_[2] ),
        .I4(\clk_reg_reg_n_0_[13] ),
        .I5(flash_on_INST_0_i_7_n_0),
        .O(\clk_reg[27]_i_6__0_n_0 ));
  LUT5 #(
    .INIT(32'hFFFFBFFF)) 
    \clk_reg[27]_i_7 
       (.I0(\clk_reg_reg_n_0_[18] ),
        .I1(\clk_reg_reg_n_0_[25] ),
        .I2(\clk_reg_reg_n_0_[4] ),
        .I3(\clk_reg_reg_n_0_[1] ),
        .I4(\clk_reg[27]_i_11_n_0 ),
        .O(\clk_reg[27]_i_7_n_0 ));
  LUT4 #(
    .INIT(16'hFF7F)) 
    \clk_reg[27]_i_8 
       (.I0(\clk_reg_reg_n_0_[7] ),
        .I1(\clk_reg_reg_n_0_[3] ),
        .I2(\clk_reg_reg_n_0_[19] ),
        .I3(\clk_reg_reg_n_0_[20] ),
        .O(\clk_reg[27]_i_8_n_0 ));
  LUT2 #(
    .INIT(4'h7)) 
    \clk_reg[27]_i_9 
       (.I0(\clk_reg_reg_n_0_[21] ),
        .I1(\clk_reg_reg_n_0_[22] ),
        .O(\clk_reg[27]_i_9_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair27" *) 
  LUT2 #(
    .INIT(4'h2)) 
    \clk_reg[2]_i_1__0 
       (.I0(clk_reg0_carry_n_6),
        .I1(\clk_reg_reg[1]_0 ),
        .O(clk_reg[2]));
  (* SOFT_HLUTNM = "soft_lutpair28" *) 
  LUT2 #(
    .INIT(4'h2)) 
    \clk_reg[3]_i_1__0 
       (.I0(clk_reg0_carry_n_5),
        .I1(\clk_reg_reg[1]_0 ),
        .O(clk_reg[3]));
  (* SOFT_HLUTNM = "soft_lutpair29" *) 
  LUT2 #(
    .INIT(4'h2)) 
    \clk_reg[4]_i_1__0 
       (.I0(clk_reg0_carry_n_4),
        .I1(\clk_reg_reg[1]_0 ),
        .O(clk_reg[4]));
  (* SOFT_HLUTNM = "soft_lutpair30" *) 
  LUT2 #(
    .INIT(4'h2)) 
    \clk_reg[5]_i_1__0 
       (.I0(clk_reg0_carry__0_n_7),
        .I1(\clk_reg_reg[1]_0 ),
        .O(clk_reg[5]));
  (* SOFT_HLUTNM = "soft_lutpair31" *) 
  LUT2 #(
    .INIT(4'h2)) 
    \clk_reg[6]_i_1__0 
       (.I0(clk_reg0_carry__0_n_6),
        .I1(\clk_reg_reg[1]_0 ),
        .O(clk_reg[6]));
  (* SOFT_HLUTNM = "soft_lutpair32" *) 
  LUT2 #(
    .INIT(4'h2)) 
    \clk_reg[7]_i_1__0 
       (.I0(clk_reg0_carry__0_n_5),
        .I1(\clk_reg_reg[1]_0 ),
        .O(clk_reg[7]));
  (* SOFT_HLUTNM = "soft_lutpair33" *) 
  LUT2 #(
    .INIT(4'h2)) 
    \clk_reg[8]_i_1__0 
       (.I0(clk_reg0_carry__0_n_4),
        .I1(\clk_reg_reg[1]_0 ),
        .O(clk_reg[8]));
  (* SOFT_HLUTNM = "soft_lutpair34" *) 
  LUT2 #(
    .INIT(4'h2)) 
    \clk_reg[9]_i_1__0 
       (.I0(clk_reg0_carry__1_n_7),
        .I1(\clk_reg_reg[1]_0 ),
        .O(clk_reg[9]));
  FDRE #(
    .INIT(1'b0)) 
    \clk_reg_reg[0] 
       (.C(clk),
        .CE(E),
        .D(clk_reg[0]),
        .Q(\clk_reg_reg_n_0_[0] ),
        .R(\clk_reg[27]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \clk_reg_reg[10] 
       (.C(clk),
        .CE(E),
        .D(clk_reg[10]),
        .Q(\clk_reg_reg_n_0_[10] ),
        .R(\clk_reg[27]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \clk_reg_reg[11] 
       (.C(clk),
        .CE(E),
        .D(clk_reg[11]),
        .Q(\clk_reg_reg_n_0_[11] ),
        .R(\clk_reg[27]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \clk_reg_reg[12] 
       (.C(clk),
        .CE(E),
        .D(clk_reg[12]),
        .Q(\clk_reg_reg_n_0_[12] ),
        .R(\clk_reg[27]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \clk_reg_reg[13] 
       (.C(clk),
        .CE(E),
        .D(clk_reg[13]),
        .Q(\clk_reg_reg_n_0_[13] ),
        .R(\clk_reg[27]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \clk_reg_reg[14] 
       (.C(clk),
        .CE(E),
        .D(clk_reg[14]),
        .Q(\clk_reg_reg_n_0_[14] ),
        .R(\clk_reg[27]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \clk_reg_reg[15] 
       (.C(clk),
        .CE(E),
        .D(clk_reg[15]),
        .Q(\clk_reg_reg_n_0_[15] ),
        .R(\clk_reg[27]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \clk_reg_reg[16] 
       (.C(clk),
        .CE(E),
        .D(clk_reg[16]),
        .Q(\clk_reg_reg_n_0_[16] ),
        .R(\clk_reg[27]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \clk_reg_reg[17] 
       (.C(clk),
        .CE(E),
        .D(clk_reg[17]),
        .Q(\clk_reg_reg_n_0_[17] ),
        .R(\clk_reg[27]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \clk_reg_reg[18] 
       (.C(clk),
        .CE(E),
        .D(clk_reg[18]),
        .Q(\clk_reg_reg_n_0_[18] ),
        .R(\clk_reg[27]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \clk_reg_reg[19] 
       (.C(clk),
        .CE(E),
        .D(clk_reg[19]),
        .Q(\clk_reg_reg_n_0_[19] ),
        .R(\clk_reg[27]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \clk_reg_reg[1] 
       (.C(clk),
        .CE(E),
        .D(clk_reg[1]),
        .Q(\clk_reg_reg_n_0_[1] ),
        .R(\clk_reg[27]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \clk_reg_reg[20] 
       (.C(clk),
        .CE(E),
        .D(clk_reg[20]),
        .Q(\clk_reg_reg_n_0_[20] ),
        .R(\clk_reg[27]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \clk_reg_reg[21] 
       (.C(clk),
        .CE(E),
        .D(clk_reg[21]),
        .Q(\clk_reg_reg_n_0_[21] ),
        .R(\clk_reg[27]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \clk_reg_reg[22] 
       (.C(clk),
        .CE(E),
        .D(clk_reg[22]),
        .Q(\clk_reg_reg_n_0_[22] ),
        .R(\clk_reg[27]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \clk_reg_reg[23] 
       (.C(clk),
        .CE(E),
        .D(clk_reg[23]),
        .Q(\clk_reg_reg_n_0_[23] ),
        .R(\clk_reg[27]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \clk_reg_reg[24] 
       (.C(clk),
        .CE(E),
        .D(clk_reg[24]),
        .Q(\clk_reg_reg_n_0_[24] ),
        .R(\clk_reg[27]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \clk_reg_reg[25] 
       (.C(clk),
        .CE(E),
        .D(clk_reg[25]),
        .Q(\clk_reg_reg_n_0_[25] ),
        .R(\clk_reg[27]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \clk_reg_reg[26] 
       (.C(clk),
        .CE(E),
        .D(clk_reg[26]),
        .Q(\clk_reg_reg_n_0_[26] ),
        .R(\clk_reg[27]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \clk_reg_reg[27] 
       (.C(clk),
        .CE(E),
        .D(clk_reg[27]),
        .Q(\clk_reg_reg_n_0_[27] ),
        .R(\clk_reg[27]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \clk_reg_reg[2] 
       (.C(clk),
        .CE(E),
        .D(clk_reg[2]),
        .Q(\clk_reg_reg_n_0_[2] ),
        .R(\clk_reg[27]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \clk_reg_reg[3] 
       (.C(clk),
        .CE(E),
        .D(clk_reg[3]),
        .Q(\clk_reg_reg_n_0_[3] ),
        .R(\clk_reg[27]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \clk_reg_reg[4] 
       (.C(clk),
        .CE(E),
        .D(clk_reg[4]),
        .Q(\clk_reg_reg_n_0_[4] ),
        .R(\clk_reg[27]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \clk_reg_reg[5] 
       (.C(clk),
        .CE(E),
        .D(clk_reg[5]),
        .Q(\clk_reg_reg_n_0_[5] ),
        .R(\clk_reg[27]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \clk_reg_reg[6] 
       (.C(clk),
        .CE(E),
        .D(clk_reg[6]),
        .Q(\clk_reg_reg_n_0_[6] ),
        .R(\clk_reg[27]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \clk_reg_reg[7] 
       (.C(clk),
        .CE(E),
        .D(clk_reg[7]),
        .Q(\clk_reg_reg_n_0_[7] ),
        .R(\clk_reg[27]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \clk_reg_reg[8] 
       (.C(clk),
        .CE(E),
        .D(clk_reg[8]),
        .Q(\clk_reg_reg_n_0_[8] ),
        .R(\clk_reg[27]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \clk_reg_reg[9] 
       (.C(clk),
        .CE(E),
        .D(clk_reg[9]),
        .Q(\clk_reg_reg_n_0_[9] ),
        .R(\clk_reg[27]_i_1_n_0 ));
  LUT5 #(
    .INIT(32'h00005575)) 
    flash_on_INST_0_i_1
       (.I0(\clk_reg_reg_n_0_[26] ),
        .I1(\clk_reg_reg_n_0_[25] ),
        .I2(flash_on_INST_0_i_2_n_0),
        .I3(flash_on_INST_0_i_3_n_0),
        .I4(\clk_reg_reg_n_0_[27] ),
        .O(flash_on));
  LUT6 #(
    .INIT(64'hBFBFBFBFBFFFFFFF)) 
    flash_on_INST_0_i_2
       (.I0(flash_on_INST_0_i_4_n_0),
        .I1(\clk_reg_reg_n_0_[23] ),
        .I2(\clk_reg_reg_n_0_[24] ),
        .I3(\clk_reg_reg_n_0_[17] ),
        .I4(\clk_reg_reg_n_0_[18] ),
        .I5(\clk_reg_reg_n_0_[19] ),
        .O(flash_on_INST_0_i_2_n_0));
  LUT6 #(
    .INIT(64'h000000000000FFFE)) 
    flash_on_INST_0_i_3
       (.I0(\clk_reg_reg_n_0_[9] ),
        .I1(\clk_reg_reg_n_0_[8] ),
        .I2(\clk_reg_reg_n_0_[10] ),
        .I3(flash_on_INST_0_i_5_n_0),
        .I4(flash_on_INST_0_i_6_n_0),
        .I5(flash_on_INST_0_i_7_n_0),
        .O(flash_on_INST_0_i_3_n_0));
  (* SOFT_HLUTNM = "soft_lutpair24" *) 
  LUT3 #(
    .INIT(8'h7F)) 
    flash_on_INST_0_i_4
       (.I0(\clk_reg_reg_n_0_[22] ),
        .I1(\clk_reg_reg_n_0_[21] ),
        .I2(\clk_reg_reg_n_0_[20] ),
        .O(flash_on_INST_0_i_4_n_0));
  (* SOFT_HLUTNM = "soft_lutpair22" *) 
  LUT2 #(
    .INIT(4'hE)) 
    flash_on_INST_0_i_5
       (.I0(\clk_reg_reg_n_0_[12] ),
        .I1(\clk_reg_reg_n_0_[11] ),
        .O(flash_on_INST_0_i_5_n_0));
  LUT6 #(
    .INIT(64'h7FFFFFFFFFFFFFFF)) 
    flash_on_INST_0_i_6
       (.I0(\clk_reg_reg_n_0_[20] ),
        .I1(\clk_reg_reg_n_0_[21] ),
        .I2(\clk_reg_reg_n_0_[22] ),
        .I3(\clk_reg_reg_n_0_[16] ),
        .I4(\clk_reg_reg_n_0_[18] ),
        .I5(\clk_reg_reg_n_0_[13] ),
        .O(flash_on_INST_0_i_6_n_0));
  LUT4 #(
    .INIT(16'h7FFF)) 
    flash_on_INST_0_i_7
       (.I0(\clk_reg_reg_n_0_[24] ),
        .I1(\clk_reg_reg_n_0_[23] ),
        .I2(\clk_reg_reg_n_0_[15] ),
        .I3(\clk_reg_reg_n_0_[14] ),
        .O(flash_on_INST_0_i_7_n_0));
  LUT4 #(
    .INIT(16'h9F90)) 
    \sec_reg[1]_i_1 
       (.I0(Q[0]),
        .I1(Q[1]),
        .I2(\FSM_sequential_etat_courant_reg[0]_1 ),
        .I3(\FSM_sequential_etat_courant_reg[0]_2 ),
        .O(p_0_in__0[1]));
  (* SOFT_HLUTNM = "soft_lutpair23" *) 
  LUT4 #(
    .INIT(16'hA802)) 
    \sec_reg[2]_i_1 
       (.I0(\FSM_sequential_etat_courant_reg[0]_1 ),
        .I1(Q[0]),
        .I2(Q[1]),
        .I3(Q[2]),
        .O(p_0_in__0[2]));
  (* SOFT_HLUTNM = "soft_lutpair23" *) 
  LUT5 #(
    .INIT(32'hAAA80002)) 
    \sec_reg[3]_i_2 
       (.I0(\FSM_sequential_etat_courant_reg[0]_1 ),
        .I1(Q[2]),
        .I2(Q[1]),
        .I3(Q[0]),
        .I4(Q[3]),
        .O(p_0_in__0[3]));
  LUT4 #(
    .INIT(16'h0001)) 
    \sec_reg[3]_i_3 
       (.I0(Q[3]),
        .I1(Q[0]),
        .I2(Q[1]),
        .I3(Q[2]),
        .O(\sec_reg_reg[3]_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \sec_reg_reg[0] 
       (.C(clk),
        .CE(\FSM_sequential_etat_courant_reg[0]_3 ),
        .D(D),
        .Q(Q[0]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \sec_reg_reg[1] 
       (.C(clk),
        .CE(\FSM_sequential_etat_courant_reg[0]_3 ),
        .D(p_0_in__0[1]),
        .Q(Q[1]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \sec_reg_reg[2] 
       (.C(clk),
        .CE(\FSM_sequential_etat_courant_reg[0]_3 ),
        .D(p_0_in__0[2]),
        .Q(Q[2]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \sec_reg_reg[3] 
       (.C(clk),
        .CE(\FSM_sequential_etat_courant_reg[0]_3 ),
        .D(p_0_in__0[3]),
        .Q(Q[3]),
        .R(1'b0));
endmodule
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

endmodule
`endif
