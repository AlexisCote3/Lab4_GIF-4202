-- Copyright 1986-2018 Xilinx, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2018.2.1 (win64) Build 2288692 Thu Jul 26 18:24:02 MDT 2018
-- Date        : Mon Nov 23 17:53:06 2026
-- Host        : pcetu-136 running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode synth_stub -rename_top decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix -prefix
--               decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_ HDMI_bd_compositeur_0_0_stub.vhdl
-- Design      : HDMI_bd_compositeur_0_0
-- Purpose     : Stub declaration of top-level module interface
-- Device      : xc7z020clg400-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix is
  Port ( 
    pixel_clk : in STD_LOGIC;
    reset : in STD_LOGIC;
    rgb_in : in STD_LOGIC_VECTOR ( 23 downto 0 );
    de_in : in STD_LOGIC;
    hsync_in : in STD_LOGIC;
    vsync_in : in STD_LOGIC;
    pixel_x : in STD_LOGIC_VECTOR ( 11 downto 0 );
    pixel_y : in STD_LOGIC_VECTOR ( 11 downto 0 );
    is_pixel_mur : in STD_LOGIC;
    is_pixel_joueur : in STD_LOGIC;
    mode_ui : in STD_LOGIC_VECTOR ( 2 downto 0 );
    decompte_ui : in STD_LOGIC_VECTOR ( 3 downto 0 );
    flash_on : in STD_LOGIC;
    score_courant : in STD_LOGIC_VECTOR ( 3 downto 0 );
    temps_restant : in STD_LOGIC_VECTOR ( 3 downto 0 );
    score_dernier : in STD_LOGIC_VECTOR ( 3 downto 0 );
    record_personnel : in STD_LOGIC_VECTOR ( 3 downto 0 );
    rgb_out : out STD_LOGIC_VECTOR ( 23 downto 0 );
    de_out : out STD_LOGIC;
    hsync_out : out STD_LOGIC;
    vsync_out : out STD_LOGIC
  );

end decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix;

architecture stub of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix is
attribute syn_black_box : boolean;
attribute black_box_pad_pin : string;
attribute syn_black_box of stub : architecture is true;
attribute black_box_pad_pin of stub : architecture is "pixel_clk,reset,rgb_in[23:0],de_in,hsync_in,vsync_in,pixel_x[11:0],pixel_y[11:0],is_pixel_mur,is_pixel_joueur,mode_ui[2:0],decompte_ui[3:0],flash_on,score_courant[3:0],temps_restant[3:0],score_dernier[3:0],record_personnel[3:0],rgb_out[23:0],de_out,hsync_out,vsync_out";
attribute x_core_info : string;
attribute x_core_info of stub : architecture is "compositeur,Vivado 2018.2.1";
begin
end;
