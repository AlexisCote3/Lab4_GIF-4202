// Copyright 1986-2018 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2018.2.1 (win64) Build 2288692 Thu Jul 26 18:24:02 MDT 2018
// Date        : Mon Nov 23 17:53:06 2026
// Host        : pcetu-136 running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode funcsim -rename_top decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix -prefix
//               decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_ HDMI_bd_compositeur_0_0_sim_netlist.v
// Design      : HDMI_bd_compositeur_0_0
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7z020clg400-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CHECK_LICENSE_TYPE = "HDMI_bd_compositeur_0_0,compositeur,{}" *) (* downgradeipidentifiedwarnings = "yes" *) (* ip_definition_source = "module_ref" *) 
(* x_core_info = "compositeur,Vivado 2018.2.1" *) 
(* NotValidForBitStream *)
module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix
   (pixel_clk,
    reset,
    rgb_in,
    de_in,
    hsync_in,
    vsync_in,
    pixel_x,
    pixel_y,
    is_pixel_mur,
    is_pixel_joueur,
    mode_ui,
    decompte_ui,
    flash_on,
    score_courant,
    temps_restant,
    score_dernier,
    record_personnel,
    rgb_out,
    de_out,
    hsync_out,
    vsync_out);
  (* x_interface_info = "xilinx.com:signal:clock:1.0 pixel_clk CLK" *) (* x_interface_parameter = "XIL_INTERFACENAME pixel_clk, ASSOCIATED_RESET reset, FREQ_HZ 100000000, PHASE 0.000, CLK_DOMAIN HDMI_bd_dvi2rgb_0_0_PixelClk" *) input pixel_clk;
  (* x_interface_info = "xilinx.com:signal:reset:1.0 reset RST" *) (* x_interface_parameter = "XIL_INTERFACENAME reset, POLARITY ACTIVE_HIGH" *) input reset;
  input [23:0]rgb_in;
  input de_in;
  input hsync_in;
  input vsync_in;
  input [11:0]pixel_x;
  input [11:0]pixel_y;
  input is_pixel_mur;
  input is_pixel_joueur;
  input [2:0]mode_ui;
  input [3:0]decompte_ui;
  input flash_on;
  input [3:0]score_courant;
  input [3:0]temps_restant;
  input [3:0]score_dernier;
  input [3:0]record_personnel;
  output [23:0]rgb_out;
  output de_out;
  output hsync_out;
  output vsync_out;

  wire [12:1]\LAST_D/local_x ;
  wire [12:1]\LAST_D/local_y ;
  wire \LAST_D/pixel_on2 ;
  wire \LAST_D/pixel_on3 ;
  wire \LAST_D/pixel_on4 ;
  wire \LAST_D/pixel_on40_in ;
  wire \LAST_D/pixel_on5 ;
  wire \LAST_D/pixel_on6 ;
  wire \LAST_D/pixel_on66_in ;
  wire \LAST_D/pixel_on7 ;
  wire \LAST_D/pixel_on712_in ;
  wire \LAST_D/pixel_on75_in ;
  wire \LAST_D/pixel_on8 ;
  wire \LAST_D/pixel_on83_in ;
  wire \LAST_D/pixel_on9 ;
  wire \LAST_D/pixel_on99_in ;
  wire [12:1]\LAST_U/local_x ;
  wire [12:1]\LAST_U/local_y ;
  wire \LAST_U/pixel_on2 ;
  wire \LAST_U/pixel_on22_in ;
  wire \LAST_U/pixel_on3 ;
  wire \LAST_U/pixel_on31_in ;
  wire \LAST_U/pixel_on4 ;
  wire \LAST_U/pixel_on40_in ;
  wire \LAST_U/pixel_on5 ;
  wire \LAST_U/pixel_on6 ;
  wire \LAST_U/pixel_on66_in ;
  wire \LAST_U/pixel_on7 ;
  wire \LAST_U/pixel_on712_in ;
  wire \LAST_U/pixel_on75_in ;
  wire \LAST_U/pixel_on8 ;
  wire \LAST_U/pixel_on83_in ;
  wire \LAST_U/pixel_on9 ;
  wire \LAST_U/pixel_on99_in ;
  wire [12:1]\REC_D/local_x ;
  wire [12:1]\REC_D/local_y ;
  wire \REC_D/pixel_on2 ;
  wire \REC_D/pixel_on3 ;
  wire \REC_D/pixel_on4 ;
  wire \REC_D/pixel_on40_in ;
  wire \REC_D/pixel_on5 ;
  wire \REC_D/pixel_on6 ;
  wire \REC_D/pixel_on66_in ;
  wire \REC_D/pixel_on7 ;
  wire \REC_D/pixel_on712_in ;
  wire \REC_D/pixel_on75_in ;
  wire \REC_D/pixel_on8 ;
  wire \REC_D/pixel_on83_in ;
  wire \REC_D/pixel_on9 ;
  wire \REC_D/pixel_on99_in ;
  wire [12:1]\REC_U/local_x ;
  wire [12:1]\REC_U/local_y ;
  wire \REC_U/pixel_on2 ;
  wire \REC_U/pixel_on22_in ;
  wire \REC_U/pixel_on3 ;
  wire \REC_U/pixel_on31_in ;
  wire \REC_U/pixel_on4 ;
  wire \REC_U/pixel_on40_in ;
  wire \REC_U/pixel_on5 ;
  wire \REC_U/pixel_on6 ;
  wire \REC_U/pixel_on66_in ;
  wire \REC_U/pixel_on7 ;
  wire \REC_U/pixel_on712_in ;
  wire \REC_U/pixel_on75_in ;
  wire \REC_U/pixel_on8 ;
  wire \REC_U/pixel_on83_in ;
  wire \REC_U/pixel_on9 ;
  wire \REC_U/pixel_on99_in ;
  wire [12:0]\SC_D/local_x ;
  wire [12:1]\SC_D/local_y ;
  wire \SC_D/pixel_on2 ;
  wire \SC_D/pixel_on3 ;
  wire \SC_D/pixel_on4 ;
  wire \SC_D/pixel_on40_in ;
  wire \SC_D/pixel_on5 ;
  wire \SC_D/pixel_on6 ;
  wire \SC_D/pixel_on712_in ;
  wire \SC_D/pixel_on75_in ;
  wire \SC_D/pixel_on8 ;
  wire \SC_D/pixel_on99_in ;
  wire [12:0]\SC_U/local_x ;
  wire [12:1]\SC_U/local_y ;
  wire \SC_U/pixel_on2 ;
  wire \SC_U/pixel_on22_in ;
  wire \SC_U/pixel_on3 ;
  wire \SC_U/pixel_on31_in ;
  wire \SC_U/pixel_on4 ;
  wire \SC_U/pixel_on40_in ;
  wire \SC_U/pixel_on5 ;
  wire \SC_U/pixel_on6 ;
  wire \SC_U/pixel_on66_in ;
  wire \SC_U/pixel_on7 ;
  wire \SC_U/pixel_on712_in ;
  wire \SC_U/pixel_on75_in ;
  wire \SC_U/pixel_on8 ;
  wire \SC_U/pixel_on83_in ;
  wire \SC_U/pixel_on99_in ;
  wire [12:2]\TM_D/local_x ;
  wire [12:1]\TM_D/local_y ;
  wire \TM_D/pixel_on2 ;
  wire \TM_D/pixel_on3 ;
  wire \TM_D/pixel_on4 ;
  wire \TM_D/pixel_on40_in ;
  wire \TM_D/pixel_on5 ;
  wire \TM_D/pixel_on6 ;
  wire \TM_D/pixel_on66_in ;
  wire \TM_D/pixel_on7 ;
  wire \TM_D/pixel_on712_in ;
  wire \TM_D/pixel_on75_in ;
  wire \TM_D/pixel_on8 ;
  wire \TM_D/pixel_on83_in ;
  wire \TM_D/pixel_on99_in ;
  wire U0_n_0;
  wire U0_n_15;
  wire de_in;
  wire de_out;
  wire [3:0]decompte_ui;
  wire flash_on;
  wire hsync_in;
  wire hsync_out;
  wire is_pixel_mur;
  wire [2:0]mode_ui;
  wire pixel_clk;
  wire [11:0]pixel_x;
  wire [11:0]pixel_y;
  wire [3:0]record_personnel;
  wire reset;
  wire [23:0]rgb_in;
  wire [23:0]rgb_out;
  wire \rgb_out[23]_i_1003_n_0 ;
  wire \rgb_out[23]_i_1004_n_0 ;
  wire \rgb_out[23]_i_1005_n_0 ;
  wire \rgb_out[23]_i_1006_n_0 ;
  wire \rgb_out[23]_i_1008_n_0 ;
  wire \rgb_out[23]_i_1009_n_0 ;
  wire \rgb_out[23]_i_1010_n_0 ;
  wire \rgb_out[23]_i_1011_n_0 ;
  wire \rgb_out[23]_i_1013_n_0 ;
  wire \rgb_out[23]_i_1014_n_0 ;
  wire \rgb_out[23]_i_1015_n_0 ;
  wire \rgb_out[23]_i_1017_n_0 ;
  wire \rgb_out[23]_i_1018_n_0 ;
  wire \rgb_out[23]_i_1019_n_0 ;
  wire \rgb_out[23]_i_1020_n_0 ;
  wire \rgb_out[23]_i_1022_n_0 ;
  wire \rgb_out[23]_i_1023_n_0 ;
  wire \rgb_out[23]_i_1024_n_0 ;
  wire \rgb_out[23]_i_1026_n_0 ;
  wire \rgb_out[23]_i_1027_n_0 ;
  wire \rgb_out[23]_i_1028_n_0 ;
  wire \rgb_out[23]_i_1029_n_0 ;
  wire \rgb_out[23]_i_1031_n_0 ;
  wire \rgb_out[23]_i_1032_n_0 ;
  wire \rgb_out[23]_i_1033_n_0 ;
  wire \rgb_out[23]_i_1035_n_0 ;
  wire \rgb_out[23]_i_1036_n_0 ;
  wire \rgb_out[23]_i_1037_n_0 ;
  wire \rgb_out[23]_i_1038_n_0 ;
  wire \rgb_out[23]_i_1040_n_0 ;
  wire \rgb_out[23]_i_1041_n_0 ;
  wire \rgb_out[23]_i_1042_n_0 ;
  wire \rgb_out[23]_i_1043_n_0 ;
  wire \rgb_out[23]_i_1045_n_0 ;
  wire \rgb_out[23]_i_1046_n_0 ;
  wire \rgb_out[23]_i_1047_n_0 ;
  wire \rgb_out[23]_i_1049_n_0 ;
  wire \rgb_out[23]_i_1050_n_0 ;
  wire \rgb_out[23]_i_1051_n_0 ;
  wire \rgb_out[23]_i_1053_n_0 ;
  wire \rgb_out[23]_i_1054_n_0 ;
  wire \rgb_out[23]_i_1055_n_0 ;
  wire \rgb_out[23]_i_1057_n_0 ;
  wire \rgb_out[23]_i_1058_n_0 ;
  wire \rgb_out[23]_i_1059_n_0 ;
  wire \rgb_out[23]_i_1060_n_0 ;
  wire \rgb_out[23]_i_1062_n_0 ;
  wire \rgb_out[23]_i_1063_n_0 ;
  wire \rgb_out[23]_i_1064_n_0 ;
  wire \rgb_out[23]_i_1065_n_0 ;
  wire \rgb_out[23]_i_1069_n_0 ;
  wire \rgb_out[23]_i_1074_n_0 ;
  wire \rgb_out[23]_i_1075_n_0 ;
  wire \rgb_out[23]_i_1076_n_0 ;
  wire \rgb_out[23]_i_1077_n_0 ;
  wire \rgb_out[23]_i_1079_n_0 ;
  wire \rgb_out[23]_i_1080_n_0 ;
  wire \rgb_out[23]_i_1081_n_0 ;
  wire \rgb_out[23]_i_1082_n_0 ;
  wire \rgb_out[23]_i_1084_n_0 ;
  wire \rgb_out[23]_i_1085_n_0 ;
  wire \rgb_out[23]_i_1086_n_0 ;
  wire \rgb_out[23]_i_1088_n_0 ;
  wire \rgb_out[23]_i_1089_n_0 ;
  wire \rgb_out[23]_i_1090_n_0 ;
  wire \rgb_out[23]_i_1091_n_0 ;
  wire \rgb_out[23]_i_1093_n_0 ;
  wire \rgb_out[23]_i_1094_n_0 ;
  wire \rgb_out[23]_i_1095_n_0 ;
  wire \rgb_out[23]_i_1097_n_0 ;
  wire \rgb_out[23]_i_1098_n_0 ;
  wire \rgb_out[23]_i_1099_n_0 ;
  wire \rgb_out[23]_i_1100_n_0 ;
  wire \rgb_out[23]_i_1102_n_0 ;
  wire \rgb_out[23]_i_1103_n_0 ;
  wire \rgb_out[23]_i_1104_n_0 ;
  wire \rgb_out[23]_i_1106_n_0 ;
  wire \rgb_out[23]_i_1107_n_0 ;
  wire \rgb_out[23]_i_1108_n_0 ;
  wire \rgb_out[23]_i_1109_n_0 ;
  wire \rgb_out[23]_i_1111_n_0 ;
  wire \rgb_out[23]_i_1112_n_0 ;
  wire \rgb_out[23]_i_1113_n_0 ;
  wire \rgb_out[23]_i_1114_n_0 ;
  wire \rgb_out[23]_i_1116_n_0 ;
  wire \rgb_out[23]_i_1117_n_0 ;
  wire \rgb_out[23]_i_1118_n_0 ;
  wire \rgb_out[23]_i_1120_n_0 ;
  wire \rgb_out[23]_i_1121_n_0 ;
  wire \rgb_out[23]_i_1122_n_0 ;
  wire \rgb_out[23]_i_1124_n_0 ;
  wire \rgb_out[23]_i_1125_n_0 ;
  wire \rgb_out[23]_i_1126_n_0 ;
  wire \rgb_out[23]_i_1128_n_0 ;
  wire \rgb_out[23]_i_1129_n_0 ;
  wire \rgb_out[23]_i_1130_n_0 ;
  wire \rgb_out[23]_i_1131_n_0 ;
  wire \rgb_out[23]_i_1133_n_0 ;
  wire \rgb_out[23]_i_1134_n_0 ;
  wire \rgb_out[23]_i_1135_n_0 ;
  wire \rgb_out[23]_i_1136_n_0 ;
  wire \rgb_out[23]_i_1138_n_0 ;
  wire \rgb_out[23]_i_1140_n_0 ;
  wire \rgb_out[23]_i_1141_n_0 ;
  wire \rgb_out[23]_i_1143_n_0 ;
  wire \rgb_out[23]_i_1144_n_0 ;
  wire \rgb_out[23]_i_1145_n_0 ;
  wire \rgb_out[23]_i_1146_n_0 ;
  wire \rgb_out[23]_i_1148_n_0 ;
  wire \rgb_out[23]_i_1149_n_0 ;
  wire \rgb_out[23]_i_1150_n_0 ;
  wire \rgb_out[23]_i_1151_n_0 ;
  wire \rgb_out[23]_i_1153_n_0 ;
  wire \rgb_out[23]_i_1154_n_0 ;
  wire \rgb_out[23]_i_1155_n_0 ;
  wire \rgb_out[23]_i_1157_n_0 ;
  wire \rgb_out[23]_i_1158_n_0 ;
  wire \rgb_out[23]_i_1159_n_0 ;
  wire \rgb_out[23]_i_1160_n_0 ;
  wire \rgb_out[23]_i_1162_n_0 ;
  wire \rgb_out[23]_i_1163_n_0 ;
  wire \rgb_out[23]_i_1164_n_0 ;
  wire \rgb_out[23]_i_1166_n_0 ;
  wire \rgb_out[23]_i_1167_n_0 ;
  wire \rgb_out[23]_i_1168_n_0 ;
  wire \rgb_out[23]_i_1169_n_0 ;
  wire \rgb_out[23]_i_1171_n_0 ;
  wire \rgb_out[23]_i_1172_n_0 ;
  wire \rgb_out[23]_i_1173_n_0 ;
  wire \rgb_out[23]_i_1174_n_0 ;
  wire \rgb_out[23]_i_1176_n_0 ;
  wire \rgb_out[23]_i_1177_n_0 ;
  wire \rgb_out[23]_i_1178_n_0 ;
  wire \rgb_out[23]_i_1179_n_0 ;
  wire \rgb_out[23]_i_1180_n_0 ;
  wire \rgb_out[23]_i_1181_n_0 ;
  wire \rgb_out[23]_i_1182_n_0 ;
  wire \rgb_out[23]_i_1183_n_0 ;
  wire \rgb_out[23]_i_1184_n_0 ;
  wire \rgb_out[23]_i_1185_n_0 ;
  wire \rgb_out[23]_i_1186_n_0 ;
  wire \rgb_out[23]_i_1187_n_0 ;
  wire \rgb_out[23]_i_1188_n_0 ;
  wire \rgb_out[23]_i_1189_n_0 ;
  wire \rgb_out[23]_i_1191_n_0 ;
  wire \rgb_out[23]_i_1192_n_0 ;
  wire \rgb_out[23]_i_1193_n_0 ;
  wire \rgb_out[23]_i_1194_n_0 ;
  wire \rgb_out[23]_i_1196_n_0 ;
  wire \rgb_out[23]_i_1197_n_0 ;
  wire \rgb_out[23]_i_1198_n_0 ;
  wire \rgb_out[23]_i_1199_n_0 ;
  wire \rgb_out[23]_i_1202_n_0 ;
  wire \rgb_out[23]_i_1205_n_0 ;
  wire \rgb_out[23]_i_1211_n_0 ;
  wire \rgb_out[23]_i_1212_n_0 ;
  wire \rgb_out[23]_i_1213_n_0 ;
  wire \rgb_out[23]_i_1214_n_0 ;
  wire \rgb_out[23]_i_1215_n_0 ;
  wire \rgb_out[23]_i_1216_n_0 ;
  wire \rgb_out[23]_i_1218_n_0 ;
  wire \rgb_out[23]_i_1219_n_0 ;
  wire \rgb_out[23]_i_1220_n_0 ;
  wire \rgb_out[23]_i_1221_n_0 ;
  wire \rgb_out[23]_i_1222_n_0 ;
  wire \rgb_out[23]_i_1223_n_0 ;
  wire \rgb_out[23]_i_1225_n_0 ;
  wire \rgb_out[23]_i_1226_n_0 ;
  wire \rgb_out[23]_i_1227_n_0 ;
  wire \rgb_out[23]_i_1228_n_0 ;
  wire \rgb_out[23]_i_1229_n_0 ;
  wire \rgb_out[23]_i_1230_n_0 ;
  wire \rgb_out[23]_i_1231_n_0 ;
  wire \rgb_out[23]_i_1232_n_0 ;
  wire \rgb_out[23]_i_1233_n_0 ;
  wire \rgb_out[23]_i_1234_n_0 ;
  wire \rgb_out[23]_i_1235_n_0 ;
  wire \rgb_out[23]_i_1236_n_0 ;
  wire \rgb_out[23]_i_1237_n_0 ;
  wire \rgb_out[23]_i_1238_n_0 ;
  wire \rgb_out[23]_i_1239_n_0 ;
  wire \rgb_out[23]_i_1240_n_0 ;
  wire \rgb_out[23]_i_1241_n_0 ;
  wire \rgb_out[23]_i_1242_n_0 ;
  wire \rgb_out[23]_i_1243_n_0 ;
  wire \rgb_out[23]_i_1245_n_0 ;
  wire \rgb_out[23]_i_1246_n_0 ;
  wire \rgb_out[23]_i_1247_n_0 ;
  wire \rgb_out[23]_i_1248_n_0 ;
  wire \rgb_out[23]_i_1250_n_0 ;
  wire \rgb_out[23]_i_1251_n_0 ;
  wire \rgb_out[23]_i_1252_n_0 ;
  wire \rgb_out[23]_i_1259_n_0 ;
  wire \rgb_out[23]_i_1260_n_0 ;
  wire \rgb_out[23]_i_1261_n_0 ;
  wire \rgb_out[23]_i_1263_n_0 ;
  wire \rgb_out[23]_i_1264_n_0 ;
  wire \rgb_out[23]_i_1265_n_0 ;
  wire \rgb_out[23]_i_1266_n_0 ;
  wire \rgb_out[23]_i_1268_n_0 ;
  wire \rgb_out[23]_i_1269_n_0 ;
  wire \rgb_out[23]_i_1270_n_0 ;
  wire \rgb_out[23]_i_1272_n_0 ;
  wire \rgb_out[23]_i_1273_n_0 ;
  wire \rgb_out[23]_i_1274_n_0 ;
  wire \rgb_out[23]_i_1276_n_0 ;
  wire \rgb_out[23]_i_1277_n_0 ;
  wire \rgb_out[23]_i_1278_n_0 ;
  wire \rgb_out[23]_i_1279_n_0 ;
  wire \rgb_out[23]_i_1281_n_0 ;
  wire \rgb_out[23]_i_1282_n_0 ;
  wire \rgb_out[23]_i_1283_n_0 ;
  wire \rgb_out[23]_i_1285_n_0 ;
  wire \rgb_out[23]_i_1286_n_0 ;
  wire \rgb_out[23]_i_1287_n_0 ;
  wire \rgb_out[23]_i_1288_n_0 ;
  wire \rgb_out[23]_i_1290_n_0 ;
  wire \rgb_out[23]_i_1291_n_0 ;
  wire \rgb_out[23]_i_1292_n_0 ;
  wire \rgb_out[23]_i_1294_n_0 ;
  wire \rgb_out[23]_i_1295_n_0 ;
  wire \rgb_out[23]_i_1296_n_0 ;
  wire \rgb_out[23]_i_1297_n_0 ;
  wire \rgb_out[23]_i_1299_n_0 ;
  wire \rgb_out[23]_i_1301_n_0 ;
  wire \rgb_out[23]_i_1302_n_0 ;
  wire \rgb_out[23]_i_1304_n_0 ;
  wire \rgb_out[23]_i_1305_n_0 ;
  wire \rgb_out[23]_i_1306_n_0 ;
  wire \rgb_out[23]_i_1307_n_0 ;
  wire \rgb_out[23]_i_1314_n_0 ;
  wire \rgb_out[23]_i_1315_n_0 ;
  wire \rgb_out[23]_i_1316_n_0 ;
  wire \rgb_out[23]_i_1327_n_0 ;
  wire \rgb_out[23]_i_1328_n_0 ;
  wire \rgb_out[23]_i_1329_n_0 ;
  wire \rgb_out[23]_i_1330_n_0 ;
  wire \rgb_out[23]_i_1335_n_0 ;
  wire \rgb_out[23]_i_1337_n_0 ;
  wire \rgb_out[23]_i_1338_n_0 ;
  wire \rgb_out[23]_i_1339_n_0 ;
  wire \rgb_out[23]_i_1340_n_0 ;
  wire \rgb_out[23]_i_1341_n_0 ;
  wire \rgb_out[23]_i_1343_n_0 ;
  wire \rgb_out[23]_i_1344_n_0 ;
  wire \rgb_out[23]_i_1345_n_0 ;
  wire \rgb_out[23]_i_1346_n_0 ;
  wire \rgb_out[23]_i_1347_n_0 ;
  wire \rgb_out[23]_i_1348_n_0 ;
  wire \rgb_out[23]_i_1350_n_0 ;
  wire \rgb_out[23]_i_1351_n_0 ;
  wire \rgb_out[23]_i_1352_n_0 ;
  wire \rgb_out[23]_i_1353_n_0 ;
  wire \rgb_out[23]_i_1355_n_0 ;
  wire \rgb_out[23]_i_1356_n_0 ;
  wire \rgb_out[23]_i_1357_n_0 ;
  wire \rgb_out[23]_i_1358_n_0 ;
  wire \rgb_out[23]_i_1361_n_0 ;
  wire \rgb_out[23]_i_1364_n_0 ;
  wire \rgb_out[23]_i_1365_n_0 ;
  wire \rgb_out[23]_i_1366_n_0 ;
  wire \rgb_out[23]_i_1367_n_0 ;
  wire \rgb_out[23]_i_1368_n_0 ;
  wire \rgb_out[23]_i_1369_n_0 ;
  wire \rgb_out[23]_i_1370_n_0 ;
  wire \rgb_out[23]_i_1372_n_0 ;
  wire \rgb_out[23]_i_1373_n_0 ;
  wire \rgb_out[23]_i_1374_n_0 ;
  wire \rgb_out[23]_i_1375_n_0 ;
  wire \rgb_out[23]_i_1377_n_0 ;
  wire \rgb_out[23]_i_1378_n_0 ;
  wire \rgb_out[23]_i_1379_n_0 ;
  wire \rgb_out[23]_i_1380_n_0 ;
  wire \rgb_out[23]_i_1381_n_0 ;
  wire \rgb_out[23]_i_1389_n_0 ;
  wire \rgb_out[23]_i_1390_n_0 ;
  wire \rgb_out[23]_i_1391_n_0 ;
  wire \rgb_out[23]_i_1392_n_0 ;
  wire \rgb_out[23]_i_1393_n_0 ;
  wire \rgb_out[23]_i_1394_n_0 ;
  wire \rgb_out[23]_i_1395_n_0 ;
  wire \rgb_out[23]_i_1396_n_0 ;
  wire \rgb_out[23]_i_1397_n_0 ;
  wire \rgb_out[23]_i_1398_n_0 ;
  wire \rgb_out[23]_i_1399_n_0 ;
  wire \rgb_out[23]_i_1400_n_0 ;
  wire \rgb_out[23]_i_1401_n_0 ;
  wire \rgb_out[23]_i_1402_n_0 ;
  wire \rgb_out[23]_i_1403_n_0 ;
  wire \rgb_out[23]_i_1404_n_0 ;
  wire \rgb_out[23]_i_1405_n_0 ;
  wire \rgb_out[23]_i_1406_n_0 ;
  wire \rgb_out[23]_i_1407_n_0 ;
  wire \rgb_out[23]_i_1408_n_0 ;
  wire \rgb_out[23]_i_1409_n_0 ;
  wire \rgb_out[23]_i_1410_n_0 ;
  wire \rgb_out[23]_i_1411_n_0 ;
  wire \rgb_out[23]_i_1412_n_0 ;
  wire \rgb_out[23]_i_1413_n_0 ;
  wire \rgb_out[23]_i_1414_n_0 ;
  wire \rgb_out[23]_i_1415_n_0 ;
  wire \rgb_out[23]_i_1416_n_0 ;
  wire \rgb_out[23]_i_1417_n_0 ;
  wire \rgb_out[23]_i_1418_n_0 ;
  wire \rgb_out[23]_i_1419_n_0 ;
  wire \rgb_out[23]_i_1420_n_0 ;
  wire \rgb_out[23]_i_1421_n_0 ;
  wire \rgb_out[23]_i_1422_n_0 ;
  wire \rgb_out[23]_i_1423_n_0 ;
  wire \rgb_out[23]_i_1424_n_0 ;
  wire \rgb_out[23]_i_1425_n_0 ;
  wire \rgb_out[23]_i_1426_n_0 ;
  wire \rgb_out[23]_i_1427_n_0 ;
  wire \rgb_out[23]_i_1428_n_0 ;
  wire \rgb_out[23]_i_1429_n_0 ;
  wire \rgb_out[23]_i_1430_n_0 ;
  wire \rgb_out[23]_i_1431_n_0 ;
  wire \rgb_out[23]_i_1432_n_0 ;
  wire \rgb_out[23]_i_1433_n_0 ;
  wire \rgb_out[23]_i_1434_n_0 ;
  wire \rgb_out[23]_i_1435_n_0 ;
  wire \rgb_out[23]_i_1436_n_0 ;
  wire \rgb_out[23]_i_1437_n_0 ;
  wire \rgb_out[23]_i_1438_n_0 ;
  wire \rgb_out[23]_i_1439_n_0 ;
  wire \rgb_out[23]_i_1440_n_0 ;
  wire \rgb_out[23]_i_1441_n_0 ;
  wire \rgb_out[23]_i_1442_n_0 ;
  wire \rgb_out[23]_i_1443_n_0 ;
  wire \rgb_out[23]_i_1444_n_0 ;
  wire \rgb_out[23]_i_1445_n_0 ;
  wire \rgb_out[23]_i_1446_n_0 ;
  wire \rgb_out[23]_i_1447_n_0 ;
  wire \rgb_out[23]_i_1448_n_0 ;
  wire \rgb_out[23]_i_1449_n_0 ;
  wire \rgb_out[23]_i_1450_n_0 ;
  wire \rgb_out[23]_i_1451_n_0 ;
  wire \rgb_out[23]_i_1452_n_0 ;
  wire \rgb_out[23]_i_1453_n_0 ;
  wire \rgb_out[23]_i_1467_n_0 ;
  wire \rgb_out[23]_i_1468_n_0 ;
  wire \rgb_out[23]_i_1471_n_0 ;
  wire \rgb_out[23]_i_1472_n_0 ;
  wire \rgb_out[23]_i_1497_n_0 ;
  wire \rgb_out[23]_i_1498_n_0 ;
  wire \rgb_out[23]_i_1499_n_0 ;
  wire \rgb_out[23]_i_1500_n_0 ;
  wire \rgb_out[23]_i_1501_n_0 ;
  wire \rgb_out[23]_i_1502_n_0 ;
  wire \rgb_out[23]_i_1504_n_0 ;
  wire \rgb_out[23]_i_1505_n_0 ;
  wire \rgb_out[23]_i_1506_n_0 ;
  wire \rgb_out[23]_i_1507_n_0 ;
  wire \rgb_out[23]_i_1509_n_0 ;
  wire \rgb_out[23]_i_1510_n_0 ;
  wire \rgb_out[23]_i_1511_n_0 ;
  wire \rgb_out[23]_i_1512_n_0 ;
  wire \rgb_out[23]_i_1513_n_0 ;
  wire \rgb_out[23]_i_1514_n_0 ;
  wire \rgb_out[23]_i_1515_n_0 ;
  wire \rgb_out[23]_i_1517_n_0 ;
  wire \rgb_out[23]_i_1518_n_0 ;
  wire \rgb_out[23]_i_1519_n_0 ;
  wire \rgb_out[23]_i_1520_n_0 ;
  wire \rgb_out[23]_i_1521_n_0 ;
  wire \rgb_out[23]_i_1522_n_0 ;
  wire \rgb_out[23]_i_1523_n_0 ;
  wire \rgb_out[23]_i_1524_n_0 ;
  wire \rgb_out[23]_i_1525_n_0 ;
  wire \rgb_out[23]_i_1526_n_0 ;
  wire \rgb_out[23]_i_1527_n_0 ;
  wire \rgb_out[23]_i_1528_n_0 ;
  wire \rgb_out[23]_i_1529_n_0 ;
  wire \rgb_out[23]_i_1530_n_0 ;
  wire \rgb_out[23]_i_1531_n_0 ;
  wire \rgb_out[23]_i_1532_n_0 ;
  wire \rgb_out[23]_i_1533_n_0 ;
  wire \rgb_out[23]_i_1534_n_0 ;
  wire \rgb_out[23]_i_1535_n_0 ;
  wire \rgb_out[23]_i_1536_n_0 ;
  wire \rgb_out[23]_i_1537_n_0 ;
  wire \rgb_out[23]_i_1538_n_0 ;
  wire \rgb_out[23]_i_1539_n_0 ;
  wire \rgb_out[23]_i_1540_n_0 ;
  wire \rgb_out[23]_i_1541_n_0 ;
  wire \rgb_out[23]_i_1542_n_0 ;
  wire \rgb_out[23]_i_1543_n_0 ;
  wire \rgb_out[23]_i_1544_n_0 ;
  wire \rgb_out[23]_i_1545_n_0 ;
  wire \rgb_out[23]_i_1546_n_0 ;
  wire \rgb_out[23]_i_1547_n_0 ;
  wire \rgb_out[23]_i_1548_n_0 ;
  wire \rgb_out[23]_i_1549_n_0 ;
  wire \rgb_out[23]_i_1550_n_0 ;
  wire \rgb_out[23]_i_1551_n_0 ;
  wire \rgb_out[23]_i_1552_n_0 ;
  wire \rgb_out[23]_i_1553_n_0 ;
  wire \rgb_out[23]_i_1554_n_0 ;
  wire \rgb_out[23]_i_1555_n_0 ;
  wire \rgb_out[23]_i_1556_n_0 ;
  wire \rgb_out[23]_i_1557_n_0 ;
  wire \rgb_out[23]_i_1558_n_0 ;
  wire \rgb_out[23]_i_1559_n_0 ;
  wire \rgb_out[23]_i_1560_n_0 ;
  wire \rgb_out[23]_i_1561_n_0 ;
  wire \rgb_out[23]_i_1562_n_0 ;
  wire \rgb_out[23]_i_1563_n_0 ;
  wire \rgb_out[23]_i_1564_n_0 ;
  wire \rgb_out[23]_i_1565_n_0 ;
  wire \rgb_out[23]_i_1566_n_0 ;
  wire \rgb_out[23]_i_1567_n_0 ;
  wire \rgb_out[23]_i_1568_n_0 ;
  wire \rgb_out[23]_i_1569_n_0 ;
  wire \rgb_out[23]_i_1570_n_0 ;
  wire \rgb_out[23]_i_1571_n_0 ;
  wire \rgb_out[23]_i_1572_n_0 ;
  wire \rgb_out[23]_i_1573_n_0 ;
  wire \rgb_out[23]_i_1574_n_0 ;
  wire \rgb_out[23]_i_1575_n_0 ;
  wire \rgb_out[23]_i_1576_n_0 ;
  wire \rgb_out[23]_i_1577_n_0 ;
  wire \rgb_out[23]_i_1578_n_0 ;
  wire \rgb_out[23]_i_1579_n_0 ;
  wire \rgb_out[23]_i_1580_n_0 ;
  wire \rgb_out[23]_i_1581_n_0 ;
  wire \rgb_out[23]_i_1582_n_0 ;
  wire \rgb_out[23]_i_1583_n_0 ;
  wire \rgb_out[23]_i_1584_n_0 ;
  wire \rgb_out[23]_i_1585_n_0 ;
  wire \rgb_out[23]_i_1586_n_0 ;
  wire \rgb_out[23]_i_1587_n_0 ;
  wire \rgb_out[23]_i_1588_n_0 ;
  wire \rgb_out[23]_i_1589_n_0 ;
  wire \rgb_out[23]_i_1590_n_0 ;
  wire \rgb_out[23]_i_1591_n_0 ;
  wire \rgb_out[23]_i_1592_n_0 ;
  wire \rgb_out[23]_i_1594_n_0 ;
  wire \rgb_out[23]_i_1595_n_0 ;
  wire \rgb_out[23]_i_1596_n_0 ;
  wire \rgb_out[23]_i_1597_n_0 ;
  wire \rgb_out[23]_i_1598_n_0 ;
  wire \rgb_out[23]_i_1599_n_0 ;
  wire \rgb_out[23]_i_1600_n_0 ;
  wire \rgb_out[23]_i_1601_n_0 ;
  wire \rgb_out[23]_i_1602_n_0 ;
  wire \rgb_out[23]_i_1604_n_0 ;
  wire \rgb_out[23]_i_1605_n_0 ;
  wire \rgb_out[23]_i_1606_n_0 ;
  wire \rgb_out[23]_i_1607_n_0 ;
  wire \rgb_out[23]_i_1608_n_0 ;
  wire \rgb_out[23]_i_1609_n_0 ;
  wire \rgb_out[23]_i_1610_n_0 ;
  wire \rgb_out[23]_i_1611_n_0 ;
  wire \rgb_out[23]_i_1612_n_0 ;
  wire \rgb_out[23]_i_1613_n_0 ;
  wire \rgb_out[23]_i_1614_n_0 ;
  wire \rgb_out[23]_i_1615_n_0 ;
  wire \rgb_out[23]_i_1616_n_0 ;
  wire \rgb_out[23]_i_1617_n_0 ;
  wire \rgb_out[23]_i_1618_n_0 ;
  wire \rgb_out[23]_i_1619_n_0 ;
  wire \rgb_out[23]_i_1620_n_0 ;
  wire \rgb_out[23]_i_1621_n_0 ;
  wire \rgb_out[23]_i_1622_n_0 ;
  wire \rgb_out[23]_i_1623_n_0 ;
  wire \rgb_out[23]_i_1624_n_0 ;
  wire \rgb_out[23]_i_1625_n_0 ;
  wire \rgb_out[23]_i_1626_n_0 ;
  wire \rgb_out[23]_i_1627_n_0 ;
  wire \rgb_out[23]_i_1628_n_0 ;
  wire \rgb_out[23]_i_1629_n_0 ;
  wire \rgb_out[23]_i_1630_n_0 ;
  wire \rgb_out[23]_i_1631_n_0 ;
  wire \rgb_out[23]_i_1632_n_0 ;
  wire \rgb_out[23]_i_1633_n_0 ;
  wire \rgb_out[23]_i_1634_n_0 ;
  wire \rgb_out[23]_i_1635_n_0 ;
  wire \rgb_out[23]_i_1636_n_0 ;
  wire \rgb_out[23]_i_1637_n_0 ;
  wire \rgb_out[23]_i_1638_n_0 ;
  wire \rgb_out[23]_i_1639_n_0 ;
  wire \rgb_out[23]_i_1640_n_0 ;
  wire \rgb_out[23]_i_1641_n_0 ;
  wire \rgb_out[23]_i_1642_n_0 ;
  wire \rgb_out[23]_i_1643_n_0 ;
  wire \rgb_out[23]_i_1644_n_0 ;
  wire \rgb_out[23]_i_1645_n_0 ;
  wire \rgb_out[23]_i_1646_n_0 ;
  wire \rgb_out[23]_i_1647_n_0 ;
  wire \rgb_out[23]_i_1648_n_0 ;
  wire \rgb_out[23]_i_1649_n_0 ;
  wire \rgb_out[23]_i_1650_n_0 ;
  wire \rgb_out[23]_i_1651_n_0 ;
  wire \rgb_out[23]_i_1652_n_0 ;
  wire \rgb_out[23]_i_1653_n_0 ;
  wire \rgb_out[23]_i_1654_n_0 ;
  wire \rgb_out[23]_i_1655_n_0 ;
  wire \rgb_out[23]_i_1656_n_0 ;
  wire \rgb_out[23]_i_1658_n_0 ;
  wire \rgb_out[23]_i_1659_n_0 ;
  wire \rgb_out[23]_i_1660_n_0 ;
  wire \rgb_out[23]_i_1661_n_0 ;
  wire \rgb_out[23]_i_1662_n_0 ;
  wire \rgb_out[23]_i_1663_n_0 ;
  wire \rgb_out[23]_i_1664_n_0 ;
  wire \rgb_out[23]_i_1666_n_0 ;
  wire \rgb_out[23]_i_1667_n_0 ;
  wire \rgb_out[23]_i_1668_n_0 ;
  wire \rgb_out[23]_i_1669_n_0 ;
  wire \rgb_out[23]_i_1670_n_0 ;
  wire \rgb_out[23]_i_1671_n_0 ;
  wire \rgb_out[23]_i_1672_n_0 ;
  wire \rgb_out[23]_i_1673_n_0 ;
  wire \rgb_out[23]_i_1674_n_0 ;
  wire \rgb_out[23]_i_1675_n_0 ;
  wire \rgb_out[23]_i_1676_n_0 ;
  wire \rgb_out[23]_i_1677_n_0 ;
  wire \rgb_out[23]_i_1678_n_0 ;
  wire \rgb_out[23]_i_1679_n_0 ;
  wire \rgb_out[23]_i_1680_n_0 ;
  wire \rgb_out[23]_i_1681_n_0 ;
  wire \rgb_out[23]_i_1682_n_0 ;
  wire \rgb_out[23]_i_1683_n_0 ;
  wire \rgb_out[23]_i_1684_n_0 ;
  wire \rgb_out[23]_i_1685_n_0 ;
  wire \rgb_out[23]_i_1686_n_0 ;
  wire \rgb_out[23]_i_1687_n_0 ;
  wire \rgb_out[23]_i_1688_n_0 ;
  wire \rgb_out[23]_i_1689_n_0 ;
  wire \rgb_out[23]_i_1690_n_0 ;
  wire \rgb_out[23]_i_1691_n_0 ;
  wire \rgb_out[23]_i_1692_n_0 ;
  wire \rgb_out[23]_i_1693_n_0 ;
  wire \rgb_out[23]_i_1694_n_0 ;
  wire \rgb_out[23]_i_1695_n_0 ;
  wire \rgb_out[23]_i_1696_n_0 ;
  wire \rgb_out[23]_i_1697_n_0 ;
  wire \rgb_out[23]_i_1698_n_0 ;
  wire \rgb_out[23]_i_1699_n_0 ;
  wire \rgb_out[23]_i_1700_n_0 ;
  wire \rgb_out[23]_i_1701_n_0 ;
  wire \rgb_out[23]_i_1702_n_0 ;
  wire \rgb_out[23]_i_1703_n_0 ;
  wire \rgb_out[23]_i_1704_n_0 ;
  wire \rgb_out[23]_i_1705_n_0 ;
  wire \rgb_out[23]_i_1706_n_0 ;
  wire \rgb_out[23]_i_1707_n_0 ;
  wire \rgb_out[23]_i_1709_n_0 ;
  wire \rgb_out[23]_i_1710_n_0 ;
  wire \rgb_out[23]_i_1711_n_0 ;
  wire \rgb_out[23]_i_1712_n_0 ;
  wire \rgb_out[23]_i_1713_n_0 ;
  wire \rgb_out[23]_i_1714_n_0 ;
  wire \rgb_out[23]_i_1715_n_0 ;
  wire \rgb_out[23]_i_1716_n_0 ;
  wire \rgb_out[23]_i_1718_n_0 ;
  wire \rgb_out[23]_i_1719_n_0 ;
  wire \rgb_out[23]_i_1720_n_0 ;
  wire \rgb_out[23]_i_1721_n_0 ;
  wire \rgb_out[23]_i_1722_n_0 ;
  wire \rgb_out[23]_i_1723_n_0 ;
  wire \rgb_out[23]_i_1724_n_0 ;
  wire \rgb_out[23]_i_1725_n_0 ;
  wire \rgb_out[23]_i_1726_n_0 ;
  wire \rgb_out[23]_i_1727_n_0 ;
  wire \rgb_out[23]_i_1728_n_0 ;
  wire \rgb_out[23]_i_1729_n_0 ;
  wire \rgb_out[23]_i_1730_n_0 ;
  wire \rgb_out[23]_i_1731_n_0 ;
  wire \rgb_out[23]_i_1732_n_0 ;
  wire \rgb_out[23]_i_1733_n_0 ;
  wire \rgb_out[23]_i_1734_n_0 ;
  wire \rgb_out[23]_i_1735_n_0 ;
  wire \rgb_out[23]_i_1736_n_0 ;
  wire \rgb_out[23]_i_1737_n_0 ;
  wire \rgb_out[23]_i_1738_n_0 ;
  wire \rgb_out[23]_i_1739_n_0 ;
  wire \rgb_out[23]_i_1740_n_0 ;
  wire \rgb_out[23]_i_1741_n_0 ;
  wire \rgb_out[23]_i_1742_n_0 ;
  wire \rgb_out[23]_i_1743_n_0 ;
  wire \rgb_out[23]_i_1744_n_0 ;
  wire \rgb_out[23]_i_1745_n_0 ;
  wire \rgb_out[23]_i_1746_n_0 ;
  wire \rgb_out[23]_i_1747_n_0 ;
  wire \rgb_out[23]_i_1748_n_0 ;
  wire \rgb_out[23]_i_1749_n_0 ;
  wire \rgb_out[23]_i_1750_n_0 ;
  wire \rgb_out[23]_i_1751_n_0 ;
  wire \rgb_out[23]_i_1752_n_0 ;
  wire \rgb_out[23]_i_1753_n_0 ;
  wire \rgb_out[23]_i_1754_n_0 ;
  wire \rgb_out[23]_i_1755_n_0 ;
  wire \rgb_out[23]_i_1756_n_0 ;
  wire \rgb_out[23]_i_1757_n_0 ;
  wire \rgb_out[23]_i_1758_n_0 ;
  wire \rgb_out[23]_i_1759_n_0 ;
  wire \rgb_out[23]_i_1760_n_0 ;
  wire \rgb_out[23]_i_1761_n_0 ;
  wire \rgb_out[23]_i_1762_n_0 ;
  wire \rgb_out[23]_i_1763_n_0 ;
  wire \rgb_out[23]_i_1764_n_0 ;
  wire \rgb_out[23]_i_1765_n_0 ;
  wire \rgb_out[23]_i_1766_n_0 ;
  wire \rgb_out[23]_i_1767_n_0 ;
  wire \rgb_out[23]_i_1768_n_0 ;
  wire \rgb_out[23]_i_1769_n_0 ;
  wire \rgb_out[23]_i_1770_n_0 ;
  wire \rgb_out[23]_i_1772_n_0 ;
  wire \rgb_out[23]_i_1773_n_0 ;
  wire \rgb_out[23]_i_1774_n_0 ;
  wire \rgb_out[23]_i_1775_n_0 ;
  wire \rgb_out[23]_i_1776_n_0 ;
  wire \rgb_out[23]_i_1777_n_0 ;
  wire \rgb_out[23]_i_1778_n_0 ;
  wire \rgb_out[23]_i_1780_n_0 ;
  wire \rgb_out[23]_i_1781_n_0 ;
  wire \rgb_out[23]_i_1782_n_0 ;
  wire \rgb_out[23]_i_1783_n_0 ;
  wire \rgb_out[23]_i_1784_n_0 ;
  wire \rgb_out[23]_i_1785_n_0 ;
  wire \rgb_out[23]_i_1786_n_0 ;
  wire \rgb_out[23]_i_1787_n_0 ;
  wire \rgb_out[23]_i_1788_n_0 ;
  wire \rgb_out[23]_i_1789_n_0 ;
  wire \rgb_out[23]_i_1790_n_0 ;
  wire \rgb_out[23]_i_1791_n_0 ;
  wire \rgb_out[23]_i_1792_n_0 ;
  wire \rgb_out[23]_i_1793_n_0 ;
  wire \rgb_out[23]_i_1794_n_0 ;
  wire \rgb_out[23]_i_1795_n_0 ;
  wire \rgb_out[23]_i_1796_n_0 ;
  wire \rgb_out[23]_i_1797_n_0 ;
  wire \rgb_out[23]_i_1798_n_0 ;
  wire \rgb_out[23]_i_1799_n_0 ;
  wire \rgb_out[23]_i_1800_n_0 ;
  wire \rgb_out[23]_i_1801_n_0 ;
  wire \rgb_out[23]_i_1802_n_0 ;
  wire \rgb_out[23]_i_1803_n_0 ;
  wire \rgb_out[23]_i_1804_n_0 ;
  wire \rgb_out[23]_i_1805_n_0 ;
  wire \rgb_out[23]_i_1806_n_0 ;
  wire \rgb_out[23]_i_1807_n_0 ;
  wire \rgb_out[23]_i_1808_n_0 ;
  wire \rgb_out[23]_i_1809_n_0 ;
  wire \rgb_out[23]_i_1810_n_0 ;
  wire \rgb_out[23]_i_1811_n_0 ;
  wire \rgb_out[23]_i_1812_n_0 ;
  wire \rgb_out[23]_i_1813_n_0 ;
  wire \rgb_out[23]_i_1814_n_0 ;
  wire \rgb_out[23]_i_1815_n_0 ;
  wire \rgb_out[23]_i_1816_n_0 ;
  wire \rgb_out[23]_i_1817_n_0 ;
  wire \rgb_out[23]_i_1818_n_0 ;
  wire \rgb_out[23]_i_1819_n_0 ;
  wire \rgb_out[23]_i_1820_n_0 ;
  wire \rgb_out[23]_i_1821_n_0 ;
  wire \rgb_out[23]_i_1823_n_0 ;
  wire \rgb_out[23]_i_1824_n_0 ;
  wire \rgb_out[23]_i_1825_n_0 ;
  wire \rgb_out[23]_i_1826_n_0 ;
  wire \rgb_out[23]_i_1828_n_0 ;
  wire \rgb_out[23]_i_1829_n_0 ;
  wire \rgb_out[23]_i_1830_n_0 ;
  wire \rgb_out[23]_i_1831_n_0 ;
  wire \rgb_out[23]_i_1832_n_0 ;
  wire \rgb_out[23]_i_1833_n_0 ;
  wire \rgb_out[23]_i_1834_n_0 ;
  wire \rgb_out[23]_i_1836_n_0 ;
  wire \rgb_out[23]_i_1837_n_0 ;
  wire \rgb_out[23]_i_1838_n_0 ;
  wire \rgb_out[23]_i_1839_n_0 ;
  wire \rgb_out[23]_i_1840_n_0 ;
  wire \rgb_out[23]_i_1841_n_0 ;
  wire \rgb_out[23]_i_1842_n_0 ;
  wire \rgb_out[23]_i_1843_n_0 ;
  wire \rgb_out[23]_i_1844_n_0 ;
  wire \rgb_out[23]_i_1845_n_0 ;
  wire \rgb_out[23]_i_1846_n_0 ;
  wire \rgb_out[23]_i_1847_n_0 ;
  wire \rgb_out[23]_i_1848_n_0 ;
  wire \rgb_out[23]_i_1849_n_0 ;
  wire \rgb_out[23]_i_1850_n_0 ;
  wire \rgb_out[23]_i_1851_n_0 ;
  wire \rgb_out[23]_i_1852_n_0 ;
  wire \rgb_out[23]_i_1853_n_0 ;
  wire \rgb_out[23]_i_1854_n_0 ;
  wire \rgb_out[23]_i_1855_n_0 ;
  wire \rgb_out[23]_i_1856_n_0 ;
  wire \rgb_out[23]_i_1857_n_0 ;
  wire \rgb_out[23]_i_1858_n_0 ;
  wire \rgb_out[23]_i_1859_n_0 ;
  wire \rgb_out[23]_i_1860_n_0 ;
  wire \rgb_out[23]_i_1861_n_0 ;
  wire \rgb_out[23]_i_1862_n_0 ;
  wire \rgb_out[23]_i_1863_n_0 ;
  wire \rgb_out[23]_i_1864_n_0 ;
  wire \rgb_out[23]_i_1865_n_0 ;
  wire \rgb_out[23]_i_1866_n_0 ;
  wire \rgb_out[23]_i_1867_n_0 ;
  wire \rgb_out[23]_i_1868_n_0 ;
  wire \rgb_out[23]_i_1869_n_0 ;
  wire \rgb_out[23]_i_1870_n_0 ;
  wire \rgb_out[23]_i_1871_n_0 ;
  wire \rgb_out[23]_i_1872_n_0 ;
  wire \rgb_out[23]_i_1873_n_0 ;
  wire \rgb_out[23]_i_1874_n_0 ;
  wire \rgb_out[23]_i_1875_n_0 ;
  wire \rgb_out[23]_i_1876_n_0 ;
  wire \rgb_out[23]_i_1877_n_0 ;
  wire \rgb_out[23]_i_1878_n_0 ;
  wire \rgb_out[23]_i_1879_n_0 ;
  wire \rgb_out[23]_i_1880_n_0 ;
  wire \rgb_out[23]_i_1881_n_0 ;
  wire \rgb_out[23]_i_1882_n_0 ;
  wire \rgb_out[23]_i_1883_n_0 ;
  wire \rgb_out[23]_i_1884_n_0 ;
  wire \rgb_out[23]_i_1885_n_0 ;
  wire \rgb_out[23]_i_1886_n_0 ;
  wire \rgb_out[23]_i_1887_n_0 ;
  wire \rgb_out[23]_i_1888_n_0 ;
  wire \rgb_out[23]_i_1889_n_0 ;
  wire \rgb_out[23]_i_1890_n_0 ;
  wire \rgb_out[23]_i_1891_n_0 ;
  wire \rgb_out[23]_i_1892_n_0 ;
  wire \rgb_out[23]_i_1893_n_0 ;
  wire \rgb_out[23]_i_1894_n_0 ;
  wire \rgb_out[23]_i_1895_n_0 ;
  wire \rgb_out[23]_i_1896_n_0 ;
  wire \rgb_out[23]_i_1897_n_0 ;
  wire \rgb_out[23]_i_1898_n_0 ;
  wire \rgb_out[23]_i_1899_n_0 ;
  wire \rgb_out[23]_i_1900_n_0 ;
  wire \rgb_out[23]_i_1901_n_0 ;
  wire \rgb_out[23]_i_1902_n_0 ;
  wire \rgb_out[23]_i_1903_n_0 ;
  wire \rgb_out[23]_i_1906_n_0 ;
  wire \rgb_out[23]_i_1907_n_0 ;
  wire \rgb_out[23]_i_1908_n_0 ;
  wire \rgb_out[23]_i_1909_n_0 ;
  wire \rgb_out[23]_i_1911_n_0 ;
  wire \rgb_out[23]_i_1912_n_0 ;
  wire \rgb_out[23]_i_1913_n_0 ;
  wire \rgb_out[23]_i_1914_n_0 ;
  wire \rgb_out[23]_i_1915_n_0 ;
  wire \rgb_out[23]_i_1916_n_0 ;
  wire \rgb_out[23]_i_1917_n_0 ;
  wire \rgb_out[23]_i_1918_n_0 ;
  wire \rgb_out[23]_i_1919_n_0 ;
  wire \rgb_out[23]_i_1920_n_0 ;
  wire \rgb_out[23]_i_1921_n_0 ;
  wire \rgb_out[23]_i_1922_n_0 ;
  wire \rgb_out[23]_i_1923_n_0 ;
  wire \rgb_out[23]_i_1924_n_0 ;
  wire \rgb_out[23]_i_1925_n_0 ;
  wire \rgb_out[23]_i_1926_n_0 ;
  wire \rgb_out[23]_i_1927_n_0 ;
  wire \rgb_out[23]_i_1935_n_0 ;
  wire \rgb_out[23]_i_1936_n_0 ;
  wire \rgb_out[23]_i_1937_n_0 ;
  wire \rgb_out[23]_i_1938_n_0 ;
  wire \rgb_out[23]_i_1939_n_0 ;
  wire \rgb_out[23]_i_1940_n_0 ;
  wire \rgb_out[23]_i_1941_n_0 ;
  wire \rgb_out[23]_i_1942_n_0 ;
  wire \rgb_out[23]_i_1943_n_0 ;
  wire \rgb_out[23]_i_1944_n_0 ;
  wire \rgb_out[23]_i_1945_n_0 ;
  wire \rgb_out[23]_i_1946_n_0 ;
  wire \rgb_out[23]_i_1947_n_0 ;
  wire \rgb_out[23]_i_1948_n_0 ;
  wire \rgb_out[23]_i_1949_n_0 ;
  wire \rgb_out[23]_i_1950_n_0 ;
  wire \rgb_out[23]_i_1951_n_0 ;
  wire \rgb_out[23]_i_1952_n_0 ;
  wire \rgb_out[23]_i_1953_n_0 ;
  wire \rgb_out[23]_i_1954_n_0 ;
  wire \rgb_out[23]_i_1955_n_0 ;
  wire \rgb_out[23]_i_1956_n_0 ;
  wire \rgb_out[23]_i_1957_n_0 ;
  wire \rgb_out[23]_i_1958_n_0 ;
  wire \rgb_out[23]_i_1959_n_0 ;
  wire \rgb_out[23]_i_1960_n_0 ;
  wire \rgb_out[23]_i_1961_n_0 ;
  wire \rgb_out[23]_i_1962_n_0 ;
  wire \rgb_out[23]_i_1963_n_0 ;
  wire \rgb_out[23]_i_1964_n_0 ;
  wire \rgb_out[23]_i_1965_n_0 ;
  wire \rgb_out[23]_i_1966_n_0 ;
  wire \rgb_out[23]_i_1967_n_0 ;
  wire \rgb_out[23]_i_1968_n_0 ;
  wire \rgb_out[23]_i_1969_n_0 ;
  wire \rgb_out[23]_i_1970_n_0 ;
  wire \rgb_out[23]_i_1971_n_0 ;
  wire \rgb_out[23]_i_1972_n_0 ;
  wire \rgb_out[23]_i_1973_n_0 ;
  wire \rgb_out[23]_i_1974_n_0 ;
  wire \rgb_out[23]_i_1975_n_0 ;
  wire \rgb_out[23]_i_1976_n_0 ;
  wire \rgb_out[23]_i_1977_n_0 ;
  wire \rgb_out[23]_i_1978_n_0 ;
  wire \rgb_out[23]_i_1979_n_0 ;
  wire \rgb_out[23]_i_1980_n_0 ;
  wire \rgb_out[23]_i_1981_n_0 ;
  wire \rgb_out[23]_i_1982_n_0 ;
  wire \rgb_out[23]_i_1983_n_0 ;
  wire \rgb_out[23]_i_1984_n_0 ;
  wire \rgb_out[23]_i_1985_n_0 ;
  wire \rgb_out[23]_i_1986_n_0 ;
  wire \rgb_out[23]_i_1987_n_0 ;
  wire \rgb_out[23]_i_1988_n_0 ;
  wire \rgb_out[23]_i_1989_n_0 ;
  wire \rgb_out[23]_i_1990_n_0 ;
  wire \rgb_out[23]_i_1991_n_0 ;
  wire \rgb_out[23]_i_1992_n_0 ;
  wire \rgb_out[23]_i_1993_n_0 ;
  wire \rgb_out[23]_i_1994_n_0 ;
  wire \rgb_out[23]_i_1995_n_0 ;
  wire \rgb_out[23]_i_1996_n_0 ;
  wire \rgb_out[23]_i_1997_n_0 ;
  wire \rgb_out[23]_i_2002_n_0 ;
  wire \rgb_out[23]_i_2004_n_0 ;
  wire \rgb_out[23]_i_2005_n_0 ;
  wire \rgb_out[23]_i_2006_n_0 ;
  wire \rgb_out[23]_i_2007_n_0 ;
  wire \rgb_out[23]_i_2008_n_0 ;
  wire \rgb_out[23]_i_2017_n_0 ;
  wire \rgb_out[23]_i_2018_n_0 ;
  wire \rgb_out[23]_i_2019_n_0 ;
  wire \rgb_out[23]_i_2020_n_0 ;
  wire \rgb_out[23]_i_2021_n_0 ;
  wire \rgb_out[23]_i_2022_n_0 ;
  wire \rgb_out[23]_i_2023_n_0 ;
  wire \rgb_out[23]_i_2038_n_0 ;
  wire \rgb_out[23]_i_2039_n_0 ;
  wire \rgb_out[23]_i_2040_n_0 ;
  wire \rgb_out[23]_i_2041_n_0 ;
  wire \rgb_out[23]_i_2042_n_0 ;
  wire \rgb_out[23]_i_2043_n_0 ;
  wire \rgb_out[23]_i_2051_n_0 ;
  wire \rgb_out[23]_i_2052_n_0 ;
  wire \rgb_out[23]_i_2053_n_0 ;
  wire \rgb_out[23]_i_2054_n_0 ;
  wire \rgb_out[23]_i_2055_n_0 ;
  wire \rgb_out[23]_i_2056_n_0 ;
  wire \rgb_out[23]_i_2057_n_0 ;
  wire \rgb_out[23]_i_2058_n_0 ;
  wire \rgb_out[23]_i_2059_n_0 ;
  wire \rgb_out[23]_i_2060_n_0 ;
  wire \rgb_out[23]_i_2061_n_0 ;
  wire \rgb_out[23]_i_2062_n_0 ;
  wire \rgb_out[23]_i_2063_n_0 ;
  wire \rgb_out[23]_i_2064_n_0 ;
  wire \rgb_out[23]_i_2065_n_0 ;
  wire \rgb_out[23]_i_2066_n_0 ;
  wire \rgb_out[23]_i_2067_n_0 ;
  wire \rgb_out[23]_i_2068_n_0 ;
  wire \rgb_out[23]_i_2069_n_0 ;
  wire \rgb_out[23]_i_2070_n_0 ;
  wire \rgb_out[23]_i_2071_n_0 ;
  wire \rgb_out[23]_i_2072_n_0 ;
  wire \rgb_out[23]_i_2073_n_0 ;
  wire \rgb_out[23]_i_2074_n_0 ;
  wire \rgb_out[23]_i_2075_n_0 ;
  wire \rgb_out[23]_i_2076_n_0 ;
  wire \rgb_out[23]_i_2077_n_0 ;
  wire \rgb_out[23]_i_2078_n_0 ;
  wire \rgb_out[23]_i_2079_n_0 ;
  wire \rgb_out[23]_i_2080_n_0 ;
  wire \rgb_out[23]_i_2081_n_0 ;
  wire \rgb_out[23]_i_2082_n_0 ;
  wire \rgb_out[23]_i_2083_n_0 ;
  wire \rgb_out[23]_i_2084_n_0 ;
  wire \rgb_out[23]_i_2085_n_0 ;
  wire \rgb_out[23]_i_2086_n_0 ;
  wire \rgb_out[23]_i_2087_n_0 ;
  wire \rgb_out[23]_i_2088_n_0 ;
  wire \rgb_out[23]_i_2089_n_0 ;
  wire \rgb_out[23]_i_2090_n_0 ;
  wire \rgb_out[23]_i_2091_n_0 ;
  wire \rgb_out[23]_i_2092_n_0 ;
  wire \rgb_out[23]_i_2093_n_0 ;
  wire \rgb_out[23]_i_2094_n_0 ;
  wire \rgb_out[23]_i_2095_n_0 ;
  wire \rgb_out[23]_i_2096_n_0 ;
  wire \rgb_out[23]_i_2097_n_0 ;
  wire \rgb_out[23]_i_2098_n_0 ;
  wire \rgb_out[23]_i_2099_n_0 ;
  wire \rgb_out[23]_i_2100_n_0 ;
  wire \rgb_out[23]_i_2101_n_0 ;
  wire \rgb_out[23]_i_2102_n_0 ;
  wire \rgb_out[23]_i_2103_n_0 ;
  wire \rgb_out[23]_i_2104_n_0 ;
  wire \rgb_out[23]_i_2105_n_0 ;
  wire \rgb_out[23]_i_2106_n_0 ;
  wire \rgb_out[23]_i_2107_n_0 ;
  wire \rgb_out[23]_i_2108_n_0 ;
  wire \rgb_out[23]_i_2109_n_0 ;
  wire \rgb_out[23]_i_2110_n_0 ;
  wire \rgb_out[23]_i_2111_n_0 ;
  wire \rgb_out[23]_i_2112_n_0 ;
  wire \rgb_out[23]_i_2113_n_0 ;
  wire \rgb_out[23]_i_2114_n_0 ;
  wire \rgb_out[23]_i_2115_n_0 ;
  wire \rgb_out[23]_i_2116_n_0 ;
  wire \rgb_out[23]_i_2117_n_0 ;
  wire \rgb_out[23]_i_2118_n_0 ;
  wire \rgb_out[23]_i_2119_n_0 ;
  wire \rgb_out[23]_i_2120_n_0 ;
  wire \rgb_out[23]_i_2121_n_0 ;
  wire \rgb_out[23]_i_2122_n_0 ;
  wire \rgb_out[23]_i_2123_n_0 ;
  wire \rgb_out[23]_i_2124_n_0 ;
  wire \rgb_out[23]_i_2131_n_0 ;
  wire \rgb_out[23]_i_2132_n_0 ;
  wire \rgb_out[23]_i_479_n_0 ;
  wire \rgb_out[23]_i_480_n_0 ;
  wire \rgb_out[23]_i_482_n_0 ;
  wire \rgb_out[23]_i_483_n_0 ;
  wire \rgb_out[23]_i_485_n_0 ;
  wire \rgb_out[23]_i_486_n_0 ;
  wire \rgb_out[23]_i_487_n_0 ;
  wire \rgb_out[23]_i_589_n_0 ;
  wire \rgb_out[23]_i_590_n_0 ;
  wire \rgb_out[23]_i_592_n_0 ;
  wire \rgb_out[23]_i_593_n_0 ;
  wire \rgb_out[23]_i_595_n_0 ;
  wire \rgb_out[23]_i_596_n_0 ;
  wire \rgb_out[23]_i_597_n_0 ;
  wire \rgb_out[23]_i_663_n_0 ;
  wire \rgb_out[23]_i_664_n_0 ;
  wire \rgb_out[23]_i_666_n_0 ;
  wire \rgb_out[23]_i_667_n_0 ;
  wire \rgb_out[23]_i_669_n_0 ;
  wire \rgb_out[23]_i_670_n_0 ;
  wire \rgb_out[23]_i_671_n_0 ;
  wire \rgb_out[23]_i_717_n_0 ;
  wire \rgb_out[23]_i_722_n_0 ;
  wire \rgb_out[23]_i_723_n_0 ;
  wire \rgb_out[23]_i_724_n_0 ;
  wire \rgb_out[23]_i_725_n_0 ;
  wire \rgb_out[23]_i_727_n_0 ;
  wire \rgb_out[23]_i_728_n_0 ;
  wire \rgb_out[23]_i_729_n_0 ;
  wire \rgb_out[23]_i_730_n_0 ;
  wire \rgb_out[23]_i_759_n_0 ;
  wire \rgb_out[23]_i_760_n_0 ;
  wire \rgb_out[23]_i_762_n_0 ;
  wire \rgb_out[23]_i_763_n_0 ;
  wire \rgb_out[23]_i_765_n_0 ;
  wire \rgb_out[23]_i_766_n_0 ;
  wire \rgb_out[23]_i_767_n_0 ;
  wire \rgb_out[23]_i_778_n_0 ;
  wire \rgb_out[23]_i_780_n_0 ;
  wire \rgb_out[23]_i_781_n_0 ;
  wire \rgb_out[23]_i_783_n_0 ;
  wire \rgb_out[23]_i_784_n_0 ;
  wire \rgb_out[23]_i_785_n_0 ;
  wire \rgb_out[23]_i_786_n_0 ;
  wire \rgb_out[23]_i_793_n_0 ;
  wire \rgb_out[23]_i_794_n_0 ;
  wire \rgb_out[23]_i_795_n_0 ;
  wire \rgb_out[23]_i_797_n_0 ;
  wire \rgb_out[23]_i_798_n_0 ;
  wire \rgb_out[23]_i_799_n_0 ;
  wire \rgb_out[23]_i_800_n_0 ;
  wire \rgb_out[23]_i_802_n_0 ;
  wire \rgb_out[23]_i_803_n_0 ;
  wire \rgb_out[23]_i_804_n_0 ;
  wire \rgb_out[23]_i_806_n_0 ;
  wire \rgb_out[23]_i_807_n_0 ;
  wire \rgb_out[23]_i_808_n_0 ;
  wire \rgb_out[23]_i_809_n_0 ;
  wire \rgb_out[23]_i_811_n_0 ;
  wire \rgb_out[23]_i_812_n_0 ;
  wire \rgb_out[23]_i_813_n_0 ;
  wire \rgb_out[23]_i_814_n_0 ;
  wire \rgb_out[23]_i_816_n_0 ;
  wire \rgb_out[23]_i_817_n_0 ;
  wire \rgb_out[23]_i_818_n_0 ;
  wire \rgb_out[23]_i_819_n_0 ;
  wire \rgb_out[23]_i_820_n_0 ;
  wire \rgb_out[23]_i_822_n_0 ;
  wire \rgb_out[23]_i_823_n_0 ;
  wire \rgb_out[23]_i_824_n_0 ;
  wire \rgb_out[23]_i_825_n_0 ;
  wire \rgb_out[23]_i_826_n_0 ;
  wire \rgb_out[23]_i_827_n_0 ;
  wire \rgb_out[23]_i_828_n_0 ;
  wire \rgb_out[23]_i_830_n_0 ;
  wire \rgb_out[23]_i_831_n_0 ;
  wire \rgb_out[23]_i_832_n_0 ;
  wire \rgb_out[23]_i_833_n_0 ;
  wire \rgb_out[23]_i_835_n_0 ;
  wire \rgb_out[23]_i_836_n_0 ;
  wire \rgb_out[23]_i_837_n_0 ;
  wire \rgb_out[23]_i_838_n_0 ;
  wire \rgb_out[23]_i_841_n_0 ;
  wire \rgb_out[23]_i_844_n_0 ;
  wire \rgb_out[23]_i_881_n_0 ;
  wire \rgb_out[23]_i_928_n_0 ;
  wire \rgb_out[23]_i_930_n_0 ;
  wire \rgb_out[23]_i_931_n_0 ;
  wire \rgb_out[23]_i_933_n_0 ;
  wire \rgb_out[23]_i_934_n_0 ;
  wire \rgb_out[23]_i_935_n_0 ;
  wire \rgb_out[23]_i_936_n_0 ;
  wire \rgb_out[23]_i_938_n_0 ;
  wire \rgb_out[23]_i_939_n_0 ;
  wire \rgb_out[23]_i_940_n_0 ;
  wire \rgb_out[23]_i_941_n_0 ;
  wire \rgb_out[23]_i_943_n_0 ;
  wire \rgb_out[23]_i_944_n_0 ;
  wire \rgb_out[23]_i_945_n_0 ;
  wire \rgb_out[23]_i_947_n_0 ;
  wire \rgb_out[23]_i_948_n_0 ;
  wire \rgb_out[23]_i_949_n_0 ;
  wire \rgb_out[23]_i_950_n_0 ;
  wire \rgb_out[23]_i_952_n_0 ;
  wire \rgb_out[23]_i_953_n_0 ;
  wire \rgb_out[23]_i_954_n_0 ;
  wire \rgb_out[23]_i_956_n_0 ;
  wire \rgb_out[23]_i_957_n_0 ;
  wire \rgb_out[23]_i_958_n_0 ;
  wire \rgb_out[23]_i_959_n_0 ;
  wire \rgb_out[23]_i_961_n_0 ;
  wire \rgb_out[23]_i_962_n_0 ;
  wire \rgb_out[23]_i_963_n_0 ;
  wire \rgb_out[23]_i_964_n_0 ;
  wire \rgb_out[23]_i_966_n_0 ;
  wire \rgb_out[23]_i_967_n_0 ;
  wire \rgb_out[23]_i_968_n_0 ;
  wire \rgb_out[23]_i_969_n_0 ;
  wire \rgb_out[23]_i_970_n_0 ;
  wire \rgb_out[23]_i_971_n_0 ;
  wire \rgb_out[23]_i_972_n_0 ;
  wire \rgb_out[23]_i_973_n_0 ;
  wire \rgb_out[23]_i_974_n_0 ;
  wire \rgb_out[23]_i_975_n_0 ;
  wire \rgb_out[23]_i_976_n_0 ;
  wire \rgb_out[23]_i_977_n_0 ;
  wire \rgb_out[23]_i_978_n_0 ;
  wire \rgb_out[23]_i_980_n_0 ;
  wire \rgb_out[23]_i_981_n_0 ;
  wire \rgb_out[23]_i_982_n_0 ;
  wire \rgb_out[23]_i_983_n_0 ;
  wire \rgb_out[23]_i_985_n_0 ;
  wire \rgb_out[23]_i_986_n_0 ;
  wire \rgb_out[23]_i_987_n_0 ;
  wire \rgb_out[23]_i_988_n_0 ;
  wire \rgb_out[23]_i_991_n_0 ;
  wire \rgb_out[23]_i_994_n_0 ;
  wire \rgb_out[23]_i_998_n_0 ;
  wire \rgb_out_reg[23]_i_1001_n_0 ;
  wire \rgb_out_reg[23]_i_1001_n_2 ;
  wire \rgb_out_reg[23]_i_1001_n_3 ;
  wire \rgb_out_reg[23]_i_1002_n_0 ;
  wire \rgb_out_reg[23]_i_1002_n_1 ;
  wire \rgb_out_reg[23]_i_1002_n_2 ;
  wire \rgb_out_reg[23]_i_1002_n_3 ;
  wire \rgb_out_reg[23]_i_1007_n_0 ;
  wire \rgb_out_reg[23]_i_1007_n_1 ;
  wire \rgb_out_reg[23]_i_1007_n_2 ;
  wire \rgb_out_reg[23]_i_1007_n_3 ;
  wire \rgb_out_reg[23]_i_1012_n_0 ;
  wire \rgb_out_reg[23]_i_1012_n_1 ;
  wire \rgb_out_reg[23]_i_1012_n_2 ;
  wire \rgb_out_reg[23]_i_1012_n_3 ;
  wire \rgb_out_reg[23]_i_1016_n_0 ;
  wire \rgb_out_reg[23]_i_1016_n_1 ;
  wire \rgb_out_reg[23]_i_1016_n_2 ;
  wire \rgb_out_reg[23]_i_1016_n_3 ;
  wire \rgb_out_reg[23]_i_1021_n_0 ;
  wire \rgb_out_reg[23]_i_1021_n_1 ;
  wire \rgb_out_reg[23]_i_1021_n_2 ;
  wire \rgb_out_reg[23]_i_1021_n_3 ;
  wire \rgb_out_reg[23]_i_1025_n_0 ;
  wire \rgb_out_reg[23]_i_1025_n_1 ;
  wire \rgb_out_reg[23]_i_1025_n_2 ;
  wire \rgb_out_reg[23]_i_1025_n_3 ;
  wire \rgb_out_reg[23]_i_1030_n_0 ;
  wire \rgb_out_reg[23]_i_1030_n_1 ;
  wire \rgb_out_reg[23]_i_1030_n_2 ;
  wire \rgb_out_reg[23]_i_1030_n_3 ;
  wire \rgb_out_reg[23]_i_1034_n_0 ;
  wire \rgb_out_reg[23]_i_1034_n_1 ;
  wire \rgb_out_reg[23]_i_1034_n_2 ;
  wire \rgb_out_reg[23]_i_1034_n_3 ;
  wire \rgb_out_reg[23]_i_1039_n_0 ;
  wire \rgb_out_reg[23]_i_1039_n_1 ;
  wire \rgb_out_reg[23]_i_1039_n_2 ;
  wire \rgb_out_reg[23]_i_1039_n_3 ;
  wire \rgb_out_reg[23]_i_1044_n_0 ;
  wire \rgb_out_reg[23]_i_1044_n_1 ;
  wire \rgb_out_reg[23]_i_1044_n_2 ;
  wire \rgb_out_reg[23]_i_1044_n_3 ;
  wire \rgb_out_reg[23]_i_1048_n_0 ;
  wire \rgb_out_reg[23]_i_1048_n_1 ;
  wire \rgb_out_reg[23]_i_1048_n_2 ;
  wire \rgb_out_reg[23]_i_1048_n_3 ;
  wire \rgb_out_reg[23]_i_1052_n_0 ;
  wire \rgb_out_reg[23]_i_1052_n_1 ;
  wire \rgb_out_reg[23]_i_1052_n_2 ;
  wire \rgb_out_reg[23]_i_1052_n_3 ;
  wire \rgb_out_reg[23]_i_1056_n_0 ;
  wire \rgb_out_reg[23]_i_1056_n_1 ;
  wire \rgb_out_reg[23]_i_1056_n_2 ;
  wire \rgb_out_reg[23]_i_1056_n_3 ;
  wire \rgb_out_reg[23]_i_1061_n_0 ;
  wire \rgb_out_reg[23]_i_1061_n_1 ;
  wire \rgb_out_reg[23]_i_1061_n_2 ;
  wire \rgb_out_reg[23]_i_1061_n_3 ;
  wire \rgb_out_reg[23]_i_1066_n_0 ;
  wire \rgb_out_reg[23]_i_1066_n_1 ;
  wire \rgb_out_reg[23]_i_1066_n_2 ;
  wire \rgb_out_reg[23]_i_1066_n_3 ;
  wire \rgb_out_reg[23]_i_1068_n_0 ;
  wire \rgb_out_reg[23]_i_1068_n_2 ;
  wire \rgb_out_reg[23]_i_1068_n_3 ;
  wire \rgb_out_reg[23]_i_1070_n_0 ;
  wire \rgb_out_reg[23]_i_1070_n_1 ;
  wire \rgb_out_reg[23]_i_1070_n_2 ;
  wire \rgb_out_reg[23]_i_1070_n_3 ;
  wire \rgb_out_reg[23]_i_1072_n_0 ;
  wire \rgb_out_reg[23]_i_1072_n_2 ;
  wire \rgb_out_reg[23]_i_1072_n_3 ;
  wire \rgb_out_reg[23]_i_1073_n_0 ;
  wire \rgb_out_reg[23]_i_1073_n_1 ;
  wire \rgb_out_reg[23]_i_1073_n_2 ;
  wire \rgb_out_reg[23]_i_1073_n_3 ;
  wire \rgb_out_reg[23]_i_1078_n_0 ;
  wire \rgb_out_reg[23]_i_1078_n_1 ;
  wire \rgb_out_reg[23]_i_1078_n_2 ;
  wire \rgb_out_reg[23]_i_1078_n_3 ;
  wire \rgb_out_reg[23]_i_1083_n_0 ;
  wire \rgb_out_reg[23]_i_1083_n_1 ;
  wire \rgb_out_reg[23]_i_1083_n_2 ;
  wire \rgb_out_reg[23]_i_1083_n_3 ;
  wire \rgb_out_reg[23]_i_1087_n_0 ;
  wire \rgb_out_reg[23]_i_1087_n_1 ;
  wire \rgb_out_reg[23]_i_1087_n_2 ;
  wire \rgb_out_reg[23]_i_1087_n_3 ;
  wire \rgb_out_reg[23]_i_1092_n_0 ;
  wire \rgb_out_reg[23]_i_1092_n_1 ;
  wire \rgb_out_reg[23]_i_1092_n_2 ;
  wire \rgb_out_reg[23]_i_1092_n_3 ;
  wire \rgb_out_reg[23]_i_1096_n_0 ;
  wire \rgb_out_reg[23]_i_1096_n_1 ;
  wire \rgb_out_reg[23]_i_1096_n_2 ;
  wire \rgb_out_reg[23]_i_1096_n_3 ;
  wire \rgb_out_reg[23]_i_1101_n_0 ;
  wire \rgb_out_reg[23]_i_1101_n_1 ;
  wire \rgb_out_reg[23]_i_1101_n_2 ;
  wire \rgb_out_reg[23]_i_1101_n_3 ;
  wire \rgb_out_reg[23]_i_1105_n_0 ;
  wire \rgb_out_reg[23]_i_1105_n_1 ;
  wire \rgb_out_reg[23]_i_1105_n_2 ;
  wire \rgb_out_reg[23]_i_1105_n_3 ;
  wire \rgb_out_reg[23]_i_1110_n_0 ;
  wire \rgb_out_reg[23]_i_1110_n_1 ;
  wire \rgb_out_reg[23]_i_1110_n_2 ;
  wire \rgb_out_reg[23]_i_1110_n_3 ;
  wire \rgb_out_reg[23]_i_1115_n_0 ;
  wire \rgb_out_reg[23]_i_1115_n_1 ;
  wire \rgb_out_reg[23]_i_1115_n_2 ;
  wire \rgb_out_reg[23]_i_1115_n_3 ;
  wire \rgb_out_reg[23]_i_1119_n_0 ;
  wire \rgb_out_reg[23]_i_1119_n_1 ;
  wire \rgb_out_reg[23]_i_1119_n_2 ;
  wire \rgb_out_reg[23]_i_1119_n_3 ;
  wire \rgb_out_reg[23]_i_1123_n_0 ;
  wire \rgb_out_reg[23]_i_1123_n_1 ;
  wire \rgb_out_reg[23]_i_1123_n_2 ;
  wire \rgb_out_reg[23]_i_1123_n_3 ;
  wire \rgb_out_reg[23]_i_1127_n_0 ;
  wire \rgb_out_reg[23]_i_1127_n_1 ;
  wire \rgb_out_reg[23]_i_1127_n_2 ;
  wire \rgb_out_reg[23]_i_1127_n_3 ;
  wire \rgb_out_reg[23]_i_1132_n_0 ;
  wire \rgb_out_reg[23]_i_1132_n_1 ;
  wire \rgb_out_reg[23]_i_1132_n_2 ;
  wire \rgb_out_reg[23]_i_1132_n_3 ;
  wire \rgb_out_reg[23]_i_1137_n_0 ;
  wire \rgb_out_reg[23]_i_1137_n_1 ;
  wire \rgb_out_reg[23]_i_1137_n_2 ;
  wire \rgb_out_reg[23]_i_1137_n_3 ;
  wire \rgb_out_reg[23]_i_1139_n_0 ;
  wire \rgb_out_reg[23]_i_1139_n_2 ;
  wire \rgb_out_reg[23]_i_1139_n_3 ;
  wire \rgb_out_reg[23]_i_1142_n_0 ;
  wire \rgb_out_reg[23]_i_1142_n_1 ;
  wire \rgb_out_reg[23]_i_1142_n_2 ;
  wire \rgb_out_reg[23]_i_1142_n_3 ;
  wire \rgb_out_reg[23]_i_1147_n_0 ;
  wire \rgb_out_reg[23]_i_1147_n_1 ;
  wire \rgb_out_reg[23]_i_1147_n_2 ;
  wire \rgb_out_reg[23]_i_1147_n_3 ;
  wire \rgb_out_reg[23]_i_1152_n_0 ;
  wire \rgb_out_reg[23]_i_1152_n_1 ;
  wire \rgb_out_reg[23]_i_1152_n_2 ;
  wire \rgb_out_reg[23]_i_1152_n_3 ;
  wire \rgb_out_reg[23]_i_1156_n_0 ;
  wire \rgb_out_reg[23]_i_1156_n_1 ;
  wire \rgb_out_reg[23]_i_1156_n_2 ;
  wire \rgb_out_reg[23]_i_1156_n_3 ;
  wire \rgb_out_reg[23]_i_1161_n_0 ;
  wire \rgb_out_reg[23]_i_1161_n_1 ;
  wire \rgb_out_reg[23]_i_1161_n_2 ;
  wire \rgb_out_reg[23]_i_1161_n_3 ;
  wire \rgb_out_reg[23]_i_1165_n_0 ;
  wire \rgb_out_reg[23]_i_1165_n_1 ;
  wire \rgb_out_reg[23]_i_1165_n_2 ;
  wire \rgb_out_reg[23]_i_1165_n_3 ;
  wire \rgb_out_reg[23]_i_1170_n_0 ;
  wire \rgb_out_reg[23]_i_1170_n_1 ;
  wire \rgb_out_reg[23]_i_1170_n_2 ;
  wire \rgb_out_reg[23]_i_1170_n_3 ;
  wire \rgb_out_reg[23]_i_1175_n_0 ;
  wire \rgb_out_reg[23]_i_1175_n_1 ;
  wire \rgb_out_reg[23]_i_1175_n_2 ;
  wire \rgb_out_reg[23]_i_1175_n_3 ;
  wire \rgb_out_reg[23]_i_1190_n_0 ;
  wire \rgb_out_reg[23]_i_1190_n_1 ;
  wire \rgb_out_reg[23]_i_1190_n_2 ;
  wire \rgb_out_reg[23]_i_1190_n_3 ;
  wire \rgb_out_reg[23]_i_1195_n_0 ;
  wire \rgb_out_reg[23]_i_1195_n_1 ;
  wire \rgb_out_reg[23]_i_1195_n_2 ;
  wire \rgb_out_reg[23]_i_1195_n_3 ;
  wire \rgb_out_reg[23]_i_1200_n_0 ;
  wire \rgb_out_reg[23]_i_1200_n_1 ;
  wire \rgb_out_reg[23]_i_1200_n_2 ;
  wire \rgb_out_reg[23]_i_1200_n_3 ;
  wire \rgb_out_reg[23]_i_1203_n_0 ;
  wire \rgb_out_reg[23]_i_1203_n_1 ;
  wire \rgb_out_reg[23]_i_1203_n_2 ;
  wire \rgb_out_reg[23]_i_1203_n_3 ;
  wire \rgb_out_reg[23]_i_1217_n_0 ;
  wire \rgb_out_reg[23]_i_1217_n_1 ;
  wire \rgb_out_reg[23]_i_1217_n_2 ;
  wire \rgb_out_reg[23]_i_1217_n_3 ;
  wire \rgb_out_reg[23]_i_1224_n_0 ;
  wire \rgb_out_reg[23]_i_1224_n_1 ;
  wire \rgb_out_reg[23]_i_1224_n_2 ;
  wire \rgb_out_reg[23]_i_1224_n_3 ;
  wire \rgb_out_reg[23]_i_1244_n_0 ;
  wire \rgb_out_reg[23]_i_1244_n_1 ;
  wire \rgb_out_reg[23]_i_1244_n_2 ;
  wire \rgb_out_reg[23]_i_1244_n_3 ;
  wire \rgb_out_reg[23]_i_1249_n_0 ;
  wire \rgb_out_reg[23]_i_1249_n_1 ;
  wire \rgb_out_reg[23]_i_1249_n_2 ;
  wire \rgb_out_reg[23]_i_1249_n_3 ;
  wire \rgb_out_reg[23]_i_1258_n_0 ;
  wire \rgb_out_reg[23]_i_1258_n_1 ;
  wire \rgb_out_reg[23]_i_1258_n_2 ;
  wire \rgb_out_reg[23]_i_1258_n_3 ;
  wire \rgb_out_reg[23]_i_1262_n_0 ;
  wire \rgb_out_reg[23]_i_1262_n_1 ;
  wire \rgb_out_reg[23]_i_1262_n_2 ;
  wire \rgb_out_reg[23]_i_1262_n_3 ;
  wire \rgb_out_reg[23]_i_1267_n_0 ;
  wire \rgb_out_reg[23]_i_1267_n_1 ;
  wire \rgb_out_reg[23]_i_1267_n_2 ;
  wire \rgb_out_reg[23]_i_1267_n_3 ;
  wire \rgb_out_reg[23]_i_1271_n_0 ;
  wire \rgb_out_reg[23]_i_1271_n_1 ;
  wire \rgb_out_reg[23]_i_1271_n_2 ;
  wire \rgb_out_reg[23]_i_1271_n_3 ;
  wire \rgb_out_reg[23]_i_1275_n_0 ;
  wire \rgb_out_reg[23]_i_1275_n_1 ;
  wire \rgb_out_reg[23]_i_1275_n_2 ;
  wire \rgb_out_reg[23]_i_1275_n_3 ;
  wire \rgb_out_reg[23]_i_1280_n_0 ;
  wire \rgb_out_reg[23]_i_1280_n_1 ;
  wire \rgb_out_reg[23]_i_1280_n_2 ;
  wire \rgb_out_reg[23]_i_1280_n_3 ;
  wire \rgb_out_reg[23]_i_1284_n_0 ;
  wire \rgb_out_reg[23]_i_1284_n_1 ;
  wire \rgb_out_reg[23]_i_1284_n_2 ;
  wire \rgb_out_reg[23]_i_1284_n_3 ;
  wire \rgb_out_reg[23]_i_1289_n_0 ;
  wire \rgb_out_reg[23]_i_1289_n_1 ;
  wire \rgb_out_reg[23]_i_1289_n_2 ;
  wire \rgb_out_reg[23]_i_1289_n_3 ;
  wire \rgb_out_reg[23]_i_1293_n_0 ;
  wire \rgb_out_reg[23]_i_1293_n_1 ;
  wire \rgb_out_reg[23]_i_1293_n_2 ;
  wire \rgb_out_reg[23]_i_1293_n_3 ;
  wire \rgb_out_reg[23]_i_1298_n_0 ;
  wire \rgb_out_reg[23]_i_1298_n_1 ;
  wire \rgb_out_reg[23]_i_1298_n_2 ;
  wire \rgb_out_reg[23]_i_1298_n_3 ;
  wire \rgb_out_reg[23]_i_1303_n_0 ;
  wire \rgb_out_reg[23]_i_1303_n_1 ;
  wire \rgb_out_reg[23]_i_1303_n_2 ;
  wire \rgb_out_reg[23]_i_1303_n_3 ;
  wire \rgb_out_reg[23]_i_1313_n_0 ;
  wire \rgb_out_reg[23]_i_1313_n_1 ;
  wire \rgb_out_reg[23]_i_1313_n_2 ;
  wire \rgb_out_reg[23]_i_1313_n_3 ;
  wire \rgb_out_reg[23]_i_1326_n_0 ;
  wire \rgb_out_reg[23]_i_1326_n_1 ;
  wire \rgb_out_reg[23]_i_1326_n_2 ;
  wire \rgb_out_reg[23]_i_1326_n_3 ;
  wire \rgb_out_reg[23]_i_1336_n_0 ;
  wire \rgb_out_reg[23]_i_1336_n_1 ;
  wire \rgb_out_reg[23]_i_1336_n_2 ;
  wire \rgb_out_reg[23]_i_1336_n_3 ;
  wire \rgb_out_reg[23]_i_1342_n_0 ;
  wire \rgb_out_reg[23]_i_1342_n_1 ;
  wire \rgb_out_reg[23]_i_1342_n_2 ;
  wire \rgb_out_reg[23]_i_1342_n_3 ;
  wire \rgb_out_reg[23]_i_1349_n_0 ;
  wire \rgb_out_reg[23]_i_1349_n_1 ;
  wire \rgb_out_reg[23]_i_1349_n_2 ;
  wire \rgb_out_reg[23]_i_1349_n_3 ;
  wire \rgb_out_reg[23]_i_1354_n_0 ;
  wire \rgb_out_reg[23]_i_1354_n_1 ;
  wire \rgb_out_reg[23]_i_1354_n_2 ;
  wire \rgb_out_reg[23]_i_1354_n_3 ;
  wire \rgb_out_reg[23]_i_1359_n_0 ;
  wire \rgb_out_reg[23]_i_1359_n_1 ;
  wire \rgb_out_reg[23]_i_1359_n_2 ;
  wire \rgb_out_reg[23]_i_1359_n_3 ;
  wire \rgb_out_reg[23]_i_1362_n_0 ;
  wire \rgb_out_reg[23]_i_1362_n_1 ;
  wire \rgb_out_reg[23]_i_1362_n_2 ;
  wire \rgb_out_reg[23]_i_1362_n_3 ;
  wire \rgb_out_reg[23]_i_1371_n_0 ;
  wire \rgb_out_reg[23]_i_1371_n_1 ;
  wire \rgb_out_reg[23]_i_1371_n_2 ;
  wire \rgb_out_reg[23]_i_1371_n_3 ;
  wire \rgb_out_reg[23]_i_1376_n_0 ;
  wire \rgb_out_reg[23]_i_1376_n_1 ;
  wire \rgb_out_reg[23]_i_1376_n_2 ;
  wire \rgb_out_reg[23]_i_1376_n_3 ;
  wire \rgb_out_reg[23]_i_1503_n_0 ;
  wire \rgb_out_reg[23]_i_1503_n_1 ;
  wire \rgb_out_reg[23]_i_1503_n_2 ;
  wire \rgb_out_reg[23]_i_1503_n_3 ;
  wire \rgb_out_reg[23]_i_1508_n_0 ;
  wire \rgb_out_reg[23]_i_1508_n_1 ;
  wire \rgb_out_reg[23]_i_1508_n_2 ;
  wire \rgb_out_reg[23]_i_1508_n_3 ;
  wire \rgb_out_reg[23]_i_1516_n_0 ;
  wire \rgb_out_reg[23]_i_1516_n_1 ;
  wire \rgb_out_reg[23]_i_1516_n_2 ;
  wire \rgb_out_reg[23]_i_1516_n_3 ;
  wire \rgb_out_reg[23]_i_1593_n_0 ;
  wire \rgb_out_reg[23]_i_1593_n_1 ;
  wire \rgb_out_reg[23]_i_1593_n_2 ;
  wire \rgb_out_reg[23]_i_1593_n_3 ;
  wire \rgb_out_reg[23]_i_1603_n_0 ;
  wire \rgb_out_reg[23]_i_1603_n_1 ;
  wire \rgb_out_reg[23]_i_1603_n_2 ;
  wire \rgb_out_reg[23]_i_1603_n_3 ;
  wire \rgb_out_reg[23]_i_1657_n_0 ;
  wire \rgb_out_reg[23]_i_1657_n_1 ;
  wire \rgb_out_reg[23]_i_1657_n_2 ;
  wire \rgb_out_reg[23]_i_1657_n_3 ;
  wire \rgb_out_reg[23]_i_1665_n_0 ;
  wire \rgb_out_reg[23]_i_1665_n_1 ;
  wire \rgb_out_reg[23]_i_1665_n_2 ;
  wire \rgb_out_reg[23]_i_1665_n_3 ;
  wire \rgb_out_reg[23]_i_1708_n_0 ;
  wire \rgb_out_reg[23]_i_1708_n_1 ;
  wire \rgb_out_reg[23]_i_1708_n_2 ;
  wire \rgb_out_reg[23]_i_1708_n_3 ;
  wire \rgb_out_reg[23]_i_1717_n_0 ;
  wire \rgb_out_reg[23]_i_1717_n_1 ;
  wire \rgb_out_reg[23]_i_1717_n_2 ;
  wire \rgb_out_reg[23]_i_1717_n_3 ;
  wire \rgb_out_reg[23]_i_1771_n_0 ;
  wire \rgb_out_reg[23]_i_1771_n_1 ;
  wire \rgb_out_reg[23]_i_1771_n_2 ;
  wire \rgb_out_reg[23]_i_1771_n_3 ;
  wire \rgb_out_reg[23]_i_1779_n_0 ;
  wire \rgb_out_reg[23]_i_1779_n_1 ;
  wire \rgb_out_reg[23]_i_1779_n_2 ;
  wire \rgb_out_reg[23]_i_1779_n_3 ;
  wire \rgb_out_reg[23]_i_1822_n_0 ;
  wire \rgb_out_reg[23]_i_1822_n_1 ;
  wire \rgb_out_reg[23]_i_1822_n_2 ;
  wire \rgb_out_reg[23]_i_1822_n_3 ;
  wire \rgb_out_reg[23]_i_1827_n_0 ;
  wire \rgb_out_reg[23]_i_1827_n_1 ;
  wire \rgb_out_reg[23]_i_1827_n_2 ;
  wire \rgb_out_reg[23]_i_1827_n_3 ;
  wire \rgb_out_reg[23]_i_1835_n_0 ;
  wire \rgb_out_reg[23]_i_1835_n_1 ;
  wire \rgb_out_reg[23]_i_1835_n_2 ;
  wire \rgb_out_reg[23]_i_1835_n_3 ;
  wire \rgb_out_reg[23]_i_189_n_2 ;
  wire \rgb_out_reg[23]_i_189_n_3 ;
  wire \rgb_out_reg[23]_i_1904_n_0 ;
  wire \rgb_out_reg[23]_i_1904_n_1 ;
  wire \rgb_out_reg[23]_i_1904_n_2 ;
  wire \rgb_out_reg[23]_i_1904_n_3 ;
  wire \rgb_out_reg[23]_i_1905_n_0 ;
  wire \rgb_out_reg[23]_i_1905_n_1 ;
  wire \rgb_out_reg[23]_i_1905_n_2 ;
  wire \rgb_out_reg[23]_i_1905_n_3 ;
  wire \rgb_out_reg[23]_i_1910_n_0 ;
  wire \rgb_out_reg[23]_i_1910_n_1 ;
  wire \rgb_out_reg[23]_i_1910_n_2 ;
  wire \rgb_out_reg[23]_i_1910_n_3 ;
  wire \rgb_out_reg[23]_i_191_n_2 ;
  wire \rgb_out_reg[23]_i_191_n_3 ;
  wire \rgb_out_reg[23]_i_2011_n_0 ;
  wire \rgb_out_reg[23]_i_2011_n_1 ;
  wire \rgb_out_reg[23]_i_2011_n_2 ;
  wire \rgb_out_reg[23]_i_2011_n_3 ;
  wire \rgb_out_reg[23]_i_311_n_2 ;
  wire \rgb_out_reg[23]_i_311_n_3 ;
  wire \rgb_out_reg[23]_i_313_n_2 ;
  wire \rgb_out_reg[23]_i_313_n_3 ;
  wire \rgb_out_reg[23]_i_329_n_2 ;
  wire \rgb_out_reg[23]_i_329_n_3 ;
  wire \rgb_out_reg[23]_i_331_n_2 ;
  wire \rgb_out_reg[23]_i_331_n_3 ;
  wire \rgb_out_reg[23]_i_438_n_3 ;
  wire \rgb_out_reg[23]_i_440_n_2 ;
  wire \rgb_out_reg[23]_i_440_n_3 ;
  wire \rgb_out_reg[23]_i_441_n_2 ;
  wire \rgb_out_reg[23]_i_441_n_3 ;
  wire \rgb_out_reg[23]_i_450_n_2 ;
  wire \rgb_out_reg[23]_i_450_n_3 ;
  wire \rgb_out_reg[23]_i_452_n_2 ;
  wire \rgb_out_reg[23]_i_452_n_3 ;
  wire \rgb_out_reg[23]_i_470_n_2 ;
  wire \rgb_out_reg[23]_i_470_n_3 ;
  wire \rgb_out_reg[23]_i_471_n_2 ;
  wire \rgb_out_reg[23]_i_471_n_3 ;
  wire \rgb_out_reg[23]_i_473_n_2 ;
  wire \rgb_out_reg[23]_i_473_n_3 ;
  wire \rgb_out_reg[23]_i_474_n_2 ;
  wire \rgb_out_reg[23]_i_474_n_3 ;
  wire \rgb_out_reg[23]_i_475_n_2 ;
  wire \rgb_out_reg[23]_i_475_n_3 ;
  wire \rgb_out_reg[23]_i_476_n_2 ;
  wire \rgb_out_reg[23]_i_476_n_3 ;
  wire \rgb_out_reg[23]_i_477_n_2 ;
  wire \rgb_out_reg[23]_i_477_n_3 ;
  wire \rgb_out_reg[23]_i_478_n_0 ;
  wire \rgb_out_reg[23]_i_478_n_1 ;
  wire \rgb_out_reg[23]_i_478_n_2 ;
  wire \rgb_out_reg[23]_i_478_n_3 ;
  wire \rgb_out_reg[23]_i_481_n_1 ;
  wire \rgb_out_reg[23]_i_481_n_3 ;
  wire \rgb_out_reg[23]_i_484_n_0 ;
  wire \rgb_out_reg[23]_i_484_n_1 ;
  wire \rgb_out_reg[23]_i_484_n_2 ;
  wire \rgb_out_reg[23]_i_484_n_3 ;
  wire \rgb_out_reg[23]_i_488_n_2 ;
  wire \rgb_out_reg[23]_i_488_n_3 ;
  wire \rgb_out_reg[23]_i_489_n_2 ;
  wire \rgb_out_reg[23]_i_489_n_3 ;
  wire \rgb_out_reg[23]_i_490_n_3 ;
  wire \rgb_out_reg[23]_i_491_n_3 ;
  wire \rgb_out_reg[23]_i_580_n_2 ;
  wire \rgb_out_reg[23]_i_580_n_3 ;
  wire \rgb_out_reg[23]_i_581_n_2 ;
  wire \rgb_out_reg[23]_i_581_n_3 ;
  wire \rgb_out_reg[23]_i_582_n_2 ;
  wire \rgb_out_reg[23]_i_582_n_3 ;
  wire \rgb_out_reg[23]_i_583_n_2 ;
  wire \rgb_out_reg[23]_i_583_n_3 ;
  wire \rgb_out_reg[23]_i_584_n_2 ;
  wire \rgb_out_reg[23]_i_584_n_3 ;
  wire \rgb_out_reg[23]_i_585_n_2 ;
  wire \rgb_out_reg[23]_i_585_n_3 ;
  wire \rgb_out_reg[23]_i_586_n_2 ;
  wire \rgb_out_reg[23]_i_586_n_3 ;
  wire \rgb_out_reg[23]_i_587_n_2 ;
  wire \rgb_out_reg[23]_i_587_n_3 ;
  wire \rgb_out_reg[23]_i_588_n_0 ;
  wire \rgb_out_reg[23]_i_588_n_1 ;
  wire \rgb_out_reg[23]_i_588_n_2 ;
  wire \rgb_out_reg[23]_i_588_n_3 ;
  wire \rgb_out_reg[23]_i_591_n_0 ;
  wire \rgb_out_reg[23]_i_591_n_2 ;
  wire \rgb_out_reg[23]_i_591_n_3 ;
  wire \rgb_out_reg[23]_i_594_n_0 ;
  wire \rgb_out_reg[23]_i_594_n_1 ;
  wire \rgb_out_reg[23]_i_594_n_2 ;
  wire \rgb_out_reg[23]_i_594_n_3 ;
  wire \rgb_out_reg[23]_i_598_n_2 ;
  wire \rgb_out_reg[23]_i_598_n_3 ;
  wire \rgb_out_reg[23]_i_599_n_2 ;
  wire \rgb_out_reg[23]_i_599_n_3 ;
  wire \rgb_out_reg[23]_i_600_n_3 ;
  wire \rgb_out_reg[23]_i_601_n_3 ;
  wire \rgb_out_reg[23]_i_602_n_3 ;
  wire \rgb_out_reg[23]_i_604_n_2 ;
  wire \rgb_out_reg[23]_i_604_n_3 ;
  wire \rgb_out_reg[23]_i_605_n_2 ;
  wire \rgb_out_reg[23]_i_605_n_3 ;
  wire \rgb_out_reg[23]_i_606_n_2 ;
  wire \rgb_out_reg[23]_i_606_n_3 ;
  wire \rgb_out_reg[23]_i_607_n_2 ;
  wire \rgb_out_reg[23]_i_607_n_3 ;
  wire \rgb_out_reg[23]_i_609_n_2 ;
  wire \rgb_out_reg[23]_i_609_n_3 ;
  wire \rgb_out_reg[23]_i_611_n_2 ;
  wire \rgb_out_reg[23]_i_611_n_3 ;
  wire \rgb_out_reg[23]_i_612_n_2 ;
  wire \rgb_out_reg[23]_i_612_n_3 ;
  wire \rgb_out_reg[23]_i_613_n_2 ;
  wire \rgb_out_reg[23]_i_613_n_3 ;
  wire \rgb_out_reg[23]_i_616_n_2 ;
  wire \rgb_out_reg[23]_i_616_n_3 ;
  wire \rgb_out_reg[23]_i_617_n_2 ;
  wire \rgb_out_reg[23]_i_617_n_3 ;
  wire \rgb_out_reg[23]_i_620_n_2 ;
  wire \rgb_out_reg[23]_i_620_n_3 ;
  wire \rgb_out_reg[23]_i_622_n_2 ;
  wire \rgb_out_reg[23]_i_622_n_3 ;
  wire \rgb_out_reg[23]_i_624_n_2 ;
  wire \rgb_out_reg[23]_i_624_n_3 ;
  wire \rgb_out_reg[23]_i_626_n_2 ;
  wire \rgb_out_reg[23]_i_626_n_3 ;
  wire \rgb_out_reg[23]_i_628_n_3 ;
  wire \rgb_out_reg[23]_i_630_n_2 ;
  wire \rgb_out_reg[23]_i_630_n_3 ;
  wire \rgb_out_reg[23]_i_631_n_2 ;
  wire \rgb_out_reg[23]_i_631_n_3 ;
  wire \rgb_out_reg[23]_i_632_n_2 ;
  wire \rgb_out_reg[23]_i_632_n_3 ;
  wire \rgb_out_reg[23]_i_633_n_2 ;
  wire \rgb_out_reg[23]_i_633_n_3 ;
  wire \rgb_out_reg[23]_i_635_n_2 ;
  wire \rgb_out_reg[23]_i_635_n_3 ;
  wire \rgb_out_reg[23]_i_637_n_2 ;
  wire \rgb_out_reg[23]_i_637_n_3 ;
  wire \rgb_out_reg[23]_i_638_n_2 ;
  wire \rgb_out_reg[23]_i_638_n_3 ;
  wire \rgb_out_reg[23]_i_639_n_2 ;
  wire \rgb_out_reg[23]_i_639_n_3 ;
  wire \rgb_out_reg[23]_i_642_n_2 ;
  wire \rgb_out_reg[23]_i_642_n_3 ;
  wire \rgb_out_reg[23]_i_643_n_2 ;
  wire \rgb_out_reg[23]_i_643_n_3 ;
  wire \rgb_out_reg[23]_i_646_n_2 ;
  wire \rgb_out_reg[23]_i_646_n_3 ;
  wire \rgb_out_reg[23]_i_648_n_2 ;
  wire \rgb_out_reg[23]_i_648_n_3 ;
  wire \rgb_out_reg[23]_i_650_n_2 ;
  wire \rgb_out_reg[23]_i_650_n_3 ;
  wire \rgb_out_reg[23]_i_652_n_2 ;
  wire \rgb_out_reg[23]_i_652_n_3 ;
  wire \rgb_out_reg[23]_i_654_n_2 ;
  wire \rgb_out_reg[23]_i_654_n_3 ;
  wire \rgb_out_reg[23]_i_655_n_2 ;
  wire \rgb_out_reg[23]_i_655_n_3 ;
  wire \rgb_out_reg[23]_i_656_n_2 ;
  wire \rgb_out_reg[23]_i_656_n_3 ;
  wire \rgb_out_reg[23]_i_657_n_2 ;
  wire \rgb_out_reg[23]_i_657_n_3 ;
  wire \rgb_out_reg[23]_i_658_n_2 ;
  wire \rgb_out_reg[23]_i_658_n_3 ;
  wire \rgb_out_reg[23]_i_659_n_2 ;
  wire \rgb_out_reg[23]_i_659_n_3 ;
  wire \rgb_out_reg[23]_i_660_n_2 ;
  wire \rgb_out_reg[23]_i_660_n_3 ;
  wire \rgb_out_reg[23]_i_661_n_2 ;
  wire \rgb_out_reg[23]_i_661_n_3 ;
  wire \rgb_out_reg[23]_i_662_n_0 ;
  wire \rgb_out_reg[23]_i_662_n_1 ;
  wire \rgb_out_reg[23]_i_662_n_2 ;
  wire \rgb_out_reg[23]_i_662_n_3 ;
  wire \rgb_out_reg[23]_i_665_n_0 ;
  wire \rgb_out_reg[23]_i_665_n_2 ;
  wire \rgb_out_reg[23]_i_665_n_3 ;
  wire \rgb_out_reg[23]_i_668_n_0 ;
  wire \rgb_out_reg[23]_i_668_n_1 ;
  wire \rgb_out_reg[23]_i_668_n_2 ;
  wire \rgb_out_reg[23]_i_668_n_3 ;
  wire \rgb_out_reg[23]_i_672_n_2 ;
  wire \rgb_out_reg[23]_i_672_n_3 ;
  wire \rgb_out_reg[23]_i_673_n_2 ;
  wire \rgb_out_reg[23]_i_673_n_3 ;
  wire \rgb_out_reg[23]_i_674_n_3 ;
  wire \rgb_out_reg[23]_i_675_n_3 ;
  wire \rgb_out_reg[23]_i_714_n_0 ;
  wire \rgb_out_reg[23]_i_714_n_1 ;
  wire \rgb_out_reg[23]_i_714_n_2 ;
  wire \rgb_out_reg[23]_i_714_n_3 ;
  wire \rgb_out_reg[23]_i_716_n_3 ;
  wire \rgb_out_reg[23]_i_718_n_0 ;
  wire \rgb_out_reg[23]_i_718_n_1 ;
  wire \rgb_out_reg[23]_i_718_n_2 ;
  wire \rgb_out_reg[23]_i_718_n_3 ;
  wire \rgb_out_reg[23]_i_720_n_0 ;
  wire \rgb_out_reg[23]_i_720_n_2 ;
  wire \rgb_out_reg[23]_i_720_n_3 ;
  wire \rgb_out_reg[23]_i_721_n_0 ;
  wire \rgb_out_reg[23]_i_721_n_1 ;
  wire \rgb_out_reg[23]_i_721_n_2 ;
  wire \rgb_out_reg[23]_i_721_n_3 ;
  wire \rgb_out_reg[23]_i_726_n_0 ;
  wire \rgb_out_reg[23]_i_726_n_1 ;
  wire \rgb_out_reg[23]_i_726_n_2 ;
  wire \rgb_out_reg[23]_i_726_n_3 ;
  wire \rgb_out_reg[23]_i_731_n_2 ;
  wire \rgb_out_reg[23]_i_731_n_3 ;
  wire \rgb_out_reg[23]_i_732_n_2 ;
  wire \rgb_out_reg[23]_i_732_n_3 ;
  wire \rgb_out_reg[23]_i_735_n_2 ;
  wire \rgb_out_reg[23]_i_735_n_3 ;
  wire \rgb_out_reg[23]_i_737_n_2 ;
  wire \rgb_out_reg[23]_i_737_n_3 ;
  wire \rgb_out_reg[23]_i_739_n_2 ;
  wire \rgb_out_reg[23]_i_739_n_3 ;
  wire \rgb_out_reg[23]_i_740_n_2 ;
  wire \rgb_out_reg[23]_i_740_n_3 ;
  wire \rgb_out_reg[23]_i_741_n_2 ;
  wire \rgb_out_reg[23]_i_741_n_3 ;
  wire \rgb_out_reg[23]_i_743_n_2 ;
  wire \rgb_out_reg[23]_i_743_n_3 ;
  wire \rgb_out_reg[23]_i_745_n_2 ;
  wire \rgb_out_reg[23]_i_745_n_3 ;
  wire \rgb_out_reg[23]_i_746_n_2 ;
  wire \rgb_out_reg[23]_i_746_n_3 ;
  wire \rgb_out_reg[23]_i_747_n_2 ;
  wire \rgb_out_reg[23]_i_747_n_3 ;
  wire \rgb_out_reg[23]_i_750_n_2 ;
  wire \rgb_out_reg[23]_i_750_n_3 ;
  wire \rgb_out_reg[23]_i_751_n_2 ;
  wire \rgb_out_reg[23]_i_751_n_3 ;
  wire \rgb_out_reg[23]_i_753_n_2 ;
  wire \rgb_out_reg[23]_i_753_n_3 ;
  wire \rgb_out_reg[23]_i_756_n_2 ;
  wire \rgb_out_reg[23]_i_756_n_3 ;
  wire \rgb_out_reg[23]_i_758_n_0 ;
  wire \rgb_out_reg[23]_i_758_n_1 ;
  wire \rgb_out_reg[23]_i_758_n_2 ;
  wire \rgb_out_reg[23]_i_758_n_3 ;
  wire \rgb_out_reg[23]_i_761_n_3 ;
  wire \rgb_out_reg[23]_i_764_n_0 ;
  wire \rgb_out_reg[23]_i_764_n_1 ;
  wire \rgb_out_reg[23]_i_764_n_2 ;
  wire \rgb_out_reg[23]_i_764_n_3 ;
  wire \rgb_out_reg[23]_i_768_n_2 ;
  wire \rgb_out_reg[23]_i_768_n_3 ;
  wire \rgb_out_reg[23]_i_769_n_2 ;
  wire \rgb_out_reg[23]_i_769_n_3 ;
  wire \rgb_out_reg[23]_i_770_n_3 ;
  wire \rgb_out_reg[23]_i_771_n_3 ;
  wire \rgb_out_reg[23]_i_777_n_0 ;
  wire \rgb_out_reg[23]_i_777_n_1 ;
  wire \rgb_out_reg[23]_i_777_n_2 ;
  wire \rgb_out_reg[23]_i_777_n_3 ;
  wire \rgb_out_reg[23]_i_779_n_0 ;
  wire \rgb_out_reg[23]_i_779_n_2 ;
  wire \rgb_out_reg[23]_i_779_n_3 ;
  wire \rgb_out_reg[23]_i_782_n_0 ;
  wire \rgb_out_reg[23]_i_782_n_1 ;
  wire \rgb_out_reg[23]_i_782_n_2 ;
  wire \rgb_out_reg[23]_i_782_n_3 ;
  wire \rgb_out_reg[23]_i_792_n_0 ;
  wire \rgb_out_reg[23]_i_792_n_1 ;
  wire \rgb_out_reg[23]_i_792_n_2 ;
  wire \rgb_out_reg[23]_i_792_n_3 ;
  wire \rgb_out_reg[23]_i_796_n_0 ;
  wire \rgb_out_reg[23]_i_796_n_1 ;
  wire \rgb_out_reg[23]_i_796_n_2 ;
  wire \rgb_out_reg[23]_i_796_n_3 ;
  wire \rgb_out_reg[23]_i_801_n_0 ;
  wire \rgb_out_reg[23]_i_801_n_1 ;
  wire \rgb_out_reg[23]_i_801_n_2 ;
  wire \rgb_out_reg[23]_i_801_n_3 ;
  wire \rgb_out_reg[23]_i_805_n_0 ;
  wire \rgb_out_reg[23]_i_805_n_1 ;
  wire \rgb_out_reg[23]_i_805_n_2 ;
  wire \rgb_out_reg[23]_i_805_n_3 ;
  wire \rgb_out_reg[23]_i_810_n_0 ;
  wire \rgb_out_reg[23]_i_810_n_1 ;
  wire \rgb_out_reg[23]_i_810_n_2 ;
  wire \rgb_out_reg[23]_i_810_n_3 ;
  wire \rgb_out_reg[23]_i_815_n_0 ;
  wire \rgb_out_reg[23]_i_815_n_1 ;
  wire \rgb_out_reg[23]_i_815_n_2 ;
  wire \rgb_out_reg[23]_i_815_n_3 ;
  wire \rgb_out_reg[23]_i_821_n_0 ;
  wire \rgb_out_reg[23]_i_821_n_1 ;
  wire \rgb_out_reg[23]_i_821_n_2 ;
  wire \rgb_out_reg[23]_i_821_n_3 ;
  wire \rgb_out_reg[23]_i_829_n_0 ;
  wire \rgb_out_reg[23]_i_829_n_1 ;
  wire \rgb_out_reg[23]_i_829_n_2 ;
  wire \rgb_out_reg[23]_i_829_n_3 ;
  wire \rgb_out_reg[23]_i_834_n_0 ;
  wire \rgb_out_reg[23]_i_834_n_1 ;
  wire \rgb_out_reg[23]_i_834_n_2 ;
  wire \rgb_out_reg[23]_i_834_n_3 ;
  wire \rgb_out_reg[23]_i_839_n_0 ;
  wire \rgb_out_reg[23]_i_839_n_1 ;
  wire \rgb_out_reg[23]_i_839_n_2 ;
  wire \rgb_out_reg[23]_i_839_n_3 ;
  wire \rgb_out_reg[23]_i_842_n_0 ;
  wire \rgb_out_reg[23]_i_842_n_1 ;
  wire \rgb_out_reg[23]_i_842_n_2 ;
  wire \rgb_out_reg[23]_i_842_n_3 ;
  wire \rgb_out_reg[23]_i_927_n_0 ;
  wire \rgb_out_reg[23]_i_927_n_1 ;
  wire \rgb_out_reg[23]_i_927_n_2 ;
  wire \rgb_out_reg[23]_i_927_n_3 ;
  wire \rgb_out_reg[23]_i_929_n_0 ;
  wire \rgb_out_reg[23]_i_929_n_2 ;
  wire \rgb_out_reg[23]_i_929_n_3 ;
  wire \rgb_out_reg[23]_i_932_n_0 ;
  wire \rgb_out_reg[23]_i_932_n_1 ;
  wire \rgb_out_reg[23]_i_932_n_2 ;
  wire \rgb_out_reg[23]_i_932_n_3 ;
  wire \rgb_out_reg[23]_i_937_n_0 ;
  wire \rgb_out_reg[23]_i_937_n_1 ;
  wire \rgb_out_reg[23]_i_937_n_2 ;
  wire \rgb_out_reg[23]_i_937_n_3 ;
  wire \rgb_out_reg[23]_i_942_n_0 ;
  wire \rgb_out_reg[23]_i_942_n_1 ;
  wire \rgb_out_reg[23]_i_942_n_2 ;
  wire \rgb_out_reg[23]_i_942_n_3 ;
  wire \rgb_out_reg[23]_i_946_n_0 ;
  wire \rgb_out_reg[23]_i_946_n_1 ;
  wire \rgb_out_reg[23]_i_946_n_2 ;
  wire \rgb_out_reg[23]_i_946_n_3 ;
  wire \rgb_out_reg[23]_i_951_n_0 ;
  wire \rgb_out_reg[23]_i_951_n_1 ;
  wire \rgb_out_reg[23]_i_951_n_2 ;
  wire \rgb_out_reg[23]_i_951_n_3 ;
  wire \rgb_out_reg[23]_i_955_n_0 ;
  wire \rgb_out_reg[23]_i_955_n_1 ;
  wire \rgb_out_reg[23]_i_955_n_2 ;
  wire \rgb_out_reg[23]_i_955_n_3 ;
  wire \rgb_out_reg[23]_i_960_n_0 ;
  wire \rgb_out_reg[23]_i_960_n_1 ;
  wire \rgb_out_reg[23]_i_960_n_2 ;
  wire \rgb_out_reg[23]_i_960_n_3 ;
  wire \rgb_out_reg[23]_i_965_n_0 ;
  wire \rgb_out_reg[23]_i_965_n_1 ;
  wire \rgb_out_reg[23]_i_965_n_2 ;
  wire \rgb_out_reg[23]_i_965_n_3 ;
  wire \rgb_out_reg[23]_i_979_n_0 ;
  wire \rgb_out_reg[23]_i_979_n_1 ;
  wire \rgb_out_reg[23]_i_979_n_2 ;
  wire \rgb_out_reg[23]_i_979_n_3 ;
  wire \rgb_out_reg[23]_i_984_n_0 ;
  wire \rgb_out_reg[23]_i_984_n_1 ;
  wire \rgb_out_reg[23]_i_984_n_2 ;
  wire \rgb_out_reg[23]_i_984_n_3 ;
  wire \rgb_out_reg[23]_i_989_n_0 ;
  wire \rgb_out_reg[23]_i_989_n_1 ;
  wire \rgb_out_reg[23]_i_989_n_2 ;
  wire \rgb_out_reg[23]_i_989_n_3 ;
  wire \rgb_out_reg[23]_i_992_n_0 ;
  wire \rgb_out_reg[23]_i_992_n_1 ;
  wire \rgb_out_reg[23]_i_992_n_2 ;
  wire \rgb_out_reg[23]_i_992_n_3 ;
  wire \rgb_out_reg[23]_i_995_n_0 ;
  wire \rgb_out_reg[23]_i_995_n_1 ;
  wire \rgb_out_reg[23]_i_995_n_2 ;
  wire \rgb_out_reg[23]_i_995_n_3 ;
  wire \rgb_out_reg[23]_i_997_n_0 ;
  wire \rgb_out_reg[23]_i_997_n_2 ;
  wire \rgb_out_reg[23]_i_997_n_3 ;
  wire \rgb_out_reg[23]_i_999_n_0 ;
  wire \rgb_out_reg[23]_i_999_n_1 ;
  wire \rgb_out_reg[23]_i_999_n_2 ;
  wire \rgb_out_reg[23]_i_999_n_3 ;
  wire [3:0]score_courant;
  wire [3:0]score_dernier;
  wire [3:0]temps_restant;
  wire vsync_in;
  wire vsync_out;
  wire [2:2]\NLW_rgb_out_reg[23]_i_1001_CO_UNCONNECTED ;
  wire [3:3]\NLW_rgb_out_reg[23]_i_1001_O_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_1002_O_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_1007_O_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_1012_O_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_1016_O_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_1021_O_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_1025_O_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_1030_O_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_1034_O_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_1039_O_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_1044_O_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_1048_O_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_1052_O_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_1056_O_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_1061_O_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_1066_O_UNCONNECTED ;
  wire [2:2]\NLW_rgb_out_reg[23]_i_1068_CO_UNCONNECTED ;
  wire [3:3]\NLW_rgb_out_reg[23]_i_1068_O_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_1070_O_UNCONNECTED ;
  wire [2:2]\NLW_rgb_out_reg[23]_i_1072_CO_UNCONNECTED ;
  wire [3:3]\NLW_rgb_out_reg[23]_i_1072_O_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_1073_O_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_1078_O_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_1083_O_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_1087_O_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_1092_O_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_1096_O_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_1101_O_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_1105_O_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_1110_O_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_1115_O_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_1119_O_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_1123_O_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_1127_O_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_1132_O_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_1137_O_UNCONNECTED ;
  wire [2:2]\NLW_rgb_out_reg[23]_i_1139_CO_UNCONNECTED ;
  wire [3:3]\NLW_rgb_out_reg[23]_i_1139_O_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_1142_O_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_1147_O_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_1152_O_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_1156_O_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_1161_O_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_1165_O_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_1170_O_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_1190_O_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_1195_O_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_1200_O_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_1203_O_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_1244_O_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_1249_O_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_1258_O_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_1262_O_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_1267_O_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_1271_O_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_1275_O_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_1280_O_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_1284_O_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_1289_O_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_1293_O_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_1298_O_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_1303_O_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_1313_O_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_1326_O_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_1349_O_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_1354_O_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_1359_O_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_1362_O_UNCONNECTED ;
  wire [3:3]\NLW_rgb_out_reg[23]_i_189_CO_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_189_O_UNCONNECTED ;
  wire [3:3]\NLW_rgb_out_reg[23]_i_191_CO_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_191_O_UNCONNECTED ;
  wire [3:3]\NLW_rgb_out_reg[23]_i_311_CO_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_311_O_UNCONNECTED ;
  wire [3:3]\NLW_rgb_out_reg[23]_i_313_CO_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_313_O_UNCONNECTED ;
  wire [3:3]\NLW_rgb_out_reg[23]_i_329_CO_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_329_O_UNCONNECTED ;
  wire [3:3]\NLW_rgb_out_reg[23]_i_331_CO_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_331_O_UNCONNECTED ;
  wire [3:2]\NLW_rgb_out_reg[23]_i_438_CO_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_438_O_UNCONNECTED ;
  wire [3:1]\NLW_rgb_out_reg[23]_i_439_CO_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_439_O_UNCONNECTED ;
  wire [3:3]\NLW_rgb_out_reg[23]_i_440_CO_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_440_O_UNCONNECTED ;
  wire [3:3]\NLW_rgb_out_reg[23]_i_441_CO_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_441_O_UNCONNECTED ;
  wire [3:3]\NLW_rgb_out_reg[23]_i_450_CO_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_450_O_UNCONNECTED ;
  wire [3:3]\NLW_rgb_out_reg[23]_i_452_CO_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_452_O_UNCONNECTED ;
  wire [3:3]\NLW_rgb_out_reg[23]_i_470_CO_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_470_O_UNCONNECTED ;
  wire [3:3]\NLW_rgb_out_reg[23]_i_471_CO_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_471_O_UNCONNECTED ;
  wire [3:3]\NLW_rgb_out_reg[23]_i_473_CO_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_473_O_UNCONNECTED ;
  wire [3:3]\NLW_rgb_out_reg[23]_i_474_CO_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_474_O_UNCONNECTED ;
  wire [3:3]\NLW_rgb_out_reg[23]_i_475_CO_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_475_O_UNCONNECTED ;
  wire [3:3]\NLW_rgb_out_reg[23]_i_476_CO_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_476_O_UNCONNECTED ;
  wire [3:3]\NLW_rgb_out_reg[23]_i_477_CO_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_477_O_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_478_O_UNCONNECTED ;
  wire [3:1]\NLW_rgb_out_reg[23]_i_481_CO_UNCONNECTED ;
  wire [3:2]\NLW_rgb_out_reg[23]_i_481_O_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_484_O_UNCONNECTED ;
  wire [3:3]\NLW_rgb_out_reg[23]_i_488_CO_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_488_O_UNCONNECTED ;
  wire [3:3]\NLW_rgb_out_reg[23]_i_489_CO_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_489_O_UNCONNECTED ;
  wire [3:2]\NLW_rgb_out_reg[23]_i_490_CO_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_490_O_UNCONNECTED ;
  wire [3:2]\NLW_rgb_out_reg[23]_i_491_CO_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_491_O_UNCONNECTED ;
  wire [3:3]\NLW_rgb_out_reg[23]_i_580_CO_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_580_O_UNCONNECTED ;
  wire [3:3]\NLW_rgb_out_reg[23]_i_581_CO_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_581_O_UNCONNECTED ;
  wire [3:3]\NLW_rgb_out_reg[23]_i_582_CO_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_582_O_UNCONNECTED ;
  wire [3:3]\NLW_rgb_out_reg[23]_i_583_CO_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_583_O_UNCONNECTED ;
  wire [3:3]\NLW_rgb_out_reg[23]_i_584_CO_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_584_O_UNCONNECTED ;
  wire [3:3]\NLW_rgb_out_reg[23]_i_585_CO_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_585_O_UNCONNECTED ;
  wire [3:3]\NLW_rgb_out_reg[23]_i_586_CO_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_586_O_UNCONNECTED ;
  wire [3:3]\NLW_rgb_out_reg[23]_i_587_CO_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_587_O_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_588_O_UNCONNECTED ;
  wire [2:2]\NLW_rgb_out_reg[23]_i_591_CO_UNCONNECTED ;
  wire [3:3]\NLW_rgb_out_reg[23]_i_591_O_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_594_O_UNCONNECTED ;
  wire [3:3]\NLW_rgb_out_reg[23]_i_598_CO_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_598_O_UNCONNECTED ;
  wire [3:3]\NLW_rgb_out_reg[23]_i_599_CO_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_599_O_UNCONNECTED ;
  wire [3:2]\NLW_rgb_out_reg[23]_i_600_CO_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_600_O_UNCONNECTED ;
  wire [3:2]\NLW_rgb_out_reg[23]_i_601_CO_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_601_O_UNCONNECTED ;
  wire [3:2]\NLW_rgb_out_reg[23]_i_602_CO_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_602_O_UNCONNECTED ;
  wire [3:1]\NLW_rgb_out_reg[23]_i_603_CO_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_603_O_UNCONNECTED ;
  wire [3:3]\NLW_rgb_out_reg[23]_i_604_CO_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_604_O_UNCONNECTED ;
  wire [3:3]\NLW_rgb_out_reg[23]_i_605_CO_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_605_O_UNCONNECTED ;
  wire [3:3]\NLW_rgb_out_reg[23]_i_606_CO_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_606_O_UNCONNECTED ;
  wire [3:3]\NLW_rgb_out_reg[23]_i_607_CO_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_607_O_UNCONNECTED ;
  wire [3:3]\NLW_rgb_out_reg[23]_i_609_CO_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_609_O_UNCONNECTED ;
  wire [3:3]\NLW_rgb_out_reg[23]_i_611_CO_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_611_O_UNCONNECTED ;
  wire [3:3]\NLW_rgb_out_reg[23]_i_612_CO_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_612_O_UNCONNECTED ;
  wire [3:3]\NLW_rgb_out_reg[23]_i_613_CO_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_613_O_UNCONNECTED ;
  wire [3:3]\NLW_rgb_out_reg[23]_i_616_CO_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_616_O_UNCONNECTED ;
  wire [3:3]\NLW_rgb_out_reg[23]_i_617_CO_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_617_O_UNCONNECTED ;
  wire [3:3]\NLW_rgb_out_reg[23]_i_620_CO_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_620_O_UNCONNECTED ;
  wire [3:3]\NLW_rgb_out_reg[23]_i_622_CO_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_622_O_UNCONNECTED ;
  wire [3:3]\NLW_rgb_out_reg[23]_i_624_CO_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_624_O_UNCONNECTED ;
  wire [3:3]\NLW_rgb_out_reg[23]_i_626_CO_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_626_O_UNCONNECTED ;
  wire [3:2]\NLW_rgb_out_reg[23]_i_628_CO_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_628_O_UNCONNECTED ;
  wire [3:1]\NLW_rgb_out_reg[23]_i_629_CO_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_629_O_UNCONNECTED ;
  wire [3:3]\NLW_rgb_out_reg[23]_i_630_CO_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_630_O_UNCONNECTED ;
  wire [3:3]\NLW_rgb_out_reg[23]_i_631_CO_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_631_O_UNCONNECTED ;
  wire [3:3]\NLW_rgb_out_reg[23]_i_632_CO_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_632_O_UNCONNECTED ;
  wire [3:3]\NLW_rgb_out_reg[23]_i_633_CO_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_633_O_UNCONNECTED ;
  wire [3:3]\NLW_rgb_out_reg[23]_i_635_CO_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_635_O_UNCONNECTED ;
  wire [3:3]\NLW_rgb_out_reg[23]_i_637_CO_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_637_O_UNCONNECTED ;
  wire [3:3]\NLW_rgb_out_reg[23]_i_638_CO_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_638_O_UNCONNECTED ;
  wire [3:3]\NLW_rgb_out_reg[23]_i_639_CO_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_639_O_UNCONNECTED ;
  wire [3:3]\NLW_rgb_out_reg[23]_i_642_CO_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_642_O_UNCONNECTED ;
  wire [3:3]\NLW_rgb_out_reg[23]_i_643_CO_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_643_O_UNCONNECTED ;
  wire [3:3]\NLW_rgb_out_reg[23]_i_646_CO_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_646_O_UNCONNECTED ;
  wire [3:3]\NLW_rgb_out_reg[23]_i_648_CO_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_648_O_UNCONNECTED ;
  wire [3:3]\NLW_rgb_out_reg[23]_i_650_CO_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_650_O_UNCONNECTED ;
  wire [3:3]\NLW_rgb_out_reg[23]_i_652_CO_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_652_O_UNCONNECTED ;
  wire [3:3]\NLW_rgb_out_reg[23]_i_654_CO_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_654_O_UNCONNECTED ;
  wire [3:3]\NLW_rgb_out_reg[23]_i_655_CO_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_655_O_UNCONNECTED ;
  wire [3:3]\NLW_rgb_out_reg[23]_i_656_CO_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_656_O_UNCONNECTED ;
  wire [3:3]\NLW_rgb_out_reg[23]_i_657_CO_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_657_O_UNCONNECTED ;
  wire [3:3]\NLW_rgb_out_reg[23]_i_658_CO_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_658_O_UNCONNECTED ;
  wire [3:3]\NLW_rgb_out_reg[23]_i_659_CO_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_659_O_UNCONNECTED ;
  wire [3:3]\NLW_rgb_out_reg[23]_i_660_CO_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_660_O_UNCONNECTED ;
  wire [3:3]\NLW_rgb_out_reg[23]_i_661_CO_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_661_O_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_662_O_UNCONNECTED ;
  wire [2:2]\NLW_rgb_out_reg[23]_i_665_CO_UNCONNECTED ;
  wire [3:3]\NLW_rgb_out_reg[23]_i_665_O_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_668_O_UNCONNECTED ;
  wire [3:3]\NLW_rgb_out_reg[23]_i_672_CO_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_672_O_UNCONNECTED ;
  wire [3:3]\NLW_rgb_out_reg[23]_i_673_CO_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_673_O_UNCONNECTED ;
  wire [3:2]\NLW_rgb_out_reg[23]_i_674_CO_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_674_O_UNCONNECTED ;
  wire [3:2]\NLW_rgb_out_reg[23]_i_675_CO_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_675_O_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_714_O_UNCONNECTED ;
  wire [3:1]\NLW_rgb_out_reg[23]_i_716_CO_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_716_O_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_718_O_UNCONNECTED ;
  wire [2:2]\NLW_rgb_out_reg[23]_i_720_CO_UNCONNECTED ;
  wire [3:3]\NLW_rgb_out_reg[23]_i_720_O_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_721_O_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_726_O_UNCONNECTED ;
  wire [3:3]\NLW_rgb_out_reg[23]_i_731_CO_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_731_O_UNCONNECTED ;
  wire [3:3]\NLW_rgb_out_reg[23]_i_732_CO_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_732_O_UNCONNECTED ;
  wire [3:3]\NLW_rgb_out_reg[23]_i_735_CO_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_735_O_UNCONNECTED ;
  wire [3:3]\NLW_rgb_out_reg[23]_i_737_CO_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_737_O_UNCONNECTED ;
  wire [3:3]\NLW_rgb_out_reg[23]_i_739_CO_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_739_O_UNCONNECTED ;
  wire [3:3]\NLW_rgb_out_reg[23]_i_740_CO_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_740_O_UNCONNECTED ;
  wire [3:3]\NLW_rgb_out_reg[23]_i_741_CO_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_741_O_UNCONNECTED ;
  wire [3:3]\NLW_rgb_out_reg[23]_i_743_CO_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_743_O_UNCONNECTED ;
  wire [3:3]\NLW_rgb_out_reg[23]_i_745_CO_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_745_O_UNCONNECTED ;
  wire [3:3]\NLW_rgb_out_reg[23]_i_746_CO_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_746_O_UNCONNECTED ;
  wire [3:3]\NLW_rgb_out_reg[23]_i_747_CO_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_747_O_UNCONNECTED ;
  wire [3:3]\NLW_rgb_out_reg[23]_i_750_CO_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_750_O_UNCONNECTED ;
  wire [3:3]\NLW_rgb_out_reg[23]_i_751_CO_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_751_O_UNCONNECTED ;
  wire [3:3]\NLW_rgb_out_reg[23]_i_753_CO_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_753_O_UNCONNECTED ;
  wire [3:3]\NLW_rgb_out_reg[23]_i_756_CO_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_756_O_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_758_O_UNCONNECTED ;
  wire [3:1]\NLW_rgb_out_reg[23]_i_761_CO_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_761_O_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_764_O_UNCONNECTED ;
  wire [3:3]\NLW_rgb_out_reg[23]_i_768_CO_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_768_O_UNCONNECTED ;
  wire [3:3]\NLW_rgb_out_reg[23]_i_769_CO_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_769_O_UNCONNECTED ;
  wire [3:2]\NLW_rgb_out_reg[23]_i_770_CO_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_770_O_UNCONNECTED ;
  wire [3:2]\NLW_rgb_out_reg[23]_i_771_CO_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_771_O_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_777_O_UNCONNECTED ;
  wire [2:2]\NLW_rgb_out_reg[23]_i_779_CO_UNCONNECTED ;
  wire [3:3]\NLW_rgb_out_reg[23]_i_779_O_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_782_O_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_792_O_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_796_O_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_801_O_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_805_O_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_810_O_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_829_O_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_834_O_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_839_O_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_842_O_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_927_O_UNCONNECTED ;
  wire [2:2]\NLW_rgb_out_reg[23]_i_929_CO_UNCONNECTED ;
  wire [3:3]\NLW_rgb_out_reg[23]_i_929_O_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_932_O_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_937_O_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_942_O_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_946_O_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_951_O_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_955_O_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_960_O_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_979_O_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_984_O_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_989_O_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_992_O_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_995_O_UNCONNECTED ;
  wire [2:2]\NLW_rgb_out_reg[23]_i_997_CO_UNCONNECTED ;
  wire [3:3]\NLW_rgb_out_reg[23]_i_997_O_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_999_O_UNCONNECTED ;

  decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_compositeur U0
       (.CO(U0_n_0),
        .DI({\rgb_out[23]_i_1467_n_0 ,\rgb_out[23]_i_1468_n_0 }),
        .S({\rgb_out[23]_i_1471_n_0 ,\rgb_out[23]_i_1472_n_0 }),
        .de_in(de_in),
        .de_out(de_out),
        .decompte_ui(decompte_ui),
        .flash_on(flash_on),
        .hsync_in(hsync_in),
        .hsync_out(hsync_out),
        .is_pixel_mur(is_pixel_mur),
        .local_x(\SC_D/local_x [11:0]),
        .local_x_0(\SC_U/local_x [11:0]),
        .local_x_1(\TM_D/local_x [11:2]),
        .local_y(\SC_D/local_y [11:1]),
        .mode_ui(mode_ui),
        .pixel_clk(pixel_clk),
        .pixel_x(pixel_x),
        .\pixel_x[1] (\SC_D/pixel_on99_in ),
        .\pixel_x[1]_0 (\SC_D/pixel_on40_in ),
        .\pixel_x[1]_1 (\SC_D/pixel_on4 ),
        .\pixel_x[1]_2 (\SC_D/pixel_on8 ),
        .\pixel_x[1]_3 (\rgb_out_reg[23]_i_761_n_3 ),
        .\pixel_x[1]_4 (\SC_U/pixel_on8 ),
        .\pixel_x[1]_5 (\SC_U/pixel_on99_in ),
        .\pixel_x[1]_6 (\SC_U/pixel_on4 ),
        .\pixel_x[1]_7 (\SC_U/pixel_on40_in ),
        .\pixel_x[1]_8 (\rgb_out_reg[23]_i_716_n_3 ),
        .\pixel_x[2] (\LAST_D/pixel_on99_in ),
        .\pixel_x[2]_0 (\LAST_D/pixel_on6 ),
        .\pixel_x[2]_1 (\LAST_D/pixel_on40_in ),
        .\pixel_x[2]_10 (\REC_D/pixel_on6 ),
        .\pixel_x[2]_11 (\REC_D/pixel_on40_in ),
        .\pixel_x[2]_12 (\REC_D/pixel_on4 ),
        .\pixel_x[2]_13 (\REC_D/pixel_on8 ),
        .\pixel_x[2]_14 (\REC_U/pixel_on8 ),
        .\pixel_x[2]_15 (\REC_U/pixel_on6 ),
        .\pixel_x[2]_16 (\REC_U/pixel_on99_in ),
        .\pixel_x[2]_17 (\REC_U/pixel_on4 ),
        .\pixel_x[2]_18 (\REC_U/pixel_on40_in ),
        .\pixel_x[2]_2 (\LAST_D/pixel_on4 ),
        .\pixel_x[2]_3 (\LAST_D/pixel_on8 ),
        .\pixel_x[2]_4 (\LAST_U/pixel_on8 ),
        .\pixel_x[2]_5 (\LAST_U/pixel_on6 ),
        .\pixel_x[2]_6 (\LAST_U/pixel_on99_in ),
        .\pixel_x[2]_7 (\LAST_U/pixel_on4 ),
        .\pixel_x[2]_8 (\LAST_U/pixel_on40_in ),
        .\pixel_x[2]_9 (\REC_D/pixel_on99_in ),
        .\pixel_x[3] (\TM_D/pixel_on6 ),
        .\pixel_x[3]_0 (\TM_D/pixel_on40_in ),
        .\pixel_x[3]_1 (\TM_D/pixel_on4 ),
        .\pixel_x[3]_2 (\TM_D/pixel_on8 ),
        .\pixel_x[3]_3 (\rgb_out_reg[23]_i_481_n_1 ),
        .\pixel_x[5] (\SC_D/pixel_on6 ),
        .\pixel_x[5]_0 (\LAST_U/pixel_on9 ),
        .\pixel_x[5]_1 (\REC_D/pixel_on9 ),
        .\pixel_x[5]_2 (\rgb_out[23]_i_881_n_0 ),
        .\pixel_x[6] (\SC_U/pixel_on6 ),
        .\pixel_x[6]_0 (\REC_U/pixel_on9 ),
        .\pixel_x[7] (\TM_D/pixel_on99_in ),
        .\pixel_x[7]_0 (\LAST_D/pixel_on9 ),
        .pixel_y(pixel_y),
        .\pixel_y[1] (\LAST_D/pixel_on3 ),
        .\pixel_y[1]_0 (\LAST_D/pixel_on2 ),
        .\pixel_y[1]_1 (\LAST_D/pixel_on712_in ),
        .\pixel_y[1]_10 (\LAST_U/pixel_on31_in ),
        .\pixel_y[1]_11 (\LAST_U/pixel_on2 ),
        .\pixel_y[1]_12 (\LAST_U/pixel_on3 ),
        .\pixel_y[1]_13 (\REC_D/pixel_on3 ),
        .\pixel_y[1]_14 (\REC_D/pixel_on2 ),
        .\pixel_y[1]_15 (\REC_D/pixel_on712_in ),
        .\pixel_y[1]_16 (\REC_D/pixel_on7 ),
        .\pixel_y[1]_17 (\REC_D/pixel_on75_in ),
        .\pixel_y[1]_18 (\REC_D/pixel_on66_in ),
        .\pixel_y[1]_19 (\REC_U/pixel_on712_in ),
        .\pixel_y[1]_2 (\LAST_D/pixel_on7 ),
        .\pixel_y[1]_20 (\REC_U/pixel_on66_in ),
        .\pixel_y[1]_21 (\REC_U/pixel_on75_in ),
        .\pixel_y[1]_22 (\REC_U/pixel_on7 ),
        .\pixel_y[1]_23 (\REC_U/pixel_on22_in ),
        .\pixel_y[1]_24 (\REC_U/pixel_on31_in ),
        .\pixel_y[1]_25 (\REC_U/pixel_on2 ),
        .\pixel_y[1]_26 (\REC_U/pixel_on3 ),
        .\pixel_y[1]_3 (\LAST_D/pixel_on75_in ),
        .\pixel_y[1]_4 (\LAST_D/pixel_on66_in ),
        .\pixel_y[1]_5 (\LAST_U/pixel_on712_in ),
        .\pixel_y[1]_6 (\LAST_U/pixel_on66_in ),
        .\pixel_y[1]_7 (\LAST_U/pixel_on75_in ),
        .\pixel_y[1]_8 (\LAST_U/pixel_on7 ),
        .\pixel_y[1]_9 (\LAST_U/pixel_on22_in ),
        .\pixel_y[2] (\SC_D/pixel_on3 ),
        .\pixel_y[2]_0 (\SC_D/pixel_on2 ),
        .\pixel_y[2]_1 (\SC_D/pixel_on712_in ),
        .\pixel_y[2]_10 (\SC_U/pixel_on3 ),
        .\pixel_y[2]_11 (\TM_D/pixel_on3 ),
        .\pixel_y[2]_12 (\TM_D/pixel_on2 ),
        .\pixel_y[2]_13 (\TM_D/pixel_on712_in ),
        .\pixel_y[2]_14 (\TM_D/pixel_on7 ),
        .\pixel_y[2]_15 (\TM_D/pixel_on75_in ),
        .\pixel_y[2]_16 (\TM_D/pixel_on66_in ),
        .\pixel_y[2]_2 (\SC_D/pixel_on75_in ),
        .\pixel_y[2]_3 (\SC_U/pixel_on712_in ),
        .\pixel_y[2]_4 (\SC_U/pixel_on66_in ),
        .\pixel_y[2]_5 (\SC_U/pixel_on75_in ),
        .\pixel_y[2]_6 (\SC_U/pixel_on7 ),
        .\pixel_y[2]_7 (\SC_U/pixel_on22_in ),
        .\pixel_y[2]_8 (\SC_U/pixel_on31_in ),
        .\pixel_y[2]_9 (\SC_U/pixel_on2 ),
        .\pixel_y[5] (\SC_D/pixel_on5 ),
        .\pixel_y[5]_0 (\SC_U/pixel_on5 ),
        .\pixel_y[5]_1 (\SC_U/pixel_on83_in ),
        .\pixel_y[5]_10 (\REC_U/pixel_on5 ),
        .\pixel_y[5]_11 (\REC_U/pixel_on83_in ),
        .\pixel_y[5]_2 (\TM_D/pixel_on5 ),
        .\pixel_y[5]_3 (\TM_D/pixel_on83_in ),
        .\pixel_y[5]_4 (\LAST_D/pixel_on5 ),
        .\pixel_y[5]_5 (\LAST_D/pixel_on83_in ),
        .\pixel_y[5]_6 (\LAST_U/pixel_on5 ),
        .\pixel_y[5]_7 (\LAST_U/pixel_on83_in ),
        .\pixel_y[5]_8 (\REC_D/pixel_on5 ),
        .\pixel_y[5]_9 (\REC_D/pixel_on83_in ),
        .record_personnel(record_personnel),
        .reset(reset),
        .rgb_in(rgb_in),
        .rgb_out(rgb_out),
        .\rgb_out_reg[0]_0 (U0_n_15),
        .score_courant(score_courant),
        .score_dernier(score_dernier),
        .temps_restant(temps_restant),
        .vsync_in(vsync_in),
        .vsync_out(vsync_out));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_1000 
       (.I0(\rgb_out_reg[23]_i_1001_n_0 ),
        .O(\LAST_U/local_y [12]));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1003 
       (.I0(\LAST_U/local_x [10]),
        .I1(\LAST_U/local_x [11]),
        .O(\rgb_out[23]_i_1003_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1004 
       (.I0(\LAST_U/local_x [8]),
        .I1(\LAST_U/local_x [9]),
        .O(\rgb_out[23]_i_1004_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1005 
       (.I0(\LAST_U/local_x [11]),
        .I1(\LAST_U/local_x [10]),
        .O(\rgb_out[23]_i_1005_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1006 
       (.I0(\LAST_U/local_x [9]),
        .I1(\LAST_U/local_x [8]),
        .O(\rgb_out[23]_i_1006_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1008 
       (.I0(\LAST_U/local_y [10]),
        .I1(\LAST_U/local_y [11]),
        .O(\rgb_out[23]_i_1008_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1009 
       (.I0(\LAST_U/local_y [8]),
        .I1(\LAST_U/local_y [9]),
        .O(\rgb_out[23]_i_1009_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1010 
       (.I0(\LAST_U/local_y [11]),
        .I1(\LAST_U/local_y [10]),
        .O(\rgb_out[23]_i_1010_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1011 
       (.I0(\LAST_U/local_y [9]),
        .I1(\LAST_U/local_y [8]),
        .O(\rgb_out[23]_i_1011_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_1013 
       (.I0(\rgb_out_reg[23]_i_1001_n_0 ),
        .O(\rgb_out[23]_i_1013_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1014 
       (.I0(\LAST_U/local_y [11]),
        .I1(\LAST_U/local_y [10]),
        .O(\rgb_out[23]_i_1014_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1015 
       (.I0(\LAST_U/local_y [9]),
        .I1(\LAST_U/local_y [8]),
        .O(\rgb_out[23]_i_1015_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1017 
       (.I0(\LAST_U/local_y [10]),
        .I1(\LAST_U/local_y [11]),
        .O(\rgb_out[23]_i_1017_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1018 
       (.I0(\LAST_U/local_y [8]),
        .I1(\LAST_U/local_y [9]),
        .O(\rgb_out[23]_i_1018_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1019 
       (.I0(\LAST_U/local_y [11]),
        .I1(\LAST_U/local_y [10]),
        .O(\rgb_out[23]_i_1019_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1020 
       (.I0(\LAST_U/local_y [9]),
        .I1(\LAST_U/local_y [8]),
        .O(\rgb_out[23]_i_1020_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_1022 
       (.I0(\rgb_out_reg[23]_i_997_n_0 ),
        .O(\rgb_out[23]_i_1022_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1023 
       (.I0(\LAST_U/local_x [11]),
        .I1(\LAST_U/local_x [10]),
        .O(\rgb_out[23]_i_1023_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1024 
       (.I0(\LAST_U/local_x [9]),
        .I1(\LAST_U/local_x [8]),
        .O(\rgb_out[23]_i_1024_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1026 
       (.I0(\LAST_U/local_x [10]),
        .I1(\LAST_U/local_x [11]),
        .O(\rgb_out[23]_i_1026_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1027 
       (.I0(\LAST_U/local_x [8]),
        .I1(\LAST_U/local_x [9]),
        .O(\rgb_out[23]_i_1027_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1028 
       (.I0(\LAST_U/local_x [11]),
        .I1(\LAST_U/local_x [10]),
        .O(\rgb_out[23]_i_1028_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1029 
       (.I0(\LAST_U/local_x [9]),
        .I1(\LAST_U/local_x [8]),
        .O(\rgb_out[23]_i_1029_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_1031 
       (.I0(\rgb_out_reg[23]_i_1001_n_0 ),
        .O(\rgb_out[23]_i_1031_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1032 
       (.I0(\LAST_U/local_y [11]),
        .I1(\LAST_U/local_y [10]),
        .O(\rgb_out[23]_i_1032_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1033 
       (.I0(\LAST_U/local_y [9]),
        .I1(\LAST_U/local_y [8]),
        .O(\rgb_out[23]_i_1033_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1035 
       (.I0(\LAST_U/local_y [10]),
        .I1(\LAST_U/local_y [11]),
        .O(\rgb_out[23]_i_1035_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1036 
       (.I0(\LAST_U/local_y [8]),
        .I1(\LAST_U/local_y [9]),
        .O(\rgb_out[23]_i_1036_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1037 
       (.I0(\LAST_U/local_y [11]),
        .I1(\LAST_U/local_y [10]),
        .O(\rgb_out[23]_i_1037_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1038 
       (.I0(\LAST_U/local_y [9]),
        .I1(\LAST_U/local_y [8]),
        .O(\rgb_out[23]_i_1038_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1040 
       (.I0(\LAST_U/local_x [10]),
        .I1(\LAST_U/local_x [11]),
        .O(\rgb_out[23]_i_1040_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1041 
       (.I0(\LAST_U/local_x [8]),
        .I1(\LAST_U/local_x [9]),
        .O(\rgb_out[23]_i_1041_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1042 
       (.I0(\LAST_U/local_x [11]),
        .I1(\LAST_U/local_x [10]),
        .O(\rgb_out[23]_i_1042_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1043 
       (.I0(\LAST_U/local_x [9]),
        .I1(\LAST_U/local_x [8]),
        .O(\rgb_out[23]_i_1043_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_1045 
       (.I0(\rgb_out_reg[23]_i_997_n_0 ),
        .O(\rgb_out[23]_i_1045_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1046 
       (.I0(\LAST_U/local_x [11]),
        .I1(\LAST_U/local_x [10]),
        .O(\rgb_out[23]_i_1046_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1047 
       (.I0(\LAST_U/local_x [9]),
        .I1(\LAST_U/local_x [8]),
        .O(\rgb_out[23]_i_1047_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_1049 
       (.I0(\rgb_out_reg[23]_i_1001_n_0 ),
        .O(\rgb_out[23]_i_1049_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1050 
       (.I0(\LAST_U/local_y [11]),
        .I1(\LAST_U/local_y [10]),
        .O(\rgb_out[23]_i_1050_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1051 
       (.I0(\LAST_U/local_y [9]),
        .I1(\LAST_U/local_y [8]),
        .O(\rgb_out[23]_i_1051_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_1053 
       (.I0(\rgb_out_reg[23]_i_1001_n_0 ),
        .O(\rgb_out[23]_i_1053_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1054 
       (.I0(\LAST_U/local_y [11]),
        .I1(\LAST_U/local_y [10]),
        .O(\rgb_out[23]_i_1054_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1055 
       (.I0(\LAST_U/local_y [9]),
        .I1(\LAST_U/local_y [8]),
        .O(\rgb_out[23]_i_1055_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1057 
       (.I0(\LAST_U/local_y [10]),
        .I1(\LAST_U/local_y [11]),
        .O(\rgb_out[23]_i_1057_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1058 
       (.I0(\LAST_U/local_y [8]),
        .I1(\LAST_U/local_y [9]),
        .O(\rgb_out[23]_i_1058_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1059 
       (.I0(\LAST_U/local_y [11]),
        .I1(\LAST_U/local_y [10]),
        .O(\rgb_out[23]_i_1059_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1060 
       (.I0(\LAST_U/local_y [9]),
        .I1(\LAST_U/local_y [8]),
        .O(\rgb_out[23]_i_1060_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1062 
       (.I0(\LAST_U/local_y [10]),
        .I1(\LAST_U/local_y [11]),
        .O(\rgb_out[23]_i_1062_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1063 
       (.I0(\LAST_U/local_y [8]),
        .I1(\LAST_U/local_y [9]),
        .O(\rgb_out[23]_i_1063_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1064 
       (.I0(\LAST_U/local_y [11]),
        .I1(\LAST_U/local_y [10]),
        .O(\rgb_out[23]_i_1064_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1065 
       (.I0(\LAST_U/local_y [9]),
        .I1(\LAST_U/local_y [8]),
        .O(\rgb_out[23]_i_1065_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_1067 
       (.I0(\rgb_out_reg[23]_i_1068_n_0 ),
        .O(\REC_U/local_x [12]));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1069 
       (.I0(\REC_U/local_x [11]),
        .I1(\REC_U/local_x [10]),
        .O(\rgb_out[23]_i_1069_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_1071 
       (.I0(\rgb_out_reg[23]_i_1072_n_0 ),
        .O(\REC_U/local_y [12]));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1074 
       (.I0(\REC_U/local_x [10]),
        .I1(\REC_U/local_x [11]),
        .O(\rgb_out[23]_i_1074_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1075 
       (.I0(\REC_U/local_x [8]),
        .I1(\REC_U/local_x [9]),
        .O(\rgb_out[23]_i_1075_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1076 
       (.I0(\REC_U/local_x [11]),
        .I1(\REC_U/local_x [10]),
        .O(\rgb_out[23]_i_1076_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1077 
       (.I0(\REC_U/local_x [9]),
        .I1(\REC_U/local_x [8]),
        .O(\rgb_out[23]_i_1077_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1079 
       (.I0(\REC_U/local_y [10]),
        .I1(\REC_U/local_y [11]),
        .O(\rgb_out[23]_i_1079_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1080 
       (.I0(\REC_U/local_y [8]),
        .I1(\REC_U/local_y [9]),
        .O(\rgb_out[23]_i_1080_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1081 
       (.I0(\REC_U/local_y [11]),
        .I1(\REC_U/local_y [10]),
        .O(\rgb_out[23]_i_1081_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1082 
       (.I0(\REC_U/local_y [9]),
        .I1(\REC_U/local_y [8]),
        .O(\rgb_out[23]_i_1082_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_1084 
       (.I0(\rgb_out_reg[23]_i_1072_n_0 ),
        .O(\rgb_out[23]_i_1084_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1085 
       (.I0(\REC_U/local_y [11]),
        .I1(\REC_U/local_y [10]),
        .O(\rgb_out[23]_i_1085_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1086 
       (.I0(\REC_U/local_y [9]),
        .I1(\REC_U/local_y [8]),
        .O(\rgb_out[23]_i_1086_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1088 
       (.I0(\REC_U/local_y [10]),
        .I1(\REC_U/local_y [11]),
        .O(\rgb_out[23]_i_1088_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1089 
       (.I0(\REC_U/local_y [8]),
        .I1(\REC_U/local_y [9]),
        .O(\rgb_out[23]_i_1089_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1090 
       (.I0(\REC_U/local_y [11]),
        .I1(\REC_U/local_y [10]),
        .O(\rgb_out[23]_i_1090_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1091 
       (.I0(\REC_U/local_y [9]),
        .I1(\REC_U/local_y [8]),
        .O(\rgb_out[23]_i_1091_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_1093 
       (.I0(\rgb_out_reg[23]_i_1068_n_0 ),
        .O(\rgb_out[23]_i_1093_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1094 
       (.I0(\REC_U/local_x [11]),
        .I1(\REC_U/local_x [10]),
        .O(\rgb_out[23]_i_1094_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1095 
       (.I0(\REC_U/local_x [9]),
        .I1(\REC_U/local_x [8]),
        .O(\rgb_out[23]_i_1095_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1097 
       (.I0(\REC_U/local_x [10]),
        .I1(\REC_U/local_x [11]),
        .O(\rgb_out[23]_i_1097_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1098 
       (.I0(\REC_U/local_x [8]),
        .I1(\REC_U/local_x [9]),
        .O(\rgb_out[23]_i_1098_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1099 
       (.I0(\REC_U/local_x [11]),
        .I1(\REC_U/local_x [10]),
        .O(\rgb_out[23]_i_1099_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1100 
       (.I0(\REC_U/local_x [9]),
        .I1(\REC_U/local_x [8]),
        .O(\rgb_out[23]_i_1100_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_1102 
       (.I0(\rgb_out_reg[23]_i_1072_n_0 ),
        .O(\rgb_out[23]_i_1102_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1103 
       (.I0(\REC_U/local_y [11]),
        .I1(\REC_U/local_y [10]),
        .O(\rgb_out[23]_i_1103_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1104 
       (.I0(\REC_U/local_y [9]),
        .I1(\REC_U/local_y [8]),
        .O(\rgb_out[23]_i_1104_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1106 
       (.I0(\REC_U/local_y [10]),
        .I1(\REC_U/local_y [11]),
        .O(\rgb_out[23]_i_1106_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1107 
       (.I0(\REC_U/local_y [8]),
        .I1(\REC_U/local_y [9]),
        .O(\rgb_out[23]_i_1107_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1108 
       (.I0(\REC_U/local_y [11]),
        .I1(\REC_U/local_y [10]),
        .O(\rgb_out[23]_i_1108_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1109 
       (.I0(\REC_U/local_y [9]),
        .I1(\REC_U/local_y [8]),
        .O(\rgb_out[23]_i_1109_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1111 
       (.I0(\REC_U/local_x [10]),
        .I1(\REC_U/local_x [11]),
        .O(\rgb_out[23]_i_1111_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1112 
       (.I0(\REC_U/local_x [8]),
        .I1(\REC_U/local_x [9]),
        .O(\rgb_out[23]_i_1112_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1113 
       (.I0(\REC_U/local_x [11]),
        .I1(\REC_U/local_x [10]),
        .O(\rgb_out[23]_i_1113_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1114 
       (.I0(\REC_U/local_x [9]),
        .I1(\REC_U/local_x [8]),
        .O(\rgb_out[23]_i_1114_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_1116 
       (.I0(\rgb_out_reg[23]_i_1068_n_0 ),
        .O(\rgb_out[23]_i_1116_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1117 
       (.I0(\REC_U/local_x [11]),
        .I1(\REC_U/local_x [10]),
        .O(\rgb_out[23]_i_1117_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1118 
       (.I0(\REC_U/local_x [9]),
        .I1(\REC_U/local_x [8]),
        .O(\rgb_out[23]_i_1118_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_1120 
       (.I0(\rgb_out_reg[23]_i_1072_n_0 ),
        .O(\rgb_out[23]_i_1120_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1121 
       (.I0(\REC_U/local_y [11]),
        .I1(\REC_U/local_y [10]),
        .O(\rgb_out[23]_i_1121_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1122 
       (.I0(\REC_U/local_y [9]),
        .I1(\REC_U/local_y [8]),
        .O(\rgb_out[23]_i_1122_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_1124 
       (.I0(\rgb_out_reg[23]_i_1072_n_0 ),
        .O(\rgb_out[23]_i_1124_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1125 
       (.I0(\REC_U/local_y [11]),
        .I1(\REC_U/local_y [10]),
        .O(\rgb_out[23]_i_1125_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1126 
       (.I0(\REC_U/local_y [9]),
        .I1(\REC_U/local_y [8]),
        .O(\rgb_out[23]_i_1126_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1128 
       (.I0(\REC_U/local_y [10]),
        .I1(\REC_U/local_y [11]),
        .O(\rgb_out[23]_i_1128_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1129 
       (.I0(\REC_U/local_y [8]),
        .I1(\REC_U/local_y [9]),
        .O(\rgb_out[23]_i_1129_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1130 
       (.I0(\REC_U/local_y [11]),
        .I1(\REC_U/local_y [10]),
        .O(\rgb_out[23]_i_1130_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1131 
       (.I0(\REC_U/local_y [9]),
        .I1(\REC_U/local_y [8]),
        .O(\rgb_out[23]_i_1131_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1133 
       (.I0(\REC_U/local_y [10]),
        .I1(\REC_U/local_y [11]),
        .O(\rgb_out[23]_i_1133_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1134 
       (.I0(\REC_U/local_y [8]),
        .I1(\REC_U/local_y [9]),
        .O(\rgb_out[23]_i_1134_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1135 
       (.I0(\REC_U/local_y [11]),
        .I1(\REC_U/local_y [10]),
        .O(\rgb_out[23]_i_1135_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1136 
       (.I0(\REC_U/local_y [9]),
        .I1(\REC_U/local_y [8]),
        .O(\rgb_out[23]_i_1136_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_1138 
       (.I0(\rgb_out_reg[23]_i_1139_n_0 ),
        .O(\rgb_out[23]_i_1138_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1140 
       (.I0(\LAST_D/local_y [11]),
        .I1(\LAST_D/local_y [10]),
        .O(\rgb_out[23]_i_1140_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1141 
       (.I0(\LAST_D/local_y [9]),
        .I1(\LAST_D/local_y [8]),
        .O(\rgb_out[23]_i_1141_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1143 
       (.I0(\LAST_D/local_y [10]),
        .I1(\LAST_D/local_y [11]),
        .O(\rgb_out[23]_i_1143_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1144 
       (.I0(\LAST_D/local_y [8]),
        .I1(\LAST_D/local_y [9]),
        .O(\rgb_out[23]_i_1144_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1145 
       (.I0(\LAST_D/local_y [11]),
        .I1(\LAST_D/local_y [10]),
        .O(\rgb_out[23]_i_1145_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1146 
       (.I0(\LAST_D/local_y [9]),
        .I1(\LAST_D/local_y [8]),
        .O(\rgb_out[23]_i_1146_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1148 
       (.I0(\LAST_D/local_x [10]),
        .I1(\LAST_D/local_x [11]),
        .O(\rgb_out[23]_i_1148_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1149 
       (.I0(\LAST_D/local_x [8]),
        .I1(\LAST_D/local_x [9]),
        .O(\rgb_out[23]_i_1149_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1150 
       (.I0(\LAST_D/local_x [11]),
        .I1(\LAST_D/local_x [10]),
        .O(\rgb_out[23]_i_1150_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1151 
       (.I0(\LAST_D/local_x [9]),
        .I1(\LAST_D/local_x [8]),
        .O(\rgb_out[23]_i_1151_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_1153 
       (.I0(\rgb_out_reg[23]_i_665_n_0 ),
        .O(\rgb_out[23]_i_1153_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1154 
       (.I0(\LAST_D/local_x [11]),
        .I1(\LAST_D/local_x [10]),
        .O(\rgb_out[23]_i_1154_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1155 
       (.I0(\LAST_D/local_x [9]),
        .I1(\LAST_D/local_x [8]),
        .O(\rgb_out[23]_i_1155_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1157 
       (.I0(\LAST_D/local_y [10]),
        .I1(\LAST_D/local_y [11]),
        .O(\rgb_out[23]_i_1157_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1158 
       (.I0(\LAST_D/local_y [8]),
        .I1(\LAST_D/local_y [9]),
        .O(\rgb_out[23]_i_1158_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1159 
       (.I0(\LAST_D/local_y [11]),
        .I1(\LAST_D/local_y [10]),
        .O(\rgb_out[23]_i_1159_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1160 
       (.I0(\LAST_D/local_y [9]),
        .I1(\LAST_D/local_y [8]),
        .O(\rgb_out[23]_i_1160_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_1162 
       (.I0(\rgb_out_reg[23]_i_1139_n_0 ),
        .O(\rgb_out[23]_i_1162_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1163 
       (.I0(\LAST_D/local_y [11]),
        .I1(\LAST_D/local_y [10]),
        .O(\rgb_out[23]_i_1163_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1164 
       (.I0(\LAST_D/local_y [9]),
        .I1(\LAST_D/local_y [8]),
        .O(\rgb_out[23]_i_1164_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1166 
       (.I0(\LAST_D/local_y [10]),
        .I1(\LAST_D/local_y [11]),
        .O(\rgb_out[23]_i_1166_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1167 
       (.I0(\LAST_D/local_y [8]),
        .I1(\LAST_D/local_y [9]),
        .O(\rgb_out[23]_i_1167_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1168 
       (.I0(\LAST_D/local_y [11]),
        .I1(\LAST_D/local_y [10]),
        .O(\rgb_out[23]_i_1168_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1169 
       (.I0(\LAST_D/local_y [9]),
        .I1(\LAST_D/local_y [8]),
        .O(\rgb_out[23]_i_1169_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_1171 
       (.I0(\rgb_out_reg[23]_i_1139_n_0 ),
        .O(\rgb_out[23]_i_1171_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1172 
       (.I0(\LAST_D/local_y [11]),
        .I1(\LAST_D/local_y [10]),
        .O(\rgb_out[23]_i_1172_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1173 
       (.I0(\LAST_D/local_y [9]),
        .I1(\LAST_D/local_y [8]),
        .O(\rgb_out[23]_i_1173_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1174 
       (.I0(\LAST_D/local_x [6]),
        .I1(\LAST_D/local_x [7]),
        .O(\rgb_out[23]_i_1174_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1176 
       (.I0(\LAST_D/local_x [1]),
        .I1(pixel_x[0]),
        .O(\rgb_out[23]_i_1176_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1177 
       (.I0(\LAST_D/local_x [7]),
        .I1(\LAST_D/local_x [6]),
        .O(\rgb_out[23]_i_1177_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1178 
       (.I0(\LAST_D/local_x [4]),
        .I1(\LAST_D/local_x [5]),
        .O(\rgb_out[23]_i_1178_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_1179 
       (.I0(\LAST_D/local_x [3]),
        .I1(\LAST_D/local_x [2]),
        .O(\rgb_out[23]_i_1179_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_1180 
       (.I0(pixel_x[0]),
        .I1(\LAST_D/local_x [1]),
        .O(\rgb_out[23]_i_1180_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_1181 
       (.I0(pixel_x[11]),
        .O(\rgb_out[23]_i_1181_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_1182 
       (.I0(pixel_x[10]),
        .O(\rgb_out[23]_i_1182_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_1183 
       (.I0(pixel_x[9]),
        .O(\rgb_out[23]_i_1183_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1184 
       (.I0(\LAST_D/local_x [3]),
        .I1(\LAST_D/local_x [2]),
        .O(\rgb_out[23]_i_1184_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_1185 
       (.I0(\LAST_D/local_x [1]),
        .O(\rgb_out[23]_i_1185_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1186 
       (.I0(\LAST_D/local_x [7]),
        .I1(\LAST_D/local_x [6]),
        .O(\rgb_out[23]_i_1186_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1187 
       (.I0(\LAST_D/local_x [5]),
        .I1(\LAST_D/local_x [4]),
        .O(\rgb_out[23]_i_1187_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1188 
       (.I0(\LAST_D/local_x [2]),
        .I1(\LAST_D/local_x [3]),
        .O(\rgb_out[23]_i_1188_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_1189 
       (.I0(pixel_x[0]),
        .I1(\LAST_D/local_x [1]),
        .O(\rgb_out[23]_i_1189_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1191 
       (.I0(\LAST_D/local_y [10]),
        .I1(\LAST_D/local_y [11]),
        .O(\rgb_out[23]_i_1191_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1192 
       (.I0(\LAST_D/local_y [8]),
        .I1(\LAST_D/local_y [9]),
        .O(\rgb_out[23]_i_1192_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1193 
       (.I0(\LAST_D/local_y [11]),
        .I1(\LAST_D/local_y [10]),
        .O(\rgb_out[23]_i_1193_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1194 
       (.I0(\LAST_D/local_y [9]),
        .I1(\LAST_D/local_y [8]),
        .O(\rgb_out[23]_i_1194_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1196 
       (.I0(\LAST_D/local_x [10]),
        .I1(\LAST_D/local_x [11]),
        .O(\rgb_out[23]_i_1196_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1197 
       (.I0(\LAST_D/local_x [8]),
        .I1(\LAST_D/local_x [9]),
        .O(\rgb_out[23]_i_1197_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1198 
       (.I0(\LAST_D/local_x [11]),
        .I1(\LAST_D/local_x [10]),
        .O(\rgb_out[23]_i_1198_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1199 
       (.I0(\LAST_D/local_x [9]),
        .I1(\LAST_D/local_x [8]),
        .O(\rgb_out[23]_i_1199_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_1201 
       (.I0(\rgb_out_reg[23]_i_1139_n_0 ),
        .O(\LAST_D/local_y [12]));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1202 
       (.I0(\LAST_D/local_y [11]),
        .I1(\LAST_D/local_y [10]),
        .O(\rgb_out[23]_i_1202_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_1204 
       (.I0(\rgb_out_reg[23]_i_665_n_0 ),
        .O(\LAST_D/local_x [12]));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1205 
       (.I0(\LAST_D/local_x [11]),
        .I1(\LAST_D/local_x [10]),
        .O(\rgb_out[23]_i_1205_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_1211 
       (.I0(\SC_U/local_x [5]),
        .O(\rgb_out[23]_i_1211_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1212 
       (.I0(\SC_U/local_x [3]),
        .I1(\SC_U/local_x [2]),
        .O(\rgb_out[23]_i_1212_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1213 
       (.I0(\SC_U/local_x [9]),
        .I1(\SC_U/local_x [8]),
        .O(\rgb_out[23]_i_1213_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1214 
       (.I0(\SC_U/local_x [7]),
        .I1(\SC_U/local_x [6]),
        .O(\rgb_out[23]_i_1214_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1215 
       (.I0(\SC_U/local_x [5]),
        .I1(\SC_U/local_x [4]),
        .O(\rgb_out[23]_i_1215_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1216 
       (.I0(\SC_U/local_x [2]),
        .I1(\SC_U/local_x [3]),
        .O(\rgb_out[23]_i_1216_n_0 ));
  LUT2 #(
    .INIT(4'h7)) 
    \rgb_out[23]_i_1218 
       (.I0(\SC_U/local_y [3]),
        .I1(\SC_U/local_y [2]),
        .O(\rgb_out[23]_i_1218_n_0 ));
  LUT2 #(
    .INIT(4'h7)) 
    \rgb_out[23]_i_1219 
       (.I0(\SC_U/local_y [5]),
        .I1(\SC_U/local_y [4]),
        .O(\rgb_out[23]_i_1219_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1220 
       (.I0(\SC_U/local_y [11]),
        .I1(\SC_U/local_y [10]),
        .O(\rgb_out[23]_i_1220_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1221 
       (.I0(\SC_U/local_y [9]),
        .I1(\SC_U/local_y [8]),
        .O(\rgb_out[23]_i_1221_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1222 
       (.I0(\SC_U/local_y [7]),
        .I1(\SC_U/local_y [6]),
        .O(\rgb_out[23]_i_1222_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_1223 
       (.I0(\SC_U/local_y [4]),
        .I1(\SC_U/local_y [5]),
        .O(\rgb_out[23]_i_1223_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_1225 
       (.I0(pixel_y[11]),
        .O(\rgb_out[23]_i_1225_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_1226 
       (.I0(pixel_y[10]),
        .O(\rgb_out[23]_i_1226_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_1227 
       (.I0(pixel_y[9]),
        .O(\rgb_out[23]_i_1227_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1228 
       (.I0(\SC_U/local_x [6]),
        .I1(\SC_U/local_x [7]),
        .O(\rgb_out[23]_i_1228_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1229 
       (.I0(\SC_U/local_x [5]),
        .I1(\SC_U/local_x [4]),
        .O(\rgb_out[23]_i_1229_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1230 
       (.I0(\SC_U/local_x [2]),
        .I1(\SC_U/local_x [3]),
        .O(\rgb_out[23]_i_1230_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1231 
       (.I0(\SC_U/local_x [0]),
        .I1(\SC_U/local_x [1]),
        .O(\rgb_out[23]_i_1231_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1232 
       (.I0(\SC_U/local_x [7]),
        .I1(\SC_U/local_x [6]),
        .O(\rgb_out[23]_i_1232_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1233 
       (.I0(\SC_U/local_x [4]),
        .I1(\SC_U/local_x [5]),
        .O(\rgb_out[23]_i_1233_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1234 
       (.I0(\SC_U/local_x [3]),
        .I1(\SC_U/local_x [2]),
        .O(\rgb_out[23]_i_1234_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1235 
       (.I0(\SC_U/local_x [1]),
        .I1(\SC_U/local_x [0]),
        .O(\rgb_out[23]_i_1235_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1236 
       (.I0(\SC_U/local_y [6]),
        .I1(\SC_U/local_y [7]),
        .O(\rgb_out[23]_i_1236_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1237 
       (.I0(\SC_U/local_y [4]),
        .I1(\SC_U/local_y [5]),
        .O(\rgb_out[23]_i_1237_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1238 
       (.I0(\SC_U/local_y [2]),
        .I1(\SC_U/local_y [3]),
        .O(\rgb_out[23]_i_1238_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1239 
       (.I0(pixel_y[0]),
        .I1(\SC_U/local_y [1]),
        .O(\rgb_out[23]_i_1239_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1240 
       (.I0(\SC_U/local_y [7]),
        .I1(\SC_U/local_y [6]),
        .O(\rgb_out[23]_i_1240_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1241 
       (.I0(\SC_U/local_y [5]),
        .I1(\SC_U/local_y [4]),
        .O(\rgb_out[23]_i_1241_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1242 
       (.I0(\SC_U/local_y [3]),
        .I1(\SC_U/local_y [2]),
        .O(\rgb_out[23]_i_1242_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1243 
       (.I0(\SC_U/local_y [1]),
        .I1(pixel_y[0]),
        .O(\rgb_out[23]_i_1243_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1245 
       (.I0(\SC_U/local_y [10]),
        .I1(\SC_U/local_y [11]),
        .O(\rgb_out[23]_i_1245_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1246 
       (.I0(\SC_U/local_y [8]),
        .I1(\SC_U/local_y [9]),
        .O(\rgb_out[23]_i_1246_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1247 
       (.I0(\SC_U/local_y [11]),
        .I1(\SC_U/local_y [10]),
        .O(\rgb_out[23]_i_1247_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1248 
       (.I0(\SC_U/local_y [9]),
        .I1(\SC_U/local_y [8]),
        .O(\rgb_out[23]_i_1248_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_1250 
       (.I0(\rgb_out_reg[23]_i_716_n_3 ),
        .O(\rgb_out[23]_i_1250_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1251 
       (.I0(\SC_U/local_x [11]),
        .I1(\SC_U/local_x [10]),
        .O(\rgb_out[23]_i_1251_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1252 
       (.I0(\SC_U/local_x [9]),
        .I1(\SC_U/local_x [8]),
        .O(\rgb_out[23]_i_1252_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_1259 
       (.I0(\rgb_out_reg[23]_i_720_n_0 ),
        .O(\rgb_out[23]_i_1259_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1260 
       (.I0(\SC_U/local_y [11]),
        .I1(\SC_U/local_y [10]),
        .O(\rgb_out[23]_i_1260_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1261 
       (.I0(\SC_U/local_y [9]),
        .I1(\SC_U/local_y [8]),
        .O(\rgb_out[23]_i_1261_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1263 
       (.I0(\SC_U/local_y [10]),
        .I1(\SC_U/local_y [11]),
        .O(\rgb_out[23]_i_1263_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1264 
       (.I0(\SC_U/local_y [8]),
        .I1(\SC_U/local_y [9]),
        .O(\rgb_out[23]_i_1264_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1265 
       (.I0(\SC_U/local_y [11]),
        .I1(\SC_U/local_y [10]),
        .O(\rgb_out[23]_i_1265_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1266 
       (.I0(\SC_U/local_y [9]),
        .I1(\SC_U/local_y [8]),
        .O(\rgb_out[23]_i_1266_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_1268 
       (.I0(\rgb_out_reg[23]_i_720_n_0 ),
        .O(\rgb_out[23]_i_1268_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1269 
       (.I0(\SC_U/local_y [11]),
        .I1(\SC_U/local_y [10]),
        .O(\rgb_out[23]_i_1269_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1270 
       (.I0(\SC_U/local_y [9]),
        .I1(\SC_U/local_y [8]),
        .O(\rgb_out[23]_i_1270_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_1272 
       (.I0(\rgb_out_reg[23]_i_720_n_0 ),
        .O(\rgb_out[23]_i_1272_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1273 
       (.I0(\SC_U/local_y [11]),
        .I1(\SC_U/local_y [10]),
        .O(\rgb_out[23]_i_1273_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1274 
       (.I0(\SC_U/local_y [9]),
        .I1(\SC_U/local_y [8]),
        .O(\rgb_out[23]_i_1274_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1276 
       (.I0(\SC_U/local_y [10]),
        .I1(\SC_U/local_y [11]),
        .O(\rgb_out[23]_i_1276_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1277 
       (.I0(\SC_U/local_y [8]),
        .I1(\SC_U/local_y [9]),
        .O(\rgb_out[23]_i_1277_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1278 
       (.I0(\SC_U/local_y [11]),
        .I1(\SC_U/local_y [10]),
        .O(\rgb_out[23]_i_1278_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1279 
       (.I0(\SC_U/local_y [9]),
        .I1(\SC_U/local_y [8]),
        .O(\rgb_out[23]_i_1279_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_1281 
       (.I0(\rgb_out_reg[23]_i_716_n_3 ),
        .O(\rgb_out[23]_i_1281_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1282 
       (.I0(\SC_U/local_x [11]),
        .I1(\SC_U/local_x [10]),
        .O(\rgb_out[23]_i_1282_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1283 
       (.I0(\SC_U/local_x [9]),
        .I1(\SC_U/local_x [8]),
        .O(\rgb_out[23]_i_1283_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1285 
       (.I0(\SC_U/local_x [10]),
        .I1(\SC_U/local_x [11]),
        .O(\rgb_out[23]_i_1285_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1286 
       (.I0(\SC_U/local_x [8]),
        .I1(\SC_U/local_x [9]),
        .O(\rgb_out[23]_i_1286_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1287 
       (.I0(\SC_U/local_x [11]),
        .I1(\SC_U/local_x [10]),
        .O(\rgb_out[23]_i_1287_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1288 
       (.I0(\SC_U/local_x [9]),
        .I1(\SC_U/local_x [8]),
        .O(\rgb_out[23]_i_1288_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_1290 
       (.I0(\rgb_out_reg[23]_i_720_n_0 ),
        .O(\rgb_out[23]_i_1290_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1291 
       (.I0(\SC_U/local_y [11]),
        .I1(\SC_U/local_y [10]),
        .O(\rgb_out[23]_i_1291_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1292 
       (.I0(\SC_U/local_y [9]),
        .I1(\SC_U/local_y [8]),
        .O(\rgb_out[23]_i_1292_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1294 
       (.I0(\SC_U/local_y [10]),
        .I1(\SC_U/local_y [11]),
        .O(\rgb_out[23]_i_1294_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1295 
       (.I0(\SC_U/local_y [8]),
        .I1(\SC_U/local_y [9]),
        .O(\rgb_out[23]_i_1295_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1296 
       (.I0(\SC_U/local_y [11]),
        .I1(\SC_U/local_y [10]),
        .O(\rgb_out[23]_i_1296_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1297 
       (.I0(\SC_U/local_y [9]),
        .I1(\SC_U/local_y [8]),
        .O(\rgb_out[23]_i_1297_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_1299 
       (.I0(U0_n_15),
        .O(\rgb_out[23]_i_1299_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1301 
       (.I0(\SC_D/local_y [11]),
        .I1(\SC_D/local_y [10]),
        .O(\rgb_out[23]_i_1301_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1302 
       (.I0(\SC_D/local_y [9]),
        .I1(\SC_D/local_y [8]),
        .O(\rgb_out[23]_i_1302_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1304 
       (.I0(\SC_D/local_y [10]),
        .I1(\SC_D/local_y [11]),
        .O(\rgb_out[23]_i_1304_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1305 
       (.I0(\SC_D/local_y [8]),
        .I1(\SC_D/local_y [9]),
        .O(\rgb_out[23]_i_1305_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1306 
       (.I0(\SC_D/local_y [11]),
        .I1(\SC_D/local_y [10]),
        .O(\rgb_out[23]_i_1306_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1307 
       (.I0(\SC_D/local_y [9]),
        .I1(\SC_D/local_y [8]),
        .O(\rgb_out[23]_i_1307_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_1314 
       (.I0(\rgb_out_reg[23]_i_761_n_3 ),
        .O(\rgb_out[23]_i_1314_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1315 
       (.I0(\SC_D/local_x [11]),
        .I1(\SC_D/local_x [10]),
        .O(\rgb_out[23]_i_1315_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1316 
       (.I0(\SC_D/local_x [9]),
        .I1(\SC_D/local_x [8]),
        .O(\rgb_out[23]_i_1316_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1327 
       (.I0(\SC_D/local_y [10]),
        .I1(\SC_D/local_y [11]),
        .O(\rgb_out[23]_i_1327_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1328 
       (.I0(\SC_D/local_y [8]),
        .I1(\SC_D/local_y [9]),
        .O(\rgb_out[23]_i_1328_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1329 
       (.I0(\SC_D/local_y [11]),
        .I1(\SC_D/local_y [10]),
        .O(\rgb_out[23]_i_1329_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1330 
       (.I0(\SC_D/local_y [9]),
        .I1(\SC_D/local_y [8]),
        .O(\rgb_out[23]_i_1330_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1335 
       (.I0(\SC_D/local_x [6]),
        .I1(\SC_D/local_x [7]),
        .O(\rgb_out[23]_i_1335_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_1337 
       (.I0(\SC_D/local_x [0]),
        .I1(\SC_D/local_x [1]),
        .O(\rgb_out[23]_i_1337_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1338 
       (.I0(\SC_D/local_x [7]),
        .I1(\SC_D/local_x [6]),
        .O(\rgb_out[23]_i_1338_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1339 
       (.I0(\SC_D/local_x [4]),
        .I1(\SC_D/local_x [5]),
        .O(\rgb_out[23]_i_1339_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_1340 
       (.I0(\SC_D/local_x [3]),
        .I1(\SC_D/local_x [2]),
        .O(\rgb_out[23]_i_1340_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1341 
       (.I0(\SC_D/local_x [1]),
        .I1(\SC_D/local_x [0]),
        .O(\rgb_out[23]_i_1341_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1343 
       (.I0(\SC_D/local_x [3]),
        .I1(\SC_D/local_x [2]),
        .O(\rgb_out[23]_i_1343_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_1344 
       (.I0(\SC_D/local_x [1]),
        .O(\rgb_out[23]_i_1344_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1345 
       (.I0(\SC_D/local_x [7]),
        .I1(\SC_D/local_x [6]),
        .O(\rgb_out[23]_i_1345_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1346 
       (.I0(\SC_D/local_x [5]),
        .I1(\SC_D/local_x [4]),
        .O(\rgb_out[23]_i_1346_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1347 
       (.I0(\SC_D/local_x [2]),
        .I1(\SC_D/local_x [3]),
        .O(\rgb_out[23]_i_1347_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1348 
       (.I0(\SC_D/local_x [1]),
        .I1(\SC_D/local_x [0]),
        .O(\rgb_out[23]_i_1348_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1350 
       (.I0(\SC_D/local_y [10]),
        .I1(\SC_D/local_y [11]),
        .O(\rgb_out[23]_i_1350_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1351 
       (.I0(\SC_D/local_y [8]),
        .I1(\SC_D/local_y [9]),
        .O(\rgb_out[23]_i_1351_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1352 
       (.I0(\SC_D/local_y [11]),
        .I1(\SC_D/local_y [10]),
        .O(\rgb_out[23]_i_1352_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1353 
       (.I0(\SC_D/local_y [9]),
        .I1(\SC_D/local_y [8]),
        .O(\rgb_out[23]_i_1353_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1355 
       (.I0(\SC_D/local_x [10]),
        .I1(\SC_D/local_x [11]),
        .O(\rgb_out[23]_i_1355_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1356 
       (.I0(\SC_D/local_x [8]),
        .I1(\SC_D/local_x [9]),
        .O(\rgb_out[23]_i_1356_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1357 
       (.I0(\SC_D/local_x [11]),
        .I1(\SC_D/local_x [10]),
        .O(\rgb_out[23]_i_1357_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1358 
       (.I0(\SC_D/local_x [9]),
        .I1(\SC_D/local_x [8]),
        .O(\rgb_out[23]_i_1358_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_1360 
       (.I0(U0_n_15),
        .O(\SC_D/local_y [12]));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1361 
       (.I0(\SC_D/local_y [11]),
        .I1(\SC_D/local_y [10]),
        .O(\rgb_out[23]_i_1361_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_1363 
       (.I0(\rgb_out_reg[23]_i_761_n_3 ),
        .O(\SC_D/local_x [12]));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1364 
       (.I0(\SC_D/local_x [11]),
        .I1(\SC_D/local_x [10]),
        .O(\rgb_out[23]_i_1364_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1365 
       (.I0(\TM_D/local_y [3]),
        .I1(\TM_D/local_y [2]),
        .O(\rgb_out[23]_i_1365_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_1366 
       (.I0(\TM_D/local_y [1]),
        .O(\rgb_out[23]_i_1366_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1367 
       (.I0(\TM_D/local_y [7]),
        .I1(\TM_D/local_y [6]),
        .O(\rgb_out[23]_i_1367_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1368 
       (.I0(\TM_D/local_y [5]),
        .I1(\TM_D/local_y [4]),
        .O(\rgb_out[23]_i_1368_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1369 
       (.I0(\TM_D/local_y [2]),
        .I1(\TM_D/local_y [3]),
        .O(\rgb_out[23]_i_1369_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1370 
       (.I0(\TM_D/local_y [1]),
        .I1(pixel_y[0]),
        .O(\rgb_out[23]_i_1370_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_1372 
       (.I0(pixel_y[11]),
        .O(\rgb_out[23]_i_1372_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_1373 
       (.I0(pixel_y[10]),
        .O(\rgb_out[23]_i_1373_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_1374 
       (.I0(pixel_y[9]),
        .O(\rgb_out[23]_i_1374_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1375 
       (.I0(\TM_D/local_y [6]),
        .I1(\TM_D/local_y [7]),
        .O(\rgb_out[23]_i_1375_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_1377 
       (.I0(pixel_y[0]),
        .I1(\TM_D/local_y [1]),
        .O(\rgb_out[23]_i_1377_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1378 
       (.I0(\TM_D/local_y [7]),
        .I1(\TM_D/local_y [6]),
        .O(\rgb_out[23]_i_1378_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_1379 
       (.I0(\TM_D/local_y [5]),
        .I1(\TM_D/local_y [4]),
        .O(\rgb_out[23]_i_1379_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1380 
       (.I0(\TM_D/local_y [2]),
        .I1(\TM_D/local_y [3]),
        .O(\rgb_out[23]_i_1380_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1381 
       (.I0(\TM_D/local_y [1]),
        .I1(pixel_y[0]),
        .O(\rgb_out[23]_i_1381_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1389 
       (.I0(\TM_D/local_x [5]),
        .I1(\TM_D/local_x [4]),
        .O(\rgb_out[23]_i_1389_n_0 ));
  LUT2 #(
    .INIT(4'h7)) 
    \rgb_out[23]_i_1390 
       (.I0(\TM_D/local_x [2]),
        .I1(\TM_D/local_x [3]),
        .O(\rgb_out[23]_i_1390_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_1391 
       (.I0(pixel_x[1]),
        .O(\rgb_out[23]_i_1391_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1392 
       (.I0(\TM_D/local_x [7]),
        .I1(\TM_D/local_x [6]),
        .O(\rgb_out[23]_i_1392_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1393 
       (.I0(\TM_D/local_x [4]),
        .I1(\TM_D/local_x [5]),
        .O(\rgb_out[23]_i_1393_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_1394 
       (.I0(\TM_D/local_x [3]),
        .I1(\TM_D/local_x [2]),
        .O(\rgb_out[23]_i_1394_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1395 
       (.I0(pixel_x[1]),
        .I1(pixel_x[0]),
        .O(\rgb_out[23]_i_1395_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1396 
       (.I0(\TM_D/local_y [6]),
        .I1(\TM_D/local_y [7]),
        .O(\rgb_out[23]_i_1396_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1397 
       (.I0(\TM_D/local_y [4]),
        .I1(\TM_D/local_y [5]),
        .O(\rgb_out[23]_i_1397_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_1398 
       (.I0(pixel_y[0]),
        .I1(\TM_D/local_y [1]),
        .O(\rgb_out[23]_i_1398_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1399 
       (.I0(\TM_D/local_y [7]),
        .I1(\TM_D/local_y [6]),
        .O(\rgb_out[23]_i_1399_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1400 
       (.I0(\TM_D/local_y [5]),
        .I1(\TM_D/local_y [4]),
        .O(\rgb_out[23]_i_1400_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1401 
       (.I0(\TM_D/local_y [2]),
        .I1(\TM_D/local_y [3]),
        .O(\rgb_out[23]_i_1401_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1402 
       (.I0(\TM_D/local_y [1]),
        .I1(pixel_y[0]),
        .O(\rgb_out[23]_i_1402_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1403 
       (.I0(\TM_D/local_y [5]),
        .I1(\TM_D/local_y [4]),
        .O(\rgb_out[23]_i_1403_n_0 ));
  LUT2 #(
    .INIT(4'h7)) 
    \rgb_out[23]_i_1404 
       (.I0(\TM_D/local_y [2]),
        .I1(\TM_D/local_y [3]),
        .O(\rgb_out[23]_i_1404_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_1405 
       (.I0(\TM_D/local_y [1]),
        .O(\rgb_out[23]_i_1405_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1406 
       (.I0(\TM_D/local_y [7]),
        .I1(\TM_D/local_y [6]),
        .O(\rgb_out[23]_i_1406_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1407 
       (.I0(\TM_D/local_y [4]),
        .I1(\TM_D/local_y [5]),
        .O(\rgb_out[23]_i_1407_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_1408 
       (.I0(\TM_D/local_y [3]),
        .I1(\TM_D/local_y [2]),
        .O(\rgb_out[23]_i_1408_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1409 
       (.I0(\TM_D/local_y [1]),
        .I1(pixel_y[0]),
        .O(\rgb_out[23]_i_1409_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1410 
       (.I0(\TM_D/local_y [6]),
        .I1(\TM_D/local_y [7]),
        .O(\rgb_out[23]_i_1410_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_1411 
       (.I0(pixel_y[0]),
        .I1(\TM_D/local_y [1]),
        .O(\rgb_out[23]_i_1411_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1412 
       (.I0(\TM_D/local_y [7]),
        .I1(\TM_D/local_y [6]),
        .O(\rgb_out[23]_i_1412_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1413 
       (.I0(\TM_D/local_y [4]),
        .I1(\TM_D/local_y [5]),
        .O(\rgb_out[23]_i_1413_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_1414 
       (.I0(\TM_D/local_y [3]),
        .I1(\TM_D/local_y [2]),
        .O(\rgb_out[23]_i_1414_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1415 
       (.I0(\TM_D/local_y [1]),
        .I1(pixel_y[0]),
        .O(\rgb_out[23]_i_1415_n_0 ));
  LUT2 #(
    .INIT(4'h7)) 
    \rgb_out[23]_i_1416 
       (.I0(\TM_D/local_y [4]),
        .I1(\TM_D/local_y [5]),
        .O(\rgb_out[23]_i_1416_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1417 
       (.I0(\TM_D/local_y [3]),
        .I1(\TM_D/local_y [2]),
        .O(\rgb_out[23]_i_1417_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_1418 
       (.I0(\TM_D/local_y [1]),
        .O(\rgb_out[23]_i_1418_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1419 
       (.I0(\TM_D/local_y [7]),
        .I1(\TM_D/local_y [6]),
        .O(\rgb_out[23]_i_1419_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_1420 
       (.I0(\TM_D/local_y [5]),
        .I1(\TM_D/local_y [4]),
        .O(\rgb_out[23]_i_1420_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1421 
       (.I0(\TM_D/local_y [2]),
        .I1(\TM_D/local_y [3]),
        .O(\rgb_out[23]_i_1421_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1422 
       (.I0(\TM_D/local_y [1]),
        .I1(pixel_y[0]),
        .O(\rgb_out[23]_i_1422_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_1423 
       (.I0(pixel_x[3]),
        .O(\rgb_out[23]_i_1423_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_1424 
       (.I0(pixel_x[9]),
        .O(\rgb_out[23]_i_1424_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_1425 
       (.I0(pixel_x[7]),
        .O(\rgb_out[23]_i_1425_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1426 
       (.I0(\TM_D/local_y [6]),
        .I1(\TM_D/local_y [7]),
        .O(\rgb_out[23]_i_1426_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1427 
       (.I0(\TM_D/local_y [4]),
        .I1(\TM_D/local_y [5]),
        .O(\rgb_out[23]_i_1427_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1428 
       (.I0(\TM_D/local_y [2]),
        .I1(\TM_D/local_y [3]),
        .O(\rgb_out[23]_i_1428_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1429 
       (.I0(\TM_D/local_y [1]),
        .I1(pixel_y[0]),
        .O(\rgb_out[23]_i_1429_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1430 
       (.I0(\TM_D/local_y [7]),
        .I1(\TM_D/local_y [6]),
        .O(\rgb_out[23]_i_1430_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1431 
       (.I0(\TM_D/local_y [5]),
        .I1(\TM_D/local_y [4]),
        .O(\rgb_out[23]_i_1431_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1432 
       (.I0(\TM_D/local_y [3]),
        .I1(\TM_D/local_y [2]),
        .O(\rgb_out[23]_i_1432_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1433 
       (.I0(pixel_y[0]),
        .I1(\TM_D/local_y [1]),
        .O(\rgb_out[23]_i_1433_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1434 
       (.I0(\TM_D/local_x [6]),
        .I1(\TM_D/local_x [7]),
        .O(\rgb_out[23]_i_1434_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1435 
       (.I0(\TM_D/local_x [4]),
        .I1(\TM_D/local_x [5]),
        .O(\rgb_out[23]_i_1435_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1436 
       (.I0(\TM_D/local_x [2]),
        .I1(\TM_D/local_x [3]),
        .O(\rgb_out[23]_i_1436_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1437 
       (.I0(pixel_x[1]),
        .I1(pixel_x[0]),
        .O(\rgb_out[23]_i_1437_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1438 
       (.I0(\TM_D/local_x [7]),
        .I1(\TM_D/local_x [6]),
        .O(\rgb_out[23]_i_1438_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1439 
       (.I0(\TM_D/local_x [5]),
        .I1(\TM_D/local_x [4]),
        .O(\rgb_out[23]_i_1439_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1440 
       (.I0(\TM_D/local_x [3]),
        .I1(\TM_D/local_x [2]),
        .O(\rgb_out[23]_i_1440_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1441 
       (.I0(pixel_x[0]),
        .I1(pixel_x[1]),
        .O(\rgb_out[23]_i_1441_n_0 ));
  LUT2 #(
    .INIT(4'h7)) 
    \rgb_out[23]_i_1442 
       (.I0(\TM_D/local_y [4]),
        .I1(\TM_D/local_y [5]),
        .O(\rgb_out[23]_i_1442_n_0 ));
  LUT2 #(
    .INIT(4'h7)) 
    \rgb_out[23]_i_1443 
       (.I0(\TM_D/local_y [2]),
        .I1(\TM_D/local_y [3]),
        .O(\rgb_out[23]_i_1443_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1444 
       (.I0(\TM_D/local_y [9]),
        .I1(\TM_D/local_y [8]),
        .O(\rgb_out[23]_i_1444_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1445 
       (.I0(\TM_D/local_y [7]),
        .I1(\TM_D/local_y [6]),
        .O(\rgb_out[23]_i_1445_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_1446 
       (.I0(\TM_D/local_y [5]),
        .I1(\TM_D/local_y [4]),
        .O(\rgb_out[23]_i_1446_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_1447 
       (.I0(\TM_D/local_y [3]),
        .I1(\TM_D/local_y [2]),
        .O(\rgb_out[23]_i_1447_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_1448 
       (.I0(\TM_D/local_x [5]),
        .O(\rgb_out[23]_i_1448_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1449 
       (.I0(\TM_D/local_x [3]),
        .I1(\TM_D/local_x [2]),
        .O(\rgb_out[23]_i_1449_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1450 
       (.I0(\TM_D/local_x [9]),
        .I1(\TM_D/local_x [8]),
        .O(\rgb_out[23]_i_1450_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1451 
       (.I0(\TM_D/local_x [7]),
        .I1(\TM_D/local_x [6]),
        .O(\rgb_out[23]_i_1451_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1452 
       (.I0(\TM_D/local_x [5]),
        .I1(\TM_D/local_x [4]),
        .O(\rgb_out[23]_i_1452_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1453 
       (.I0(\TM_D/local_x [2]),
        .I1(\TM_D/local_x [3]),
        .O(\rgb_out[23]_i_1453_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1467 
       (.I0(pixel_x[3]),
        .I1(pixel_x[2]),
        .O(\rgb_out[23]_i_1467_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_1468 
       (.I0(pixel_x[1]),
        .O(\rgb_out[23]_i_1468_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1471 
       (.I0(pixel_x[2]),
        .I1(pixel_x[3]),
        .O(\rgb_out[23]_i_1471_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1472 
       (.I0(pixel_x[1]),
        .I1(pixel_x[0]),
        .O(\rgb_out[23]_i_1472_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1497 
       (.I0(\REC_D/local_y [3]),
        .I1(\REC_D/local_y [2]),
        .O(\rgb_out[23]_i_1497_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_1498 
       (.I0(\REC_D/local_y [1]),
        .O(\rgb_out[23]_i_1498_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1499 
       (.I0(\REC_D/local_y [7]),
        .I1(\REC_D/local_y [6]),
        .O(\rgb_out[23]_i_1499_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1500 
       (.I0(\REC_D/local_y [5]),
        .I1(\REC_D/local_y [4]),
        .O(\rgb_out[23]_i_1500_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1501 
       (.I0(\REC_D/local_y [2]),
        .I1(\REC_D/local_y [3]),
        .O(\rgb_out[23]_i_1501_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_1502 
       (.I0(pixel_y[0]),
        .I1(\REC_D/local_y [1]),
        .O(\rgb_out[23]_i_1502_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_1504 
       (.I0(pixel_y[11]),
        .O(\rgb_out[23]_i_1504_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_1505 
       (.I0(pixel_y[10]),
        .O(\rgb_out[23]_i_1505_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_1506 
       (.I0(pixel_y[9]),
        .O(\rgb_out[23]_i_1506_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1507 
       (.I0(\REC_D/local_y [6]),
        .I1(\REC_D/local_y [7]),
        .O(\rgb_out[23]_i_1507_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1509 
       (.I0(\REC_D/local_y [1]),
        .I1(pixel_y[0]),
        .O(\rgb_out[23]_i_1509_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1510 
       (.I0(\REC_D/local_y [7]),
        .I1(\REC_D/local_y [6]),
        .O(\rgb_out[23]_i_1510_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_1511 
       (.I0(\REC_D/local_y [5]),
        .I1(\REC_D/local_y [4]),
        .O(\rgb_out[23]_i_1511_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1512 
       (.I0(\REC_D/local_y [2]),
        .I1(\REC_D/local_y [3]),
        .O(\rgb_out[23]_i_1512_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_1513 
       (.I0(pixel_y[0]),
        .I1(\REC_D/local_y [1]),
        .O(\rgb_out[23]_i_1513_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1514 
       (.I0(\REC_D/local_x [6]),
        .I1(\REC_D/local_x [7]),
        .O(\rgb_out[23]_i_1514_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1515 
       (.I0(\REC_D/local_x [4]),
        .I1(\REC_D/local_x [5]),
        .O(\rgb_out[23]_i_1515_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1517 
       (.I0(\REC_D/local_x [1]),
        .I1(pixel_x[0]),
        .O(\rgb_out[23]_i_1517_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1518 
       (.I0(\REC_D/local_x [7]),
        .I1(\REC_D/local_x [6]),
        .O(\rgb_out[23]_i_1518_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1519 
       (.I0(\REC_D/local_x [5]),
        .I1(\REC_D/local_x [4]),
        .O(\rgb_out[23]_i_1519_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1520 
       (.I0(\REC_D/local_x [2]),
        .I1(\REC_D/local_x [3]),
        .O(\rgb_out[23]_i_1520_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_1521 
       (.I0(pixel_x[0]),
        .I1(\REC_D/local_x [1]),
        .O(\rgb_out[23]_i_1521_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1522 
       (.I0(\REC_D/local_x [5]),
        .I1(\REC_D/local_x [4]),
        .O(\rgb_out[23]_i_1522_n_0 ));
  LUT2 #(
    .INIT(4'h7)) 
    \rgb_out[23]_i_1523 
       (.I0(\REC_D/local_x [2]),
        .I1(\REC_D/local_x [3]),
        .O(\rgb_out[23]_i_1523_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_1524 
       (.I0(\REC_D/local_x [1]),
        .O(\rgb_out[23]_i_1524_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1525 
       (.I0(\REC_D/local_x [7]),
        .I1(\REC_D/local_x [6]),
        .O(\rgb_out[23]_i_1525_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1526 
       (.I0(\REC_D/local_x [4]),
        .I1(\REC_D/local_x [5]),
        .O(\rgb_out[23]_i_1526_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_1527 
       (.I0(\REC_D/local_x [3]),
        .I1(\REC_D/local_x [2]),
        .O(\rgb_out[23]_i_1527_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_1528 
       (.I0(pixel_x[0]),
        .I1(\REC_D/local_x [1]),
        .O(\rgb_out[23]_i_1528_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1529 
       (.I0(\REC_D/local_y [6]),
        .I1(\REC_D/local_y [7]),
        .O(\rgb_out[23]_i_1529_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1530 
       (.I0(\REC_D/local_y [4]),
        .I1(\REC_D/local_y [5]),
        .O(\rgb_out[23]_i_1530_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1531 
       (.I0(\REC_D/local_y [1]),
        .I1(pixel_y[0]),
        .O(\rgb_out[23]_i_1531_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1532 
       (.I0(\REC_D/local_y [7]),
        .I1(\REC_D/local_y [6]),
        .O(\rgb_out[23]_i_1532_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1533 
       (.I0(\REC_D/local_y [5]),
        .I1(\REC_D/local_y [4]),
        .O(\rgb_out[23]_i_1533_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1534 
       (.I0(\REC_D/local_y [2]),
        .I1(\REC_D/local_y [3]),
        .O(\rgb_out[23]_i_1534_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_1535 
       (.I0(pixel_y[0]),
        .I1(\REC_D/local_y [1]),
        .O(\rgb_out[23]_i_1535_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1536 
       (.I0(\REC_D/local_y [5]),
        .I1(\REC_D/local_y [4]),
        .O(\rgb_out[23]_i_1536_n_0 ));
  LUT2 #(
    .INIT(4'h7)) 
    \rgb_out[23]_i_1537 
       (.I0(\REC_D/local_y [2]),
        .I1(\REC_D/local_y [3]),
        .O(\rgb_out[23]_i_1537_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_1538 
       (.I0(\REC_D/local_y [1]),
        .O(\rgb_out[23]_i_1538_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1539 
       (.I0(\REC_D/local_y [7]),
        .I1(\REC_D/local_y [6]),
        .O(\rgb_out[23]_i_1539_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1540 
       (.I0(\REC_D/local_y [4]),
        .I1(\REC_D/local_y [5]),
        .O(\rgb_out[23]_i_1540_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_1541 
       (.I0(\REC_D/local_y [3]),
        .I1(\REC_D/local_y [2]),
        .O(\rgb_out[23]_i_1541_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_1542 
       (.I0(pixel_y[0]),
        .I1(\REC_D/local_y [1]),
        .O(\rgb_out[23]_i_1542_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1543 
       (.I0(\REC_D/local_y [6]),
        .I1(\REC_D/local_y [7]),
        .O(\rgb_out[23]_i_1543_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1544 
       (.I0(\REC_D/local_y [1]),
        .I1(pixel_y[0]),
        .O(\rgb_out[23]_i_1544_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1545 
       (.I0(\REC_D/local_y [7]),
        .I1(\REC_D/local_y [6]),
        .O(\rgb_out[23]_i_1545_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1546 
       (.I0(\REC_D/local_y [4]),
        .I1(\REC_D/local_y [5]),
        .O(\rgb_out[23]_i_1546_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_1547 
       (.I0(\REC_D/local_y [3]),
        .I1(\REC_D/local_y [2]),
        .O(\rgb_out[23]_i_1547_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_1548 
       (.I0(pixel_y[0]),
        .I1(\REC_D/local_y [1]),
        .O(\rgb_out[23]_i_1548_n_0 ));
  LUT2 #(
    .INIT(4'h7)) 
    \rgb_out[23]_i_1549 
       (.I0(\REC_D/local_y [4]),
        .I1(\REC_D/local_y [5]),
        .O(\rgb_out[23]_i_1549_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1550 
       (.I0(\REC_D/local_y [3]),
        .I1(\REC_D/local_y [2]),
        .O(\rgb_out[23]_i_1550_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_1551 
       (.I0(\REC_D/local_y [1]),
        .O(\rgb_out[23]_i_1551_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1552 
       (.I0(\REC_D/local_y [7]),
        .I1(\REC_D/local_y [6]),
        .O(\rgb_out[23]_i_1552_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_1553 
       (.I0(\REC_D/local_y [5]),
        .I1(\REC_D/local_y [4]),
        .O(\rgb_out[23]_i_1553_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1554 
       (.I0(\REC_D/local_y [2]),
        .I1(\REC_D/local_y [3]),
        .O(\rgb_out[23]_i_1554_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_1555 
       (.I0(pixel_y[0]),
        .I1(\REC_D/local_y [1]),
        .O(\rgb_out[23]_i_1555_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_1556 
       (.I0(pixel_x[8]),
        .O(\rgb_out[23]_i_1556_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_1557 
       (.I0(pixel_x[6]),
        .O(\rgb_out[23]_i_1557_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_1558 
       (.I0(pixel_x[5]),
        .O(\rgb_out[23]_i_1558_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1559 
       (.I0(\REC_D/local_y [6]),
        .I1(\REC_D/local_y [7]),
        .O(\rgb_out[23]_i_1559_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1560 
       (.I0(\REC_D/local_y [4]),
        .I1(\REC_D/local_y [5]),
        .O(\rgb_out[23]_i_1560_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1561 
       (.I0(\REC_D/local_y [2]),
        .I1(\REC_D/local_y [3]),
        .O(\rgb_out[23]_i_1561_n_0 ));
  LUT2 #(
    .INIT(4'hB)) 
    \rgb_out[23]_i_1562 
       (.I0(\REC_D/local_y [1]),
        .I1(pixel_y[0]),
        .O(\rgb_out[23]_i_1562_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1563 
       (.I0(\REC_D/local_y [7]),
        .I1(\REC_D/local_y [6]),
        .O(\rgb_out[23]_i_1563_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1564 
       (.I0(\REC_D/local_y [5]),
        .I1(\REC_D/local_y [4]),
        .O(\rgb_out[23]_i_1564_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1565 
       (.I0(\REC_D/local_y [3]),
        .I1(\REC_D/local_y [2]),
        .O(\rgb_out[23]_i_1565_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1566 
       (.I0(pixel_y[0]),
        .I1(\REC_D/local_y [1]),
        .O(\rgb_out[23]_i_1566_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1567 
       (.I0(\REC_D/local_x [6]),
        .I1(\REC_D/local_x [7]),
        .O(\rgb_out[23]_i_1567_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1568 
       (.I0(\REC_D/local_x [4]),
        .I1(\REC_D/local_x [5]),
        .O(\rgb_out[23]_i_1568_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1569 
       (.I0(\REC_D/local_x [2]),
        .I1(\REC_D/local_x [3]),
        .O(\rgb_out[23]_i_1569_n_0 ));
  LUT2 #(
    .INIT(4'hB)) 
    \rgb_out[23]_i_1570 
       (.I0(\REC_D/local_x [1]),
        .I1(pixel_x[0]),
        .O(\rgb_out[23]_i_1570_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1571 
       (.I0(\REC_D/local_x [7]),
        .I1(\REC_D/local_x [6]),
        .O(\rgb_out[23]_i_1571_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1572 
       (.I0(\REC_D/local_x [5]),
        .I1(\REC_D/local_x [4]),
        .O(\rgb_out[23]_i_1572_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1573 
       (.I0(\REC_D/local_x [3]),
        .I1(\REC_D/local_x [2]),
        .O(\rgb_out[23]_i_1573_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1574 
       (.I0(pixel_x[0]),
        .I1(\REC_D/local_x [1]),
        .O(\rgb_out[23]_i_1574_n_0 ));
  LUT2 #(
    .INIT(4'h7)) 
    \rgb_out[23]_i_1575 
       (.I0(\REC_D/local_y [4]),
        .I1(\REC_D/local_y [5]),
        .O(\rgb_out[23]_i_1575_n_0 ));
  LUT2 #(
    .INIT(4'h7)) 
    \rgb_out[23]_i_1576 
       (.I0(\REC_D/local_y [2]),
        .I1(\REC_D/local_y [3]),
        .O(\rgb_out[23]_i_1576_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1577 
       (.I0(\REC_D/local_y [9]),
        .I1(\REC_D/local_y [8]),
        .O(\rgb_out[23]_i_1577_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1578 
       (.I0(\REC_D/local_y [7]),
        .I1(\REC_D/local_y [6]),
        .O(\rgb_out[23]_i_1578_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_1579 
       (.I0(\REC_D/local_y [5]),
        .I1(\REC_D/local_y [4]),
        .O(\rgb_out[23]_i_1579_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_1580 
       (.I0(\REC_D/local_y [3]),
        .I1(\REC_D/local_y [2]),
        .O(\rgb_out[23]_i_1580_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_1581 
       (.I0(\REC_D/local_x [5]),
        .O(\rgb_out[23]_i_1581_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1582 
       (.I0(\REC_D/local_x [3]),
        .I1(\REC_D/local_x [2]),
        .O(\rgb_out[23]_i_1582_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1583 
       (.I0(\REC_D/local_x [9]),
        .I1(\REC_D/local_x [8]),
        .O(\rgb_out[23]_i_1583_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1584 
       (.I0(\REC_D/local_x [7]),
        .I1(\REC_D/local_x [6]),
        .O(\rgb_out[23]_i_1584_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1585 
       (.I0(\REC_D/local_x [5]),
        .I1(\REC_D/local_x [4]),
        .O(\rgb_out[23]_i_1585_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1586 
       (.I0(\REC_D/local_x [2]),
        .I1(\REC_D/local_x [3]),
        .O(\rgb_out[23]_i_1586_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_1587 
       (.I0(\LAST_U/local_x [5]),
        .O(\rgb_out[23]_i_1587_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1588 
       (.I0(\LAST_U/local_x [3]),
        .I1(\LAST_U/local_x [2]),
        .O(\rgb_out[23]_i_1588_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1589 
       (.I0(\LAST_U/local_x [9]),
        .I1(\LAST_U/local_x [8]),
        .O(\rgb_out[23]_i_1589_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1590 
       (.I0(\LAST_U/local_x [7]),
        .I1(\LAST_U/local_x [6]),
        .O(\rgb_out[23]_i_1590_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1591 
       (.I0(\LAST_U/local_x [5]),
        .I1(\LAST_U/local_x [4]),
        .O(\rgb_out[23]_i_1591_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1592 
       (.I0(\LAST_U/local_x [2]),
        .I1(\LAST_U/local_x [3]),
        .O(\rgb_out[23]_i_1592_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_1594 
       (.I0(pixel_x[11]),
        .O(\rgb_out[23]_i_1594_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_1595 
       (.I0(pixel_x[10]),
        .O(\rgb_out[23]_i_1595_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_1596 
       (.I0(pixel_x[9]),
        .O(\rgb_out[23]_i_1596_n_0 ));
  LUT2 #(
    .INIT(4'h7)) 
    \rgb_out[23]_i_1597 
       (.I0(\LAST_U/local_y [3]),
        .I1(\LAST_U/local_y [2]),
        .O(\rgb_out[23]_i_1597_n_0 ));
  LUT2 #(
    .INIT(4'h7)) 
    \rgb_out[23]_i_1598 
       (.I0(\LAST_U/local_y [5]),
        .I1(\LAST_U/local_y [4]),
        .O(\rgb_out[23]_i_1598_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1599 
       (.I0(\LAST_U/local_y [11]),
        .I1(\LAST_U/local_y [10]),
        .O(\rgb_out[23]_i_1599_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1600 
       (.I0(\LAST_U/local_y [9]),
        .I1(\LAST_U/local_y [8]),
        .O(\rgb_out[23]_i_1600_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1601 
       (.I0(\LAST_U/local_y [7]),
        .I1(\LAST_U/local_y [6]),
        .O(\rgb_out[23]_i_1601_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_1602 
       (.I0(\LAST_U/local_y [4]),
        .I1(\LAST_U/local_y [5]),
        .O(\rgb_out[23]_i_1602_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_1604 
       (.I0(pixel_y[11]),
        .O(\rgb_out[23]_i_1604_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_1605 
       (.I0(pixel_y[10]),
        .O(\rgb_out[23]_i_1605_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_1606 
       (.I0(pixel_y[9]),
        .O(\rgb_out[23]_i_1606_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1607 
       (.I0(\LAST_U/local_x [6]),
        .I1(\LAST_U/local_x [7]),
        .O(\rgb_out[23]_i_1607_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1608 
       (.I0(\LAST_U/local_x [5]),
        .I1(\LAST_U/local_x [4]),
        .O(\rgb_out[23]_i_1608_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1609 
       (.I0(\LAST_U/local_x [2]),
        .I1(\LAST_U/local_x [3]),
        .O(\rgb_out[23]_i_1609_n_0 ));
  LUT2 #(
    .INIT(4'hB)) 
    \rgb_out[23]_i_1610 
       (.I0(\LAST_U/local_x [1]),
        .I1(pixel_x[0]),
        .O(\rgb_out[23]_i_1610_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1611 
       (.I0(\LAST_U/local_x [7]),
        .I1(\LAST_U/local_x [6]),
        .O(\rgb_out[23]_i_1611_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1612 
       (.I0(\LAST_U/local_x [4]),
        .I1(\LAST_U/local_x [5]),
        .O(\rgb_out[23]_i_1612_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1613 
       (.I0(\LAST_U/local_x [3]),
        .I1(\LAST_U/local_x [2]),
        .O(\rgb_out[23]_i_1613_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1614 
       (.I0(pixel_x[0]),
        .I1(\LAST_U/local_x [1]),
        .O(\rgb_out[23]_i_1614_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1615 
       (.I0(\LAST_U/local_y [6]),
        .I1(\LAST_U/local_y [7]),
        .O(\rgb_out[23]_i_1615_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1616 
       (.I0(\LAST_U/local_y [4]),
        .I1(\LAST_U/local_y [5]),
        .O(\rgb_out[23]_i_1616_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1617 
       (.I0(\LAST_U/local_y [2]),
        .I1(\LAST_U/local_y [3]),
        .O(\rgb_out[23]_i_1617_n_0 ));
  LUT2 #(
    .INIT(4'hB)) 
    \rgb_out[23]_i_1618 
       (.I0(\LAST_U/local_y [1]),
        .I1(pixel_y[0]),
        .O(\rgb_out[23]_i_1618_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1619 
       (.I0(\LAST_U/local_y [7]),
        .I1(\LAST_U/local_y [6]),
        .O(\rgb_out[23]_i_1619_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1620 
       (.I0(\LAST_U/local_y [5]),
        .I1(\LAST_U/local_y [4]),
        .O(\rgb_out[23]_i_1620_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1621 
       (.I0(\LAST_U/local_y [3]),
        .I1(\LAST_U/local_y [2]),
        .O(\rgb_out[23]_i_1621_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1622 
       (.I0(pixel_y[0]),
        .I1(\LAST_U/local_y [1]),
        .O(\rgb_out[23]_i_1622_n_0 ));
  LUT2 #(
    .INIT(4'h7)) 
    \rgb_out[23]_i_1623 
       (.I0(\LAST_U/local_y [5]),
        .I1(\LAST_U/local_y [4]),
        .O(\rgb_out[23]_i_1623_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1624 
       (.I0(\LAST_U/local_y [3]),
        .I1(\LAST_U/local_y [2]),
        .O(\rgb_out[23]_i_1624_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_1625 
       (.I0(\LAST_U/local_y [1]),
        .O(\rgb_out[23]_i_1625_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1626 
       (.I0(\LAST_U/local_y [7]),
        .I1(\LAST_U/local_y [6]),
        .O(\rgb_out[23]_i_1626_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_1627 
       (.I0(\LAST_U/local_y [4]),
        .I1(\LAST_U/local_y [5]),
        .O(\rgb_out[23]_i_1627_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1628 
       (.I0(\LAST_U/local_y [2]),
        .I1(\LAST_U/local_y [3]),
        .O(\rgb_out[23]_i_1628_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_1629 
       (.I0(pixel_y[0]),
        .I1(\LAST_U/local_y [1]),
        .O(\rgb_out[23]_i_1629_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1630 
       (.I0(\LAST_U/local_y [6]),
        .I1(\LAST_U/local_y [7]),
        .O(\rgb_out[23]_i_1630_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1631 
       (.I0(\LAST_U/local_y [1]),
        .I1(pixel_y[0]),
        .O(\rgb_out[23]_i_1631_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1632 
       (.I0(\LAST_U/local_y [7]),
        .I1(\LAST_U/local_y [6]),
        .O(\rgb_out[23]_i_1632_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1633 
       (.I0(\LAST_U/local_y [4]),
        .I1(\LAST_U/local_y [5]),
        .O(\rgb_out[23]_i_1633_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_1634 
       (.I0(\LAST_U/local_y [2]),
        .I1(\LAST_U/local_y [3]),
        .O(\rgb_out[23]_i_1634_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_1635 
       (.I0(pixel_y[0]),
        .I1(\LAST_U/local_y [1]),
        .O(\rgb_out[23]_i_1635_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1636 
       (.I0(\LAST_U/local_x [3]),
        .I1(\LAST_U/local_x [2]),
        .O(\rgb_out[23]_i_1636_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_1637 
       (.I0(\LAST_U/local_x [1]),
        .O(\rgb_out[23]_i_1637_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1638 
       (.I0(\LAST_U/local_x [7]),
        .I1(\LAST_U/local_x [6]),
        .O(\rgb_out[23]_i_1638_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1639 
       (.I0(\LAST_U/local_x [4]),
        .I1(\LAST_U/local_x [5]),
        .O(\rgb_out[23]_i_1639_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1640 
       (.I0(\LAST_U/local_x [2]),
        .I1(\LAST_U/local_x [3]),
        .O(\rgb_out[23]_i_1640_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_1641 
       (.I0(pixel_x[0]),
        .I1(\LAST_U/local_x [1]),
        .O(\rgb_out[23]_i_1641_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1642 
       (.I0(\LAST_U/local_x [6]),
        .I1(\LAST_U/local_x [7]),
        .O(\rgb_out[23]_i_1642_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1643 
       (.I0(\LAST_U/local_x [1]),
        .I1(pixel_x[0]),
        .O(\rgb_out[23]_i_1643_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1644 
       (.I0(\LAST_U/local_x [7]),
        .I1(\LAST_U/local_x [6]),
        .O(\rgb_out[23]_i_1644_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1645 
       (.I0(\LAST_U/local_x [4]),
        .I1(\LAST_U/local_x [5]),
        .O(\rgb_out[23]_i_1645_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_1646 
       (.I0(\LAST_U/local_x [2]),
        .I1(\LAST_U/local_x [3]),
        .O(\rgb_out[23]_i_1646_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_1647 
       (.I0(pixel_x[0]),
        .I1(\LAST_U/local_x [1]),
        .O(\rgb_out[23]_i_1647_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1648 
       (.I0(\LAST_U/local_y [5]),
        .I1(\LAST_U/local_y [4]),
        .O(\rgb_out[23]_i_1648_n_0 ));
  LUT2 #(
    .INIT(4'h7)) 
    \rgb_out[23]_i_1649 
       (.I0(\LAST_U/local_y [3]),
        .I1(\LAST_U/local_y [2]),
        .O(\rgb_out[23]_i_1649_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_1650 
       (.I0(\LAST_U/local_y [1]),
        .O(\rgb_out[23]_i_1650_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1651 
       (.I0(\LAST_U/local_y [7]),
        .I1(\LAST_U/local_y [6]),
        .O(\rgb_out[23]_i_1651_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1652 
       (.I0(\LAST_U/local_y [4]),
        .I1(\LAST_U/local_y [5]),
        .O(\rgb_out[23]_i_1652_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_1653 
       (.I0(\LAST_U/local_y [2]),
        .I1(\LAST_U/local_y [3]),
        .O(\rgb_out[23]_i_1653_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_1654 
       (.I0(pixel_y[0]),
        .I1(\LAST_U/local_y [1]),
        .O(\rgb_out[23]_i_1654_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1655 
       (.I0(\LAST_U/local_y [6]),
        .I1(\LAST_U/local_y [7]),
        .O(\rgb_out[23]_i_1655_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1656 
       (.I0(\LAST_U/local_y [4]),
        .I1(\LAST_U/local_y [5]),
        .O(\rgb_out[23]_i_1656_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1658 
       (.I0(\LAST_U/local_y [1]),
        .I1(pixel_y[0]),
        .O(\rgb_out[23]_i_1658_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1659 
       (.I0(\LAST_U/local_y [7]),
        .I1(\LAST_U/local_y [6]),
        .O(\rgb_out[23]_i_1659_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1660 
       (.I0(\LAST_U/local_y [5]),
        .I1(\LAST_U/local_y [4]),
        .O(\rgb_out[23]_i_1660_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1661 
       (.I0(\LAST_U/local_y [2]),
        .I1(\LAST_U/local_y [3]),
        .O(\rgb_out[23]_i_1661_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_1662 
       (.I0(pixel_y[0]),
        .I1(\LAST_U/local_y [1]),
        .O(\rgb_out[23]_i_1662_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1663 
       (.I0(\LAST_U/local_x [6]),
        .I1(\LAST_U/local_x [7]),
        .O(\rgb_out[23]_i_1663_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1664 
       (.I0(\LAST_U/local_x [5]),
        .I1(\LAST_U/local_x [4]),
        .O(\rgb_out[23]_i_1664_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1666 
       (.I0(\LAST_U/local_x [1]),
        .I1(pixel_x[0]),
        .O(\rgb_out[23]_i_1666_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1667 
       (.I0(\LAST_U/local_x [7]),
        .I1(\LAST_U/local_x [6]),
        .O(\rgb_out[23]_i_1667_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1668 
       (.I0(\LAST_U/local_x [4]),
        .I1(\LAST_U/local_x [5]),
        .O(\rgb_out[23]_i_1668_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1669 
       (.I0(\LAST_U/local_x [2]),
        .I1(\LAST_U/local_x [3]),
        .O(\rgb_out[23]_i_1669_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_1670 
       (.I0(pixel_x[0]),
        .I1(\LAST_U/local_x [1]),
        .O(\rgb_out[23]_i_1670_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1671 
       (.I0(\LAST_U/local_x [4]),
        .I1(\LAST_U/local_x [5]),
        .O(\rgb_out[23]_i_1671_n_0 ));
  LUT2 #(
    .INIT(4'h7)) 
    \rgb_out[23]_i_1672 
       (.I0(\LAST_U/local_x [3]),
        .I1(\LAST_U/local_x [2]),
        .O(\rgb_out[23]_i_1672_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_1673 
       (.I0(\LAST_U/local_x [1]),
        .O(\rgb_out[23]_i_1673_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1674 
       (.I0(\LAST_U/local_x [7]),
        .I1(\LAST_U/local_x [6]),
        .O(\rgb_out[23]_i_1674_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1675 
       (.I0(\LAST_U/local_x [4]),
        .I1(\LAST_U/local_x [5]),
        .O(\rgb_out[23]_i_1675_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_1676 
       (.I0(\LAST_U/local_x [2]),
        .I1(\LAST_U/local_x [3]),
        .O(\rgb_out[23]_i_1676_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_1677 
       (.I0(pixel_x[0]),
        .I1(\LAST_U/local_x [1]),
        .O(\rgb_out[23]_i_1677_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1678 
       (.I0(\LAST_U/local_y [3]),
        .I1(\LAST_U/local_y [2]),
        .O(\rgb_out[23]_i_1678_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_1679 
       (.I0(\LAST_U/local_y [1]),
        .O(\rgb_out[23]_i_1679_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1680 
       (.I0(\LAST_U/local_y [7]),
        .I1(\LAST_U/local_y [6]),
        .O(\rgb_out[23]_i_1680_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1681 
       (.I0(\LAST_U/local_y [5]),
        .I1(\LAST_U/local_y [4]),
        .O(\rgb_out[23]_i_1681_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1682 
       (.I0(\LAST_U/local_y [2]),
        .I1(\LAST_U/local_y [3]),
        .O(\rgb_out[23]_i_1682_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_1683 
       (.I0(pixel_y[0]),
        .I1(\LAST_U/local_y [1]),
        .O(\rgb_out[23]_i_1683_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_1684 
       (.I0(\LAST_U/local_y [5]),
        .O(\rgb_out[23]_i_1684_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1685 
       (.I0(pixel_y[0]),
        .I1(\LAST_U/local_y [1]),
        .O(\rgb_out[23]_i_1685_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1686 
       (.I0(\LAST_U/local_y [7]),
        .I1(\LAST_U/local_y [6]),
        .O(\rgb_out[23]_i_1686_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1687 
       (.I0(\LAST_U/local_y [5]),
        .I1(\LAST_U/local_y [4]),
        .O(\rgb_out[23]_i_1687_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1688 
       (.I0(\LAST_U/local_y [3]),
        .I1(\LAST_U/local_y [2]),
        .O(\rgb_out[23]_i_1688_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1689 
       (.I0(\LAST_U/local_y [1]),
        .I1(pixel_y[0]),
        .O(\rgb_out[23]_i_1689_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1690 
       (.I0(\LAST_U/local_y [6]),
        .I1(\LAST_U/local_y [7]),
        .O(\rgb_out[23]_i_1690_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_1691 
       (.I0(\LAST_U/local_y [2]),
        .I1(\LAST_U/local_y [3]),
        .O(\rgb_out[23]_i_1691_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1692 
       (.I0(\LAST_U/local_y [7]),
        .I1(\LAST_U/local_y [6]),
        .O(\rgb_out[23]_i_1692_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1693 
       (.I0(\LAST_U/local_y [4]),
        .I1(\LAST_U/local_y [5]),
        .O(\rgb_out[23]_i_1693_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1694 
       (.I0(\LAST_U/local_y [3]),
        .I1(\LAST_U/local_y [2]),
        .O(\rgb_out[23]_i_1694_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1695 
       (.I0(\LAST_U/local_y [1]),
        .I1(pixel_y[0]),
        .O(\rgb_out[23]_i_1695_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1696 
       (.I0(\LAST_U/local_y [6]),
        .I1(\LAST_U/local_y [7]),
        .O(\rgb_out[23]_i_1696_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1697 
       (.I0(\LAST_U/local_y [1]),
        .I1(pixel_y[0]),
        .O(\rgb_out[23]_i_1697_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1698 
       (.I0(\LAST_U/local_y [7]),
        .I1(\LAST_U/local_y [6]),
        .O(\rgb_out[23]_i_1698_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_1699 
       (.I0(\LAST_U/local_y [4]),
        .I1(\LAST_U/local_y [5]),
        .O(\rgb_out[23]_i_1699_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1700 
       (.I0(\LAST_U/local_y [2]),
        .I1(\LAST_U/local_y [3]),
        .O(\rgb_out[23]_i_1700_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_1701 
       (.I0(pixel_y[0]),
        .I1(\LAST_U/local_y [1]),
        .O(\rgb_out[23]_i_1701_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_1702 
       (.I0(\REC_U/local_x [5]),
        .O(\rgb_out[23]_i_1702_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1703 
       (.I0(\REC_U/local_x [3]),
        .I1(\REC_U/local_x [2]),
        .O(\rgb_out[23]_i_1703_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1704 
       (.I0(\REC_U/local_x [9]),
        .I1(\REC_U/local_x [8]),
        .O(\rgb_out[23]_i_1704_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1705 
       (.I0(\REC_U/local_x [7]),
        .I1(\REC_U/local_x [6]),
        .O(\rgb_out[23]_i_1705_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1706 
       (.I0(\REC_U/local_x [5]),
        .I1(\REC_U/local_x [4]),
        .O(\rgb_out[23]_i_1706_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1707 
       (.I0(\REC_U/local_x [2]),
        .I1(\REC_U/local_x [3]),
        .O(\rgb_out[23]_i_1707_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_1709 
       (.I0(pixel_x[11]),
        .O(\rgb_out[23]_i_1709_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_1710 
       (.I0(pixel_x[9]),
        .O(\rgb_out[23]_i_1710_n_0 ));
  LUT2 #(
    .INIT(4'h7)) 
    \rgb_out[23]_i_1711 
       (.I0(\REC_U/local_y [3]),
        .I1(\REC_U/local_y [2]),
        .O(\rgb_out[23]_i_1711_n_0 ));
  LUT2 #(
    .INIT(4'h7)) 
    \rgb_out[23]_i_1712 
       (.I0(\REC_U/local_y [5]),
        .I1(\REC_U/local_y [4]),
        .O(\rgb_out[23]_i_1712_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1713 
       (.I0(\REC_U/local_y [11]),
        .I1(\REC_U/local_y [10]),
        .O(\rgb_out[23]_i_1713_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1714 
       (.I0(\REC_U/local_y [9]),
        .I1(\REC_U/local_y [8]),
        .O(\rgb_out[23]_i_1714_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1715 
       (.I0(\REC_U/local_y [7]),
        .I1(\REC_U/local_y [6]),
        .O(\rgb_out[23]_i_1715_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_1716 
       (.I0(\REC_U/local_y [4]),
        .I1(\REC_U/local_y [5]),
        .O(\rgb_out[23]_i_1716_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_1718 
       (.I0(pixel_y[11]),
        .O(\rgb_out[23]_i_1718_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_1719 
       (.I0(pixel_y[10]),
        .O(\rgb_out[23]_i_1719_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_1720 
       (.I0(pixel_y[9]),
        .O(\rgb_out[23]_i_1720_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1721 
       (.I0(\REC_U/local_x [6]),
        .I1(\REC_U/local_x [7]),
        .O(\rgb_out[23]_i_1721_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1722 
       (.I0(\REC_U/local_x [5]),
        .I1(\REC_U/local_x [4]),
        .O(\rgb_out[23]_i_1722_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1723 
       (.I0(\REC_U/local_x [2]),
        .I1(\REC_U/local_x [3]),
        .O(\rgb_out[23]_i_1723_n_0 ));
  LUT2 #(
    .INIT(4'hB)) 
    \rgb_out[23]_i_1724 
       (.I0(\REC_U/local_x [1]),
        .I1(pixel_x[0]),
        .O(\rgb_out[23]_i_1724_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1725 
       (.I0(\REC_U/local_x [7]),
        .I1(\REC_U/local_x [6]),
        .O(\rgb_out[23]_i_1725_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1726 
       (.I0(\REC_U/local_x [4]),
        .I1(\REC_U/local_x [5]),
        .O(\rgb_out[23]_i_1726_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1727 
       (.I0(\REC_U/local_x [3]),
        .I1(\REC_U/local_x [2]),
        .O(\rgb_out[23]_i_1727_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1728 
       (.I0(pixel_x[0]),
        .I1(\REC_U/local_x [1]),
        .O(\rgb_out[23]_i_1728_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1729 
       (.I0(\REC_U/local_y [6]),
        .I1(\REC_U/local_y [7]),
        .O(\rgb_out[23]_i_1729_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1730 
       (.I0(\REC_U/local_y [4]),
        .I1(\REC_U/local_y [5]),
        .O(\rgb_out[23]_i_1730_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1731 
       (.I0(\REC_U/local_y [2]),
        .I1(\REC_U/local_y [3]),
        .O(\rgb_out[23]_i_1731_n_0 ));
  LUT2 #(
    .INIT(4'hB)) 
    \rgb_out[23]_i_1732 
       (.I0(\REC_U/local_y [1]),
        .I1(pixel_y[0]),
        .O(\rgb_out[23]_i_1732_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1733 
       (.I0(\REC_U/local_y [7]),
        .I1(\REC_U/local_y [6]),
        .O(\rgb_out[23]_i_1733_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1734 
       (.I0(\REC_U/local_y [5]),
        .I1(\REC_U/local_y [4]),
        .O(\rgb_out[23]_i_1734_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1735 
       (.I0(\REC_U/local_y [3]),
        .I1(\REC_U/local_y [2]),
        .O(\rgb_out[23]_i_1735_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1736 
       (.I0(pixel_y[0]),
        .I1(\REC_U/local_y [1]),
        .O(\rgb_out[23]_i_1736_n_0 ));
  LUT2 #(
    .INIT(4'h7)) 
    \rgb_out[23]_i_1737 
       (.I0(\REC_U/local_y [5]),
        .I1(\REC_U/local_y [4]),
        .O(\rgb_out[23]_i_1737_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1738 
       (.I0(\REC_U/local_y [3]),
        .I1(\REC_U/local_y [2]),
        .O(\rgb_out[23]_i_1738_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_1739 
       (.I0(\REC_U/local_y [1]),
        .O(\rgb_out[23]_i_1739_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1740 
       (.I0(\REC_U/local_y [7]),
        .I1(\REC_U/local_y [6]),
        .O(\rgb_out[23]_i_1740_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_1741 
       (.I0(\REC_U/local_y [4]),
        .I1(\REC_U/local_y [5]),
        .O(\rgb_out[23]_i_1741_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1742 
       (.I0(\REC_U/local_y [2]),
        .I1(\REC_U/local_y [3]),
        .O(\rgb_out[23]_i_1742_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_1743 
       (.I0(pixel_y[0]),
        .I1(\REC_U/local_y [1]),
        .O(\rgb_out[23]_i_1743_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1744 
       (.I0(\REC_U/local_y [6]),
        .I1(\REC_U/local_y [7]),
        .O(\rgb_out[23]_i_1744_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1745 
       (.I0(\REC_U/local_y [1]),
        .I1(pixel_y[0]),
        .O(\rgb_out[23]_i_1745_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1746 
       (.I0(\REC_U/local_y [7]),
        .I1(\REC_U/local_y [6]),
        .O(\rgb_out[23]_i_1746_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1747 
       (.I0(\REC_U/local_y [4]),
        .I1(\REC_U/local_y [5]),
        .O(\rgb_out[23]_i_1747_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_1748 
       (.I0(\REC_U/local_y [2]),
        .I1(\REC_U/local_y [3]),
        .O(\rgb_out[23]_i_1748_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_1749 
       (.I0(pixel_y[0]),
        .I1(\REC_U/local_y [1]),
        .O(\rgb_out[23]_i_1749_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1750 
       (.I0(\REC_U/local_x [3]),
        .I1(\REC_U/local_x [2]),
        .O(\rgb_out[23]_i_1750_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_1751 
       (.I0(\REC_U/local_x [1]),
        .O(\rgb_out[23]_i_1751_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1752 
       (.I0(\REC_U/local_x [7]),
        .I1(\REC_U/local_x [6]),
        .O(\rgb_out[23]_i_1752_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1753 
       (.I0(\REC_U/local_x [4]),
        .I1(\REC_U/local_x [5]),
        .O(\rgb_out[23]_i_1753_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1754 
       (.I0(\REC_U/local_x [2]),
        .I1(\REC_U/local_x [3]),
        .O(\rgb_out[23]_i_1754_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_1755 
       (.I0(pixel_x[0]),
        .I1(\REC_U/local_x [1]),
        .O(\rgb_out[23]_i_1755_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1756 
       (.I0(\REC_U/local_x [6]),
        .I1(\REC_U/local_x [7]),
        .O(\rgb_out[23]_i_1756_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1757 
       (.I0(\REC_U/local_x [1]),
        .I1(pixel_x[0]),
        .O(\rgb_out[23]_i_1757_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1758 
       (.I0(\REC_U/local_x [7]),
        .I1(\REC_U/local_x [6]),
        .O(\rgb_out[23]_i_1758_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1759 
       (.I0(\REC_U/local_x [4]),
        .I1(\REC_U/local_x [5]),
        .O(\rgb_out[23]_i_1759_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_1760 
       (.I0(\REC_U/local_x [2]),
        .I1(\REC_U/local_x [3]),
        .O(\rgb_out[23]_i_1760_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_1761 
       (.I0(pixel_x[0]),
        .I1(\REC_U/local_x [1]),
        .O(\rgb_out[23]_i_1761_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1762 
       (.I0(\REC_U/local_y [5]),
        .I1(\REC_U/local_y [4]),
        .O(\rgb_out[23]_i_1762_n_0 ));
  LUT2 #(
    .INIT(4'h7)) 
    \rgb_out[23]_i_1763 
       (.I0(\REC_U/local_y [3]),
        .I1(\REC_U/local_y [2]),
        .O(\rgb_out[23]_i_1763_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_1764 
       (.I0(\REC_U/local_y [1]),
        .O(\rgb_out[23]_i_1764_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1765 
       (.I0(\REC_U/local_y [7]),
        .I1(\REC_U/local_y [6]),
        .O(\rgb_out[23]_i_1765_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1766 
       (.I0(\REC_U/local_y [4]),
        .I1(\REC_U/local_y [5]),
        .O(\rgb_out[23]_i_1766_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_1767 
       (.I0(\REC_U/local_y [2]),
        .I1(\REC_U/local_y [3]),
        .O(\rgb_out[23]_i_1767_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_1768 
       (.I0(pixel_y[0]),
        .I1(\REC_U/local_y [1]),
        .O(\rgb_out[23]_i_1768_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1769 
       (.I0(\REC_U/local_y [6]),
        .I1(\REC_U/local_y [7]),
        .O(\rgb_out[23]_i_1769_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1770 
       (.I0(\REC_U/local_y [4]),
        .I1(\REC_U/local_y [5]),
        .O(\rgb_out[23]_i_1770_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1772 
       (.I0(\REC_U/local_y [1]),
        .I1(pixel_y[0]),
        .O(\rgb_out[23]_i_1772_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1773 
       (.I0(\REC_U/local_y [7]),
        .I1(\REC_U/local_y [6]),
        .O(\rgb_out[23]_i_1773_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1774 
       (.I0(\REC_U/local_y [5]),
        .I1(\REC_U/local_y [4]),
        .O(\rgb_out[23]_i_1774_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1775 
       (.I0(\REC_U/local_y [2]),
        .I1(\REC_U/local_y [3]),
        .O(\rgb_out[23]_i_1775_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_1776 
       (.I0(pixel_y[0]),
        .I1(\REC_U/local_y [1]),
        .O(\rgb_out[23]_i_1776_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1777 
       (.I0(\REC_U/local_x [6]),
        .I1(\REC_U/local_x [7]),
        .O(\rgb_out[23]_i_1777_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1778 
       (.I0(\REC_U/local_x [5]),
        .I1(\REC_U/local_x [4]),
        .O(\rgb_out[23]_i_1778_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1780 
       (.I0(\REC_U/local_x [1]),
        .I1(pixel_x[0]),
        .O(\rgb_out[23]_i_1780_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1781 
       (.I0(\REC_U/local_x [7]),
        .I1(\REC_U/local_x [6]),
        .O(\rgb_out[23]_i_1781_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1782 
       (.I0(\REC_U/local_x [4]),
        .I1(\REC_U/local_x [5]),
        .O(\rgb_out[23]_i_1782_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1783 
       (.I0(\REC_U/local_x [2]),
        .I1(\REC_U/local_x [3]),
        .O(\rgb_out[23]_i_1783_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_1784 
       (.I0(pixel_x[0]),
        .I1(\REC_U/local_x [1]),
        .O(\rgb_out[23]_i_1784_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1785 
       (.I0(\REC_U/local_x [4]),
        .I1(\REC_U/local_x [5]),
        .O(\rgb_out[23]_i_1785_n_0 ));
  LUT2 #(
    .INIT(4'h7)) 
    \rgb_out[23]_i_1786 
       (.I0(\REC_U/local_x [3]),
        .I1(\REC_U/local_x [2]),
        .O(\rgb_out[23]_i_1786_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_1787 
       (.I0(\REC_U/local_x [1]),
        .O(\rgb_out[23]_i_1787_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1788 
       (.I0(\REC_U/local_x [7]),
        .I1(\REC_U/local_x [6]),
        .O(\rgb_out[23]_i_1788_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1789 
       (.I0(\REC_U/local_x [4]),
        .I1(\REC_U/local_x [5]),
        .O(\rgb_out[23]_i_1789_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_1790 
       (.I0(\REC_U/local_x [2]),
        .I1(\REC_U/local_x [3]),
        .O(\rgb_out[23]_i_1790_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_1791 
       (.I0(pixel_x[0]),
        .I1(\REC_U/local_x [1]),
        .O(\rgb_out[23]_i_1791_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1792 
       (.I0(\REC_U/local_y [3]),
        .I1(\REC_U/local_y [2]),
        .O(\rgb_out[23]_i_1792_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_1793 
       (.I0(\REC_U/local_y [1]),
        .O(\rgb_out[23]_i_1793_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1794 
       (.I0(\REC_U/local_y [7]),
        .I1(\REC_U/local_y [6]),
        .O(\rgb_out[23]_i_1794_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1795 
       (.I0(\REC_U/local_y [5]),
        .I1(\REC_U/local_y [4]),
        .O(\rgb_out[23]_i_1795_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1796 
       (.I0(\REC_U/local_y [2]),
        .I1(\REC_U/local_y [3]),
        .O(\rgb_out[23]_i_1796_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_1797 
       (.I0(pixel_y[0]),
        .I1(\REC_U/local_y [1]),
        .O(\rgb_out[23]_i_1797_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_1798 
       (.I0(\REC_U/local_y [5]),
        .O(\rgb_out[23]_i_1798_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1799 
       (.I0(pixel_y[0]),
        .I1(\REC_U/local_y [1]),
        .O(\rgb_out[23]_i_1799_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1800 
       (.I0(\REC_U/local_y [7]),
        .I1(\REC_U/local_y [6]),
        .O(\rgb_out[23]_i_1800_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1801 
       (.I0(\REC_U/local_y [5]),
        .I1(\REC_U/local_y [4]),
        .O(\rgb_out[23]_i_1801_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1802 
       (.I0(\REC_U/local_y [3]),
        .I1(\REC_U/local_y [2]),
        .O(\rgb_out[23]_i_1802_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1803 
       (.I0(\REC_U/local_y [1]),
        .I1(pixel_y[0]),
        .O(\rgb_out[23]_i_1803_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1804 
       (.I0(\REC_U/local_y [6]),
        .I1(\REC_U/local_y [7]),
        .O(\rgb_out[23]_i_1804_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_1805 
       (.I0(\REC_U/local_y [2]),
        .I1(\REC_U/local_y [3]),
        .O(\rgb_out[23]_i_1805_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1806 
       (.I0(\REC_U/local_y [7]),
        .I1(\REC_U/local_y [6]),
        .O(\rgb_out[23]_i_1806_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1807 
       (.I0(\REC_U/local_y [4]),
        .I1(\REC_U/local_y [5]),
        .O(\rgb_out[23]_i_1807_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1808 
       (.I0(\REC_U/local_y [3]),
        .I1(\REC_U/local_y [2]),
        .O(\rgb_out[23]_i_1808_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1809 
       (.I0(\REC_U/local_y [1]),
        .I1(pixel_y[0]),
        .O(\rgb_out[23]_i_1809_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1810 
       (.I0(\REC_U/local_y [6]),
        .I1(\REC_U/local_y [7]),
        .O(\rgb_out[23]_i_1810_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1811 
       (.I0(\REC_U/local_y [1]),
        .I1(pixel_y[0]),
        .O(\rgb_out[23]_i_1811_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1812 
       (.I0(\REC_U/local_y [7]),
        .I1(\REC_U/local_y [6]),
        .O(\rgb_out[23]_i_1812_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_1813 
       (.I0(\REC_U/local_y [4]),
        .I1(\REC_U/local_y [5]),
        .O(\rgb_out[23]_i_1813_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1814 
       (.I0(\REC_U/local_y [2]),
        .I1(\REC_U/local_y [3]),
        .O(\rgb_out[23]_i_1814_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_1815 
       (.I0(pixel_y[0]),
        .I1(\REC_U/local_y [1]),
        .O(\rgb_out[23]_i_1815_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1816 
       (.I0(\LAST_D/local_y [3]),
        .I1(\LAST_D/local_y [2]),
        .O(\rgb_out[23]_i_1816_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_1817 
       (.I0(\LAST_D/local_y [1]),
        .O(\rgb_out[23]_i_1817_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1818 
       (.I0(\LAST_D/local_y [7]),
        .I1(\LAST_D/local_y [6]),
        .O(\rgb_out[23]_i_1818_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1819 
       (.I0(\LAST_D/local_y [5]),
        .I1(\LAST_D/local_y [4]),
        .O(\rgb_out[23]_i_1819_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1820 
       (.I0(\LAST_D/local_y [2]),
        .I1(\LAST_D/local_y [3]),
        .O(\rgb_out[23]_i_1820_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_1821 
       (.I0(pixel_y[0]),
        .I1(\LAST_D/local_y [1]),
        .O(\rgb_out[23]_i_1821_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_1823 
       (.I0(pixel_y[11]),
        .O(\rgb_out[23]_i_1823_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_1824 
       (.I0(pixel_y[10]),
        .O(\rgb_out[23]_i_1824_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_1825 
       (.I0(pixel_y[9]),
        .O(\rgb_out[23]_i_1825_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1826 
       (.I0(\LAST_D/local_y [6]),
        .I1(\LAST_D/local_y [7]),
        .O(\rgb_out[23]_i_1826_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1828 
       (.I0(\LAST_D/local_y [1]),
        .I1(pixel_y[0]),
        .O(\rgb_out[23]_i_1828_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1829 
       (.I0(\LAST_D/local_y [7]),
        .I1(\LAST_D/local_y [6]),
        .O(\rgb_out[23]_i_1829_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_1830 
       (.I0(\LAST_D/local_y [5]),
        .I1(\LAST_D/local_y [4]),
        .O(\rgb_out[23]_i_1830_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1831 
       (.I0(\LAST_D/local_y [2]),
        .I1(\LAST_D/local_y [3]),
        .O(\rgb_out[23]_i_1831_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_1832 
       (.I0(pixel_y[0]),
        .I1(\LAST_D/local_y [1]),
        .O(\rgb_out[23]_i_1832_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1833 
       (.I0(\LAST_D/local_x [6]),
        .I1(\LAST_D/local_x [7]),
        .O(\rgb_out[23]_i_1833_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1834 
       (.I0(\LAST_D/local_x [4]),
        .I1(\LAST_D/local_x [5]),
        .O(\rgb_out[23]_i_1834_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1836 
       (.I0(\LAST_D/local_x [1]),
        .I1(pixel_x[0]),
        .O(\rgb_out[23]_i_1836_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1837 
       (.I0(\LAST_D/local_x [7]),
        .I1(\LAST_D/local_x [6]),
        .O(\rgb_out[23]_i_1837_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1838 
       (.I0(\LAST_D/local_x [5]),
        .I1(\LAST_D/local_x [4]),
        .O(\rgb_out[23]_i_1838_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1839 
       (.I0(\LAST_D/local_x [2]),
        .I1(\LAST_D/local_x [3]),
        .O(\rgb_out[23]_i_1839_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_1840 
       (.I0(pixel_x[0]),
        .I1(\LAST_D/local_x [1]),
        .O(\rgb_out[23]_i_1840_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1841 
       (.I0(\LAST_D/local_x [5]),
        .I1(\LAST_D/local_x [4]),
        .O(\rgb_out[23]_i_1841_n_0 ));
  LUT2 #(
    .INIT(4'h7)) 
    \rgb_out[23]_i_1842 
       (.I0(\LAST_D/local_x [2]),
        .I1(\LAST_D/local_x [3]),
        .O(\rgb_out[23]_i_1842_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_1843 
       (.I0(\LAST_D/local_x [1]),
        .O(\rgb_out[23]_i_1843_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1844 
       (.I0(\LAST_D/local_x [7]),
        .I1(\LAST_D/local_x [6]),
        .O(\rgb_out[23]_i_1844_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1845 
       (.I0(\LAST_D/local_x [4]),
        .I1(\LAST_D/local_x [5]),
        .O(\rgb_out[23]_i_1845_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_1846 
       (.I0(\LAST_D/local_x [3]),
        .I1(\LAST_D/local_x [2]),
        .O(\rgb_out[23]_i_1846_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_1847 
       (.I0(pixel_x[0]),
        .I1(\LAST_D/local_x [1]),
        .O(\rgb_out[23]_i_1847_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1848 
       (.I0(\LAST_D/local_y [6]),
        .I1(\LAST_D/local_y [7]),
        .O(\rgb_out[23]_i_1848_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1849 
       (.I0(\LAST_D/local_y [4]),
        .I1(\LAST_D/local_y [5]),
        .O(\rgb_out[23]_i_1849_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1850 
       (.I0(\LAST_D/local_y [1]),
        .I1(pixel_y[0]),
        .O(\rgb_out[23]_i_1850_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1851 
       (.I0(\LAST_D/local_y [7]),
        .I1(\LAST_D/local_y [6]),
        .O(\rgb_out[23]_i_1851_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1852 
       (.I0(\LAST_D/local_y [5]),
        .I1(\LAST_D/local_y [4]),
        .O(\rgb_out[23]_i_1852_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1853 
       (.I0(\LAST_D/local_y [2]),
        .I1(\LAST_D/local_y [3]),
        .O(\rgb_out[23]_i_1853_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_1854 
       (.I0(pixel_y[0]),
        .I1(\LAST_D/local_y [1]),
        .O(\rgb_out[23]_i_1854_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1855 
       (.I0(\LAST_D/local_y [5]),
        .I1(\LAST_D/local_y [4]),
        .O(\rgb_out[23]_i_1855_n_0 ));
  LUT2 #(
    .INIT(4'h7)) 
    \rgb_out[23]_i_1856 
       (.I0(\LAST_D/local_y [2]),
        .I1(\LAST_D/local_y [3]),
        .O(\rgb_out[23]_i_1856_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_1857 
       (.I0(\LAST_D/local_y [1]),
        .O(\rgb_out[23]_i_1857_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1858 
       (.I0(\LAST_D/local_y [7]),
        .I1(\LAST_D/local_y [6]),
        .O(\rgb_out[23]_i_1858_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1859 
       (.I0(\LAST_D/local_y [4]),
        .I1(\LAST_D/local_y [5]),
        .O(\rgb_out[23]_i_1859_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_1860 
       (.I0(\LAST_D/local_y [3]),
        .I1(\LAST_D/local_y [2]),
        .O(\rgb_out[23]_i_1860_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_1861 
       (.I0(pixel_y[0]),
        .I1(\LAST_D/local_y [1]),
        .O(\rgb_out[23]_i_1861_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1862 
       (.I0(\LAST_D/local_y [6]),
        .I1(\LAST_D/local_y [7]),
        .O(\rgb_out[23]_i_1862_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1863 
       (.I0(\LAST_D/local_y [1]),
        .I1(pixel_y[0]),
        .O(\rgb_out[23]_i_1863_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1864 
       (.I0(\LAST_D/local_y [7]),
        .I1(\LAST_D/local_y [6]),
        .O(\rgb_out[23]_i_1864_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1865 
       (.I0(\LAST_D/local_y [4]),
        .I1(\LAST_D/local_y [5]),
        .O(\rgb_out[23]_i_1865_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_1866 
       (.I0(\LAST_D/local_y [3]),
        .I1(\LAST_D/local_y [2]),
        .O(\rgb_out[23]_i_1866_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_1867 
       (.I0(pixel_y[0]),
        .I1(\LAST_D/local_y [1]),
        .O(\rgb_out[23]_i_1867_n_0 ));
  LUT2 #(
    .INIT(4'h7)) 
    \rgb_out[23]_i_1868 
       (.I0(\LAST_D/local_y [4]),
        .I1(\LAST_D/local_y [5]),
        .O(\rgb_out[23]_i_1868_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1869 
       (.I0(\LAST_D/local_y [3]),
        .I1(\LAST_D/local_y [2]),
        .O(\rgb_out[23]_i_1869_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_1870 
       (.I0(\LAST_D/local_y [1]),
        .O(\rgb_out[23]_i_1870_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1871 
       (.I0(\LAST_D/local_y [7]),
        .I1(\LAST_D/local_y [6]),
        .O(\rgb_out[23]_i_1871_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_1872 
       (.I0(\LAST_D/local_y [5]),
        .I1(\LAST_D/local_y [4]),
        .O(\rgb_out[23]_i_1872_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1873 
       (.I0(\LAST_D/local_y [2]),
        .I1(\LAST_D/local_y [3]),
        .O(\rgb_out[23]_i_1873_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_1874 
       (.I0(pixel_y[0]),
        .I1(\LAST_D/local_y [1]),
        .O(\rgb_out[23]_i_1874_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_1875 
       (.I0(pixel_x[7]),
        .O(\rgb_out[23]_i_1875_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1876 
       (.I0(\LAST_D/local_y [6]),
        .I1(\LAST_D/local_y [7]),
        .O(\rgb_out[23]_i_1876_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1877 
       (.I0(\LAST_D/local_y [4]),
        .I1(\LAST_D/local_y [5]),
        .O(\rgb_out[23]_i_1877_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1878 
       (.I0(\LAST_D/local_y [2]),
        .I1(\LAST_D/local_y [3]),
        .O(\rgb_out[23]_i_1878_n_0 ));
  LUT2 #(
    .INIT(4'hB)) 
    \rgb_out[23]_i_1879 
       (.I0(\LAST_D/local_y [1]),
        .I1(pixel_y[0]),
        .O(\rgb_out[23]_i_1879_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1880 
       (.I0(\LAST_D/local_y [7]),
        .I1(\LAST_D/local_y [6]),
        .O(\rgb_out[23]_i_1880_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1881 
       (.I0(\LAST_D/local_y [5]),
        .I1(\LAST_D/local_y [4]),
        .O(\rgb_out[23]_i_1881_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1882 
       (.I0(\LAST_D/local_y [3]),
        .I1(\LAST_D/local_y [2]),
        .O(\rgb_out[23]_i_1882_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1883 
       (.I0(pixel_y[0]),
        .I1(\LAST_D/local_y [1]),
        .O(\rgb_out[23]_i_1883_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1884 
       (.I0(\LAST_D/local_x [6]),
        .I1(\LAST_D/local_x [7]),
        .O(\rgb_out[23]_i_1884_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1885 
       (.I0(\LAST_D/local_x [4]),
        .I1(\LAST_D/local_x [5]),
        .O(\rgb_out[23]_i_1885_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1886 
       (.I0(\LAST_D/local_x [2]),
        .I1(\LAST_D/local_x [3]),
        .O(\rgb_out[23]_i_1886_n_0 ));
  LUT2 #(
    .INIT(4'hB)) 
    \rgb_out[23]_i_1887 
       (.I0(\LAST_D/local_x [1]),
        .I1(pixel_x[0]),
        .O(\rgb_out[23]_i_1887_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1888 
       (.I0(\LAST_D/local_x [7]),
        .I1(\LAST_D/local_x [6]),
        .O(\rgb_out[23]_i_1888_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1889 
       (.I0(\LAST_D/local_x [5]),
        .I1(\LAST_D/local_x [4]),
        .O(\rgb_out[23]_i_1889_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1890 
       (.I0(\LAST_D/local_x [3]),
        .I1(\LAST_D/local_x [2]),
        .O(\rgb_out[23]_i_1890_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1891 
       (.I0(pixel_x[0]),
        .I1(\LAST_D/local_x [1]),
        .O(\rgb_out[23]_i_1891_n_0 ));
  LUT2 #(
    .INIT(4'h7)) 
    \rgb_out[23]_i_1892 
       (.I0(\LAST_D/local_y [4]),
        .I1(\LAST_D/local_y [5]),
        .O(\rgb_out[23]_i_1892_n_0 ));
  LUT2 #(
    .INIT(4'h7)) 
    \rgb_out[23]_i_1893 
       (.I0(\LAST_D/local_y [2]),
        .I1(\LAST_D/local_y [3]),
        .O(\rgb_out[23]_i_1893_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1894 
       (.I0(\LAST_D/local_y [9]),
        .I1(\LAST_D/local_y [8]),
        .O(\rgb_out[23]_i_1894_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1895 
       (.I0(\LAST_D/local_y [7]),
        .I1(\LAST_D/local_y [6]),
        .O(\rgb_out[23]_i_1895_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_1896 
       (.I0(\LAST_D/local_y [5]),
        .I1(\LAST_D/local_y [4]),
        .O(\rgb_out[23]_i_1896_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_1897 
       (.I0(\LAST_D/local_y [3]),
        .I1(\LAST_D/local_y [2]),
        .O(\rgb_out[23]_i_1897_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_1898 
       (.I0(\LAST_D/local_x [5]),
        .O(\rgb_out[23]_i_1898_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1899 
       (.I0(\LAST_D/local_x [3]),
        .I1(\LAST_D/local_x [2]),
        .O(\rgb_out[23]_i_1899_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1900 
       (.I0(\LAST_D/local_x [9]),
        .I1(\LAST_D/local_x [8]),
        .O(\rgb_out[23]_i_1900_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1901 
       (.I0(\LAST_D/local_x [7]),
        .I1(\LAST_D/local_x [6]),
        .O(\rgb_out[23]_i_1901_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1902 
       (.I0(\LAST_D/local_x [5]),
        .I1(\LAST_D/local_x [4]),
        .O(\rgb_out[23]_i_1902_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1903 
       (.I0(\LAST_D/local_x [2]),
        .I1(\LAST_D/local_x [3]),
        .O(\rgb_out[23]_i_1903_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_1906 
       (.I0(pixel_x[11]),
        .O(\rgb_out[23]_i_1906_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_1907 
       (.I0(pixel_x[10]),
        .O(\rgb_out[23]_i_1907_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_1908 
       (.I0(pixel_x[9]),
        .O(\rgb_out[23]_i_1908_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_1909 
       (.I0(pixel_x[8]),
        .O(\rgb_out[23]_i_1909_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_1911 
       (.I0(pixel_y[8]),
        .O(\rgb_out[23]_i_1911_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_1912 
       (.I0(pixel_y[7]),
        .O(\rgb_out[23]_i_1912_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_1913 
       (.I0(pixel_y[6]),
        .O(\rgb_out[23]_i_1913_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_1914 
       (.I0(pixel_y[5]),
        .O(\rgb_out[23]_i_1914_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1915 
       (.I0(\SC_U/local_y [6]),
        .I1(\SC_U/local_y [7]),
        .O(\rgb_out[23]_i_1915_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_1916 
       (.I0(pixel_y[0]),
        .I1(\SC_U/local_y [1]),
        .O(\rgb_out[23]_i_1916_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1917 
       (.I0(\SC_U/local_y [7]),
        .I1(\SC_U/local_y [6]),
        .O(\rgb_out[23]_i_1917_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_1918 
       (.I0(\SC_U/local_y [4]),
        .I1(\SC_U/local_y [5]),
        .O(\rgb_out[23]_i_1918_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1919 
       (.I0(\SC_U/local_y [2]),
        .I1(\SC_U/local_y [3]),
        .O(\rgb_out[23]_i_1919_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1920 
       (.I0(\SC_U/local_y [1]),
        .I1(pixel_y[0]),
        .O(\rgb_out[23]_i_1920_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1921 
       (.I0(\SC_U/local_x [4]),
        .I1(\SC_U/local_x [5]),
        .O(\rgb_out[23]_i_1921_n_0 ));
  LUT2 #(
    .INIT(4'h7)) 
    \rgb_out[23]_i_1922 
       (.I0(\SC_U/local_x [3]),
        .I1(\SC_U/local_x [2]),
        .O(\rgb_out[23]_i_1922_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_1923 
       (.I0(\SC_U/local_x [1]),
        .O(\rgb_out[23]_i_1923_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1924 
       (.I0(\SC_U/local_x [7]),
        .I1(\SC_U/local_x [6]),
        .O(\rgb_out[23]_i_1924_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1925 
       (.I0(\SC_U/local_x [4]),
        .I1(\SC_U/local_x [5]),
        .O(\rgb_out[23]_i_1925_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_1926 
       (.I0(\SC_U/local_x [2]),
        .I1(\SC_U/local_x [3]),
        .O(\rgb_out[23]_i_1926_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1927 
       (.I0(\SC_U/local_x [1]),
        .I1(\SC_U/local_x [0]),
        .O(\rgb_out[23]_i_1927_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_1935 
       (.I0(\SC_U/local_y [5]),
        .O(\rgb_out[23]_i_1935_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1936 
       (.I0(\SC_U/local_y [1]),
        .I1(pixel_y[0]),
        .O(\rgb_out[23]_i_1936_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1937 
       (.I0(\SC_U/local_y [7]),
        .I1(\SC_U/local_y [6]),
        .O(\rgb_out[23]_i_1937_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1938 
       (.I0(\SC_U/local_y [5]),
        .I1(\SC_U/local_y [4]),
        .O(\rgb_out[23]_i_1938_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1939 
       (.I0(\SC_U/local_y [3]),
        .I1(\SC_U/local_y [2]),
        .O(\rgb_out[23]_i_1939_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1940 
       (.I0(pixel_y[0]),
        .I1(\SC_U/local_y [1]),
        .O(\rgb_out[23]_i_1940_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1941 
       (.I0(\SC_U/local_y [6]),
        .I1(\SC_U/local_y [7]),
        .O(\rgb_out[23]_i_1941_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_1942 
       (.I0(\SC_U/local_y [2]),
        .I1(\SC_U/local_y [3]),
        .O(\rgb_out[23]_i_1942_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1943 
       (.I0(\SC_U/local_y [7]),
        .I1(\SC_U/local_y [6]),
        .O(\rgb_out[23]_i_1943_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1944 
       (.I0(\SC_U/local_y [4]),
        .I1(\SC_U/local_y [5]),
        .O(\rgb_out[23]_i_1944_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1945 
       (.I0(\SC_U/local_y [3]),
        .I1(\SC_U/local_y [2]),
        .O(\rgb_out[23]_i_1945_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_1946 
       (.I0(pixel_y[0]),
        .I1(\SC_U/local_y [1]),
        .O(\rgb_out[23]_i_1946_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1947 
       (.I0(\SC_U/local_y [3]),
        .I1(\SC_U/local_y [2]),
        .O(\rgb_out[23]_i_1947_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_1948 
       (.I0(\SC_U/local_y [1]),
        .O(\rgb_out[23]_i_1948_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1949 
       (.I0(\SC_U/local_y [7]),
        .I1(\SC_U/local_y [6]),
        .O(\rgb_out[23]_i_1949_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1950 
       (.I0(\SC_U/local_y [5]),
        .I1(\SC_U/local_y [4]),
        .O(\rgb_out[23]_i_1950_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1951 
       (.I0(\SC_U/local_y [2]),
        .I1(\SC_U/local_y [3]),
        .O(\rgb_out[23]_i_1951_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1952 
       (.I0(\SC_U/local_y [1]),
        .I1(pixel_y[0]),
        .O(\rgb_out[23]_i_1952_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1953 
       (.I0(\SC_U/local_y [5]),
        .I1(\SC_U/local_y [4]),
        .O(\rgb_out[23]_i_1953_n_0 ));
  LUT2 #(
    .INIT(4'h7)) 
    \rgb_out[23]_i_1954 
       (.I0(\SC_U/local_y [3]),
        .I1(\SC_U/local_y [2]),
        .O(\rgb_out[23]_i_1954_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_1955 
       (.I0(\SC_U/local_y [1]),
        .O(\rgb_out[23]_i_1955_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1956 
       (.I0(\SC_U/local_y [7]),
        .I1(\SC_U/local_y [6]),
        .O(\rgb_out[23]_i_1956_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1957 
       (.I0(\SC_U/local_y [4]),
        .I1(\SC_U/local_y [5]),
        .O(\rgb_out[23]_i_1957_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_1958 
       (.I0(\SC_U/local_y [2]),
        .I1(\SC_U/local_y [3]),
        .O(\rgb_out[23]_i_1958_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1959 
       (.I0(\SC_U/local_y [1]),
        .I1(pixel_y[0]),
        .O(\rgb_out[23]_i_1959_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1960 
       (.I0(\SC_U/local_y [6]),
        .I1(\SC_U/local_y [7]),
        .O(\rgb_out[23]_i_1960_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1961 
       (.I0(\SC_U/local_y [4]),
        .I1(\SC_U/local_y [5]),
        .O(\rgb_out[23]_i_1961_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_1962 
       (.I0(pixel_y[0]),
        .I1(\SC_U/local_y [1]),
        .O(\rgb_out[23]_i_1962_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1963 
       (.I0(\SC_U/local_y [7]),
        .I1(\SC_U/local_y [6]),
        .O(\rgb_out[23]_i_1963_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1964 
       (.I0(\SC_U/local_y [5]),
        .I1(\SC_U/local_y [4]),
        .O(\rgb_out[23]_i_1964_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1965 
       (.I0(\SC_U/local_y [2]),
        .I1(\SC_U/local_y [3]),
        .O(\rgb_out[23]_i_1965_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1966 
       (.I0(\SC_U/local_y [1]),
        .I1(pixel_y[0]),
        .O(\rgb_out[23]_i_1966_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1967 
       (.I0(\SC_U/local_x [3]),
        .I1(\SC_U/local_x [2]),
        .O(\rgb_out[23]_i_1967_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_1968 
       (.I0(\SC_U/local_x [1]),
        .O(\rgb_out[23]_i_1968_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1969 
       (.I0(\SC_U/local_x [7]),
        .I1(\SC_U/local_x [6]),
        .O(\rgb_out[23]_i_1969_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1970 
       (.I0(\SC_U/local_x [4]),
        .I1(\SC_U/local_x [5]),
        .O(\rgb_out[23]_i_1970_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1971 
       (.I0(\SC_U/local_x [2]),
        .I1(\SC_U/local_x [3]),
        .O(\rgb_out[23]_i_1971_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1972 
       (.I0(\SC_U/local_x [1]),
        .I1(\SC_U/local_x [0]),
        .O(\rgb_out[23]_i_1972_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1973 
       (.I0(\SC_U/local_x [6]),
        .I1(\SC_U/local_x [7]),
        .O(\rgb_out[23]_i_1973_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_1974 
       (.I0(\SC_U/local_x [0]),
        .I1(\SC_U/local_x [1]),
        .O(\rgb_out[23]_i_1974_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1975 
       (.I0(\SC_U/local_x [7]),
        .I1(\SC_U/local_x [6]),
        .O(\rgb_out[23]_i_1975_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1976 
       (.I0(\SC_U/local_x [4]),
        .I1(\SC_U/local_x [5]),
        .O(\rgb_out[23]_i_1976_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_1977 
       (.I0(\SC_U/local_x [2]),
        .I1(\SC_U/local_x [3]),
        .O(\rgb_out[23]_i_1977_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1978 
       (.I0(\SC_U/local_x [1]),
        .I1(\SC_U/local_x [0]),
        .O(\rgb_out[23]_i_1978_n_0 ));
  LUT2 #(
    .INIT(4'h7)) 
    \rgb_out[23]_i_1979 
       (.I0(\SC_U/local_y [5]),
        .I1(\SC_U/local_y [4]),
        .O(\rgb_out[23]_i_1979_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1980 
       (.I0(\SC_U/local_y [3]),
        .I1(\SC_U/local_y [2]),
        .O(\rgb_out[23]_i_1980_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_1981 
       (.I0(\SC_U/local_y [1]),
        .O(\rgb_out[23]_i_1981_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1982 
       (.I0(\SC_U/local_y [7]),
        .I1(\SC_U/local_y [6]),
        .O(\rgb_out[23]_i_1982_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_1983 
       (.I0(\SC_U/local_y [4]),
        .I1(\SC_U/local_y [5]),
        .O(\rgb_out[23]_i_1983_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1984 
       (.I0(\SC_U/local_y [2]),
        .I1(\SC_U/local_y [3]),
        .O(\rgb_out[23]_i_1984_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1985 
       (.I0(\SC_U/local_y [1]),
        .I1(pixel_y[0]),
        .O(\rgb_out[23]_i_1985_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1986 
       (.I0(\SC_U/local_y [6]),
        .I1(\SC_U/local_y [7]),
        .O(\rgb_out[23]_i_1986_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_1987 
       (.I0(pixel_y[0]),
        .I1(\SC_U/local_y [1]),
        .O(\rgb_out[23]_i_1987_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1988 
       (.I0(\SC_U/local_y [7]),
        .I1(\SC_U/local_y [6]),
        .O(\rgb_out[23]_i_1988_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1989 
       (.I0(\SC_U/local_y [4]),
        .I1(\SC_U/local_y [5]),
        .O(\rgb_out[23]_i_1989_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_1990 
       (.I0(\SC_U/local_y [2]),
        .I1(\SC_U/local_y [3]),
        .O(\rgb_out[23]_i_1990_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1991 
       (.I0(\SC_U/local_y [1]),
        .I1(pixel_y[0]),
        .O(\rgb_out[23]_i_1991_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1992 
       (.I0(\SC_D/local_y [3]),
        .I1(\SC_D/local_y [2]),
        .O(\rgb_out[23]_i_1992_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_1993 
       (.I0(\SC_D/local_y [1]),
        .O(\rgb_out[23]_i_1993_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1994 
       (.I0(\SC_D/local_y [7]),
        .I1(\SC_D/local_y [6]),
        .O(\rgb_out[23]_i_1994_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1995 
       (.I0(\SC_D/local_y [5]),
        .I1(\SC_D/local_y [4]),
        .O(\rgb_out[23]_i_1995_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1996 
       (.I0(\SC_D/local_y [2]),
        .I1(\SC_D/local_y [3]),
        .O(\rgb_out[23]_i_1996_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1997 
       (.I0(\SC_D/local_y [1]),
        .I1(pixel_y[0]),
        .O(\rgb_out[23]_i_1997_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_2002 
       (.I0(\SC_D/local_y [6]),
        .I1(\SC_D/local_y [7]),
        .O(\rgb_out[23]_i_2002_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_2004 
       (.I0(pixel_y[0]),
        .I1(\SC_D/local_y [1]),
        .O(\rgb_out[23]_i_2004_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_2005 
       (.I0(\SC_D/local_y [7]),
        .I1(\SC_D/local_y [6]),
        .O(\rgb_out[23]_i_2005_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_2006 
       (.I0(\SC_D/local_y [5]),
        .I1(\SC_D/local_y [4]),
        .O(\rgb_out[23]_i_2006_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_2007 
       (.I0(\SC_D/local_y [2]),
        .I1(\SC_D/local_y [3]),
        .O(\rgb_out[23]_i_2007_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_2008 
       (.I0(\SC_D/local_y [1]),
        .I1(pixel_y[0]),
        .O(\rgb_out[23]_i_2008_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_2017 
       (.I0(\SC_D/local_x [5]),
        .I1(\SC_D/local_x [4]),
        .O(\rgb_out[23]_i_2017_n_0 ));
  LUT2 #(
    .INIT(4'h7)) 
    \rgb_out[23]_i_2018 
       (.I0(\SC_D/local_x [2]),
        .I1(\SC_D/local_x [3]),
        .O(\rgb_out[23]_i_2018_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_2019 
       (.I0(\SC_D/local_x [1]),
        .O(\rgb_out[23]_i_2019_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_2020 
       (.I0(\SC_D/local_x [7]),
        .I1(\SC_D/local_x [6]),
        .O(\rgb_out[23]_i_2020_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_2021 
       (.I0(\SC_D/local_x [4]),
        .I1(\SC_D/local_x [5]),
        .O(\rgb_out[23]_i_2021_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_2022 
       (.I0(\SC_D/local_x [3]),
        .I1(\SC_D/local_x [2]),
        .O(\rgb_out[23]_i_2022_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_2023 
       (.I0(\SC_D/local_x [1]),
        .I1(\SC_D/local_x [0]),
        .O(\rgb_out[23]_i_2023_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_2038 
       (.I0(\SC_D/local_y [6]),
        .I1(\SC_D/local_y [7]),
        .O(\rgb_out[23]_i_2038_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_2039 
       (.I0(pixel_y[0]),
        .I1(\SC_D/local_y [1]),
        .O(\rgb_out[23]_i_2039_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_2040 
       (.I0(\SC_D/local_y [7]),
        .I1(\SC_D/local_y [6]),
        .O(\rgb_out[23]_i_2040_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_2041 
       (.I0(\SC_D/local_y [4]),
        .I1(\SC_D/local_y [5]),
        .O(\rgb_out[23]_i_2041_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_2042 
       (.I0(\SC_D/local_y [3]),
        .I1(\SC_D/local_y [2]),
        .O(\rgb_out[23]_i_2042_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_2043 
       (.I0(\SC_D/local_y [1]),
        .I1(pixel_y[0]),
        .O(\rgb_out[23]_i_2043_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_2051 
       (.I0(pixel_x[6]),
        .O(\rgb_out[23]_i_2051_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_2052 
       (.I0(pixel_x[5]),
        .O(\rgb_out[23]_i_2052_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_2053 
       (.I0(pixel_x[11]),
        .O(\rgb_out[23]_i_2053_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_2054 
       (.I0(pixel_x[10]),
        .O(\rgb_out[23]_i_2054_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_2055 
       (.I0(pixel_x[9]),
        .O(\rgb_out[23]_i_2055_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_2056 
       (.I0(pixel_x[8]),
        .O(\rgb_out[23]_i_2056_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_2057 
       (.I0(\SC_D/local_y [6]),
        .I1(\SC_D/local_y [7]),
        .O(\rgb_out[23]_i_2057_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_2058 
       (.I0(\SC_D/local_y [4]),
        .I1(\SC_D/local_y [5]),
        .O(\rgb_out[23]_i_2058_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_2059 
       (.I0(\SC_D/local_y [2]),
        .I1(\SC_D/local_y [3]),
        .O(\rgb_out[23]_i_2059_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_2060 
       (.I0(\SC_D/local_y [1]),
        .I1(pixel_y[0]),
        .O(\rgb_out[23]_i_2060_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_2061 
       (.I0(\SC_D/local_y [7]),
        .I1(\SC_D/local_y [6]),
        .O(\rgb_out[23]_i_2061_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_2062 
       (.I0(\SC_D/local_y [5]),
        .I1(\SC_D/local_y [4]),
        .O(\rgb_out[23]_i_2062_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_2063 
       (.I0(\SC_D/local_y [3]),
        .I1(\SC_D/local_y [2]),
        .O(\rgb_out[23]_i_2063_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_2064 
       (.I0(pixel_y[0]),
        .I1(\SC_D/local_y [1]),
        .O(\rgb_out[23]_i_2064_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_2065 
       (.I0(\SC_D/local_x [6]),
        .I1(\SC_D/local_x [7]),
        .O(\rgb_out[23]_i_2065_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_2066 
       (.I0(\SC_D/local_x [4]),
        .I1(\SC_D/local_x [5]),
        .O(\rgb_out[23]_i_2066_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_2067 
       (.I0(\SC_D/local_x [2]),
        .I1(\SC_D/local_x [3]),
        .O(\rgb_out[23]_i_2067_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_2068 
       (.I0(\SC_D/local_x [1]),
        .I1(\SC_D/local_x [0]),
        .O(\rgb_out[23]_i_2068_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_2069 
       (.I0(\SC_D/local_x [7]),
        .I1(\SC_D/local_x [6]),
        .O(\rgb_out[23]_i_2069_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_2070 
       (.I0(\SC_D/local_x [5]),
        .I1(\SC_D/local_x [4]),
        .O(\rgb_out[23]_i_2070_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_2071 
       (.I0(\SC_D/local_x [3]),
        .I1(\SC_D/local_x [2]),
        .O(\rgb_out[23]_i_2071_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_2072 
       (.I0(\SC_D/local_x [0]),
        .I1(\SC_D/local_x [1]),
        .O(\rgb_out[23]_i_2072_n_0 ));
  LUT2 #(
    .INIT(4'h7)) 
    \rgb_out[23]_i_2073 
       (.I0(\SC_D/local_y [4]),
        .I1(\SC_D/local_y [5]),
        .O(\rgb_out[23]_i_2073_n_0 ));
  LUT2 #(
    .INIT(4'h7)) 
    \rgb_out[23]_i_2074 
       (.I0(\SC_D/local_y [2]),
        .I1(\SC_D/local_y [3]),
        .O(\rgb_out[23]_i_2074_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_2075 
       (.I0(\SC_D/local_y [9]),
        .I1(\SC_D/local_y [8]),
        .O(\rgb_out[23]_i_2075_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_2076 
       (.I0(\SC_D/local_y [7]),
        .I1(\SC_D/local_y [6]),
        .O(\rgb_out[23]_i_2076_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_2077 
       (.I0(\SC_D/local_y [5]),
        .I1(\SC_D/local_y [4]),
        .O(\rgb_out[23]_i_2077_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_2078 
       (.I0(\SC_D/local_y [3]),
        .I1(\SC_D/local_y [2]),
        .O(\rgb_out[23]_i_2078_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_2079 
       (.I0(\SC_D/local_x [5]),
        .O(\rgb_out[23]_i_2079_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_2080 
       (.I0(\SC_D/local_x [3]),
        .I1(\SC_D/local_x [2]),
        .O(\rgb_out[23]_i_2080_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_2081 
       (.I0(\SC_D/local_x [9]),
        .I1(\SC_D/local_x [8]),
        .O(\rgb_out[23]_i_2081_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_2082 
       (.I0(\SC_D/local_x [7]),
        .I1(\SC_D/local_x [6]),
        .O(\rgb_out[23]_i_2082_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_2083 
       (.I0(\SC_D/local_x [5]),
        .I1(\SC_D/local_x [4]),
        .O(\rgb_out[23]_i_2083_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_2084 
       (.I0(\SC_D/local_x [2]),
        .I1(\SC_D/local_x [3]),
        .O(\rgb_out[23]_i_2084_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_2085 
       (.I0(pixel_y[8]),
        .O(\rgb_out[23]_i_2085_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_2086 
       (.I0(pixel_y[7]),
        .O(\rgb_out[23]_i_2086_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_2087 
       (.I0(pixel_y[6]),
        .O(\rgb_out[23]_i_2087_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_2088 
       (.I0(pixel_y[5]),
        .O(\rgb_out[23]_i_2088_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_2089 
       (.I0(pixel_y[4]),
        .O(\rgb_out[23]_i_2089_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_2090 
       (.I0(pixel_y[2]),
        .O(\rgb_out[23]_i_2090_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_2091 
       (.I0(pixel_y[5]),
        .O(\rgb_out[23]_i_2091_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_2092 
       (.I0(pixel_y[4]),
        .O(\rgb_out[23]_i_2092_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_2093 
       (.I0(pixel_y[3]),
        .O(\rgb_out[23]_i_2093_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_2094 
       (.I0(pixel_y[1]),
        .O(\rgb_out[23]_i_2094_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_2095 
       (.I0(pixel_x[4]),
        .O(\rgb_out[23]_i_2095_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_2096 
       (.I0(pixel_x[3]),
        .O(\rgb_out[23]_i_2096_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_2097 
       (.I0(pixel_x[2]),
        .O(\rgb_out[23]_i_2097_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_2098 
       (.I0(pixel_x[6]),
        .O(\rgb_out[23]_i_2098_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_2099 
       (.I0(pixel_x[5]),
        .O(\rgb_out[23]_i_2099_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_2100 
       (.I0(pixel_y[5]),
        .O(\rgb_out[23]_i_2100_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_2101 
       (.I0(pixel_y[4]),
        .O(\rgb_out[23]_i_2101_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_2102 
       (.I0(pixel_y[3]),
        .O(\rgb_out[23]_i_2102_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_2103 
       (.I0(pixel_y[1]),
        .O(\rgb_out[23]_i_2103_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_2104 
       (.I0(pixel_x[4]),
        .O(\rgb_out[23]_i_2104_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_2105 
       (.I0(pixel_x[2]),
        .O(\rgb_out[23]_i_2105_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_2106 
       (.I0(pixel_x[8]),
        .O(\rgb_out[23]_i_2106_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_2107 
       (.I0(pixel_x[6]),
        .O(\rgb_out[23]_i_2107_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_2108 
       (.I0(pixel_y[5]),
        .O(\rgb_out[23]_i_2108_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_2109 
       (.I0(pixel_y[4]),
        .O(\rgb_out[23]_i_2109_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_2110 
       (.I0(pixel_y[3]),
        .O(\rgb_out[23]_i_2110_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_2111 
       (.I0(pixel_y[1]),
        .O(\rgb_out[23]_i_2111_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_2112 
       (.I0(pixel_x[4]),
        .O(\rgb_out[23]_i_2112_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_2113 
       (.I0(pixel_x[2]),
        .O(\rgb_out[23]_i_2113_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_2114 
       (.I0(pixel_y[5]),
        .O(\rgb_out[23]_i_2114_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_2115 
       (.I0(pixel_y[4]),
        .O(\rgb_out[23]_i_2115_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_2116 
       (.I0(pixel_y[3]),
        .O(\rgb_out[23]_i_2116_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_2117 
       (.I0(pixel_y[1]),
        .O(\rgb_out[23]_i_2117_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_2118 
       (.I0(pixel_x[4]),
        .O(\rgb_out[23]_i_2118_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_2119 
       (.I0(pixel_x[3]),
        .O(\rgb_out[23]_i_2119_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_2120 
       (.I0(pixel_x[2]),
        .O(\rgb_out[23]_i_2120_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_2121 
       (.I0(pixel_x[6]),
        .O(\rgb_out[23]_i_2121_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_2122 
       (.I0(pixel_x[1]),
        .O(\rgb_out[23]_i_2122_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_2123 
       (.I0(pixel_y[4]),
        .O(\rgb_out[23]_i_2123_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_2124 
       (.I0(pixel_y[2]),
        .O(\rgb_out[23]_i_2124_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_2131 
       (.I0(pixel_x[3]),
        .O(\rgb_out[23]_i_2131_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_2132 
       (.I0(pixel_x[1]),
        .O(\rgb_out[23]_i_2132_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_479 
       (.I0(\TM_D/local_x [10]),
        .I1(\TM_D/local_x [11]),
        .O(\rgb_out[23]_i_479_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_480 
       (.I0(\TM_D/local_x [8]),
        .I1(\TM_D/local_x [9]),
        .O(\rgb_out[23]_i_480_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_482 
       (.I0(\TM_D/local_x [11]),
        .I1(\TM_D/local_x [10]),
        .O(\rgb_out[23]_i_482_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_483 
       (.I0(\TM_D/local_x [9]),
        .I1(\TM_D/local_x [8]),
        .O(\rgb_out[23]_i_483_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_485 
       (.I0(\rgb_out_reg[23]_i_481_n_1 ),
        .O(\rgb_out[23]_i_485_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_486 
       (.I0(\TM_D/local_x [11]),
        .I1(\TM_D/local_x [10]),
        .O(\rgb_out[23]_i_486_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_487 
       (.I0(\TM_D/local_x [9]),
        .I1(\TM_D/local_x [8]),
        .O(\rgb_out[23]_i_487_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_589 
       (.I0(\REC_D/local_x [10]),
        .I1(\REC_D/local_x [11]),
        .O(\rgb_out[23]_i_589_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_590 
       (.I0(\REC_D/local_x [8]),
        .I1(\REC_D/local_x [9]),
        .O(\rgb_out[23]_i_590_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_592 
       (.I0(\REC_D/local_x [11]),
        .I1(\REC_D/local_x [10]),
        .O(\rgb_out[23]_i_592_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_593 
       (.I0(\REC_D/local_x [9]),
        .I1(\REC_D/local_x [8]),
        .O(\rgb_out[23]_i_593_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_595 
       (.I0(\rgb_out_reg[23]_i_591_n_0 ),
        .O(\rgb_out[23]_i_595_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_596 
       (.I0(\REC_D/local_x [11]),
        .I1(\REC_D/local_x [10]),
        .O(\rgb_out[23]_i_596_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_597 
       (.I0(\REC_D/local_x [9]),
        .I1(\REC_D/local_x [8]),
        .O(\rgb_out[23]_i_597_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_663 
       (.I0(\LAST_D/local_x [10]),
        .I1(\LAST_D/local_x [11]),
        .O(\rgb_out[23]_i_663_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_664 
       (.I0(\LAST_D/local_x [8]),
        .I1(\LAST_D/local_x [9]),
        .O(\rgb_out[23]_i_664_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_666 
       (.I0(\LAST_D/local_x [11]),
        .I1(\LAST_D/local_x [10]),
        .O(\rgb_out[23]_i_666_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_667 
       (.I0(\LAST_D/local_x [9]),
        .I1(\LAST_D/local_x [8]),
        .O(\rgb_out[23]_i_667_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_669 
       (.I0(\rgb_out_reg[23]_i_665_n_0 ),
        .O(\rgb_out[23]_i_669_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_670 
       (.I0(\LAST_D/local_x [11]),
        .I1(\LAST_D/local_x [10]),
        .O(\rgb_out[23]_i_670_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_671 
       (.I0(\LAST_D/local_x [9]),
        .I1(\LAST_D/local_x [8]),
        .O(\rgb_out[23]_i_671_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_715 
       (.I0(\rgb_out_reg[23]_i_716_n_3 ),
        .O(\SC_U/local_x [12]));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_717 
       (.I0(\SC_U/local_x [11]),
        .I1(\SC_U/local_x [10]),
        .O(\rgb_out[23]_i_717_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_719 
       (.I0(\rgb_out_reg[23]_i_720_n_0 ),
        .O(\SC_U/local_y [12]));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_722 
       (.I0(\SC_U/local_x [10]),
        .I1(\SC_U/local_x [11]),
        .O(\rgb_out[23]_i_722_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_723 
       (.I0(\SC_U/local_x [8]),
        .I1(\SC_U/local_x [9]),
        .O(\rgb_out[23]_i_723_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_724 
       (.I0(\SC_U/local_x [11]),
        .I1(\SC_U/local_x [10]),
        .O(\rgb_out[23]_i_724_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_725 
       (.I0(\SC_U/local_x [9]),
        .I1(\SC_U/local_x [8]),
        .O(\rgb_out[23]_i_725_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_727 
       (.I0(\SC_U/local_y [10]),
        .I1(\SC_U/local_y [11]),
        .O(\rgb_out[23]_i_727_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_728 
       (.I0(\SC_U/local_y [8]),
        .I1(\SC_U/local_y [9]),
        .O(\rgb_out[23]_i_728_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_729 
       (.I0(\SC_U/local_y [11]),
        .I1(\SC_U/local_y [10]),
        .O(\rgb_out[23]_i_729_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_730 
       (.I0(\SC_U/local_y [9]),
        .I1(\SC_U/local_y [8]),
        .O(\rgb_out[23]_i_730_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_759 
       (.I0(\SC_D/local_x [10]),
        .I1(\SC_D/local_x [11]),
        .O(\rgb_out[23]_i_759_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_760 
       (.I0(\SC_D/local_x [8]),
        .I1(\SC_D/local_x [9]),
        .O(\rgb_out[23]_i_760_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_762 
       (.I0(\SC_D/local_x [11]),
        .I1(\SC_D/local_x [10]),
        .O(\rgb_out[23]_i_762_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_763 
       (.I0(\SC_D/local_x [9]),
        .I1(\SC_D/local_x [8]),
        .O(\rgb_out[23]_i_763_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_765 
       (.I0(\rgb_out_reg[23]_i_761_n_3 ),
        .O(\rgb_out[23]_i_765_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_766 
       (.I0(\SC_D/local_x [11]),
        .I1(\SC_D/local_x [10]),
        .O(\rgb_out[23]_i_766_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_767 
       (.I0(\SC_D/local_x [9]),
        .I1(\SC_D/local_x [8]),
        .O(\rgb_out[23]_i_767_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_778 
       (.I0(\rgb_out_reg[23]_i_779_n_0 ),
        .O(\rgb_out[23]_i_778_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_780 
       (.I0(\TM_D/local_y [11]),
        .I1(\TM_D/local_y [10]),
        .O(\rgb_out[23]_i_780_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_781 
       (.I0(\TM_D/local_y [9]),
        .I1(\TM_D/local_y [8]),
        .O(\rgb_out[23]_i_781_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_783 
       (.I0(\TM_D/local_y [10]),
        .I1(\TM_D/local_y [11]),
        .O(\rgb_out[23]_i_783_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_784 
       (.I0(\TM_D/local_y [8]),
        .I1(\TM_D/local_y [9]),
        .O(\rgb_out[23]_i_784_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_785 
       (.I0(\TM_D/local_y [11]),
        .I1(\TM_D/local_y [10]),
        .O(\rgb_out[23]_i_785_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_786 
       (.I0(\TM_D/local_y [9]),
        .I1(\TM_D/local_y [8]),
        .O(\rgb_out[23]_i_786_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_793 
       (.I0(\rgb_out_reg[23]_i_481_n_1 ),
        .O(\rgb_out[23]_i_793_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_794 
       (.I0(\TM_D/local_x [11]),
        .I1(\TM_D/local_x [10]),
        .O(\rgb_out[23]_i_794_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_795 
       (.I0(\TM_D/local_x [9]),
        .I1(\TM_D/local_x [8]),
        .O(\rgb_out[23]_i_795_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_797 
       (.I0(\TM_D/local_y [10]),
        .I1(\TM_D/local_y [11]),
        .O(\rgb_out[23]_i_797_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_798 
       (.I0(\TM_D/local_y [8]),
        .I1(\TM_D/local_y [9]),
        .O(\rgb_out[23]_i_798_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_799 
       (.I0(\TM_D/local_y [11]),
        .I1(\TM_D/local_y [10]),
        .O(\rgb_out[23]_i_799_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_800 
       (.I0(\TM_D/local_y [9]),
        .I1(\TM_D/local_y [8]),
        .O(\rgb_out[23]_i_800_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_802 
       (.I0(\rgb_out_reg[23]_i_779_n_0 ),
        .O(\rgb_out[23]_i_802_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_803 
       (.I0(\TM_D/local_y [11]),
        .I1(\TM_D/local_y [10]),
        .O(\rgb_out[23]_i_803_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_804 
       (.I0(\TM_D/local_y [9]),
        .I1(\TM_D/local_y [8]),
        .O(\rgb_out[23]_i_804_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_806 
       (.I0(\TM_D/local_y [10]),
        .I1(\TM_D/local_y [11]),
        .O(\rgb_out[23]_i_806_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_807 
       (.I0(\TM_D/local_y [8]),
        .I1(\TM_D/local_y [9]),
        .O(\rgb_out[23]_i_807_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_808 
       (.I0(\TM_D/local_y [11]),
        .I1(\TM_D/local_y [10]),
        .O(\rgb_out[23]_i_808_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_809 
       (.I0(\TM_D/local_y [9]),
        .I1(\TM_D/local_y [8]),
        .O(\rgb_out[23]_i_809_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_811 
       (.I0(\rgb_out_reg[23]_i_779_n_0 ),
        .O(\rgb_out[23]_i_811_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_812 
       (.I0(\TM_D/local_y [11]),
        .I1(\TM_D/local_y [10]),
        .O(\rgb_out[23]_i_812_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_813 
       (.I0(\TM_D/local_y [9]),
        .I1(\TM_D/local_y [8]),
        .O(\rgb_out[23]_i_813_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_814 
       (.I0(\TM_D/local_x [6]),
        .I1(\TM_D/local_x [7]),
        .O(\rgb_out[23]_i_814_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_816 
       (.I0(pixel_x[0]),
        .I1(pixel_x[1]),
        .O(\rgb_out[23]_i_816_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_817 
       (.I0(\TM_D/local_x [7]),
        .I1(\TM_D/local_x [6]),
        .O(\rgb_out[23]_i_817_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_818 
       (.I0(\TM_D/local_x [4]),
        .I1(\TM_D/local_x [5]),
        .O(\rgb_out[23]_i_818_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_819 
       (.I0(\TM_D/local_x [3]),
        .I1(\TM_D/local_x [2]),
        .O(\rgb_out[23]_i_819_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_820 
       (.I0(pixel_x[1]),
        .I1(pixel_x[0]),
        .O(\rgb_out[23]_i_820_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_822 
       (.I0(pixel_x[11]),
        .O(\rgb_out[23]_i_822_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_823 
       (.I0(\TM_D/local_x [3]),
        .I1(\TM_D/local_x [2]),
        .O(\rgb_out[23]_i_823_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_824 
       (.I0(pixel_x[1]),
        .O(\rgb_out[23]_i_824_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_825 
       (.I0(\TM_D/local_x [7]),
        .I1(\TM_D/local_x [6]),
        .O(\rgb_out[23]_i_825_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_826 
       (.I0(\TM_D/local_x [5]),
        .I1(\TM_D/local_x [4]),
        .O(\rgb_out[23]_i_826_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_827 
       (.I0(\TM_D/local_x [2]),
        .I1(\TM_D/local_x [3]),
        .O(\rgb_out[23]_i_827_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_828 
       (.I0(pixel_x[1]),
        .I1(pixel_x[0]),
        .O(\rgb_out[23]_i_828_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_830 
       (.I0(\TM_D/local_y [10]),
        .I1(\TM_D/local_y [11]),
        .O(\rgb_out[23]_i_830_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_831 
       (.I0(\TM_D/local_y [8]),
        .I1(\TM_D/local_y [9]),
        .O(\rgb_out[23]_i_831_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_832 
       (.I0(\TM_D/local_y [11]),
        .I1(\TM_D/local_y [10]),
        .O(\rgb_out[23]_i_832_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_833 
       (.I0(\TM_D/local_y [9]),
        .I1(\TM_D/local_y [8]),
        .O(\rgb_out[23]_i_833_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_835 
       (.I0(\TM_D/local_x [10]),
        .I1(\TM_D/local_x [11]),
        .O(\rgb_out[23]_i_835_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_836 
       (.I0(\TM_D/local_x [8]),
        .I1(\TM_D/local_x [9]),
        .O(\rgb_out[23]_i_836_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_837 
       (.I0(\TM_D/local_x [11]),
        .I1(\TM_D/local_x [10]),
        .O(\rgb_out[23]_i_837_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_838 
       (.I0(\TM_D/local_x [9]),
        .I1(\TM_D/local_x [8]),
        .O(\rgb_out[23]_i_838_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_840 
       (.I0(\rgb_out_reg[23]_i_779_n_0 ),
        .O(\TM_D/local_y [12]));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_841 
       (.I0(\TM_D/local_y [11]),
        .I1(\TM_D/local_y [10]),
        .O(\rgb_out[23]_i_841_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_843 
       (.I0(\rgb_out_reg[23]_i_481_n_1 ),
        .O(\TM_D/local_x [12]));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_844 
       (.I0(\TM_D/local_x [11]),
        .I1(\TM_D/local_x [10]),
        .O(\rgb_out[23]_i_844_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_881 
       (.I0(U0_n_0),
        .O(\rgb_out[23]_i_881_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_928 
       (.I0(\rgb_out_reg[23]_i_929_n_0 ),
        .O(\rgb_out[23]_i_928_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_930 
       (.I0(\REC_D/local_y [11]),
        .I1(\REC_D/local_y [10]),
        .O(\rgb_out[23]_i_930_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_931 
       (.I0(\REC_D/local_y [9]),
        .I1(\REC_D/local_y [8]),
        .O(\rgb_out[23]_i_931_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_933 
       (.I0(\REC_D/local_y [10]),
        .I1(\REC_D/local_y [11]),
        .O(\rgb_out[23]_i_933_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_934 
       (.I0(\REC_D/local_y [8]),
        .I1(\REC_D/local_y [9]),
        .O(\rgb_out[23]_i_934_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_935 
       (.I0(\REC_D/local_y [11]),
        .I1(\REC_D/local_y [10]),
        .O(\rgb_out[23]_i_935_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_936 
       (.I0(\REC_D/local_y [9]),
        .I1(\REC_D/local_y [8]),
        .O(\rgb_out[23]_i_936_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_938 
       (.I0(\REC_D/local_x [10]),
        .I1(\REC_D/local_x [11]),
        .O(\rgb_out[23]_i_938_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_939 
       (.I0(\REC_D/local_x [8]),
        .I1(\REC_D/local_x [9]),
        .O(\rgb_out[23]_i_939_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_940 
       (.I0(\REC_D/local_x [11]),
        .I1(\REC_D/local_x [10]),
        .O(\rgb_out[23]_i_940_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_941 
       (.I0(\REC_D/local_x [9]),
        .I1(\REC_D/local_x [8]),
        .O(\rgb_out[23]_i_941_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_943 
       (.I0(\rgb_out_reg[23]_i_591_n_0 ),
        .O(\rgb_out[23]_i_943_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_944 
       (.I0(\REC_D/local_x [11]),
        .I1(\REC_D/local_x [10]),
        .O(\rgb_out[23]_i_944_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_945 
       (.I0(\REC_D/local_x [9]),
        .I1(\REC_D/local_x [8]),
        .O(\rgb_out[23]_i_945_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_947 
       (.I0(\REC_D/local_y [10]),
        .I1(\REC_D/local_y [11]),
        .O(\rgb_out[23]_i_947_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_948 
       (.I0(\REC_D/local_y [8]),
        .I1(\REC_D/local_y [9]),
        .O(\rgb_out[23]_i_948_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_949 
       (.I0(\REC_D/local_y [11]),
        .I1(\REC_D/local_y [10]),
        .O(\rgb_out[23]_i_949_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_950 
       (.I0(\REC_D/local_y [9]),
        .I1(\REC_D/local_y [8]),
        .O(\rgb_out[23]_i_950_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_952 
       (.I0(\rgb_out_reg[23]_i_929_n_0 ),
        .O(\rgb_out[23]_i_952_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_953 
       (.I0(\REC_D/local_y [11]),
        .I1(\REC_D/local_y [10]),
        .O(\rgb_out[23]_i_953_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_954 
       (.I0(\REC_D/local_y [9]),
        .I1(\REC_D/local_y [8]),
        .O(\rgb_out[23]_i_954_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_956 
       (.I0(\REC_D/local_y [10]),
        .I1(\REC_D/local_y [11]),
        .O(\rgb_out[23]_i_956_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_957 
       (.I0(\REC_D/local_y [8]),
        .I1(\REC_D/local_y [9]),
        .O(\rgb_out[23]_i_957_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_958 
       (.I0(\REC_D/local_y [11]),
        .I1(\REC_D/local_y [10]),
        .O(\rgb_out[23]_i_958_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_959 
       (.I0(\REC_D/local_y [9]),
        .I1(\REC_D/local_y [8]),
        .O(\rgb_out[23]_i_959_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_961 
       (.I0(\rgb_out_reg[23]_i_929_n_0 ),
        .O(\rgb_out[23]_i_961_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_962 
       (.I0(\REC_D/local_y [11]),
        .I1(\REC_D/local_y [10]),
        .O(\rgb_out[23]_i_962_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_963 
       (.I0(\REC_D/local_y [9]),
        .I1(\REC_D/local_y [8]),
        .O(\rgb_out[23]_i_963_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_964 
       (.I0(\REC_D/local_x [6]),
        .I1(\REC_D/local_x [7]),
        .O(\rgb_out[23]_i_964_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_966 
       (.I0(\REC_D/local_x [1]),
        .I1(pixel_x[0]),
        .O(\rgb_out[23]_i_966_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_967 
       (.I0(\REC_D/local_x [7]),
        .I1(\REC_D/local_x [6]),
        .O(\rgb_out[23]_i_967_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_968 
       (.I0(\REC_D/local_x [4]),
        .I1(\REC_D/local_x [5]),
        .O(\rgb_out[23]_i_968_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_969 
       (.I0(\REC_D/local_x [3]),
        .I1(\REC_D/local_x [2]),
        .O(\rgb_out[23]_i_969_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_970 
       (.I0(pixel_x[0]),
        .I1(\REC_D/local_x [1]),
        .O(\rgb_out[23]_i_970_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_971 
       (.I0(pixel_x[11]),
        .O(\rgb_out[23]_i_971_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_972 
       (.I0(pixel_x[9]),
        .O(\rgb_out[23]_i_972_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_973 
       (.I0(\REC_D/local_x [3]),
        .I1(\REC_D/local_x [2]),
        .O(\rgb_out[23]_i_973_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_974 
       (.I0(\REC_D/local_x [1]),
        .O(\rgb_out[23]_i_974_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_975 
       (.I0(\REC_D/local_x [7]),
        .I1(\REC_D/local_x [6]),
        .O(\rgb_out[23]_i_975_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_976 
       (.I0(\REC_D/local_x [5]),
        .I1(\REC_D/local_x [4]),
        .O(\rgb_out[23]_i_976_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_977 
       (.I0(\REC_D/local_x [2]),
        .I1(\REC_D/local_x [3]),
        .O(\rgb_out[23]_i_977_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_978 
       (.I0(pixel_x[0]),
        .I1(\REC_D/local_x [1]),
        .O(\rgb_out[23]_i_978_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_980 
       (.I0(\REC_D/local_y [10]),
        .I1(\REC_D/local_y [11]),
        .O(\rgb_out[23]_i_980_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_981 
       (.I0(\REC_D/local_y [8]),
        .I1(\REC_D/local_y [9]),
        .O(\rgb_out[23]_i_981_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_982 
       (.I0(\REC_D/local_y [11]),
        .I1(\REC_D/local_y [10]),
        .O(\rgb_out[23]_i_982_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_983 
       (.I0(\REC_D/local_y [9]),
        .I1(\REC_D/local_y [8]),
        .O(\rgb_out[23]_i_983_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_985 
       (.I0(\REC_D/local_x [10]),
        .I1(\REC_D/local_x [11]),
        .O(\rgb_out[23]_i_985_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_986 
       (.I0(\REC_D/local_x [8]),
        .I1(\REC_D/local_x [9]),
        .O(\rgb_out[23]_i_986_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_987 
       (.I0(\REC_D/local_x [11]),
        .I1(\REC_D/local_x [10]),
        .O(\rgb_out[23]_i_987_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_988 
       (.I0(\REC_D/local_x [9]),
        .I1(\REC_D/local_x [8]),
        .O(\rgb_out[23]_i_988_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_990 
       (.I0(\rgb_out_reg[23]_i_929_n_0 ),
        .O(\REC_D/local_y [12]));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_991 
       (.I0(\REC_D/local_y [11]),
        .I1(\REC_D/local_y [10]),
        .O(\rgb_out[23]_i_991_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_993 
       (.I0(\rgb_out_reg[23]_i_591_n_0 ),
        .O(\REC_D/local_x [12]));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_994 
       (.I0(\REC_D/local_x [11]),
        .I1(\REC_D/local_x [10]),
        .O(\rgb_out[23]_i_994_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_996 
       (.I0(\rgb_out_reg[23]_i_997_n_0 ),
        .O(\LAST_U/local_x [12]));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_998 
       (.I0(\LAST_U/local_x [11]),
        .I1(\LAST_U/local_x [10]),
        .O(\rgb_out[23]_i_998_n_0 ));
  CARRY4 \rgb_out_reg[23]_i_1001 
       (.CI(\rgb_out_reg[23]_i_1603_n_0 ),
        .CO({\rgb_out_reg[23]_i_1001_n_0 ,\NLW_rgb_out_reg[23]_i_1001_CO_UNCONNECTED [2],\rgb_out_reg[23]_i_1001_n_2 ,\rgb_out_reg[23]_i_1001_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,pixel_y[11:9]}),
        .O({\NLW_rgb_out_reg[23]_i_1001_O_UNCONNECTED [3],\LAST_U/local_y [11:9]}),
        .S({1'b1,\rgb_out[23]_i_1604_n_0 ,\rgb_out[23]_i_1605_n_0 ,\rgb_out[23]_i_1606_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_1002 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_1002_n_0 ,\rgb_out_reg[23]_i_1002_n_1 ,\rgb_out_reg[23]_i_1002_n_2 ,\rgb_out_reg[23]_i_1002_n_3 }),
        .CYINIT(1'b1),
        .DI({\rgb_out[23]_i_1607_n_0 ,\rgb_out[23]_i_1608_n_0 ,\rgb_out[23]_i_1609_n_0 ,\rgb_out[23]_i_1610_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_1002_O_UNCONNECTED [3:0]),
        .S({\rgb_out[23]_i_1611_n_0 ,\rgb_out[23]_i_1612_n_0 ,\rgb_out[23]_i_1613_n_0 ,\rgb_out[23]_i_1614_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_1007 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_1007_n_0 ,\rgb_out_reg[23]_i_1007_n_1 ,\rgb_out_reg[23]_i_1007_n_2 ,\rgb_out_reg[23]_i_1007_n_3 }),
        .CYINIT(1'b1),
        .DI({\rgb_out[23]_i_1615_n_0 ,\rgb_out[23]_i_1616_n_0 ,\rgb_out[23]_i_1617_n_0 ,\rgb_out[23]_i_1618_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_1007_O_UNCONNECTED [3:0]),
        .S({\rgb_out[23]_i_1619_n_0 ,\rgb_out[23]_i_1620_n_0 ,\rgb_out[23]_i_1621_n_0 ,\rgb_out[23]_i_1622_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_1012 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_1012_n_0 ,\rgb_out_reg[23]_i_1012_n_1 ,\rgb_out_reg[23]_i_1012_n_2 ,\rgb_out_reg[23]_i_1012_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,\rgb_out[23]_i_1623_n_0 ,\rgb_out[23]_i_1624_n_0 ,\rgb_out[23]_i_1625_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_1012_O_UNCONNECTED [3:0]),
        .S({\rgb_out[23]_i_1626_n_0 ,\rgb_out[23]_i_1627_n_0 ,\rgb_out[23]_i_1628_n_0 ,\rgb_out[23]_i_1629_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_1016 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_1016_n_0 ,\rgb_out_reg[23]_i_1016_n_1 ,\rgb_out_reg[23]_i_1016_n_2 ,\rgb_out_reg[23]_i_1016_n_3 }),
        .CYINIT(1'b1),
        .DI({\rgb_out[23]_i_1630_n_0 ,\LAST_U/local_y [5],1'b0,\rgb_out[23]_i_1631_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_1016_O_UNCONNECTED [3:0]),
        .S({\rgb_out[23]_i_1632_n_0 ,\rgb_out[23]_i_1633_n_0 ,\rgb_out[23]_i_1634_n_0 ,\rgb_out[23]_i_1635_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_1021 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_1021_n_0 ,\rgb_out_reg[23]_i_1021_n_1 ,\rgb_out_reg[23]_i_1021_n_2 ,\rgb_out_reg[23]_i_1021_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\rgb_out[23]_i_1636_n_0 ,\rgb_out[23]_i_1637_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_1021_O_UNCONNECTED [3:0]),
        .S({\rgb_out[23]_i_1638_n_0 ,\rgb_out[23]_i_1639_n_0 ,\rgb_out[23]_i_1640_n_0 ,\rgb_out[23]_i_1641_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_1025 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_1025_n_0 ,\rgb_out_reg[23]_i_1025_n_1 ,\rgb_out_reg[23]_i_1025_n_2 ,\rgb_out_reg[23]_i_1025_n_3 }),
        .CYINIT(1'b1),
        .DI({\rgb_out[23]_i_1642_n_0 ,\LAST_U/local_x [5],1'b0,\rgb_out[23]_i_1643_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_1025_O_UNCONNECTED [3:0]),
        .S({\rgb_out[23]_i_1644_n_0 ,\rgb_out[23]_i_1645_n_0 ,\rgb_out[23]_i_1646_n_0 ,\rgb_out[23]_i_1647_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_1030 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_1030_n_0 ,\rgb_out_reg[23]_i_1030_n_1 ,\rgb_out_reg[23]_i_1030_n_2 ,\rgb_out_reg[23]_i_1030_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,\rgb_out[23]_i_1648_n_0 ,\rgb_out[23]_i_1649_n_0 ,\rgb_out[23]_i_1650_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_1030_O_UNCONNECTED [3:0]),
        .S({\rgb_out[23]_i_1651_n_0 ,\rgb_out[23]_i_1652_n_0 ,\rgb_out[23]_i_1653_n_0 ,\rgb_out[23]_i_1654_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_1034 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_1034_n_0 ,\rgb_out_reg[23]_i_1034_n_1 ,\rgb_out_reg[23]_i_1034_n_2 ,\rgb_out_reg[23]_i_1034_n_3 }),
        .CYINIT(1'b1),
        .DI({\rgb_out[23]_i_1655_n_0 ,\rgb_out[23]_i_1656_n_0 ,\LAST_U/local_y [3],\rgb_out[23]_i_1658_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_1034_O_UNCONNECTED [3:0]),
        .S({\rgb_out[23]_i_1659_n_0 ,\rgb_out[23]_i_1660_n_0 ,\rgb_out[23]_i_1661_n_0 ,\rgb_out[23]_i_1662_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_1039 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_1039_n_0 ,\rgb_out_reg[23]_i_1039_n_1 ,\rgb_out_reg[23]_i_1039_n_2 ,\rgb_out_reg[23]_i_1039_n_3 }),
        .CYINIT(1'b1),
        .DI({\rgb_out[23]_i_1663_n_0 ,\rgb_out[23]_i_1664_n_0 ,\LAST_U/local_x [3],\rgb_out[23]_i_1666_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_1039_O_UNCONNECTED [3:0]),
        .S({\rgb_out[23]_i_1667_n_0 ,\rgb_out[23]_i_1668_n_0 ,\rgb_out[23]_i_1669_n_0 ,\rgb_out[23]_i_1670_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_1044 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_1044_n_0 ,\rgb_out_reg[23]_i_1044_n_1 ,\rgb_out_reg[23]_i_1044_n_2 ,\rgb_out_reg[23]_i_1044_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,\rgb_out[23]_i_1671_n_0 ,\rgb_out[23]_i_1672_n_0 ,\rgb_out[23]_i_1673_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_1044_O_UNCONNECTED [3:0]),
        .S({\rgb_out[23]_i_1674_n_0 ,\rgb_out[23]_i_1675_n_0 ,\rgb_out[23]_i_1676_n_0 ,\rgb_out[23]_i_1677_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_1048 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_1048_n_0 ,\rgb_out_reg[23]_i_1048_n_1 ,\rgb_out_reg[23]_i_1048_n_2 ,\rgb_out_reg[23]_i_1048_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\rgb_out[23]_i_1678_n_0 ,\rgb_out[23]_i_1679_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_1048_O_UNCONNECTED [3:0]),
        .S({\rgb_out[23]_i_1680_n_0 ,\rgb_out[23]_i_1681_n_0 ,\rgb_out[23]_i_1682_n_0 ,\rgb_out[23]_i_1683_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_1052 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_1052_n_0 ,\rgb_out_reg[23]_i_1052_n_1 ,\rgb_out_reg[23]_i_1052_n_2 ,\rgb_out_reg[23]_i_1052_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,\rgb_out[23]_i_1684_n_0 ,1'b0,\rgb_out[23]_i_1685_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_1052_O_UNCONNECTED [3:0]),
        .S({\rgb_out[23]_i_1686_n_0 ,\rgb_out[23]_i_1687_n_0 ,\rgb_out[23]_i_1688_n_0 ,\rgb_out[23]_i_1689_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_1056 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_1056_n_0 ,\rgb_out_reg[23]_i_1056_n_1 ,\rgb_out_reg[23]_i_1056_n_2 ,\rgb_out_reg[23]_i_1056_n_3 }),
        .CYINIT(1'b1),
        .DI({\rgb_out[23]_i_1690_n_0 ,\LAST_U/local_y [5],\rgb_out[23]_i_1691_n_0 ,1'b0}),
        .O(\NLW_rgb_out_reg[23]_i_1056_O_UNCONNECTED [3:0]),
        .S({\rgb_out[23]_i_1692_n_0 ,\rgb_out[23]_i_1693_n_0 ,\rgb_out[23]_i_1694_n_0 ,\rgb_out[23]_i_1695_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_1061 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_1061_n_0 ,\rgb_out_reg[23]_i_1061_n_1 ,\rgb_out_reg[23]_i_1061_n_2 ,\rgb_out_reg[23]_i_1061_n_3 }),
        .CYINIT(1'b1),
        .DI({\rgb_out[23]_i_1696_n_0 ,1'b0,\LAST_U/local_y [3],\rgb_out[23]_i_1697_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_1061_O_UNCONNECTED [3:0]),
        .S({\rgb_out[23]_i_1698_n_0 ,\rgb_out[23]_i_1699_n_0 ,\rgb_out[23]_i_1700_n_0 ,\rgb_out[23]_i_1701_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_1066 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_1066_n_0 ,\rgb_out_reg[23]_i_1066_n_1 ,\rgb_out_reg[23]_i_1066_n_2 ,\rgb_out_reg[23]_i_1066_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\rgb_out[23]_i_1702_n_0 ,\rgb_out[23]_i_1703_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_1066_O_UNCONNECTED [3:0]),
        .S({\rgb_out[23]_i_1704_n_0 ,\rgb_out[23]_i_1705_n_0 ,\rgb_out[23]_i_1706_n_0 ,\rgb_out[23]_i_1707_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_1068 
       (.CI(\rgb_out_reg[23]_i_1708_n_0 ),
        .CO({\rgb_out_reg[23]_i_1068_n_0 ,\NLW_rgb_out_reg[23]_i_1068_CO_UNCONNECTED [2],\rgb_out_reg[23]_i_1068_n_2 ,\rgb_out_reg[23]_i_1068_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,pixel_x[11],1'b0,pixel_x[9]}),
        .O({\NLW_rgb_out_reg[23]_i_1068_O_UNCONNECTED [3],\REC_U/local_x [11:9]}),
        .S({1'b1,\rgb_out[23]_i_1709_n_0 ,pixel_x[10],\rgb_out[23]_i_1710_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_1070 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_1070_n_0 ,\rgb_out_reg[23]_i_1070_n_1 ,\rgb_out_reg[23]_i_1070_n_2 ,\rgb_out_reg[23]_i_1070_n_3 }),
        .CYINIT(\rgb_out[23]_i_1711_n_0 ),
        .DI({1'b0,1'b0,1'b0,\rgb_out[23]_i_1712_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_1070_O_UNCONNECTED [3:0]),
        .S({\rgb_out[23]_i_1713_n_0 ,\rgb_out[23]_i_1714_n_0 ,\rgb_out[23]_i_1715_n_0 ,\rgb_out[23]_i_1716_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_1072 
       (.CI(\rgb_out_reg[23]_i_1717_n_0 ),
        .CO({\rgb_out_reg[23]_i_1072_n_0 ,\NLW_rgb_out_reg[23]_i_1072_CO_UNCONNECTED [2],\rgb_out_reg[23]_i_1072_n_2 ,\rgb_out_reg[23]_i_1072_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,pixel_y[11:9]}),
        .O({\NLW_rgb_out_reg[23]_i_1072_O_UNCONNECTED [3],\REC_U/local_y [11:9]}),
        .S({1'b1,\rgb_out[23]_i_1718_n_0 ,\rgb_out[23]_i_1719_n_0 ,\rgb_out[23]_i_1720_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_1073 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_1073_n_0 ,\rgb_out_reg[23]_i_1073_n_1 ,\rgb_out_reg[23]_i_1073_n_2 ,\rgb_out_reg[23]_i_1073_n_3 }),
        .CYINIT(1'b1),
        .DI({\rgb_out[23]_i_1721_n_0 ,\rgb_out[23]_i_1722_n_0 ,\rgb_out[23]_i_1723_n_0 ,\rgb_out[23]_i_1724_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_1073_O_UNCONNECTED [3:0]),
        .S({\rgb_out[23]_i_1725_n_0 ,\rgb_out[23]_i_1726_n_0 ,\rgb_out[23]_i_1727_n_0 ,\rgb_out[23]_i_1728_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_1078 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_1078_n_0 ,\rgb_out_reg[23]_i_1078_n_1 ,\rgb_out_reg[23]_i_1078_n_2 ,\rgb_out_reg[23]_i_1078_n_3 }),
        .CYINIT(1'b1),
        .DI({\rgb_out[23]_i_1729_n_0 ,\rgb_out[23]_i_1730_n_0 ,\rgb_out[23]_i_1731_n_0 ,\rgb_out[23]_i_1732_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_1078_O_UNCONNECTED [3:0]),
        .S({\rgb_out[23]_i_1733_n_0 ,\rgb_out[23]_i_1734_n_0 ,\rgb_out[23]_i_1735_n_0 ,\rgb_out[23]_i_1736_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_1083 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_1083_n_0 ,\rgb_out_reg[23]_i_1083_n_1 ,\rgb_out_reg[23]_i_1083_n_2 ,\rgb_out_reg[23]_i_1083_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,\rgb_out[23]_i_1737_n_0 ,\rgb_out[23]_i_1738_n_0 ,\rgb_out[23]_i_1739_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_1083_O_UNCONNECTED [3:0]),
        .S({\rgb_out[23]_i_1740_n_0 ,\rgb_out[23]_i_1741_n_0 ,\rgb_out[23]_i_1742_n_0 ,\rgb_out[23]_i_1743_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_1087 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_1087_n_0 ,\rgb_out_reg[23]_i_1087_n_1 ,\rgb_out_reg[23]_i_1087_n_2 ,\rgb_out_reg[23]_i_1087_n_3 }),
        .CYINIT(1'b1),
        .DI({\rgb_out[23]_i_1744_n_0 ,\REC_U/local_y [5],1'b0,\rgb_out[23]_i_1745_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_1087_O_UNCONNECTED [3:0]),
        .S({\rgb_out[23]_i_1746_n_0 ,\rgb_out[23]_i_1747_n_0 ,\rgb_out[23]_i_1748_n_0 ,\rgb_out[23]_i_1749_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_1092 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_1092_n_0 ,\rgb_out_reg[23]_i_1092_n_1 ,\rgb_out_reg[23]_i_1092_n_2 ,\rgb_out_reg[23]_i_1092_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\rgb_out[23]_i_1750_n_0 ,\rgb_out[23]_i_1751_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_1092_O_UNCONNECTED [3:0]),
        .S({\rgb_out[23]_i_1752_n_0 ,\rgb_out[23]_i_1753_n_0 ,\rgb_out[23]_i_1754_n_0 ,\rgb_out[23]_i_1755_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_1096 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_1096_n_0 ,\rgb_out_reg[23]_i_1096_n_1 ,\rgb_out_reg[23]_i_1096_n_2 ,\rgb_out_reg[23]_i_1096_n_3 }),
        .CYINIT(1'b1),
        .DI({\rgb_out[23]_i_1756_n_0 ,\REC_U/local_x [5],1'b0,\rgb_out[23]_i_1757_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_1096_O_UNCONNECTED [3:0]),
        .S({\rgb_out[23]_i_1758_n_0 ,\rgb_out[23]_i_1759_n_0 ,\rgb_out[23]_i_1760_n_0 ,\rgb_out[23]_i_1761_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_1101 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_1101_n_0 ,\rgb_out_reg[23]_i_1101_n_1 ,\rgb_out_reg[23]_i_1101_n_2 ,\rgb_out_reg[23]_i_1101_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,\rgb_out[23]_i_1762_n_0 ,\rgb_out[23]_i_1763_n_0 ,\rgb_out[23]_i_1764_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_1101_O_UNCONNECTED [3:0]),
        .S({\rgb_out[23]_i_1765_n_0 ,\rgb_out[23]_i_1766_n_0 ,\rgb_out[23]_i_1767_n_0 ,\rgb_out[23]_i_1768_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_1105 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_1105_n_0 ,\rgb_out_reg[23]_i_1105_n_1 ,\rgb_out_reg[23]_i_1105_n_2 ,\rgb_out_reg[23]_i_1105_n_3 }),
        .CYINIT(1'b1),
        .DI({\rgb_out[23]_i_1769_n_0 ,\rgb_out[23]_i_1770_n_0 ,\REC_U/local_y [3],\rgb_out[23]_i_1772_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_1105_O_UNCONNECTED [3:0]),
        .S({\rgb_out[23]_i_1773_n_0 ,\rgb_out[23]_i_1774_n_0 ,\rgb_out[23]_i_1775_n_0 ,\rgb_out[23]_i_1776_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_1110 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_1110_n_0 ,\rgb_out_reg[23]_i_1110_n_1 ,\rgb_out_reg[23]_i_1110_n_2 ,\rgb_out_reg[23]_i_1110_n_3 }),
        .CYINIT(1'b1),
        .DI({\rgb_out[23]_i_1777_n_0 ,\rgb_out[23]_i_1778_n_0 ,\REC_U/local_x [3],\rgb_out[23]_i_1780_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_1110_O_UNCONNECTED [3:0]),
        .S({\rgb_out[23]_i_1781_n_0 ,\rgb_out[23]_i_1782_n_0 ,\rgb_out[23]_i_1783_n_0 ,\rgb_out[23]_i_1784_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_1115 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_1115_n_0 ,\rgb_out_reg[23]_i_1115_n_1 ,\rgb_out_reg[23]_i_1115_n_2 ,\rgb_out_reg[23]_i_1115_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,\rgb_out[23]_i_1785_n_0 ,\rgb_out[23]_i_1786_n_0 ,\rgb_out[23]_i_1787_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_1115_O_UNCONNECTED [3:0]),
        .S({\rgb_out[23]_i_1788_n_0 ,\rgb_out[23]_i_1789_n_0 ,\rgb_out[23]_i_1790_n_0 ,\rgb_out[23]_i_1791_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_1119 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_1119_n_0 ,\rgb_out_reg[23]_i_1119_n_1 ,\rgb_out_reg[23]_i_1119_n_2 ,\rgb_out_reg[23]_i_1119_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\rgb_out[23]_i_1792_n_0 ,\rgb_out[23]_i_1793_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_1119_O_UNCONNECTED [3:0]),
        .S({\rgb_out[23]_i_1794_n_0 ,\rgb_out[23]_i_1795_n_0 ,\rgb_out[23]_i_1796_n_0 ,\rgb_out[23]_i_1797_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_1123 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_1123_n_0 ,\rgb_out_reg[23]_i_1123_n_1 ,\rgb_out_reg[23]_i_1123_n_2 ,\rgb_out_reg[23]_i_1123_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,\rgb_out[23]_i_1798_n_0 ,1'b0,\rgb_out[23]_i_1799_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_1123_O_UNCONNECTED [3:0]),
        .S({\rgb_out[23]_i_1800_n_0 ,\rgb_out[23]_i_1801_n_0 ,\rgb_out[23]_i_1802_n_0 ,\rgb_out[23]_i_1803_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_1127 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_1127_n_0 ,\rgb_out_reg[23]_i_1127_n_1 ,\rgb_out_reg[23]_i_1127_n_2 ,\rgb_out_reg[23]_i_1127_n_3 }),
        .CYINIT(1'b1),
        .DI({\rgb_out[23]_i_1804_n_0 ,\REC_U/local_y [5],\rgb_out[23]_i_1805_n_0 ,1'b0}),
        .O(\NLW_rgb_out_reg[23]_i_1127_O_UNCONNECTED [3:0]),
        .S({\rgb_out[23]_i_1806_n_0 ,\rgb_out[23]_i_1807_n_0 ,\rgb_out[23]_i_1808_n_0 ,\rgb_out[23]_i_1809_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_1132 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_1132_n_0 ,\rgb_out_reg[23]_i_1132_n_1 ,\rgb_out_reg[23]_i_1132_n_2 ,\rgb_out_reg[23]_i_1132_n_3 }),
        .CYINIT(1'b1),
        .DI({\rgb_out[23]_i_1810_n_0 ,1'b0,\REC_U/local_y [3],\rgb_out[23]_i_1811_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_1132_O_UNCONNECTED [3:0]),
        .S({\rgb_out[23]_i_1812_n_0 ,\rgb_out[23]_i_1813_n_0 ,\rgb_out[23]_i_1814_n_0 ,\rgb_out[23]_i_1815_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_1137 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_1137_n_0 ,\rgb_out_reg[23]_i_1137_n_1 ,\rgb_out_reg[23]_i_1137_n_2 ,\rgb_out_reg[23]_i_1137_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\rgb_out[23]_i_1816_n_0 ,\rgb_out[23]_i_1817_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_1137_O_UNCONNECTED [3:0]),
        .S({\rgb_out[23]_i_1818_n_0 ,\rgb_out[23]_i_1819_n_0 ,\rgb_out[23]_i_1820_n_0 ,\rgb_out[23]_i_1821_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_1139 
       (.CI(\rgb_out_reg[23]_i_1822_n_0 ),
        .CO({\rgb_out_reg[23]_i_1139_n_0 ,\NLW_rgb_out_reg[23]_i_1139_CO_UNCONNECTED [2],\rgb_out_reg[23]_i_1139_n_2 ,\rgb_out_reg[23]_i_1139_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,pixel_y[11:9]}),
        .O({\NLW_rgb_out_reg[23]_i_1139_O_UNCONNECTED [3],\LAST_D/local_y [11:9]}),
        .S({1'b1,\rgb_out[23]_i_1823_n_0 ,\rgb_out[23]_i_1824_n_0 ,\rgb_out[23]_i_1825_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_1142 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_1142_n_0 ,\rgb_out_reg[23]_i_1142_n_1 ,\rgb_out_reg[23]_i_1142_n_2 ,\rgb_out_reg[23]_i_1142_n_3 }),
        .CYINIT(1'b1),
        .DI({\rgb_out[23]_i_1826_n_0 ,1'b0,\LAST_D/local_y [3],\rgb_out[23]_i_1828_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_1142_O_UNCONNECTED [3:0]),
        .S({\rgb_out[23]_i_1829_n_0 ,\rgb_out[23]_i_1830_n_0 ,\rgb_out[23]_i_1831_n_0 ,\rgb_out[23]_i_1832_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_1147 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_1147_n_0 ,\rgb_out_reg[23]_i_1147_n_1 ,\rgb_out_reg[23]_i_1147_n_2 ,\rgb_out_reg[23]_i_1147_n_3 }),
        .CYINIT(1'b1),
        .DI({\rgb_out[23]_i_1833_n_0 ,\rgb_out[23]_i_1834_n_0 ,\LAST_D/local_x [3],\rgb_out[23]_i_1836_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_1147_O_UNCONNECTED [3:0]),
        .S({\rgb_out[23]_i_1837_n_0 ,\rgb_out[23]_i_1838_n_0 ,\rgb_out[23]_i_1839_n_0 ,\rgb_out[23]_i_1840_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_1152 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_1152_n_0 ,\rgb_out_reg[23]_i_1152_n_1 ,\rgb_out_reg[23]_i_1152_n_2 ,\rgb_out_reg[23]_i_1152_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,\rgb_out[23]_i_1841_n_0 ,\rgb_out[23]_i_1842_n_0 ,\rgb_out[23]_i_1843_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_1152_O_UNCONNECTED [3:0]),
        .S({\rgb_out[23]_i_1844_n_0 ,\rgb_out[23]_i_1845_n_0 ,\rgb_out[23]_i_1846_n_0 ,\rgb_out[23]_i_1847_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_1156 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_1156_n_0 ,\rgb_out_reg[23]_i_1156_n_1 ,\rgb_out_reg[23]_i_1156_n_2 ,\rgb_out_reg[23]_i_1156_n_3 }),
        .CYINIT(1'b1),
        .DI({\rgb_out[23]_i_1848_n_0 ,\rgb_out[23]_i_1849_n_0 ,\LAST_D/local_y [3],\rgb_out[23]_i_1850_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_1156_O_UNCONNECTED [3:0]),
        .S({\rgb_out[23]_i_1851_n_0 ,\rgb_out[23]_i_1852_n_0 ,\rgb_out[23]_i_1853_n_0 ,\rgb_out[23]_i_1854_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_1161 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_1161_n_0 ,\rgb_out_reg[23]_i_1161_n_1 ,\rgb_out_reg[23]_i_1161_n_2 ,\rgb_out_reg[23]_i_1161_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,\rgb_out[23]_i_1855_n_0 ,\rgb_out[23]_i_1856_n_0 ,\rgb_out[23]_i_1857_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_1161_O_UNCONNECTED [3:0]),
        .S({\rgb_out[23]_i_1858_n_0 ,\rgb_out[23]_i_1859_n_0 ,\rgb_out[23]_i_1860_n_0 ,\rgb_out[23]_i_1861_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_1165 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_1165_n_0 ,\rgb_out_reg[23]_i_1165_n_1 ,\rgb_out_reg[23]_i_1165_n_2 ,\rgb_out_reg[23]_i_1165_n_3 }),
        .CYINIT(1'b1),
        .DI({\rgb_out[23]_i_1862_n_0 ,\LAST_D/local_y [5],1'b0,\rgb_out[23]_i_1863_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_1165_O_UNCONNECTED [3:0]),
        .S({\rgb_out[23]_i_1864_n_0 ,\rgb_out[23]_i_1865_n_0 ,\rgb_out[23]_i_1866_n_0 ,\rgb_out[23]_i_1867_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_1170 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_1170_n_0 ,\rgb_out_reg[23]_i_1170_n_1 ,\rgb_out_reg[23]_i_1170_n_2 ,\rgb_out_reg[23]_i_1170_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,\rgb_out[23]_i_1868_n_0 ,\rgb_out[23]_i_1869_n_0 ,\rgb_out[23]_i_1870_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_1170_O_UNCONNECTED [3:0]),
        .S({\rgb_out[23]_i_1871_n_0 ,\rgb_out[23]_i_1872_n_0 ,\rgb_out[23]_i_1873_n_0 ,\rgb_out[23]_i_1874_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_1175 
       (.CI(\rgb_out_reg[23]_i_1835_n_0 ),
        .CO({\rgb_out_reg[23]_i_1175_n_0 ,\rgb_out_reg[23]_i_1175_n_1 ,\rgb_out_reg[23]_i_1175_n_2 ,\rgb_out_reg[23]_i_1175_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,pixel_x[7],1'b0,1'b0}),
        .O(\LAST_D/local_x [8:5]),
        .S({pixel_x[8],\rgb_out[23]_i_1875_n_0 ,pixel_x[6:5]}));
  CARRY4 \rgb_out_reg[23]_i_1190 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_1190_n_0 ,\rgb_out_reg[23]_i_1190_n_1 ,\rgb_out_reg[23]_i_1190_n_2 ,\rgb_out_reg[23]_i_1190_n_3 }),
        .CYINIT(1'b1),
        .DI({\rgb_out[23]_i_1876_n_0 ,\rgb_out[23]_i_1877_n_0 ,\rgb_out[23]_i_1878_n_0 ,\rgb_out[23]_i_1879_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_1190_O_UNCONNECTED [3:0]),
        .S({\rgb_out[23]_i_1880_n_0 ,\rgb_out[23]_i_1881_n_0 ,\rgb_out[23]_i_1882_n_0 ,\rgb_out[23]_i_1883_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_1195 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_1195_n_0 ,\rgb_out_reg[23]_i_1195_n_1 ,\rgb_out_reg[23]_i_1195_n_2 ,\rgb_out_reg[23]_i_1195_n_3 }),
        .CYINIT(1'b1),
        .DI({\rgb_out[23]_i_1884_n_0 ,\rgb_out[23]_i_1885_n_0 ,\rgb_out[23]_i_1886_n_0 ,\rgb_out[23]_i_1887_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_1195_O_UNCONNECTED [3:0]),
        .S({\rgb_out[23]_i_1888_n_0 ,\rgb_out[23]_i_1889_n_0 ,\rgb_out[23]_i_1890_n_0 ,\rgb_out[23]_i_1891_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_1200 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_1200_n_0 ,\rgb_out_reg[23]_i_1200_n_1 ,\rgb_out_reg[23]_i_1200_n_2 ,\rgb_out_reg[23]_i_1200_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\rgb_out[23]_i_1892_n_0 ,\rgb_out[23]_i_1893_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_1200_O_UNCONNECTED [3:0]),
        .S({\rgb_out[23]_i_1894_n_0 ,\rgb_out[23]_i_1895_n_0 ,\rgb_out[23]_i_1896_n_0 ,\rgb_out[23]_i_1897_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_1203 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_1203_n_0 ,\rgb_out_reg[23]_i_1203_n_1 ,\rgb_out_reg[23]_i_1203_n_2 ,\rgb_out_reg[23]_i_1203_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\rgb_out[23]_i_1898_n_0 ,\rgb_out[23]_i_1899_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_1203_O_UNCONNECTED [3:0]),
        .S({\rgb_out[23]_i_1900_n_0 ,\rgb_out[23]_i_1901_n_0 ,\rgb_out[23]_i_1902_n_0 ,\rgb_out[23]_i_1903_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_1217 
       (.CI(\rgb_out_reg[23]_i_1904_n_0 ),
        .CO({\rgb_out_reg[23]_i_1217_n_0 ,\rgb_out_reg[23]_i_1217_n_1 ,\rgb_out_reg[23]_i_1217_n_2 ,\rgb_out_reg[23]_i_1217_n_3 }),
        .CYINIT(1'b0),
        .DI(pixel_x[11:8]),
        .O(\SC_U/local_x [11:8]),
        .S({\rgb_out[23]_i_1906_n_0 ,\rgb_out[23]_i_1907_n_0 ,\rgb_out[23]_i_1908_n_0 ,\rgb_out[23]_i_1909_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_1224 
       (.CI(\rgb_out_reg[23]_i_1910_n_0 ),
        .CO({\rgb_out_reg[23]_i_1224_n_0 ,\rgb_out_reg[23]_i_1224_n_1 ,\rgb_out_reg[23]_i_1224_n_2 ,\rgb_out_reg[23]_i_1224_n_3 }),
        .CYINIT(1'b0),
        .DI(pixel_y[8:5]),
        .O(\SC_U/local_y [8:5]),
        .S({\rgb_out[23]_i_1911_n_0 ,\rgb_out[23]_i_1912_n_0 ,\rgb_out[23]_i_1913_n_0 ,\rgb_out[23]_i_1914_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_1244 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_1244_n_0 ,\rgb_out_reg[23]_i_1244_n_1 ,\rgb_out_reg[23]_i_1244_n_2 ,\rgb_out_reg[23]_i_1244_n_3 }),
        .CYINIT(1'b1),
        .DI({\rgb_out[23]_i_1915_n_0 ,1'b0,\SC_U/local_y [3],\rgb_out[23]_i_1916_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_1244_O_UNCONNECTED [3:0]),
        .S({\rgb_out[23]_i_1917_n_0 ,\rgb_out[23]_i_1918_n_0 ,\rgb_out[23]_i_1919_n_0 ,\rgb_out[23]_i_1920_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_1249 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_1249_n_0 ,\rgb_out_reg[23]_i_1249_n_1 ,\rgb_out_reg[23]_i_1249_n_2 ,\rgb_out_reg[23]_i_1249_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,\rgb_out[23]_i_1921_n_0 ,\rgb_out[23]_i_1922_n_0 ,\rgb_out[23]_i_1923_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_1249_O_UNCONNECTED [3:0]),
        .S({\rgb_out[23]_i_1924_n_0 ,\rgb_out[23]_i_1925_n_0 ,\rgb_out[23]_i_1926_n_0 ,\rgb_out[23]_i_1927_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_1258 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_1258_n_0 ,\rgb_out_reg[23]_i_1258_n_1 ,\rgb_out_reg[23]_i_1258_n_2 ,\rgb_out_reg[23]_i_1258_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,\rgb_out[23]_i_1935_n_0 ,1'b0,\rgb_out[23]_i_1936_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_1258_O_UNCONNECTED [3:0]),
        .S({\rgb_out[23]_i_1937_n_0 ,\rgb_out[23]_i_1938_n_0 ,\rgb_out[23]_i_1939_n_0 ,\rgb_out[23]_i_1940_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_1262 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_1262_n_0 ,\rgb_out_reg[23]_i_1262_n_1 ,\rgb_out_reg[23]_i_1262_n_2 ,\rgb_out_reg[23]_i_1262_n_3 }),
        .CYINIT(1'b1),
        .DI({\rgb_out[23]_i_1941_n_0 ,\SC_U/local_y [5],\rgb_out[23]_i_1942_n_0 ,1'b0}),
        .O(\NLW_rgb_out_reg[23]_i_1262_O_UNCONNECTED [3:0]),
        .S({\rgb_out[23]_i_1943_n_0 ,\rgb_out[23]_i_1944_n_0 ,\rgb_out[23]_i_1945_n_0 ,\rgb_out[23]_i_1946_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_1267 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_1267_n_0 ,\rgb_out_reg[23]_i_1267_n_1 ,\rgb_out_reg[23]_i_1267_n_2 ,\rgb_out_reg[23]_i_1267_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\rgb_out[23]_i_1947_n_0 ,\rgb_out[23]_i_1948_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_1267_O_UNCONNECTED [3:0]),
        .S({\rgb_out[23]_i_1949_n_0 ,\rgb_out[23]_i_1950_n_0 ,\rgb_out[23]_i_1951_n_0 ,\rgb_out[23]_i_1952_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_1271 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_1271_n_0 ,\rgb_out_reg[23]_i_1271_n_1 ,\rgb_out_reg[23]_i_1271_n_2 ,\rgb_out_reg[23]_i_1271_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,\rgb_out[23]_i_1953_n_0 ,\rgb_out[23]_i_1954_n_0 ,\rgb_out[23]_i_1955_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_1271_O_UNCONNECTED [3:0]),
        .S({\rgb_out[23]_i_1956_n_0 ,\rgb_out[23]_i_1957_n_0 ,\rgb_out[23]_i_1958_n_0 ,\rgb_out[23]_i_1959_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_1275 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_1275_n_0 ,\rgb_out_reg[23]_i_1275_n_1 ,\rgb_out_reg[23]_i_1275_n_2 ,\rgb_out_reg[23]_i_1275_n_3 }),
        .CYINIT(1'b1),
        .DI({\rgb_out[23]_i_1960_n_0 ,\rgb_out[23]_i_1961_n_0 ,\SC_U/local_y [3],\rgb_out[23]_i_1962_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_1275_O_UNCONNECTED [3:0]),
        .S({\rgb_out[23]_i_1963_n_0 ,\rgb_out[23]_i_1964_n_0 ,\rgb_out[23]_i_1965_n_0 ,\rgb_out[23]_i_1966_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_1280 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_1280_n_0 ,\rgb_out_reg[23]_i_1280_n_1 ,\rgb_out_reg[23]_i_1280_n_2 ,\rgb_out_reg[23]_i_1280_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\rgb_out[23]_i_1967_n_0 ,\rgb_out[23]_i_1968_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_1280_O_UNCONNECTED [3:0]),
        .S({\rgb_out[23]_i_1969_n_0 ,\rgb_out[23]_i_1970_n_0 ,\rgb_out[23]_i_1971_n_0 ,\rgb_out[23]_i_1972_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_1284 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_1284_n_0 ,\rgb_out_reg[23]_i_1284_n_1 ,\rgb_out_reg[23]_i_1284_n_2 ,\rgb_out_reg[23]_i_1284_n_3 }),
        .CYINIT(1'b1),
        .DI({\rgb_out[23]_i_1973_n_0 ,\SC_U/local_x [5],1'b0,\rgb_out[23]_i_1974_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_1284_O_UNCONNECTED [3:0]),
        .S({\rgb_out[23]_i_1975_n_0 ,\rgb_out[23]_i_1976_n_0 ,\rgb_out[23]_i_1977_n_0 ,\rgb_out[23]_i_1978_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_1289 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_1289_n_0 ,\rgb_out_reg[23]_i_1289_n_1 ,\rgb_out_reg[23]_i_1289_n_2 ,\rgb_out_reg[23]_i_1289_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,\rgb_out[23]_i_1979_n_0 ,\rgb_out[23]_i_1980_n_0 ,\rgb_out[23]_i_1981_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_1289_O_UNCONNECTED [3:0]),
        .S({\rgb_out[23]_i_1982_n_0 ,\rgb_out[23]_i_1983_n_0 ,\rgb_out[23]_i_1984_n_0 ,\rgb_out[23]_i_1985_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_1293 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_1293_n_0 ,\rgb_out_reg[23]_i_1293_n_1 ,\rgb_out_reg[23]_i_1293_n_2 ,\rgb_out_reg[23]_i_1293_n_3 }),
        .CYINIT(1'b1),
        .DI({\rgb_out[23]_i_1986_n_0 ,\SC_U/local_y [5],1'b0,\rgb_out[23]_i_1987_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_1293_O_UNCONNECTED [3:0]),
        .S({\rgb_out[23]_i_1988_n_0 ,\rgb_out[23]_i_1989_n_0 ,\rgb_out[23]_i_1990_n_0 ,\rgb_out[23]_i_1991_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_1298 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_1298_n_0 ,\rgb_out_reg[23]_i_1298_n_1 ,\rgb_out_reg[23]_i_1298_n_2 ,\rgb_out_reg[23]_i_1298_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\rgb_out[23]_i_1992_n_0 ,\rgb_out[23]_i_1993_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_1298_O_UNCONNECTED [3:0]),
        .S({\rgb_out[23]_i_1994_n_0 ,\rgb_out[23]_i_1995_n_0 ,\rgb_out[23]_i_1996_n_0 ,\rgb_out[23]_i_1997_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_1303 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_1303_n_0 ,\rgb_out_reg[23]_i_1303_n_1 ,\rgb_out_reg[23]_i_1303_n_2 ,\rgb_out_reg[23]_i_1303_n_3 }),
        .CYINIT(1'b1),
        .DI({\rgb_out[23]_i_2002_n_0 ,1'b0,\SC_D/local_y [3],\rgb_out[23]_i_2004_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_1303_O_UNCONNECTED [3:0]),
        .S({\rgb_out[23]_i_2005_n_0 ,\rgb_out[23]_i_2006_n_0 ,\rgb_out[23]_i_2007_n_0 ,\rgb_out[23]_i_2008_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_1313 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_1313_n_0 ,\rgb_out_reg[23]_i_1313_n_1 ,\rgb_out_reg[23]_i_1313_n_2 ,\rgb_out_reg[23]_i_1313_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,\rgb_out[23]_i_2017_n_0 ,\rgb_out[23]_i_2018_n_0 ,\rgb_out[23]_i_2019_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_1313_O_UNCONNECTED [3:0]),
        .S({\rgb_out[23]_i_2020_n_0 ,\rgb_out[23]_i_2021_n_0 ,\rgb_out[23]_i_2022_n_0 ,\rgb_out[23]_i_2023_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_1326 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_1326_n_0 ,\rgb_out_reg[23]_i_1326_n_1 ,\rgb_out_reg[23]_i_1326_n_2 ,\rgb_out_reg[23]_i_1326_n_3 }),
        .CYINIT(1'b1),
        .DI({\rgb_out[23]_i_2038_n_0 ,\SC_D/local_y [5],1'b0,\rgb_out[23]_i_2039_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_1326_O_UNCONNECTED [3:0]),
        .S({\rgb_out[23]_i_2040_n_0 ,\rgb_out[23]_i_2041_n_0 ,\rgb_out[23]_i_2042_n_0 ,\rgb_out[23]_i_2043_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_1336 
       (.CI(\rgb_out_reg[23]_i_2011_n_0 ),
        .CO({\rgb_out_reg[23]_i_1336_n_0 ,\rgb_out_reg[23]_i_1336_n_1 ,\rgb_out_reg[23]_i_1336_n_2 ,\rgb_out_reg[23]_i_1336_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,pixel_x[6:5],1'b0}),
        .O(\SC_D/local_x [7:4]),
        .S({pixel_x[7],\rgb_out[23]_i_2051_n_0 ,\rgb_out[23]_i_2052_n_0 ,pixel_x[4]}));
  CARRY4 \rgb_out_reg[23]_i_1342 
       (.CI(\rgb_out_reg[23]_i_1336_n_0 ),
        .CO({\rgb_out_reg[23]_i_1342_n_0 ,\rgb_out_reg[23]_i_1342_n_1 ,\rgb_out_reg[23]_i_1342_n_2 ,\rgb_out_reg[23]_i_1342_n_3 }),
        .CYINIT(1'b0),
        .DI(pixel_x[11:8]),
        .O(\SC_D/local_x [11:8]),
        .S({\rgb_out[23]_i_2053_n_0 ,\rgb_out[23]_i_2054_n_0 ,\rgb_out[23]_i_2055_n_0 ,\rgb_out[23]_i_2056_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_1349 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_1349_n_0 ,\rgb_out_reg[23]_i_1349_n_1 ,\rgb_out_reg[23]_i_1349_n_2 ,\rgb_out_reg[23]_i_1349_n_3 }),
        .CYINIT(1'b1),
        .DI({\rgb_out[23]_i_2057_n_0 ,\rgb_out[23]_i_2058_n_0 ,\rgb_out[23]_i_2059_n_0 ,\rgb_out[23]_i_2060_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_1349_O_UNCONNECTED [3:0]),
        .S({\rgb_out[23]_i_2061_n_0 ,\rgb_out[23]_i_2062_n_0 ,\rgb_out[23]_i_2063_n_0 ,\rgb_out[23]_i_2064_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_1354 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_1354_n_0 ,\rgb_out_reg[23]_i_1354_n_1 ,\rgb_out_reg[23]_i_1354_n_2 ,\rgb_out_reg[23]_i_1354_n_3 }),
        .CYINIT(1'b1),
        .DI({\rgb_out[23]_i_2065_n_0 ,\rgb_out[23]_i_2066_n_0 ,\rgb_out[23]_i_2067_n_0 ,\rgb_out[23]_i_2068_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_1354_O_UNCONNECTED [3:0]),
        .S({\rgb_out[23]_i_2069_n_0 ,\rgb_out[23]_i_2070_n_0 ,\rgb_out[23]_i_2071_n_0 ,\rgb_out[23]_i_2072_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_1359 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_1359_n_0 ,\rgb_out_reg[23]_i_1359_n_1 ,\rgb_out_reg[23]_i_1359_n_2 ,\rgb_out_reg[23]_i_1359_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\rgb_out[23]_i_2073_n_0 ,\rgb_out[23]_i_2074_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_1359_O_UNCONNECTED [3:0]),
        .S({\rgb_out[23]_i_2075_n_0 ,\rgb_out[23]_i_2076_n_0 ,\rgb_out[23]_i_2077_n_0 ,\rgb_out[23]_i_2078_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_1362 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_1362_n_0 ,\rgb_out_reg[23]_i_1362_n_1 ,\rgb_out_reg[23]_i_1362_n_2 ,\rgb_out_reg[23]_i_1362_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\rgb_out[23]_i_2079_n_0 ,\rgb_out[23]_i_2080_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_1362_O_UNCONNECTED [3:0]),
        .S({\rgb_out[23]_i_2081_n_0 ,\rgb_out[23]_i_2082_n_0 ,\rgb_out[23]_i_2083_n_0 ,\rgb_out[23]_i_2084_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_1371 
       (.CI(\rgb_out_reg[23]_i_1376_n_0 ),
        .CO({\rgb_out_reg[23]_i_1371_n_0 ,\rgb_out_reg[23]_i_1371_n_1 ,\rgb_out_reg[23]_i_1371_n_2 ,\rgb_out_reg[23]_i_1371_n_3 }),
        .CYINIT(1'b0),
        .DI(pixel_y[8:5]),
        .O(\TM_D/local_y [8:5]),
        .S({\rgb_out[23]_i_2085_n_0 ,\rgb_out[23]_i_2086_n_0 ,\rgb_out[23]_i_2087_n_0 ,\rgb_out[23]_i_2088_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_1376 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_1376_n_0 ,\rgb_out_reg[23]_i_1376_n_1 ,\rgb_out_reg[23]_i_1376_n_2 ,\rgb_out_reg[23]_i_1376_n_3 }),
        .CYINIT(1'b0),
        .DI({pixel_y[4],1'b0,pixel_y[2],1'b0}),
        .O(\TM_D/local_y [4:1]),
        .S({\rgb_out[23]_i_2089_n_0 ,pixel_y[3],\rgb_out[23]_i_2090_n_0 ,pixel_y[1]}));
  CARRY4 \rgb_out_reg[23]_i_1503 
       (.CI(\rgb_out_reg[23]_i_1508_n_0 ),
        .CO({\rgb_out_reg[23]_i_1503_n_0 ,\rgb_out_reg[23]_i_1503_n_1 ,\rgb_out_reg[23]_i_1503_n_2 ,\rgb_out_reg[23]_i_1503_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,pixel_y[5]}),
        .O(\REC_D/local_y [8:5]),
        .S({pixel_y[8:6],\rgb_out[23]_i_2091_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_1508 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_1508_n_0 ,\rgb_out_reg[23]_i_1508_n_1 ,\rgb_out_reg[23]_i_1508_n_2 ,\rgb_out_reg[23]_i_1508_n_3 }),
        .CYINIT(pixel_y[0]),
        .DI({pixel_y[4:3],1'b0,pixel_y[1]}),
        .O(\REC_D/local_y [4:1]),
        .S({\rgb_out[23]_i_2092_n_0 ,\rgb_out[23]_i_2093_n_0 ,pixel_y[2],\rgb_out[23]_i_2094_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_1516 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_1516_n_0 ,\rgb_out_reg[23]_i_1516_n_1 ,\rgb_out_reg[23]_i_1516_n_2 ,\rgb_out_reg[23]_i_1516_n_3 }),
        .CYINIT(pixel_x[0]),
        .DI({pixel_x[4:2],1'b0}),
        .O(\REC_D/local_x [4:1]),
        .S({\rgb_out[23]_i_2095_n_0 ,\rgb_out[23]_i_2096_n_0 ,\rgb_out[23]_i_2097_n_0 ,pixel_x[1]}));
  CARRY4 \rgb_out_reg[23]_i_1593 
       (.CI(\rgb_out_reg[23]_i_1665_n_0 ),
        .CO({\rgb_out_reg[23]_i_1593_n_0 ,\rgb_out_reg[23]_i_1593_n_1 ,\rgb_out_reg[23]_i_1593_n_2 ,\rgb_out_reg[23]_i_1593_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,pixel_x[6:5]}),
        .O(\LAST_U/local_x [8:5]),
        .S({pixel_x[8:7],\rgb_out[23]_i_2098_n_0 ,\rgb_out[23]_i_2099_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_1603 
       (.CI(\rgb_out_reg[23]_i_1657_n_0 ),
        .CO({\rgb_out_reg[23]_i_1603_n_0 ,\rgb_out_reg[23]_i_1603_n_1 ,\rgb_out_reg[23]_i_1603_n_2 ,\rgb_out_reg[23]_i_1603_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,pixel_y[5]}),
        .O(\LAST_U/local_y [8:5]),
        .S({pixel_y[8:6],\rgb_out[23]_i_2100_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_1657 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_1657_n_0 ,\rgb_out_reg[23]_i_1657_n_1 ,\rgb_out_reg[23]_i_1657_n_2 ,\rgb_out_reg[23]_i_1657_n_3 }),
        .CYINIT(pixel_y[0]),
        .DI({pixel_y[4:3],1'b0,pixel_y[1]}),
        .O(\LAST_U/local_y [4:1]),
        .S({\rgb_out[23]_i_2101_n_0 ,\rgb_out[23]_i_2102_n_0 ,pixel_y[2],\rgb_out[23]_i_2103_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_1665 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_1665_n_0 ,\rgb_out_reg[23]_i_1665_n_1 ,\rgb_out_reg[23]_i_1665_n_2 ,\rgb_out_reg[23]_i_1665_n_3 }),
        .CYINIT(pixel_x[0]),
        .DI({pixel_x[4],1'b0,pixel_x[2],1'b0}),
        .O(\LAST_U/local_x [4:1]),
        .S({\rgb_out[23]_i_2104_n_0 ,pixel_x[3],\rgb_out[23]_i_2105_n_0 ,pixel_x[1]}));
  CARRY4 \rgb_out_reg[23]_i_1708 
       (.CI(\rgb_out_reg[23]_i_1779_n_0 ),
        .CO({\rgb_out_reg[23]_i_1708_n_0 ,\rgb_out_reg[23]_i_1708_n_1 ,\rgb_out_reg[23]_i_1708_n_2 ,\rgb_out_reg[23]_i_1708_n_3 }),
        .CYINIT(1'b0),
        .DI({pixel_x[8],1'b0,pixel_x[6],1'b0}),
        .O(\REC_U/local_x [8:5]),
        .S({\rgb_out[23]_i_2106_n_0 ,pixel_x[7],\rgb_out[23]_i_2107_n_0 ,pixel_x[5]}));
  CARRY4 \rgb_out_reg[23]_i_1717 
       (.CI(\rgb_out_reg[23]_i_1771_n_0 ),
        .CO({\rgb_out_reg[23]_i_1717_n_0 ,\rgb_out_reg[23]_i_1717_n_1 ,\rgb_out_reg[23]_i_1717_n_2 ,\rgb_out_reg[23]_i_1717_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,pixel_y[5]}),
        .O(\REC_U/local_y [8:5]),
        .S({pixel_y[8:6],\rgb_out[23]_i_2108_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_1771 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_1771_n_0 ,\rgb_out_reg[23]_i_1771_n_1 ,\rgb_out_reg[23]_i_1771_n_2 ,\rgb_out_reg[23]_i_1771_n_3 }),
        .CYINIT(pixel_y[0]),
        .DI({pixel_y[4:3],1'b0,pixel_y[1]}),
        .O(\REC_U/local_y [4:1]),
        .S({\rgb_out[23]_i_2109_n_0 ,\rgb_out[23]_i_2110_n_0 ,pixel_y[2],\rgb_out[23]_i_2111_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_1779 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_1779_n_0 ,\rgb_out_reg[23]_i_1779_n_1 ,\rgb_out_reg[23]_i_1779_n_2 ,\rgb_out_reg[23]_i_1779_n_3 }),
        .CYINIT(pixel_x[0]),
        .DI({pixel_x[4],1'b0,pixel_x[2],1'b0}),
        .O(\REC_U/local_x [4:1]),
        .S({\rgb_out[23]_i_2112_n_0 ,pixel_x[3],\rgb_out[23]_i_2113_n_0 ,pixel_x[1]}));
  CARRY4 \rgb_out_reg[23]_i_1822 
       (.CI(\rgb_out_reg[23]_i_1827_n_0 ),
        .CO({\rgb_out_reg[23]_i_1822_n_0 ,\rgb_out_reg[23]_i_1822_n_1 ,\rgb_out_reg[23]_i_1822_n_2 ,\rgb_out_reg[23]_i_1822_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,pixel_y[5]}),
        .O(\LAST_D/local_y [8:5]),
        .S({pixel_y[8:6],\rgb_out[23]_i_2114_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_1827 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_1827_n_0 ,\rgb_out_reg[23]_i_1827_n_1 ,\rgb_out_reg[23]_i_1827_n_2 ,\rgb_out_reg[23]_i_1827_n_3 }),
        .CYINIT(pixel_y[0]),
        .DI({pixel_y[4:3],1'b0,pixel_y[1]}),
        .O(\LAST_D/local_y [4:1]),
        .S({\rgb_out[23]_i_2115_n_0 ,\rgb_out[23]_i_2116_n_0 ,pixel_y[2],\rgb_out[23]_i_2117_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_1835 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_1835_n_0 ,\rgb_out_reg[23]_i_1835_n_1 ,\rgb_out_reg[23]_i_1835_n_2 ,\rgb_out_reg[23]_i_1835_n_3 }),
        .CYINIT(pixel_x[0]),
        .DI({pixel_x[4:2],1'b0}),
        .O(\LAST_D/local_x [4:1]),
        .S({\rgb_out[23]_i_2118_n_0 ,\rgb_out[23]_i_2119_n_0 ,\rgb_out[23]_i_2120_n_0 ,pixel_x[1]}));
  CARRY4 \rgb_out_reg[23]_i_189 
       (.CI(\rgb_out_reg[23]_i_478_n_0 ),
        .CO({\NLW_rgb_out_reg[23]_i_189_CO_UNCONNECTED [3],\TM_D/pixel_on99_in ,\rgb_out_reg[23]_i_189_n_2 ,\rgb_out_reg[23]_i_189_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\rgb_out[23]_i_479_n_0 ,\rgb_out[23]_i_480_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_189_O_UNCONNECTED [3:0]),
        .S({1'b0,\rgb_out_reg[23]_i_481_n_1 ,\rgb_out[23]_i_482_n_0 ,\rgb_out[23]_i_483_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_1904 
       (.CI(\rgb_out_reg[23]_i_1905_n_0 ),
        .CO({\rgb_out_reg[23]_i_1904_n_0 ,\rgb_out_reg[23]_i_1904_n_1 ,\rgb_out_reg[23]_i_1904_n_2 ,\rgb_out_reg[23]_i_1904_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,pixel_x[6],1'b0,1'b0}),
        .O(\SC_U/local_x [7:4]),
        .S({pixel_x[7],\rgb_out[23]_i_2121_n_0 ,pixel_x[5:4]}));
  CARRY4 \rgb_out_reg[23]_i_1905 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_1905_n_0 ,\rgb_out_reg[23]_i_1905_n_1 ,\rgb_out_reg[23]_i_1905_n_2 ,\rgb_out_reg[23]_i_1905_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,pixel_x[1],1'b0}),
        .O(\SC_U/local_x [3:0]),
        .S({pixel_x[3:2],\rgb_out[23]_i_2122_n_0 ,pixel_x[0]}));
  CARRY4 \rgb_out_reg[23]_i_191 
       (.CI(\rgb_out_reg[23]_i_484_n_0 ),
        .CO({\NLW_rgb_out_reg[23]_i_191_CO_UNCONNECTED [3],\TM_D/pixel_on6 ,\rgb_out_reg[23]_i_191_n_2 ,\rgb_out_reg[23]_i_191_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,\rgb_out[23]_i_485_n_0 ,1'b0,1'b0}),
        .O(\NLW_rgb_out_reg[23]_i_191_O_UNCONNECTED [3:0]),
        .S({1'b0,\rgb_out_reg[23]_i_481_n_1 ,\rgb_out[23]_i_486_n_0 ,\rgb_out[23]_i_487_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_1910 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_1910_n_0 ,\rgb_out_reg[23]_i_1910_n_1 ,\rgb_out_reg[23]_i_1910_n_2 ,\rgb_out_reg[23]_i_1910_n_3 }),
        .CYINIT(1'b0),
        .DI({pixel_y[4],1'b0,pixel_y[2],1'b0}),
        .O(\SC_U/local_y [4:1]),
        .S({\rgb_out[23]_i_2123_n_0 ,pixel_y[3],\rgb_out[23]_i_2124_n_0 ,pixel_y[1]}));
  CARRY4 \rgb_out_reg[23]_i_2011 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_2011_n_0 ,\rgb_out_reg[23]_i_2011_n_1 ,\rgb_out_reg[23]_i_2011_n_2 ,\rgb_out_reg[23]_i_2011_n_3 }),
        .CYINIT(1'b0),
        .DI({pixel_x[3],1'b0,pixel_x[1],1'b0}),
        .O(\SC_D/local_x [3:0]),
        .S({\rgb_out[23]_i_2131_n_0 ,pixel_x[2],\rgb_out[23]_i_2132_n_0 ,pixel_x[0]}));
  CARRY4 \rgb_out_reg[23]_i_311 
       (.CI(\rgb_out_reg[23]_i_588_n_0 ),
        .CO({\NLW_rgb_out_reg[23]_i_311_CO_UNCONNECTED [3],\REC_D/pixel_on99_in ,\rgb_out_reg[23]_i_311_n_2 ,\rgb_out_reg[23]_i_311_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\rgb_out[23]_i_589_n_0 ,\rgb_out[23]_i_590_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_311_O_UNCONNECTED [3:0]),
        .S({1'b0,\rgb_out_reg[23]_i_591_n_0 ,\rgb_out[23]_i_592_n_0 ,\rgb_out[23]_i_593_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_313 
       (.CI(\rgb_out_reg[23]_i_594_n_0 ),
        .CO({\NLW_rgb_out_reg[23]_i_313_CO_UNCONNECTED [3],\REC_D/pixel_on6 ,\rgb_out_reg[23]_i_313_n_2 ,\rgb_out_reg[23]_i_313_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,\rgb_out[23]_i_595_n_0 ,1'b0,1'b0}),
        .O(\NLW_rgb_out_reg[23]_i_313_O_UNCONNECTED [3:0]),
        .S({1'b0,\rgb_out_reg[23]_i_591_n_0 ,\rgb_out[23]_i_596_n_0 ,\rgb_out[23]_i_597_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_329 
       (.CI(\rgb_out_reg[23]_i_662_n_0 ),
        .CO({\NLW_rgb_out_reg[23]_i_329_CO_UNCONNECTED [3],\LAST_D/pixel_on99_in ,\rgb_out_reg[23]_i_329_n_2 ,\rgb_out_reg[23]_i_329_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\rgb_out[23]_i_663_n_0 ,\rgb_out[23]_i_664_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_329_O_UNCONNECTED [3:0]),
        .S({1'b0,\rgb_out_reg[23]_i_665_n_0 ,\rgb_out[23]_i_666_n_0 ,\rgb_out[23]_i_667_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_331 
       (.CI(\rgb_out_reg[23]_i_668_n_0 ),
        .CO({\NLW_rgb_out_reg[23]_i_331_CO_UNCONNECTED [3],\LAST_D/pixel_on6 ,\rgb_out_reg[23]_i_331_n_2 ,\rgb_out_reg[23]_i_331_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,\rgb_out[23]_i_669_n_0 ,1'b0,1'b0}),
        .O(\NLW_rgb_out_reg[23]_i_331_O_UNCONNECTED [3:0]),
        .S({1'b0,\rgb_out_reg[23]_i_665_n_0 ,\rgb_out[23]_i_670_n_0 ,\rgb_out[23]_i_671_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_438 
       (.CI(\rgb_out_reg[23]_i_714_n_0 ),
        .CO({\NLW_rgb_out_reg[23]_i_438_CO_UNCONNECTED [3:2],\SC_U/pixel_on4 ,\rgb_out_reg[23]_i_438_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\SC_U/local_x [12],1'b0}),
        .O(\NLW_rgb_out_reg[23]_i_438_O_UNCONNECTED [3:0]),
        .S({1'b0,1'b0,\rgb_out_reg[23]_i_716_n_3 ,\rgb_out[23]_i_717_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_439 
       (.CI(\rgb_out_reg[23]_i_718_n_0 ),
        .CO({\NLW_rgb_out_reg[23]_i_439_CO_UNCONNECTED [3:1],\SC_U/pixel_on2 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,\SC_U/local_y [12]}),
        .O(\NLW_rgb_out_reg[23]_i_439_O_UNCONNECTED [3:0]),
        .S({1'b0,1'b0,1'b0,\rgb_out_reg[23]_i_720_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_440 
       (.CI(\rgb_out_reg[23]_i_721_n_0 ),
        .CO({\NLW_rgb_out_reg[23]_i_440_CO_UNCONNECTED [3],\SC_U/pixel_on40_in ,\rgb_out_reg[23]_i_440_n_2 ,\rgb_out_reg[23]_i_440_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\rgb_out[23]_i_722_n_0 ,\rgb_out[23]_i_723_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_440_O_UNCONNECTED [3:0]),
        .S({1'b0,\rgb_out_reg[23]_i_716_n_3 ,\rgb_out[23]_i_724_n_0 ,\rgb_out[23]_i_725_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_441 
       (.CI(\rgb_out_reg[23]_i_726_n_0 ),
        .CO({\NLW_rgb_out_reg[23]_i_441_CO_UNCONNECTED [3],\SC_U/pixel_on3 ,\rgb_out_reg[23]_i_441_n_2 ,\rgb_out_reg[23]_i_441_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\rgb_out[23]_i_727_n_0 ,\rgb_out[23]_i_728_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_441_O_UNCONNECTED [3:0]),
        .S({1'b0,\rgb_out_reg[23]_i_720_n_0 ,\rgb_out[23]_i_729_n_0 ,\rgb_out[23]_i_730_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_450 
       (.CI(\rgb_out_reg[23]_i_758_n_0 ),
        .CO({\NLW_rgb_out_reg[23]_i_450_CO_UNCONNECTED [3],\SC_D/pixel_on99_in ,\rgb_out_reg[23]_i_450_n_2 ,\rgb_out_reg[23]_i_450_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\rgb_out[23]_i_759_n_0 ,\rgb_out[23]_i_760_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_450_O_UNCONNECTED [3:0]),
        .S({1'b0,\rgb_out_reg[23]_i_761_n_3 ,\rgb_out[23]_i_762_n_0 ,\rgb_out[23]_i_763_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_452 
       (.CI(\rgb_out_reg[23]_i_764_n_0 ),
        .CO({\NLW_rgb_out_reg[23]_i_452_CO_UNCONNECTED [3],\SC_D/pixel_on6 ,\rgb_out_reg[23]_i_452_n_2 ,\rgb_out_reg[23]_i_452_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,\rgb_out[23]_i_765_n_0 ,1'b0,1'b0}),
        .O(\NLW_rgb_out_reg[23]_i_452_O_UNCONNECTED [3:0]),
        .S({1'b0,\rgb_out_reg[23]_i_761_n_3 ,\rgb_out[23]_i_766_n_0 ,\rgb_out[23]_i_767_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_470 
       (.CI(\rgb_out_reg[23]_i_777_n_0 ),
        .CO({\NLW_rgb_out_reg[23]_i_470_CO_UNCONNECTED [3],\TM_D/pixel_on712_in ,\rgb_out_reg[23]_i_470_n_2 ,\rgb_out_reg[23]_i_470_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,\rgb_out[23]_i_778_n_0 ,1'b0,1'b0}),
        .O(\NLW_rgb_out_reg[23]_i_470_O_UNCONNECTED [3:0]),
        .S({1'b0,\rgb_out_reg[23]_i_779_n_0 ,\rgb_out[23]_i_780_n_0 ,\rgb_out[23]_i_781_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_471 
       (.CI(\rgb_out_reg[23]_i_782_n_0 ),
        .CO({\NLW_rgb_out_reg[23]_i_471_CO_UNCONNECTED [3],\TM_D/pixel_on5 ,\rgb_out_reg[23]_i_471_n_2 ,\rgb_out_reg[23]_i_471_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\rgb_out[23]_i_783_n_0 ,\rgb_out[23]_i_784_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_471_O_UNCONNECTED [3:0]),
        .S({1'b0,\rgb_out_reg[23]_i_779_n_0 ,\rgb_out[23]_i_785_n_0 ,\rgb_out[23]_i_786_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_473 
       (.CI(\rgb_out_reg[23]_i_792_n_0 ),
        .CO({\NLW_rgb_out_reg[23]_i_473_CO_UNCONNECTED [3],\TM_D/pixel_on8 ,\rgb_out_reg[23]_i_473_n_2 ,\rgb_out_reg[23]_i_473_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,\rgb_out[23]_i_793_n_0 ,1'b0,1'b0}),
        .O(\NLW_rgb_out_reg[23]_i_473_O_UNCONNECTED [3:0]),
        .S({1'b0,\rgb_out_reg[23]_i_481_n_1 ,\rgb_out[23]_i_794_n_0 ,\rgb_out[23]_i_795_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_474 
       (.CI(\rgb_out_reg[23]_i_796_n_0 ),
        .CO({\NLW_rgb_out_reg[23]_i_474_CO_UNCONNECTED [3],\TM_D/pixel_on83_in ,\rgb_out_reg[23]_i_474_n_2 ,\rgb_out_reg[23]_i_474_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\rgb_out[23]_i_797_n_0 ,\rgb_out[23]_i_798_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_474_O_UNCONNECTED [3:0]),
        .S({1'b0,\rgb_out_reg[23]_i_779_n_0 ,\rgb_out[23]_i_799_n_0 ,\rgb_out[23]_i_800_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_475 
       (.CI(\rgb_out_reg[23]_i_801_n_0 ),
        .CO({\NLW_rgb_out_reg[23]_i_475_CO_UNCONNECTED [3],\TM_D/pixel_on7 ,\rgb_out_reg[23]_i_475_n_2 ,\rgb_out_reg[23]_i_475_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,\rgb_out[23]_i_802_n_0 ,1'b0,1'b0}),
        .O(\NLW_rgb_out_reg[23]_i_475_O_UNCONNECTED [3:0]),
        .S({1'b0,\rgb_out_reg[23]_i_779_n_0 ,\rgb_out[23]_i_803_n_0 ,\rgb_out[23]_i_804_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_476 
       (.CI(\rgb_out_reg[23]_i_805_n_0 ),
        .CO({\NLW_rgb_out_reg[23]_i_476_CO_UNCONNECTED [3],\TM_D/pixel_on75_in ,\rgb_out_reg[23]_i_476_n_2 ,\rgb_out_reg[23]_i_476_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\rgb_out[23]_i_806_n_0 ,\rgb_out[23]_i_807_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_476_O_UNCONNECTED [3:0]),
        .S({1'b0,\rgb_out_reg[23]_i_779_n_0 ,\rgb_out[23]_i_808_n_0 ,\rgb_out[23]_i_809_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_477 
       (.CI(\rgb_out_reg[23]_i_810_n_0 ),
        .CO({\NLW_rgb_out_reg[23]_i_477_CO_UNCONNECTED [3],\TM_D/pixel_on66_in ,\rgb_out_reg[23]_i_477_n_2 ,\rgb_out_reg[23]_i_477_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,\rgb_out[23]_i_811_n_0 ,1'b0,1'b0}),
        .O(\NLW_rgb_out_reg[23]_i_477_O_UNCONNECTED [3:0]),
        .S({1'b0,\rgb_out_reg[23]_i_779_n_0 ,\rgb_out[23]_i_812_n_0 ,\rgb_out[23]_i_813_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_478 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_478_n_0 ,\rgb_out_reg[23]_i_478_n_1 ,\rgb_out_reg[23]_i_478_n_2 ,\rgb_out_reg[23]_i_478_n_3 }),
        .CYINIT(1'b1),
        .DI({\rgb_out[23]_i_814_n_0 ,\TM_D/local_x [5],1'b0,\rgb_out[23]_i_816_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_478_O_UNCONNECTED [3:0]),
        .S({\rgb_out[23]_i_817_n_0 ,\rgb_out[23]_i_818_n_0 ,\rgb_out[23]_i_819_n_0 ,\rgb_out[23]_i_820_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_481 
       (.CI(\rgb_out_reg[23]_i_821_n_0 ),
        .CO({\NLW_rgb_out_reg[23]_i_481_CO_UNCONNECTED [3],\rgb_out_reg[23]_i_481_n_1 ,\NLW_rgb_out_reg[23]_i_481_CO_UNCONNECTED [1],\rgb_out_reg[23]_i_481_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,pixel_x[11],1'b0}),
        .O({\NLW_rgb_out_reg[23]_i_481_O_UNCONNECTED [3:2],\TM_D/local_x [11:10]}),
        .S({1'b0,1'b1,\rgb_out[23]_i_822_n_0 ,pixel_x[10]}));
  CARRY4 \rgb_out_reg[23]_i_484 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_484_n_0 ,\rgb_out_reg[23]_i_484_n_1 ,\rgb_out_reg[23]_i_484_n_2 ,\rgb_out_reg[23]_i_484_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\rgb_out[23]_i_823_n_0 ,\rgb_out[23]_i_824_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_484_O_UNCONNECTED [3:0]),
        .S({\rgb_out[23]_i_825_n_0 ,\rgb_out[23]_i_826_n_0 ,\rgb_out[23]_i_827_n_0 ,\rgb_out[23]_i_828_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_488 
       (.CI(\rgb_out_reg[23]_i_829_n_0 ),
        .CO({\NLW_rgb_out_reg[23]_i_488_CO_UNCONNECTED [3],\TM_D/pixel_on3 ,\rgb_out_reg[23]_i_488_n_2 ,\rgb_out_reg[23]_i_488_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\rgb_out[23]_i_830_n_0 ,\rgb_out[23]_i_831_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_488_O_UNCONNECTED [3:0]),
        .S({1'b0,\rgb_out_reg[23]_i_779_n_0 ,\rgb_out[23]_i_832_n_0 ,\rgb_out[23]_i_833_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_489 
       (.CI(\rgb_out_reg[23]_i_834_n_0 ),
        .CO({\NLW_rgb_out_reg[23]_i_489_CO_UNCONNECTED [3],\TM_D/pixel_on40_in ,\rgb_out_reg[23]_i_489_n_2 ,\rgb_out_reg[23]_i_489_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\rgb_out[23]_i_835_n_0 ,\rgb_out[23]_i_836_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_489_O_UNCONNECTED [3:0]),
        .S({1'b0,\rgb_out_reg[23]_i_481_n_1 ,\rgb_out[23]_i_837_n_0 ,\rgb_out[23]_i_838_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_490 
       (.CI(\rgb_out_reg[23]_i_839_n_0 ),
        .CO({\NLW_rgb_out_reg[23]_i_490_CO_UNCONNECTED [3:2],\TM_D/pixel_on2 ,\rgb_out_reg[23]_i_490_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\TM_D/local_y [12],1'b0}),
        .O(\NLW_rgb_out_reg[23]_i_490_O_UNCONNECTED [3:0]),
        .S({1'b0,1'b0,\rgb_out_reg[23]_i_779_n_0 ,\rgb_out[23]_i_841_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_491 
       (.CI(\rgb_out_reg[23]_i_842_n_0 ),
        .CO({\NLW_rgb_out_reg[23]_i_491_CO_UNCONNECTED [3:2],\TM_D/pixel_on4 ,\rgb_out_reg[23]_i_491_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\TM_D/local_x [12],1'b0}),
        .O(\NLW_rgb_out_reg[23]_i_491_O_UNCONNECTED [3:0]),
        .S({1'b0,1'b0,\rgb_out_reg[23]_i_481_n_1 ,\rgb_out[23]_i_844_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_580 
       (.CI(\rgb_out_reg[23]_i_927_n_0 ),
        .CO({\NLW_rgb_out_reg[23]_i_580_CO_UNCONNECTED [3],\REC_D/pixel_on712_in ,\rgb_out_reg[23]_i_580_n_2 ,\rgb_out_reg[23]_i_580_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,\rgb_out[23]_i_928_n_0 ,1'b0,1'b0}),
        .O(\NLW_rgb_out_reg[23]_i_580_O_UNCONNECTED [3:0]),
        .S({1'b0,\rgb_out_reg[23]_i_929_n_0 ,\rgb_out[23]_i_930_n_0 ,\rgb_out[23]_i_931_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_581 
       (.CI(\rgb_out_reg[23]_i_932_n_0 ),
        .CO({\NLW_rgb_out_reg[23]_i_581_CO_UNCONNECTED [3],\REC_D/pixel_on5 ,\rgb_out_reg[23]_i_581_n_2 ,\rgb_out_reg[23]_i_581_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\rgb_out[23]_i_933_n_0 ,\rgb_out[23]_i_934_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_581_O_UNCONNECTED [3:0]),
        .S({1'b0,\rgb_out_reg[23]_i_929_n_0 ,\rgb_out[23]_i_935_n_0 ,\rgb_out[23]_i_936_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_582 
       (.CI(\rgb_out_reg[23]_i_937_n_0 ),
        .CO({\NLW_rgb_out_reg[23]_i_582_CO_UNCONNECTED [3],\REC_D/pixel_on9 ,\rgb_out_reg[23]_i_582_n_2 ,\rgb_out_reg[23]_i_582_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\rgb_out[23]_i_938_n_0 ,\rgb_out[23]_i_939_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_582_O_UNCONNECTED [3:0]),
        .S({1'b0,\rgb_out_reg[23]_i_591_n_0 ,\rgb_out[23]_i_940_n_0 ,\rgb_out[23]_i_941_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_583 
       (.CI(\rgb_out_reg[23]_i_942_n_0 ),
        .CO({\NLW_rgb_out_reg[23]_i_583_CO_UNCONNECTED [3],\REC_D/pixel_on8 ,\rgb_out_reg[23]_i_583_n_2 ,\rgb_out_reg[23]_i_583_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,\rgb_out[23]_i_943_n_0 ,1'b0,1'b0}),
        .O(\NLW_rgb_out_reg[23]_i_583_O_UNCONNECTED [3:0]),
        .S({1'b0,\rgb_out_reg[23]_i_591_n_0 ,\rgb_out[23]_i_944_n_0 ,\rgb_out[23]_i_945_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_584 
       (.CI(\rgb_out_reg[23]_i_946_n_0 ),
        .CO({\NLW_rgb_out_reg[23]_i_584_CO_UNCONNECTED [3],\REC_D/pixel_on83_in ,\rgb_out_reg[23]_i_584_n_2 ,\rgb_out_reg[23]_i_584_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\rgb_out[23]_i_947_n_0 ,\rgb_out[23]_i_948_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_584_O_UNCONNECTED [3:0]),
        .S({1'b0,\rgb_out_reg[23]_i_929_n_0 ,\rgb_out[23]_i_949_n_0 ,\rgb_out[23]_i_950_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_585 
       (.CI(\rgb_out_reg[23]_i_951_n_0 ),
        .CO({\NLW_rgb_out_reg[23]_i_585_CO_UNCONNECTED [3],\REC_D/pixel_on7 ,\rgb_out_reg[23]_i_585_n_2 ,\rgb_out_reg[23]_i_585_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,\rgb_out[23]_i_952_n_0 ,1'b0,1'b0}),
        .O(\NLW_rgb_out_reg[23]_i_585_O_UNCONNECTED [3:0]),
        .S({1'b0,\rgb_out_reg[23]_i_929_n_0 ,\rgb_out[23]_i_953_n_0 ,\rgb_out[23]_i_954_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_586 
       (.CI(\rgb_out_reg[23]_i_955_n_0 ),
        .CO({\NLW_rgb_out_reg[23]_i_586_CO_UNCONNECTED [3],\REC_D/pixel_on75_in ,\rgb_out_reg[23]_i_586_n_2 ,\rgb_out_reg[23]_i_586_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\rgb_out[23]_i_956_n_0 ,\rgb_out[23]_i_957_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_586_O_UNCONNECTED [3:0]),
        .S({1'b0,\rgb_out_reg[23]_i_929_n_0 ,\rgb_out[23]_i_958_n_0 ,\rgb_out[23]_i_959_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_587 
       (.CI(\rgb_out_reg[23]_i_960_n_0 ),
        .CO({\NLW_rgb_out_reg[23]_i_587_CO_UNCONNECTED [3],\REC_D/pixel_on66_in ,\rgb_out_reg[23]_i_587_n_2 ,\rgb_out_reg[23]_i_587_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,\rgb_out[23]_i_961_n_0 ,1'b0,1'b0}),
        .O(\NLW_rgb_out_reg[23]_i_587_O_UNCONNECTED [3:0]),
        .S({1'b0,\rgb_out_reg[23]_i_929_n_0 ,\rgb_out[23]_i_962_n_0 ,\rgb_out[23]_i_963_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_588 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_588_n_0 ,\rgb_out_reg[23]_i_588_n_1 ,\rgb_out_reg[23]_i_588_n_2 ,\rgb_out_reg[23]_i_588_n_3 }),
        .CYINIT(1'b1),
        .DI({\rgb_out[23]_i_964_n_0 ,\REC_D/local_x [5],1'b0,\rgb_out[23]_i_966_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_588_O_UNCONNECTED [3:0]),
        .S({\rgb_out[23]_i_967_n_0 ,\rgb_out[23]_i_968_n_0 ,\rgb_out[23]_i_969_n_0 ,\rgb_out[23]_i_970_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_591 
       (.CI(\rgb_out_reg[23]_i_965_n_0 ),
        .CO({\rgb_out_reg[23]_i_591_n_0 ,\NLW_rgb_out_reg[23]_i_591_CO_UNCONNECTED [2],\rgb_out_reg[23]_i_591_n_2 ,\rgb_out_reg[23]_i_591_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,pixel_x[11],1'b0,pixel_x[9]}),
        .O({\NLW_rgb_out_reg[23]_i_591_O_UNCONNECTED [3],\REC_D/local_x [11:9]}),
        .S({1'b1,\rgb_out[23]_i_971_n_0 ,pixel_x[10],\rgb_out[23]_i_972_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_594 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_594_n_0 ,\rgb_out_reg[23]_i_594_n_1 ,\rgb_out_reg[23]_i_594_n_2 ,\rgb_out_reg[23]_i_594_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\rgb_out[23]_i_973_n_0 ,\rgb_out[23]_i_974_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_594_O_UNCONNECTED [3:0]),
        .S({\rgb_out[23]_i_975_n_0 ,\rgb_out[23]_i_976_n_0 ,\rgb_out[23]_i_977_n_0 ,\rgb_out[23]_i_978_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_598 
       (.CI(\rgb_out_reg[23]_i_979_n_0 ),
        .CO({\NLW_rgb_out_reg[23]_i_598_CO_UNCONNECTED [3],\REC_D/pixel_on3 ,\rgb_out_reg[23]_i_598_n_2 ,\rgb_out_reg[23]_i_598_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\rgb_out[23]_i_980_n_0 ,\rgb_out[23]_i_981_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_598_O_UNCONNECTED [3:0]),
        .S({1'b0,\rgb_out_reg[23]_i_929_n_0 ,\rgb_out[23]_i_982_n_0 ,\rgb_out[23]_i_983_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_599 
       (.CI(\rgb_out_reg[23]_i_984_n_0 ),
        .CO({\NLW_rgb_out_reg[23]_i_599_CO_UNCONNECTED [3],\REC_D/pixel_on40_in ,\rgb_out_reg[23]_i_599_n_2 ,\rgb_out_reg[23]_i_599_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\rgb_out[23]_i_985_n_0 ,\rgb_out[23]_i_986_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_599_O_UNCONNECTED [3:0]),
        .S({1'b0,\rgb_out_reg[23]_i_591_n_0 ,\rgb_out[23]_i_987_n_0 ,\rgb_out[23]_i_988_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_600 
       (.CI(\rgb_out_reg[23]_i_989_n_0 ),
        .CO({\NLW_rgb_out_reg[23]_i_600_CO_UNCONNECTED [3:2],\REC_D/pixel_on2 ,\rgb_out_reg[23]_i_600_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\REC_D/local_y [12],1'b0}),
        .O(\NLW_rgb_out_reg[23]_i_600_O_UNCONNECTED [3:0]),
        .S({1'b0,1'b0,\rgb_out_reg[23]_i_929_n_0 ,\rgb_out[23]_i_991_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_601 
       (.CI(\rgb_out_reg[23]_i_992_n_0 ),
        .CO({\NLW_rgb_out_reg[23]_i_601_CO_UNCONNECTED [3:2],\REC_D/pixel_on4 ,\rgb_out_reg[23]_i_601_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\REC_D/local_x [12],1'b0}),
        .O(\NLW_rgb_out_reg[23]_i_601_O_UNCONNECTED [3:0]),
        .S({1'b0,1'b0,\rgb_out_reg[23]_i_591_n_0 ,\rgb_out[23]_i_994_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_602 
       (.CI(\rgb_out_reg[23]_i_995_n_0 ),
        .CO({\NLW_rgb_out_reg[23]_i_602_CO_UNCONNECTED [3:2],\LAST_U/pixel_on4 ,\rgb_out_reg[23]_i_602_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\LAST_U/local_x [12],1'b0}),
        .O(\NLW_rgb_out_reg[23]_i_602_O_UNCONNECTED [3:0]),
        .S({1'b0,1'b0,\rgb_out_reg[23]_i_997_n_0 ,\rgb_out[23]_i_998_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_603 
       (.CI(\rgb_out_reg[23]_i_999_n_0 ),
        .CO({\NLW_rgb_out_reg[23]_i_603_CO_UNCONNECTED [3:1],\LAST_U/pixel_on2 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,\LAST_U/local_y [12]}),
        .O(\NLW_rgb_out_reg[23]_i_603_O_UNCONNECTED [3:0]),
        .S({1'b0,1'b0,1'b0,\rgb_out_reg[23]_i_1001_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_604 
       (.CI(\rgb_out_reg[23]_i_1002_n_0 ),
        .CO({\NLW_rgb_out_reg[23]_i_604_CO_UNCONNECTED [3],\LAST_U/pixel_on40_in ,\rgb_out_reg[23]_i_604_n_2 ,\rgb_out_reg[23]_i_604_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\rgb_out[23]_i_1003_n_0 ,\rgb_out[23]_i_1004_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_604_O_UNCONNECTED [3:0]),
        .S({1'b0,\rgb_out_reg[23]_i_997_n_0 ,\rgb_out[23]_i_1005_n_0 ,\rgb_out[23]_i_1006_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_605 
       (.CI(\rgb_out_reg[23]_i_1007_n_0 ),
        .CO({\NLW_rgb_out_reg[23]_i_605_CO_UNCONNECTED [3],\LAST_U/pixel_on3 ,\rgb_out_reg[23]_i_605_n_2 ,\rgb_out_reg[23]_i_605_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\rgb_out[23]_i_1008_n_0 ,\rgb_out[23]_i_1009_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_605_O_UNCONNECTED [3:0]),
        .S({1'b0,\rgb_out_reg[23]_i_1001_n_0 ,\rgb_out[23]_i_1010_n_0 ,\rgb_out[23]_i_1011_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_606 
       (.CI(\rgb_out_reg[23]_i_1012_n_0 ),
        .CO({\NLW_rgb_out_reg[23]_i_606_CO_UNCONNECTED [3],\LAST_U/pixel_on66_in ,\rgb_out_reg[23]_i_606_n_2 ,\rgb_out_reg[23]_i_606_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,\rgb_out[23]_i_1013_n_0 ,1'b0,1'b0}),
        .O(\NLW_rgb_out_reg[23]_i_606_O_UNCONNECTED [3:0]),
        .S({1'b0,\rgb_out_reg[23]_i_1001_n_0 ,\rgb_out[23]_i_1014_n_0 ,\rgb_out[23]_i_1015_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_607 
       (.CI(\rgb_out_reg[23]_i_1016_n_0 ),
        .CO({\NLW_rgb_out_reg[23]_i_607_CO_UNCONNECTED [3],\LAST_U/pixel_on75_in ,\rgb_out_reg[23]_i_607_n_2 ,\rgb_out_reg[23]_i_607_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\rgb_out[23]_i_1017_n_0 ,\rgb_out[23]_i_1018_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_607_O_UNCONNECTED [3:0]),
        .S({1'b0,\rgb_out_reg[23]_i_1001_n_0 ,\rgb_out[23]_i_1019_n_0 ,\rgb_out[23]_i_1020_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_609 
       (.CI(\rgb_out_reg[23]_i_1021_n_0 ),
        .CO({\NLW_rgb_out_reg[23]_i_609_CO_UNCONNECTED [3],\LAST_U/pixel_on6 ,\rgb_out_reg[23]_i_609_n_2 ,\rgb_out_reg[23]_i_609_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,\rgb_out[23]_i_1022_n_0 ,1'b0,1'b0}),
        .O(\NLW_rgb_out_reg[23]_i_609_O_UNCONNECTED [3:0]),
        .S({1'b0,\rgb_out_reg[23]_i_997_n_0 ,\rgb_out[23]_i_1023_n_0 ,\rgb_out[23]_i_1024_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_611 
       (.CI(\rgb_out_reg[23]_i_1025_n_0 ),
        .CO({\NLW_rgb_out_reg[23]_i_611_CO_UNCONNECTED [3],\LAST_U/pixel_on99_in ,\rgb_out_reg[23]_i_611_n_2 ,\rgb_out_reg[23]_i_611_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\rgb_out[23]_i_1026_n_0 ,\rgb_out[23]_i_1027_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_611_O_UNCONNECTED [3:0]),
        .S({1'b0,\rgb_out_reg[23]_i_997_n_0 ,\rgb_out[23]_i_1028_n_0 ,\rgb_out[23]_i_1029_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_612 
       (.CI(\rgb_out_reg[23]_i_1030_n_0 ),
        .CO({\NLW_rgb_out_reg[23]_i_612_CO_UNCONNECTED [3],\LAST_U/pixel_on7 ,\rgb_out_reg[23]_i_612_n_2 ,\rgb_out_reg[23]_i_612_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,\rgb_out[23]_i_1031_n_0 ,1'b0,1'b0}),
        .O(\NLW_rgb_out_reg[23]_i_612_O_UNCONNECTED [3:0]),
        .S({1'b0,\rgb_out_reg[23]_i_1001_n_0 ,\rgb_out[23]_i_1032_n_0 ,\rgb_out[23]_i_1033_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_613 
       (.CI(\rgb_out_reg[23]_i_1034_n_0 ),
        .CO({\NLW_rgb_out_reg[23]_i_613_CO_UNCONNECTED [3],\LAST_U/pixel_on83_in ,\rgb_out_reg[23]_i_613_n_2 ,\rgb_out_reg[23]_i_613_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\rgb_out[23]_i_1035_n_0 ,\rgb_out[23]_i_1036_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_613_O_UNCONNECTED [3:0]),
        .S({1'b0,\rgb_out_reg[23]_i_1001_n_0 ,\rgb_out[23]_i_1037_n_0 ,\rgb_out[23]_i_1038_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_616 
       (.CI(\rgb_out_reg[23]_i_1039_n_0 ),
        .CO({\NLW_rgb_out_reg[23]_i_616_CO_UNCONNECTED [3],\LAST_U/pixel_on9 ,\rgb_out_reg[23]_i_616_n_2 ,\rgb_out_reg[23]_i_616_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\rgb_out[23]_i_1040_n_0 ,\rgb_out[23]_i_1041_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_616_O_UNCONNECTED [3:0]),
        .S({1'b0,\rgb_out_reg[23]_i_997_n_0 ,\rgb_out[23]_i_1042_n_0 ,\rgb_out[23]_i_1043_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_617 
       (.CI(\rgb_out_reg[23]_i_1044_n_0 ),
        .CO({\NLW_rgb_out_reg[23]_i_617_CO_UNCONNECTED [3],\LAST_U/pixel_on8 ,\rgb_out_reg[23]_i_617_n_2 ,\rgb_out_reg[23]_i_617_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,\rgb_out[23]_i_1045_n_0 ,1'b0,1'b0}),
        .O(\NLW_rgb_out_reg[23]_i_617_O_UNCONNECTED [3:0]),
        .S({1'b0,\rgb_out_reg[23]_i_997_n_0 ,\rgb_out[23]_i_1046_n_0 ,\rgb_out[23]_i_1047_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_620 
       (.CI(\rgb_out_reg[23]_i_1048_n_0 ),
        .CO({\NLW_rgb_out_reg[23]_i_620_CO_UNCONNECTED [3],\LAST_U/pixel_on712_in ,\rgb_out_reg[23]_i_620_n_2 ,\rgb_out_reg[23]_i_620_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,\rgb_out[23]_i_1049_n_0 ,1'b0,1'b0}),
        .O(\NLW_rgb_out_reg[23]_i_620_O_UNCONNECTED [3:0]),
        .S({1'b0,\rgb_out_reg[23]_i_1001_n_0 ,\rgb_out[23]_i_1050_n_0 ,\rgb_out[23]_i_1051_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_622 
       (.CI(\rgb_out_reg[23]_i_1052_n_0 ),
        .CO({\NLW_rgb_out_reg[23]_i_622_CO_UNCONNECTED [3],\LAST_U/pixel_on22_in ,\rgb_out_reg[23]_i_622_n_2 ,\rgb_out_reg[23]_i_622_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,\rgb_out[23]_i_1053_n_0 ,1'b0,1'b0}),
        .O(\NLW_rgb_out_reg[23]_i_622_O_UNCONNECTED [3:0]),
        .S({1'b0,\rgb_out_reg[23]_i_1001_n_0 ,\rgb_out[23]_i_1054_n_0 ,\rgb_out[23]_i_1055_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_624 
       (.CI(\rgb_out_reg[23]_i_1056_n_0 ),
        .CO({\NLW_rgb_out_reg[23]_i_624_CO_UNCONNECTED [3],\LAST_U/pixel_on31_in ,\rgb_out_reg[23]_i_624_n_2 ,\rgb_out_reg[23]_i_624_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\rgb_out[23]_i_1057_n_0 ,\rgb_out[23]_i_1058_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_624_O_UNCONNECTED [3:0]),
        .S({1'b0,\rgb_out_reg[23]_i_1001_n_0 ,\rgb_out[23]_i_1059_n_0 ,\rgb_out[23]_i_1060_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_626 
       (.CI(\rgb_out_reg[23]_i_1061_n_0 ),
        .CO({\NLW_rgb_out_reg[23]_i_626_CO_UNCONNECTED [3],\LAST_U/pixel_on5 ,\rgb_out_reg[23]_i_626_n_2 ,\rgb_out_reg[23]_i_626_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\rgb_out[23]_i_1062_n_0 ,\rgb_out[23]_i_1063_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_626_O_UNCONNECTED [3:0]),
        .S({1'b0,\rgb_out_reg[23]_i_1001_n_0 ,\rgb_out[23]_i_1064_n_0 ,\rgb_out[23]_i_1065_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_628 
       (.CI(\rgb_out_reg[23]_i_1066_n_0 ),
        .CO({\NLW_rgb_out_reg[23]_i_628_CO_UNCONNECTED [3:2],\REC_U/pixel_on4 ,\rgb_out_reg[23]_i_628_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\REC_U/local_x [12],1'b0}),
        .O(\NLW_rgb_out_reg[23]_i_628_O_UNCONNECTED [3:0]),
        .S({1'b0,1'b0,\rgb_out_reg[23]_i_1068_n_0 ,\rgb_out[23]_i_1069_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_629 
       (.CI(\rgb_out_reg[23]_i_1070_n_0 ),
        .CO({\NLW_rgb_out_reg[23]_i_629_CO_UNCONNECTED [3:1],\REC_U/pixel_on2 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,\REC_U/local_y [12]}),
        .O(\NLW_rgb_out_reg[23]_i_629_O_UNCONNECTED [3:0]),
        .S({1'b0,1'b0,1'b0,\rgb_out_reg[23]_i_1072_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_630 
       (.CI(\rgb_out_reg[23]_i_1073_n_0 ),
        .CO({\NLW_rgb_out_reg[23]_i_630_CO_UNCONNECTED [3],\REC_U/pixel_on40_in ,\rgb_out_reg[23]_i_630_n_2 ,\rgb_out_reg[23]_i_630_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\rgb_out[23]_i_1074_n_0 ,\rgb_out[23]_i_1075_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_630_O_UNCONNECTED [3:0]),
        .S({1'b0,\rgb_out_reg[23]_i_1068_n_0 ,\rgb_out[23]_i_1076_n_0 ,\rgb_out[23]_i_1077_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_631 
       (.CI(\rgb_out_reg[23]_i_1078_n_0 ),
        .CO({\NLW_rgb_out_reg[23]_i_631_CO_UNCONNECTED [3],\REC_U/pixel_on3 ,\rgb_out_reg[23]_i_631_n_2 ,\rgb_out_reg[23]_i_631_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\rgb_out[23]_i_1079_n_0 ,\rgb_out[23]_i_1080_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_631_O_UNCONNECTED [3:0]),
        .S({1'b0,\rgb_out_reg[23]_i_1072_n_0 ,\rgb_out[23]_i_1081_n_0 ,\rgb_out[23]_i_1082_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_632 
       (.CI(\rgb_out_reg[23]_i_1083_n_0 ),
        .CO({\NLW_rgb_out_reg[23]_i_632_CO_UNCONNECTED [3],\REC_U/pixel_on66_in ,\rgb_out_reg[23]_i_632_n_2 ,\rgb_out_reg[23]_i_632_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,\rgb_out[23]_i_1084_n_0 ,1'b0,1'b0}),
        .O(\NLW_rgb_out_reg[23]_i_632_O_UNCONNECTED [3:0]),
        .S({1'b0,\rgb_out_reg[23]_i_1072_n_0 ,\rgb_out[23]_i_1085_n_0 ,\rgb_out[23]_i_1086_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_633 
       (.CI(\rgb_out_reg[23]_i_1087_n_0 ),
        .CO({\NLW_rgb_out_reg[23]_i_633_CO_UNCONNECTED [3],\REC_U/pixel_on75_in ,\rgb_out_reg[23]_i_633_n_2 ,\rgb_out_reg[23]_i_633_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\rgb_out[23]_i_1088_n_0 ,\rgb_out[23]_i_1089_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_633_O_UNCONNECTED [3:0]),
        .S({1'b0,\rgb_out_reg[23]_i_1072_n_0 ,\rgb_out[23]_i_1090_n_0 ,\rgb_out[23]_i_1091_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_635 
       (.CI(\rgb_out_reg[23]_i_1092_n_0 ),
        .CO({\NLW_rgb_out_reg[23]_i_635_CO_UNCONNECTED [3],\REC_U/pixel_on6 ,\rgb_out_reg[23]_i_635_n_2 ,\rgb_out_reg[23]_i_635_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,\rgb_out[23]_i_1093_n_0 ,1'b0,1'b0}),
        .O(\NLW_rgb_out_reg[23]_i_635_O_UNCONNECTED [3:0]),
        .S({1'b0,\rgb_out_reg[23]_i_1068_n_0 ,\rgb_out[23]_i_1094_n_0 ,\rgb_out[23]_i_1095_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_637 
       (.CI(\rgb_out_reg[23]_i_1096_n_0 ),
        .CO({\NLW_rgb_out_reg[23]_i_637_CO_UNCONNECTED [3],\REC_U/pixel_on99_in ,\rgb_out_reg[23]_i_637_n_2 ,\rgb_out_reg[23]_i_637_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\rgb_out[23]_i_1097_n_0 ,\rgb_out[23]_i_1098_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_637_O_UNCONNECTED [3:0]),
        .S({1'b0,\rgb_out_reg[23]_i_1068_n_0 ,\rgb_out[23]_i_1099_n_0 ,\rgb_out[23]_i_1100_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_638 
       (.CI(\rgb_out_reg[23]_i_1101_n_0 ),
        .CO({\NLW_rgb_out_reg[23]_i_638_CO_UNCONNECTED [3],\REC_U/pixel_on7 ,\rgb_out_reg[23]_i_638_n_2 ,\rgb_out_reg[23]_i_638_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,\rgb_out[23]_i_1102_n_0 ,1'b0,1'b0}),
        .O(\NLW_rgb_out_reg[23]_i_638_O_UNCONNECTED [3:0]),
        .S({1'b0,\rgb_out_reg[23]_i_1072_n_0 ,\rgb_out[23]_i_1103_n_0 ,\rgb_out[23]_i_1104_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_639 
       (.CI(\rgb_out_reg[23]_i_1105_n_0 ),
        .CO({\NLW_rgb_out_reg[23]_i_639_CO_UNCONNECTED [3],\REC_U/pixel_on83_in ,\rgb_out_reg[23]_i_639_n_2 ,\rgb_out_reg[23]_i_639_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\rgb_out[23]_i_1106_n_0 ,\rgb_out[23]_i_1107_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_639_O_UNCONNECTED [3:0]),
        .S({1'b0,\rgb_out_reg[23]_i_1072_n_0 ,\rgb_out[23]_i_1108_n_0 ,\rgb_out[23]_i_1109_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_642 
       (.CI(\rgb_out_reg[23]_i_1110_n_0 ),
        .CO({\NLW_rgb_out_reg[23]_i_642_CO_UNCONNECTED [3],\REC_U/pixel_on9 ,\rgb_out_reg[23]_i_642_n_2 ,\rgb_out_reg[23]_i_642_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\rgb_out[23]_i_1111_n_0 ,\rgb_out[23]_i_1112_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_642_O_UNCONNECTED [3:0]),
        .S({1'b0,\rgb_out_reg[23]_i_1068_n_0 ,\rgb_out[23]_i_1113_n_0 ,\rgb_out[23]_i_1114_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_643 
       (.CI(\rgb_out_reg[23]_i_1115_n_0 ),
        .CO({\NLW_rgb_out_reg[23]_i_643_CO_UNCONNECTED [3],\REC_U/pixel_on8 ,\rgb_out_reg[23]_i_643_n_2 ,\rgb_out_reg[23]_i_643_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,\rgb_out[23]_i_1116_n_0 ,1'b0,1'b0}),
        .O(\NLW_rgb_out_reg[23]_i_643_O_UNCONNECTED [3:0]),
        .S({1'b0,\rgb_out_reg[23]_i_1068_n_0 ,\rgb_out[23]_i_1117_n_0 ,\rgb_out[23]_i_1118_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_646 
       (.CI(\rgb_out_reg[23]_i_1119_n_0 ),
        .CO({\NLW_rgb_out_reg[23]_i_646_CO_UNCONNECTED [3],\REC_U/pixel_on712_in ,\rgb_out_reg[23]_i_646_n_2 ,\rgb_out_reg[23]_i_646_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,\rgb_out[23]_i_1120_n_0 ,1'b0,1'b0}),
        .O(\NLW_rgb_out_reg[23]_i_646_O_UNCONNECTED [3:0]),
        .S({1'b0,\rgb_out_reg[23]_i_1072_n_0 ,\rgb_out[23]_i_1121_n_0 ,\rgb_out[23]_i_1122_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_648 
       (.CI(\rgb_out_reg[23]_i_1123_n_0 ),
        .CO({\NLW_rgb_out_reg[23]_i_648_CO_UNCONNECTED [3],\REC_U/pixel_on22_in ,\rgb_out_reg[23]_i_648_n_2 ,\rgb_out_reg[23]_i_648_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,\rgb_out[23]_i_1124_n_0 ,1'b0,1'b0}),
        .O(\NLW_rgb_out_reg[23]_i_648_O_UNCONNECTED [3:0]),
        .S({1'b0,\rgb_out_reg[23]_i_1072_n_0 ,\rgb_out[23]_i_1125_n_0 ,\rgb_out[23]_i_1126_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_650 
       (.CI(\rgb_out_reg[23]_i_1127_n_0 ),
        .CO({\NLW_rgb_out_reg[23]_i_650_CO_UNCONNECTED [3],\REC_U/pixel_on31_in ,\rgb_out_reg[23]_i_650_n_2 ,\rgb_out_reg[23]_i_650_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\rgb_out[23]_i_1128_n_0 ,\rgb_out[23]_i_1129_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_650_O_UNCONNECTED [3:0]),
        .S({1'b0,\rgb_out_reg[23]_i_1072_n_0 ,\rgb_out[23]_i_1130_n_0 ,\rgb_out[23]_i_1131_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_652 
       (.CI(\rgb_out_reg[23]_i_1132_n_0 ),
        .CO({\NLW_rgb_out_reg[23]_i_652_CO_UNCONNECTED [3],\REC_U/pixel_on5 ,\rgb_out_reg[23]_i_652_n_2 ,\rgb_out_reg[23]_i_652_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\rgb_out[23]_i_1133_n_0 ,\rgb_out[23]_i_1134_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_652_O_UNCONNECTED [3:0]),
        .S({1'b0,\rgb_out_reg[23]_i_1072_n_0 ,\rgb_out[23]_i_1135_n_0 ,\rgb_out[23]_i_1136_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_654 
       (.CI(\rgb_out_reg[23]_i_1137_n_0 ),
        .CO({\NLW_rgb_out_reg[23]_i_654_CO_UNCONNECTED [3],\LAST_D/pixel_on712_in ,\rgb_out_reg[23]_i_654_n_2 ,\rgb_out_reg[23]_i_654_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,\rgb_out[23]_i_1138_n_0 ,1'b0,1'b0}),
        .O(\NLW_rgb_out_reg[23]_i_654_O_UNCONNECTED [3:0]),
        .S({1'b0,\rgb_out_reg[23]_i_1139_n_0 ,\rgb_out[23]_i_1140_n_0 ,\rgb_out[23]_i_1141_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_655 
       (.CI(\rgb_out_reg[23]_i_1142_n_0 ),
        .CO({\NLW_rgb_out_reg[23]_i_655_CO_UNCONNECTED [3],\LAST_D/pixel_on5 ,\rgb_out_reg[23]_i_655_n_2 ,\rgb_out_reg[23]_i_655_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\rgb_out[23]_i_1143_n_0 ,\rgb_out[23]_i_1144_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_655_O_UNCONNECTED [3:0]),
        .S({1'b0,\rgb_out_reg[23]_i_1139_n_0 ,\rgb_out[23]_i_1145_n_0 ,\rgb_out[23]_i_1146_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_656 
       (.CI(\rgb_out_reg[23]_i_1147_n_0 ),
        .CO({\NLW_rgb_out_reg[23]_i_656_CO_UNCONNECTED [3],\LAST_D/pixel_on9 ,\rgb_out_reg[23]_i_656_n_2 ,\rgb_out_reg[23]_i_656_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\rgb_out[23]_i_1148_n_0 ,\rgb_out[23]_i_1149_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_656_O_UNCONNECTED [3:0]),
        .S({1'b0,\rgb_out_reg[23]_i_665_n_0 ,\rgb_out[23]_i_1150_n_0 ,\rgb_out[23]_i_1151_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_657 
       (.CI(\rgb_out_reg[23]_i_1152_n_0 ),
        .CO({\NLW_rgb_out_reg[23]_i_657_CO_UNCONNECTED [3],\LAST_D/pixel_on8 ,\rgb_out_reg[23]_i_657_n_2 ,\rgb_out_reg[23]_i_657_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,\rgb_out[23]_i_1153_n_0 ,1'b0,1'b0}),
        .O(\NLW_rgb_out_reg[23]_i_657_O_UNCONNECTED [3:0]),
        .S({1'b0,\rgb_out_reg[23]_i_665_n_0 ,\rgb_out[23]_i_1154_n_0 ,\rgb_out[23]_i_1155_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_658 
       (.CI(\rgb_out_reg[23]_i_1156_n_0 ),
        .CO({\NLW_rgb_out_reg[23]_i_658_CO_UNCONNECTED [3],\LAST_D/pixel_on83_in ,\rgb_out_reg[23]_i_658_n_2 ,\rgb_out_reg[23]_i_658_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\rgb_out[23]_i_1157_n_0 ,\rgb_out[23]_i_1158_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_658_O_UNCONNECTED [3:0]),
        .S({1'b0,\rgb_out_reg[23]_i_1139_n_0 ,\rgb_out[23]_i_1159_n_0 ,\rgb_out[23]_i_1160_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_659 
       (.CI(\rgb_out_reg[23]_i_1161_n_0 ),
        .CO({\NLW_rgb_out_reg[23]_i_659_CO_UNCONNECTED [3],\LAST_D/pixel_on7 ,\rgb_out_reg[23]_i_659_n_2 ,\rgb_out_reg[23]_i_659_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,\rgb_out[23]_i_1162_n_0 ,1'b0,1'b0}),
        .O(\NLW_rgb_out_reg[23]_i_659_O_UNCONNECTED [3:0]),
        .S({1'b0,\rgb_out_reg[23]_i_1139_n_0 ,\rgb_out[23]_i_1163_n_0 ,\rgb_out[23]_i_1164_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_660 
       (.CI(\rgb_out_reg[23]_i_1165_n_0 ),
        .CO({\NLW_rgb_out_reg[23]_i_660_CO_UNCONNECTED [3],\LAST_D/pixel_on75_in ,\rgb_out_reg[23]_i_660_n_2 ,\rgb_out_reg[23]_i_660_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\rgb_out[23]_i_1166_n_0 ,\rgb_out[23]_i_1167_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_660_O_UNCONNECTED [3:0]),
        .S({1'b0,\rgb_out_reg[23]_i_1139_n_0 ,\rgb_out[23]_i_1168_n_0 ,\rgb_out[23]_i_1169_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_661 
       (.CI(\rgb_out_reg[23]_i_1170_n_0 ),
        .CO({\NLW_rgb_out_reg[23]_i_661_CO_UNCONNECTED [3],\LAST_D/pixel_on66_in ,\rgb_out_reg[23]_i_661_n_2 ,\rgb_out_reg[23]_i_661_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,\rgb_out[23]_i_1171_n_0 ,1'b0,1'b0}),
        .O(\NLW_rgb_out_reg[23]_i_661_O_UNCONNECTED [3:0]),
        .S({1'b0,\rgb_out_reg[23]_i_1139_n_0 ,\rgb_out[23]_i_1172_n_0 ,\rgb_out[23]_i_1173_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_662 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_662_n_0 ,\rgb_out_reg[23]_i_662_n_1 ,\rgb_out_reg[23]_i_662_n_2 ,\rgb_out_reg[23]_i_662_n_3 }),
        .CYINIT(1'b1),
        .DI({\rgb_out[23]_i_1174_n_0 ,\LAST_D/local_x [5],1'b0,\rgb_out[23]_i_1176_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_662_O_UNCONNECTED [3:0]),
        .S({\rgb_out[23]_i_1177_n_0 ,\rgb_out[23]_i_1178_n_0 ,\rgb_out[23]_i_1179_n_0 ,\rgb_out[23]_i_1180_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_665 
       (.CI(\rgb_out_reg[23]_i_1175_n_0 ),
        .CO({\rgb_out_reg[23]_i_665_n_0 ,\NLW_rgb_out_reg[23]_i_665_CO_UNCONNECTED [2],\rgb_out_reg[23]_i_665_n_2 ,\rgb_out_reg[23]_i_665_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,pixel_x[11:9]}),
        .O({\NLW_rgb_out_reg[23]_i_665_O_UNCONNECTED [3],\LAST_D/local_x [11:9]}),
        .S({1'b1,\rgb_out[23]_i_1181_n_0 ,\rgb_out[23]_i_1182_n_0 ,\rgb_out[23]_i_1183_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_668 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_668_n_0 ,\rgb_out_reg[23]_i_668_n_1 ,\rgb_out_reg[23]_i_668_n_2 ,\rgb_out_reg[23]_i_668_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\rgb_out[23]_i_1184_n_0 ,\rgb_out[23]_i_1185_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_668_O_UNCONNECTED [3:0]),
        .S({\rgb_out[23]_i_1186_n_0 ,\rgb_out[23]_i_1187_n_0 ,\rgb_out[23]_i_1188_n_0 ,\rgb_out[23]_i_1189_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_672 
       (.CI(\rgb_out_reg[23]_i_1190_n_0 ),
        .CO({\NLW_rgb_out_reg[23]_i_672_CO_UNCONNECTED [3],\LAST_D/pixel_on3 ,\rgb_out_reg[23]_i_672_n_2 ,\rgb_out_reg[23]_i_672_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\rgb_out[23]_i_1191_n_0 ,\rgb_out[23]_i_1192_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_672_O_UNCONNECTED [3:0]),
        .S({1'b0,\rgb_out_reg[23]_i_1139_n_0 ,\rgb_out[23]_i_1193_n_0 ,\rgb_out[23]_i_1194_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_673 
       (.CI(\rgb_out_reg[23]_i_1195_n_0 ),
        .CO({\NLW_rgb_out_reg[23]_i_673_CO_UNCONNECTED [3],\LAST_D/pixel_on40_in ,\rgb_out_reg[23]_i_673_n_2 ,\rgb_out_reg[23]_i_673_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\rgb_out[23]_i_1196_n_0 ,\rgb_out[23]_i_1197_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_673_O_UNCONNECTED [3:0]),
        .S({1'b0,\rgb_out_reg[23]_i_665_n_0 ,\rgb_out[23]_i_1198_n_0 ,\rgb_out[23]_i_1199_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_674 
       (.CI(\rgb_out_reg[23]_i_1200_n_0 ),
        .CO({\NLW_rgb_out_reg[23]_i_674_CO_UNCONNECTED [3:2],\LAST_D/pixel_on2 ,\rgb_out_reg[23]_i_674_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\LAST_D/local_y [12],1'b0}),
        .O(\NLW_rgb_out_reg[23]_i_674_O_UNCONNECTED [3:0]),
        .S({1'b0,1'b0,\rgb_out_reg[23]_i_1139_n_0 ,\rgb_out[23]_i_1202_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_675 
       (.CI(\rgb_out_reg[23]_i_1203_n_0 ),
        .CO({\NLW_rgb_out_reg[23]_i_675_CO_UNCONNECTED [3:2],\LAST_D/pixel_on4 ,\rgb_out_reg[23]_i_675_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\LAST_D/local_x [12],1'b0}),
        .O(\NLW_rgb_out_reg[23]_i_675_O_UNCONNECTED [3:0]),
        .S({1'b0,1'b0,\rgb_out_reg[23]_i_665_n_0 ,\rgb_out[23]_i_1205_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_714 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_714_n_0 ,\rgb_out_reg[23]_i_714_n_1 ,\rgb_out_reg[23]_i_714_n_2 ,\rgb_out_reg[23]_i_714_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\rgb_out[23]_i_1211_n_0 ,\rgb_out[23]_i_1212_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_714_O_UNCONNECTED [3:0]),
        .S({\rgb_out[23]_i_1213_n_0 ,\rgb_out[23]_i_1214_n_0 ,\rgb_out[23]_i_1215_n_0 ,\rgb_out[23]_i_1216_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_716 
       (.CI(\rgb_out_reg[23]_i_1217_n_0 ),
        .CO({\NLW_rgb_out_reg[23]_i_716_CO_UNCONNECTED [3:1],\rgb_out_reg[23]_i_716_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(\NLW_rgb_out_reg[23]_i_716_O_UNCONNECTED [3:0]),
        .S({1'b0,1'b0,1'b0,1'b1}));
  CARRY4 \rgb_out_reg[23]_i_718 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_718_n_0 ,\rgb_out_reg[23]_i_718_n_1 ,\rgb_out_reg[23]_i_718_n_2 ,\rgb_out_reg[23]_i_718_n_3 }),
        .CYINIT(\rgb_out[23]_i_1218_n_0 ),
        .DI({1'b0,1'b0,1'b0,\rgb_out[23]_i_1219_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_718_O_UNCONNECTED [3:0]),
        .S({\rgb_out[23]_i_1220_n_0 ,\rgb_out[23]_i_1221_n_0 ,\rgb_out[23]_i_1222_n_0 ,\rgb_out[23]_i_1223_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_720 
       (.CI(\rgb_out_reg[23]_i_1224_n_0 ),
        .CO({\rgb_out_reg[23]_i_720_n_0 ,\NLW_rgb_out_reg[23]_i_720_CO_UNCONNECTED [2],\rgb_out_reg[23]_i_720_n_2 ,\rgb_out_reg[23]_i_720_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,pixel_y[11:9]}),
        .O({\NLW_rgb_out_reg[23]_i_720_O_UNCONNECTED [3],\SC_U/local_y [11:9]}),
        .S({1'b1,\rgb_out[23]_i_1225_n_0 ,\rgb_out[23]_i_1226_n_0 ,\rgb_out[23]_i_1227_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_721 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_721_n_0 ,\rgb_out_reg[23]_i_721_n_1 ,\rgb_out_reg[23]_i_721_n_2 ,\rgb_out_reg[23]_i_721_n_3 }),
        .CYINIT(1'b1),
        .DI({\rgb_out[23]_i_1228_n_0 ,\rgb_out[23]_i_1229_n_0 ,\rgb_out[23]_i_1230_n_0 ,\rgb_out[23]_i_1231_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_721_O_UNCONNECTED [3:0]),
        .S({\rgb_out[23]_i_1232_n_0 ,\rgb_out[23]_i_1233_n_0 ,\rgb_out[23]_i_1234_n_0 ,\rgb_out[23]_i_1235_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_726 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_726_n_0 ,\rgb_out_reg[23]_i_726_n_1 ,\rgb_out_reg[23]_i_726_n_2 ,\rgb_out_reg[23]_i_726_n_3 }),
        .CYINIT(1'b1),
        .DI({\rgb_out[23]_i_1236_n_0 ,\rgb_out[23]_i_1237_n_0 ,\rgb_out[23]_i_1238_n_0 ,\rgb_out[23]_i_1239_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_726_O_UNCONNECTED [3:0]),
        .S({\rgb_out[23]_i_1240_n_0 ,\rgb_out[23]_i_1241_n_0 ,\rgb_out[23]_i_1242_n_0 ,\rgb_out[23]_i_1243_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_731 
       (.CI(\rgb_out_reg[23]_i_1244_n_0 ),
        .CO({\NLW_rgb_out_reg[23]_i_731_CO_UNCONNECTED [3],\SC_U/pixel_on5 ,\rgb_out_reg[23]_i_731_n_2 ,\rgb_out_reg[23]_i_731_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\rgb_out[23]_i_1245_n_0 ,\rgb_out[23]_i_1246_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_731_O_UNCONNECTED [3:0]),
        .S({1'b0,\rgb_out_reg[23]_i_720_n_0 ,\rgb_out[23]_i_1247_n_0 ,\rgb_out[23]_i_1248_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_732 
       (.CI(\rgb_out_reg[23]_i_1249_n_0 ),
        .CO({\NLW_rgb_out_reg[23]_i_732_CO_UNCONNECTED [3],\SC_U/pixel_on8 ,\rgb_out_reg[23]_i_732_n_2 ,\rgb_out_reg[23]_i_732_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,\rgb_out[23]_i_1250_n_0 ,1'b0,1'b0}),
        .O(\NLW_rgb_out_reg[23]_i_732_O_UNCONNECTED [3:0]),
        .S({1'b0,\rgb_out_reg[23]_i_716_n_3 ,\rgb_out[23]_i_1251_n_0 ,\rgb_out[23]_i_1252_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_735 
       (.CI(\rgb_out_reg[23]_i_1258_n_0 ),
        .CO({\NLW_rgb_out_reg[23]_i_735_CO_UNCONNECTED [3],\SC_U/pixel_on22_in ,\rgb_out_reg[23]_i_735_n_2 ,\rgb_out_reg[23]_i_735_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,\rgb_out[23]_i_1259_n_0 ,1'b0,1'b0}),
        .O(\NLW_rgb_out_reg[23]_i_735_O_UNCONNECTED [3:0]),
        .S({1'b0,\rgb_out_reg[23]_i_720_n_0 ,\rgb_out[23]_i_1260_n_0 ,\rgb_out[23]_i_1261_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_737 
       (.CI(\rgb_out_reg[23]_i_1262_n_0 ),
        .CO({\NLW_rgb_out_reg[23]_i_737_CO_UNCONNECTED [3],\SC_U/pixel_on31_in ,\rgb_out_reg[23]_i_737_n_2 ,\rgb_out_reg[23]_i_737_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\rgb_out[23]_i_1263_n_0 ,\rgb_out[23]_i_1264_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_737_O_UNCONNECTED [3:0]),
        .S({1'b0,\rgb_out_reg[23]_i_720_n_0 ,\rgb_out[23]_i_1265_n_0 ,\rgb_out[23]_i_1266_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_739 
       (.CI(\rgb_out_reg[23]_i_1267_n_0 ),
        .CO({\NLW_rgb_out_reg[23]_i_739_CO_UNCONNECTED [3],\SC_U/pixel_on712_in ,\rgb_out_reg[23]_i_739_n_2 ,\rgb_out_reg[23]_i_739_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,\rgb_out[23]_i_1268_n_0 ,1'b0,1'b0}),
        .O(\NLW_rgb_out_reg[23]_i_739_O_UNCONNECTED [3:0]),
        .S({1'b0,\rgb_out_reg[23]_i_720_n_0 ,\rgb_out[23]_i_1269_n_0 ,\rgb_out[23]_i_1270_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_740 
       (.CI(\rgb_out_reg[23]_i_1271_n_0 ),
        .CO({\NLW_rgb_out_reg[23]_i_740_CO_UNCONNECTED [3],\SC_U/pixel_on7 ,\rgb_out_reg[23]_i_740_n_2 ,\rgb_out_reg[23]_i_740_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,\rgb_out[23]_i_1272_n_0 ,1'b0,1'b0}),
        .O(\NLW_rgb_out_reg[23]_i_740_O_UNCONNECTED [3:0]),
        .S({1'b0,\rgb_out_reg[23]_i_720_n_0 ,\rgb_out[23]_i_1273_n_0 ,\rgb_out[23]_i_1274_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_741 
       (.CI(\rgb_out_reg[23]_i_1275_n_0 ),
        .CO({\NLW_rgb_out_reg[23]_i_741_CO_UNCONNECTED [3],\SC_U/pixel_on83_in ,\rgb_out_reg[23]_i_741_n_2 ,\rgb_out_reg[23]_i_741_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\rgb_out[23]_i_1276_n_0 ,\rgb_out[23]_i_1277_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_741_O_UNCONNECTED [3:0]),
        .S({1'b0,\rgb_out_reg[23]_i_720_n_0 ,\rgb_out[23]_i_1278_n_0 ,\rgb_out[23]_i_1279_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_743 
       (.CI(\rgb_out_reg[23]_i_1280_n_0 ),
        .CO({\NLW_rgb_out_reg[23]_i_743_CO_UNCONNECTED [3],\SC_U/pixel_on6 ,\rgb_out_reg[23]_i_743_n_2 ,\rgb_out_reg[23]_i_743_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,\rgb_out[23]_i_1281_n_0 ,1'b0,1'b0}),
        .O(\NLW_rgb_out_reg[23]_i_743_O_UNCONNECTED [3:0]),
        .S({1'b0,\rgb_out_reg[23]_i_716_n_3 ,\rgb_out[23]_i_1282_n_0 ,\rgb_out[23]_i_1283_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_745 
       (.CI(\rgb_out_reg[23]_i_1284_n_0 ),
        .CO({\NLW_rgb_out_reg[23]_i_745_CO_UNCONNECTED [3],\SC_U/pixel_on99_in ,\rgb_out_reg[23]_i_745_n_2 ,\rgb_out_reg[23]_i_745_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\rgb_out[23]_i_1285_n_0 ,\rgb_out[23]_i_1286_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_745_O_UNCONNECTED [3:0]),
        .S({1'b0,\rgb_out_reg[23]_i_716_n_3 ,\rgb_out[23]_i_1287_n_0 ,\rgb_out[23]_i_1288_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_746 
       (.CI(\rgb_out_reg[23]_i_1289_n_0 ),
        .CO({\NLW_rgb_out_reg[23]_i_746_CO_UNCONNECTED [3],\SC_U/pixel_on66_in ,\rgb_out_reg[23]_i_746_n_2 ,\rgb_out_reg[23]_i_746_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,\rgb_out[23]_i_1290_n_0 ,1'b0,1'b0}),
        .O(\NLW_rgb_out_reg[23]_i_746_O_UNCONNECTED [3:0]),
        .S({1'b0,\rgb_out_reg[23]_i_720_n_0 ,\rgb_out[23]_i_1291_n_0 ,\rgb_out[23]_i_1292_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_747 
       (.CI(\rgb_out_reg[23]_i_1293_n_0 ),
        .CO({\NLW_rgb_out_reg[23]_i_747_CO_UNCONNECTED [3],\SC_U/pixel_on75_in ,\rgb_out_reg[23]_i_747_n_2 ,\rgb_out_reg[23]_i_747_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\rgb_out[23]_i_1294_n_0 ,\rgb_out[23]_i_1295_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_747_O_UNCONNECTED [3:0]),
        .S({1'b0,\rgb_out_reg[23]_i_720_n_0 ,\rgb_out[23]_i_1296_n_0 ,\rgb_out[23]_i_1297_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_750 
       (.CI(\rgb_out_reg[23]_i_1298_n_0 ),
        .CO({\NLW_rgb_out_reg[23]_i_750_CO_UNCONNECTED [3],\SC_D/pixel_on712_in ,\rgb_out_reg[23]_i_750_n_2 ,\rgb_out_reg[23]_i_750_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,\rgb_out[23]_i_1299_n_0 ,1'b0,1'b0}),
        .O(\NLW_rgb_out_reg[23]_i_750_O_UNCONNECTED [3:0]),
        .S({1'b0,U0_n_15,\rgb_out[23]_i_1301_n_0 ,\rgb_out[23]_i_1302_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_751 
       (.CI(\rgb_out_reg[23]_i_1303_n_0 ),
        .CO({\NLW_rgb_out_reg[23]_i_751_CO_UNCONNECTED [3],\SC_D/pixel_on5 ,\rgb_out_reg[23]_i_751_n_2 ,\rgb_out_reg[23]_i_751_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\rgb_out[23]_i_1304_n_0 ,\rgb_out[23]_i_1305_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_751_O_UNCONNECTED [3:0]),
        .S({1'b0,U0_n_15,\rgb_out[23]_i_1306_n_0 ,\rgb_out[23]_i_1307_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_753 
       (.CI(\rgb_out_reg[23]_i_1313_n_0 ),
        .CO({\NLW_rgb_out_reg[23]_i_753_CO_UNCONNECTED [3],\SC_D/pixel_on8 ,\rgb_out_reg[23]_i_753_n_2 ,\rgb_out_reg[23]_i_753_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,\rgb_out[23]_i_1314_n_0 ,1'b0,1'b0}),
        .O(\NLW_rgb_out_reg[23]_i_753_O_UNCONNECTED [3:0]),
        .S({1'b0,\rgb_out_reg[23]_i_761_n_3 ,\rgb_out[23]_i_1315_n_0 ,\rgb_out[23]_i_1316_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_756 
       (.CI(\rgb_out_reg[23]_i_1326_n_0 ),
        .CO({\NLW_rgb_out_reg[23]_i_756_CO_UNCONNECTED [3],\SC_D/pixel_on75_in ,\rgb_out_reg[23]_i_756_n_2 ,\rgb_out_reg[23]_i_756_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\rgb_out[23]_i_1327_n_0 ,\rgb_out[23]_i_1328_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_756_O_UNCONNECTED [3:0]),
        .S({1'b0,U0_n_15,\rgb_out[23]_i_1329_n_0 ,\rgb_out[23]_i_1330_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_758 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_758_n_0 ,\rgb_out_reg[23]_i_758_n_1 ,\rgb_out_reg[23]_i_758_n_2 ,\rgb_out_reg[23]_i_758_n_3 }),
        .CYINIT(1'b1),
        .DI({\rgb_out[23]_i_1335_n_0 ,\SC_D/local_x [5],1'b0,\rgb_out[23]_i_1337_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_758_O_UNCONNECTED [3:0]),
        .S({\rgb_out[23]_i_1338_n_0 ,\rgb_out[23]_i_1339_n_0 ,\rgb_out[23]_i_1340_n_0 ,\rgb_out[23]_i_1341_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_761 
       (.CI(\rgb_out_reg[23]_i_1342_n_0 ),
        .CO({\NLW_rgb_out_reg[23]_i_761_CO_UNCONNECTED [3:1],\rgb_out_reg[23]_i_761_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(\NLW_rgb_out_reg[23]_i_761_O_UNCONNECTED [3:0]),
        .S({1'b0,1'b0,1'b0,1'b1}));
  CARRY4 \rgb_out_reg[23]_i_764 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_764_n_0 ,\rgb_out_reg[23]_i_764_n_1 ,\rgb_out_reg[23]_i_764_n_2 ,\rgb_out_reg[23]_i_764_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\rgb_out[23]_i_1343_n_0 ,\rgb_out[23]_i_1344_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_764_O_UNCONNECTED [3:0]),
        .S({\rgb_out[23]_i_1345_n_0 ,\rgb_out[23]_i_1346_n_0 ,\rgb_out[23]_i_1347_n_0 ,\rgb_out[23]_i_1348_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_768 
       (.CI(\rgb_out_reg[23]_i_1349_n_0 ),
        .CO({\NLW_rgb_out_reg[23]_i_768_CO_UNCONNECTED [3],\SC_D/pixel_on3 ,\rgb_out_reg[23]_i_768_n_2 ,\rgb_out_reg[23]_i_768_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\rgb_out[23]_i_1350_n_0 ,\rgb_out[23]_i_1351_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_768_O_UNCONNECTED [3:0]),
        .S({1'b0,U0_n_15,\rgb_out[23]_i_1352_n_0 ,\rgb_out[23]_i_1353_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_769 
       (.CI(\rgb_out_reg[23]_i_1354_n_0 ),
        .CO({\NLW_rgb_out_reg[23]_i_769_CO_UNCONNECTED [3],\SC_D/pixel_on40_in ,\rgb_out_reg[23]_i_769_n_2 ,\rgb_out_reg[23]_i_769_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\rgb_out[23]_i_1355_n_0 ,\rgb_out[23]_i_1356_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_769_O_UNCONNECTED [3:0]),
        .S({1'b0,\rgb_out_reg[23]_i_761_n_3 ,\rgb_out[23]_i_1357_n_0 ,\rgb_out[23]_i_1358_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_770 
       (.CI(\rgb_out_reg[23]_i_1359_n_0 ),
        .CO({\NLW_rgb_out_reg[23]_i_770_CO_UNCONNECTED [3:2],\SC_D/pixel_on2 ,\rgb_out_reg[23]_i_770_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\SC_D/local_y [12],1'b0}),
        .O(\NLW_rgb_out_reg[23]_i_770_O_UNCONNECTED [3:0]),
        .S({1'b0,1'b0,U0_n_15,\rgb_out[23]_i_1361_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_771 
       (.CI(\rgb_out_reg[23]_i_1362_n_0 ),
        .CO({\NLW_rgb_out_reg[23]_i_771_CO_UNCONNECTED [3:2],\SC_D/pixel_on4 ,\rgb_out_reg[23]_i_771_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\SC_D/local_x [12],1'b0}),
        .O(\NLW_rgb_out_reg[23]_i_771_O_UNCONNECTED [3:0]),
        .S({1'b0,1'b0,\rgb_out_reg[23]_i_761_n_3 ,\rgb_out[23]_i_1364_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_777 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_777_n_0 ,\rgb_out_reg[23]_i_777_n_1 ,\rgb_out_reg[23]_i_777_n_2 ,\rgb_out_reg[23]_i_777_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\rgb_out[23]_i_1365_n_0 ,\rgb_out[23]_i_1366_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_777_O_UNCONNECTED [3:0]),
        .S({\rgb_out[23]_i_1367_n_0 ,\rgb_out[23]_i_1368_n_0 ,\rgb_out[23]_i_1369_n_0 ,\rgb_out[23]_i_1370_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_779 
       (.CI(\rgb_out_reg[23]_i_1371_n_0 ),
        .CO({\rgb_out_reg[23]_i_779_n_0 ,\NLW_rgb_out_reg[23]_i_779_CO_UNCONNECTED [2],\rgb_out_reg[23]_i_779_n_2 ,\rgb_out_reg[23]_i_779_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,pixel_y[11:9]}),
        .O({\NLW_rgb_out_reg[23]_i_779_O_UNCONNECTED [3],\TM_D/local_y [11:9]}),
        .S({1'b1,\rgb_out[23]_i_1372_n_0 ,\rgb_out[23]_i_1373_n_0 ,\rgb_out[23]_i_1374_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_782 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_782_n_0 ,\rgb_out_reg[23]_i_782_n_1 ,\rgb_out_reg[23]_i_782_n_2 ,\rgb_out_reg[23]_i_782_n_3 }),
        .CYINIT(1'b1),
        .DI({\rgb_out[23]_i_1375_n_0 ,1'b0,\TM_D/local_y [3],\rgb_out[23]_i_1377_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_782_O_UNCONNECTED [3:0]),
        .S({\rgb_out[23]_i_1378_n_0 ,\rgb_out[23]_i_1379_n_0 ,\rgb_out[23]_i_1380_n_0 ,\rgb_out[23]_i_1381_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_792 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_792_n_0 ,\rgb_out_reg[23]_i_792_n_1 ,\rgb_out_reg[23]_i_792_n_2 ,\rgb_out_reg[23]_i_792_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,\rgb_out[23]_i_1389_n_0 ,\rgb_out[23]_i_1390_n_0 ,\rgb_out[23]_i_1391_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_792_O_UNCONNECTED [3:0]),
        .S({\rgb_out[23]_i_1392_n_0 ,\rgb_out[23]_i_1393_n_0 ,\rgb_out[23]_i_1394_n_0 ,\rgb_out[23]_i_1395_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_796 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_796_n_0 ,\rgb_out_reg[23]_i_796_n_1 ,\rgb_out_reg[23]_i_796_n_2 ,\rgb_out_reg[23]_i_796_n_3 }),
        .CYINIT(1'b1),
        .DI({\rgb_out[23]_i_1396_n_0 ,\rgb_out[23]_i_1397_n_0 ,\TM_D/local_y [3],\rgb_out[23]_i_1398_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_796_O_UNCONNECTED [3:0]),
        .S({\rgb_out[23]_i_1399_n_0 ,\rgb_out[23]_i_1400_n_0 ,\rgb_out[23]_i_1401_n_0 ,\rgb_out[23]_i_1402_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_801 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_801_n_0 ,\rgb_out_reg[23]_i_801_n_1 ,\rgb_out_reg[23]_i_801_n_2 ,\rgb_out_reg[23]_i_801_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,\rgb_out[23]_i_1403_n_0 ,\rgb_out[23]_i_1404_n_0 ,\rgb_out[23]_i_1405_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_801_O_UNCONNECTED [3:0]),
        .S({\rgb_out[23]_i_1406_n_0 ,\rgb_out[23]_i_1407_n_0 ,\rgb_out[23]_i_1408_n_0 ,\rgb_out[23]_i_1409_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_805 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_805_n_0 ,\rgb_out_reg[23]_i_805_n_1 ,\rgb_out_reg[23]_i_805_n_2 ,\rgb_out_reg[23]_i_805_n_3 }),
        .CYINIT(1'b1),
        .DI({\rgb_out[23]_i_1410_n_0 ,\TM_D/local_y [5],1'b0,\rgb_out[23]_i_1411_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_805_O_UNCONNECTED [3:0]),
        .S({\rgb_out[23]_i_1412_n_0 ,\rgb_out[23]_i_1413_n_0 ,\rgb_out[23]_i_1414_n_0 ,\rgb_out[23]_i_1415_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_810 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_810_n_0 ,\rgb_out_reg[23]_i_810_n_1 ,\rgb_out_reg[23]_i_810_n_2 ,\rgb_out_reg[23]_i_810_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,\rgb_out[23]_i_1416_n_0 ,\rgb_out[23]_i_1417_n_0 ,\rgb_out[23]_i_1418_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_810_O_UNCONNECTED [3:0]),
        .S({\rgb_out[23]_i_1419_n_0 ,\rgb_out[23]_i_1420_n_0 ,\rgb_out[23]_i_1421_n_0 ,\rgb_out[23]_i_1422_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_815 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_815_n_0 ,\rgb_out_reg[23]_i_815_n_1 ,\rgb_out_reg[23]_i_815_n_2 ,\rgb_out_reg[23]_i_815_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,pixel_x[3],1'b0}),
        .O(\TM_D/local_x [5:2]),
        .S({pixel_x[5:4],\rgb_out[23]_i_1423_n_0 ,pixel_x[2]}));
  CARRY4 \rgb_out_reg[23]_i_821 
       (.CI(\rgb_out_reg[23]_i_815_n_0 ),
        .CO({\rgb_out_reg[23]_i_821_n_0 ,\rgb_out_reg[23]_i_821_n_1 ,\rgb_out_reg[23]_i_821_n_2 ,\rgb_out_reg[23]_i_821_n_3 }),
        .CYINIT(1'b0),
        .DI({pixel_x[9],1'b0,pixel_x[7],1'b0}),
        .O(\TM_D/local_x [9:6]),
        .S({\rgb_out[23]_i_1424_n_0 ,pixel_x[8],\rgb_out[23]_i_1425_n_0 ,pixel_x[6]}));
  CARRY4 \rgb_out_reg[23]_i_829 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_829_n_0 ,\rgb_out_reg[23]_i_829_n_1 ,\rgb_out_reg[23]_i_829_n_2 ,\rgb_out_reg[23]_i_829_n_3 }),
        .CYINIT(1'b1),
        .DI({\rgb_out[23]_i_1426_n_0 ,\rgb_out[23]_i_1427_n_0 ,\rgb_out[23]_i_1428_n_0 ,\rgb_out[23]_i_1429_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_829_O_UNCONNECTED [3:0]),
        .S({\rgb_out[23]_i_1430_n_0 ,\rgb_out[23]_i_1431_n_0 ,\rgb_out[23]_i_1432_n_0 ,\rgb_out[23]_i_1433_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_834 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_834_n_0 ,\rgb_out_reg[23]_i_834_n_1 ,\rgb_out_reg[23]_i_834_n_2 ,\rgb_out_reg[23]_i_834_n_3 }),
        .CYINIT(1'b1),
        .DI({\rgb_out[23]_i_1434_n_0 ,\rgb_out[23]_i_1435_n_0 ,\rgb_out[23]_i_1436_n_0 ,\rgb_out[23]_i_1437_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_834_O_UNCONNECTED [3:0]),
        .S({\rgb_out[23]_i_1438_n_0 ,\rgb_out[23]_i_1439_n_0 ,\rgb_out[23]_i_1440_n_0 ,\rgb_out[23]_i_1441_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_839 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_839_n_0 ,\rgb_out_reg[23]_i_839_n_1 ,\rgb_out_reg[23]_i_839_n_2 ,\rgb_out_reg[23]_i_839_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\rgb_out[23]_i_1442_n_0 ,\rgb_out[23]_i_1443_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_839_O_UNCONNECTED [3:0]),
        .S({\rgb_out[23]_i_1444_n_0 ,\rgb_out[23]_i_1445_n_0 ,\rgb_out[23]_i_1446_n_0 ,\rgb_out[23]_i_1447_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_842 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_842_n_0 ,\rgb_out_reg[23]_i_842_n_1 ,\rgb_out_reg[23]_i_842_n_2 ,\rgb_out_reg[23]_i_842_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\rgb_out[23]_i_1448_n_0 ,\rgb_out[23]_i_1449_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_842_O_UNCONNECTED [3:0]),
        .S({\rgb_out[23]_i_1450_n_0 ,\rgb_out[23]_i_1451_n_0 ,\rgb_out[23]_i_1452_n_0 ,\rgb_out[23]_i_1453_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_927 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_927_n_0 ,\rgb_out_reg[23]_i_927_n_1 ,\rgb_out_reg[23]_i_927_n_2 ,\rgb_out_reg[23]_i_927_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\rgb_out[23]_i_1497_n_0 ,\rgb_out[23]_i_1498_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_927_O_UNCONNECTED [3:0]),
        .S({\rgb_out[23]_i_1499_n_0 ,\rgb_out[23]_i_1500_n_0 ,\rgb_out[23]_i_1501_n_0 ,\rgb_out[23]_i_1502_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_929 
       (.CI(\rgb_out_reg[23]_i_1503_n_0 ),
        .CO({\rgb_out_reg[23]_i_929_n_0 ,\NLW_rgb_out_reg[23]_i_929_CO_UNCONNECTED [2],\rgb_out_reg[23]_i_929_n_2 ,\rgb_out_reg[23]_i_929_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,pixel_y[11:9]}),
        .O({\NLW_rgb_out_reg[23]_i_929_O_UNCONNECTED [3],\REC_D/local_y [11:9]}),
        .S({1'b1,\rgb_out[23]_i_1504_n_0 ,\rgb_out[23]_i_1505_n_0 ,\rgb_out[23]_i_1506_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_932 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_932_n_0 ,\rgb_out_reg[23]_i_932_n_1 ,\rgb_out_reg[23]_i_932_n_2 ,\rgb_out_reg[23]_i_932_n_3 }),
        .CYINIT(1'b1),
        .DI({\rgb_out[23]_i_1507_n_0 ,1'b0,\REC_D/local_y [3],\rgb_out[23]_i_1509_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_932_O_UNCONNECTED [3:0]),
        .S({\rgb_out[23]_i_1510_n_0 ,\rgb_out[23]_i_1511_n_0 ,\rgb_out[23]_i_1512_n_0 ,\rgb_out[23]_i_1513_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_937 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_937_n_0 ,\rgb_out_reg[23]_i_937_n_1 ,\rgb_out_reg[23]_i_937_n_2 ,\rgb_out_reg[23]_i_937_n_3 }),
        .CYINIT(1'b1),
        .DI({\rgb_out[23]_i_1514_n_0 ,\rgb_out[23]_i_1515_n_0 ,\REC_D/local_x [3],\rgb_out[23]_i_1517_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_937_O_UNCONNECTED [3:0]),
        .S({\rgb_out[23]_i_1518_n_0 ,\rgb_out[23]_i_1519_n_0 ,\rgb_out[23]_i_1520_n_0 ,\rgb_out[23]_i_1521_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_942 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_942_n_0 ,\rgb_out_reg[23]_i_942_n_1 ,\rgb_out_reg[23]_i_942_n_2 ,\rgb_out_reg[23]_i_942_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,\rgb_out[23]_i_1522_n_0 ,\rgb_out[23]_i_1523_n_0 ,\rgb_out[23]_i_1524_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_942_O_UNCONNECTED [3:0]),
        .S({\rgb_out[23]_i_1525_n_0 ,\rgb_out[23]_i_1526_n_0 ,\rgb_out[23]_i_1527_n_0 ,\rgb_out[23]_i_1528_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_946 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_946_n_0 ,\rgb_out_reg[23]_i_946_n_1 ,\rgb_out_reg[23]_i_946_n_2 ,\rgb_out_reg[23]_i_946_n_3 }),
        .CYINIT(1'b1),
        .DI({\rgb_out[23]_i_1529_n_0 ,\rgb_out[23]_i_1530_n_0 ,\REC_D/local_y [3],\rgb_out[23]_i_1531_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_946_O_UNCONNECTED [3:0]),
        .S({\rgb_out[23]_i_1532_n_0 ,\rgb_out[23]_i_1533_n_0 ,\rgb_out[23]_i_1534_n_0 ,\rgb_out[23]_i_1535_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_951 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_951_n_0 ,\rgb_out_reg[23]_i_951_n_1 ,\rgb_out_reg[23]_i_951_n_2 ,\rgb_out_reg[23]_i_951_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,\rgb_out[23]_i_1536_n_0 ,\rgb_out[23]_i_1537_n_0 ,\rgb_out[23]_i_1538_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_951_O_UNCONNECTED [3:0]),
        .S({\rgb_out[23]_i_1539_n_0 ,\rgb_out[23]_i_1540_n_0 ,\rgb_out[23]_i_1541_n_0 ,\rgb_out[23]_i_1542_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_955 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_955_n_0 ,\rgb_out_reg[23]_i_955_n_1 ,\rgb_out_reg[23]_i_955_n_2 ,\rgb_out_reg[23]_i_955_n_3 }),
        .CYINIT(1'b1),
        .DI({\rgb_out[23]_i_1543_n_0 ,\REC_D/local_y [5],1'b0,\rgb_out[23]_i_1544_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_955_O_UNCONNECTED [3:0]),
        .S({\rgb_out[23]_i_1545_n_0 ,\rgb_out[23]_i_1546_n_0 ,\rgb_out[23]_i_1547_n_0 ,\rgb_out[23]_i_1548_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_960 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_960_n_0 ,\rgb_out_reg[23]_i_960_n_1 ,\rgb_out_reg[23]_i_960_n_2 ,\rgb_out_reg[23]_i_960_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,\rgb_out[23]_i_1549_n_0 ,\rgb_out[23]_i_1550_n_0 ,\rgb_out[23]_i_1551_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_960_O_UNCONNECTED [3:0]),
        .S({\rgb_out[23]_i_1552_n_0 ,\rgb_out[23]_i_1553_n_0 ,\rgb_out[23]_i_1554_n_0 ,\rgb_out[23]_i_1555_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_965 
       (.CI(\rgb_out_reg[23]_i_1516_n_0 ),
        .CO({\rgb_out_reg[23]_i_965_n_0 ,\rgb_out_reg[23]_i_965_n_1 ,\rgb_out_reg[23]_i_965_n_2 ,\rgb_out_reg[23]_i_965_n_3 }),
        .CYINIT(1'b0),
        .DI({pixel_x[8],1'b0,pixel_x[6:5]}),
        .O(\REC_D/local_x [8:5]),
        .S({\rgb_out[23]_i_1556_n_0 ,pixel_x[7],\rgb_out[23]_i_1557_n_0 ,\rgb_out[23]_i_1558_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_979 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_979_n_0 ,\rgb_out_reg[23]_i_979_n_1 ,\rgb_out_reg[23]_i_979_n_2 ,\rgb_out_reg[23]_i_979_n_3 }),
        .CYINIT(1'b1),
        .DI({\rgb_out[23]_i_1559_n_0 ,\rgb_out[23]_i_1560_n_0 ,\rgb_out[23]_i_1561_n_0 ,\rgb_out[23]_i_1562_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_979_O_UNCONNECTED [3:0]),
        .S({\rgb_out[23]_i_1563_n_0 ,\rgb_out[23]_i_1564_n_0 ,\rgb_out[23]_i_1565_n_0 ,\rgb_out[23]_i_1566_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_984 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_984_n_0 ,\rgb_out_reg[23]_i_984_n_1 ,\rgb_out_reg[23]_i_984_n_2 ,\rgb_out_reg[23]_i_984_n_3 }),
        .CYINIT(1'b1),
        .DI({\rgb_out[23]_i_1567_n_0 ,\rgb_out[23]_i_1568_n_0 ,\rgb_out[23]_i_1569_n_0 ,\rgb_out[23]_i_1570_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_984_O_UNCONNECTED [3:0]),
        .S({\rgb_out[23]_i_1571_n_0 ,\rgb_out[23]_i_1572_n_0 ,\rgb_out[23]_i_1573_n_0 ,\rgb_out[23]_i_1574_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_989 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_989_n_0 ,\rgb_out_reg[23]_i_989_n_1 ,\rgb_out_reg[23]_i_989_n_2 ,\rgb_out_reg[23]_i_989_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\rgb_out[23]_i_1575_n_0 ,\rgb_out[23]_i_1576_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_989_O_UNCONNECTED [3:0]),
        .S({\rgb_out[23]_i_1577_n_0 ,\rgb_out[23]_i_1578_n_0 ,\rgb_out[23]_i_1579_n_0 ,\rgb_out[23]_i_1580_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_992 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_992_n_0 ,\rgb_out_reg[23]_i_992_n_1 ,\rgb_out_reg[23]_i_992_n_2 ,\rgb_out_reg[23]_i_992_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\rgb_out[23]_i_1581_n_0 ,\rgb_out[23]_i_1582_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_992_O_UNCONNECTED [3:0]),
        .S({\rgb_out[23]_i_1583_n_0 ,\rgb_out[23]_i_1584_n_0 ,\rgb_out[23]_i_1585_n_0 ,\rgb_out[23]_i_1586_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_995 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_995_n_0 ,\rgb_out_reg[23]_i_995_n_1 ,\rgb_out_reg[23]_i_995_n_2 ,\rgb_out_reg[23]_i_995_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\rgb_out[23]_i_1587_n_0 ,\rgb_out[23]_i_1588_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_995_O_UNCONNECTED [3:0]),
        .S({\rgb_out[23]_i_1589_n_0 ,\rgb_out[23]_i_1590_n_0 ,\rgb_out[23]_i_1591_n_0 ,\rgb_out[23]_i_1592_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_997 
       (.CI(\rgb_out_reg[23]_i_1593_n_0 ),
        .CO({\rgb_out_reg[23]_i_997_n_0 ,\NLW_rgb_out_reg[23]_i_997_CO_UNCONNECTED [2],\rgb_out_reg[23]_i_997_n_2 ,\rgb_out_reg[23]_i_997_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,pixel_x[11:9]}),
        .O({\NLW_rgb_out_reg[23]_i_997_O_UNCONNECTED [3],\LAST_U/local_x [11:9]}),
        .S({1'b1,\rgb_out[23]_i_1594_n_0 ,\rgb_out[23]_i_1595_n_0 ,\rgb_out[23]_i_1596_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_999 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_999_n_0 ,\rgb_out_reg[23]_i_999_n_1 ,\rgb_out_reg[23]_i_999_n_2 ,\rgb_out_reg[23]_i_999_n_3 }),
        .CYINIT(\rgb_out[23]_i_1597_n_0 ),
        .DI({1'b0,1'b0,1'b0,\rgb_out[23]_i_1598_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_999_O_UNCONNECTED [3:0]),
        .S({\rgb_out[23]_i_1599_n_0 ,\rgb_out[23]_i_1600_n_0 ,\rgb_out[23]_i_1601_n_0 ,\rgb_out[23]_i_1602_n_0 }));
endmodule

(* ORIG_REF_NAME = "chiffre_7seg" *) 
module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_chiffre_7seg__parameterized2
   (CO,
    D,
    \rgb_out_reg[20] ,
    \rgb_out_reg[20]_0 ,
    \rgb_out_reg[20]_1 ,
    \rgb_out_reg[20]_2 ,
    \rgb_out_reg[20]_3 ,
    \rgb_out_reg[20]_4 ,
    \rgb_out_reg[20]_5 ,
    \rgb_out_reg[20]_6 ,
    \rgb_out_reg[20]_7 ,
    pixel_x,
    pixel_y,
    pixel_x_5_sp_1,
    rgb_in,
    pixel_x_2_sp_1,
    \pixel_x[2]_0 ,
    pixel_x_1_sp_1,
    is_pixel_mur,
    pixel_y_4_sp_1,
    \pixel_y[4]_0 ,
    pixel_y_9_sp_1,
    \pixel_x[2]_1 ,
    mode_ui_1_sp_1,
    \pixel_y[4]_1 ,
    \pixel_x[2]_2 ,
    mode_ui_2_sp_1,
    pixel_y_6_sp_1,
    pixel_x_3_sp_1,
    \pixel_x[2]_3 ,
    pixel_y_7_sp_1,
    \pixel_y[4]_2 ,
    \pixel_y[4]_3 ,
    mode_ui_0_sp_1,
    \pixel_y[9]_0 ,
    \pixel_x[2]_4 ,
    \pixel_x[3]_0 ,
    \pixel_y[4]_4 ,
    \pixel_x[2]_5 ,
    \pixel_x[2]_6 ,
    \pixel_x[3]_1 ,
    \pixel_x[2]_7 ,
    \pixel_y[4]_5 ,
    \pixel_x[2]_8 ,
    \pixel_x[3]_2 ,
    \pixel_y[4]_6 ,
    \pixel_x[2]_9 ,
    \pixel_x[3]_3 ,
    \pixel_y[4]_7 ,
    \pixel_x[2]_10 ,
    \pixel_x[3]_4 ,
    \pixel_y[4]_8 ,
    \pixel_x[2]_11 ,
    \pixel_x[3]_5 ,
    \pixel_y[4]_9 ,
    \pixel_x[2]_12 ,
    \pixel_x[3]_6 ,
    \pixel_y[4]_10 ,
    \pixel_x[2]_13 ,
    \pixel_x[3]_7 ,
    \pixel_y[4]_11 ,
    \pixel_x[2]_14 ,
    \pixel_x[3]_8 ,
    \pixel_y[4]_12 ,
    \pixel_x[2]_15 ,
    \pixel_x[3]_9 ,
    \pixel_y[4]_13 ,
    \pixel_x[2]_16 ,
    \pixel_x[3]_10 ,
    \pixel_y[4]_14 ,
    \pixel_x[2]_17 ,
    \pixel_x[3]_11 ,
    \pixel_x[2]_18 ,
    mode_ui,
    \pixel_x[1]_0 ,
    \mode_ui[0]_0 ,
    \pixel_x[2]_19 ,
    \pixel_x[2]_20 ,
    \pixel_y[9]_1 ,
    \pixel_x[2]_21 ,
    \pixel_x[2]_22 ,
    \pixel_x[2]_23 ,
    \pixel_x[2]_24 ,
    \pixel_x[2]_25 ,
    \pixel_x[3]_12 ,
    \mode_ui[2]_0 ,
    \mode_ui[2]_1 ,
    num_tm_d,
    \pixel_x[5]_0 ,
    pixel_x_8_sp_1,
    decompte_ui_1_sp_1,
    pixel_y_2_sp_1,
    \temps_restant[2] ,
    decompte_ui,
    \pixel_y[2]_0 ,
    pixel_y_5_sp_1,
    \pixel_y[2]_1 ,
    \pixel_x[5]_1 ,
    \pixel_x[5]_2 ,
    \pixel_y[5]_0 ,
    \pixel_y[2]_2 ,
    \pixel_y[5]_1 ,
    \pixel_y[2]_3 ,
    \pixel_y[2]_4 ,
    DI,
    S,
    \pixel_x[1]_1 ,
    \pixel_x[3]_13 ,
    \pixel_x[2]_26 ,
    \pixel_x[3]_14 ,
    \pixel_x[5]_3 ,
    pixel_x_4_sp_1);
  output [0:0]CO;
  output [23:0]D;
  output [0:0]\rgb_out_reg[20] ;
  output [0:0]\rgb_out_reg[20]_0 ;
  output [0:0]\rgb_out_reg[20]_1 ;
  output [0:0]\rgb_out_reg[20]_2 ;
  output [0:0]\rgb_out_reg[20]_3 ;
  output [0:0]\rgb_out_reg[20]_4 ;
  output [0:0]\rgb_out_reg[20]_5 ;
  output [0:0]\rgb_out_reg[20]_6 ;
  output [0:0]\rgb_out_reg[20]_7 ;
  input [11:0]pixel_x;
  input [11:0]pixel_y;
  input pixel_x_5_sp_1;
  input [11:0]rgb_in;
  input pixel_x_2_sp_1;
  input \pixel_x[2]_0 ;
  input pixel_x_1_sp_1;
  input is_pixel_mur;
  input pixel_y_4_sp_1;
  input \pixel_y[4]_0 ;
  input pixel_y_9_sp_1;
  input \pixel_x[2]_1 ;
  input mode_ui_1_sp_1;
  input \pixel_y[4]_1 ;
  input \pixel_x[2]_2 ;
  input mode_ui_2_sp_1;
  input pixel_y_6_sp_1;
  input pixel_x_3_sp_1;
  input \pixel_x[2]_3 ;
  input pixel_y_7_sp_1;
  input \pixel_y[4]_2 ;
  input \pixel_y[4]_3 ;
  input mode_ui_0_sp_1;
  input \pixel_y[9]_0 ;
  input \pixel_x[2]_4 ;
  input \pixel_x[3]_0 ;
  input \pixel_y[4]_4 ;
  input \pixel_x[2]_5 ;
  input \pixel_x[2]_6 ;
  input \pixel_x[3]_1 ;
  input \pixel_x[2]_7 ;
  input \pixel_y[4]_5 ;
  input \pixel_x[2]_8 ;
  input \pixel_x[3]_2 ;
  input \pixel_y[4]_6 ;
  input \pixel_x[2]_9 ;
  input \pixel_x[3]_3 ;
  input \pixel_y[4]_7 ;
  input \pixel_x[2]_10 ;
  input \pixel_x[3]_4 ;
  input \pixel_y[4]_8 ;
  input \pixel_x[2]_11 ;
  input \pixel_x[3]_5 ;
  input \pixel_y[4]_9 ;
  input \pixel_x[2]_12 ;
  input \pixel_x[3]_6 ;
  input \pixel_y[4]_10 ;
  input \pixel_x[2]_13 ;
  input \pixel_x[3]_7 ;
  input \pixel_y[4]_11 ;
  input \pixel_x[2]_14 ;
  input \pixel_x[3]_8 ;
  input \pixel_y[4]_12 ;
  input \pixel_x[2]_15 ;
  input \pixel_x[3]_9 ;
  input \pixel_y[4]_13 ;
  input \pixel_x[2]_16 ;
  input \pixel_x[3]_10 ;
  input \pixel_y[4]_14 ;
  input \pixel_x[2]_17 ;
  input \pixel_x[3]_11 ;
  input \pixel_x[2]_18 ;
  input [2:0]mode_ui;
  input \pixel_x[1]_0 ;
  input \mode_ui[0]_0 ;
  input \pixel_x[2]_19 ;
  input \pixel_x[2]_20 ;
  input \pixel_y[9]_1 ;
  input \pixel_x[2]_21 ;
  input \pixel_x[2]_22 ;
  input \pixel_x[2]_23 ;
  input \pixel_x[2]_24 ;
  input \pixel_x[2]_25 ;
  input \pixel_x[3]_12 ;
  input \mode_ui[2]_0 ;
  input \mode_ui[2]_1 ;
  input num_tm_d;
  input \pixel_x[5]_0 ;
  input pixel_x_8_sp_1;
  input decompte_ui_1_sp_1;
  input pixel_y_2_sp_1;
  input \temps_restant[2] ;
  input [3:0]decompte_ui;
  input \pixel_y[2]_0 ;
  input pixel_y_5_sp_1;
  input \pixel_y[2]_1 ;
  input \pixel_x[5]_1 ;
  input \pixel_x[5]_2 ;
  input \pixel_y[5]_0 ;
  input \pixel_y[2]_2 ;
  input \pixel_y[5]_1 ;
  input \pixel_y[2]_3 ;
  input \pixel_y[2]_4 ;
  input [0:0]DI;
  input [1:0]S;
  input [0:0]\pixel_x[1]_1 ;
  input [1:0]\pixel_x[3]_13 ;
  input [1:0]\pixel_x[2]_26 ;
  input [1:0]\pixel_x[3]_14 ;
  input [0:0]\pixel_x[5]_3 ;
  input pixel_x_4_sp_1;

  wire [0:0]CO;
  wire [23:0]D;
  wire [0:0]DI;
  wire [1:0]S;
  wire [3:0]decompte_ui;
  wire decompte_ui_1_sn_1;
  wire is_pixel_mur;
  wire [12:4]local_x_2;
  wire local_x_carry__0_i_1_n_0;
  wire local_x_carry__0_i_2_n_0;
  wire local_x_carry__0_n_0;
  wire local_x_carry__0_n_1;
  wire local_x_carry__0_n_2;
  wire local_x_carry__0_n_3;
  wire local_x_carry_i_1_n_0;
  wire local_x_carry_i_2_n_0;
  wire local_x_carry_n_0;
  wire local_x_carry_n_1;
  wire local_x_carry_n_2;
  wire local_x_carry_n_3;
  wire [12:1]local_y_3;
  wire local_y_carry__0_i_1_n_0;
  wire local_y_carry__0_i_2_n_0;
  wire local_y_carry__0_i_3_n_0;
  wire local_y_carry__0_i_4_n_0;
  wire local_y_carry__0_n_0;
  wire local_y_carry__0_n_1;
  wire local_y_carry__0_n_2;
  wire local_y_carry__0_n_3;
  wire local_y_carry__1_i_1_n_0;
  wire local_y_carry__1_i_2_n_0;
  wire local_y_carry__1_i_3_n_0;
  wire local_y_carry__1_n_0;
  wire local_y_carry__1_n_2;
  wire local_y_carry__1_n_3;
  wire local_y_carry_i_1_n_0;
  wire local_y_carry_i_2_n_0;
  wire local_y_carry_n_0;
  wire local_y_carry_n_1;
  wire local_y_carry_n_2;
  wire local_y_carry_n_3;
  wire [2:0]mode_ui;
  wire \mode_ui[0]_0 ;
  wire \mode_ui[2]_0 ;
  wire \mode_ui[2]_1 ;
  wire mode_ui_0_sn_1;
  wire mode_ui_1_sn_1;
  wire mode_ui_2_sn_1;
  wire num_tm_d;
  wire pixel_on2;
  wire pixel_on3;
  wire pixel_on3_carry__0_i_1_n_0;
  wire pixel_on3_carry__0_i_2_n_0;
  wire pixel_on3_carry__0_i_3_n_0;
  wire pixel_on3_carry__0_i_4_n_0;
  wire pixel_on3_carry__0_n_2;
  wire pixel_on3_carry__0_n_3;
  wire pixel_on3_carry_i_1_n_0;
  wire pixel_on3_carry_i_2_n_0;
  wire pixel_on3_carry_i_3_n_0;
  wire pixel_on3_carry_i_4_n_0;
  wire pixel_on3_carry_i_5_n_0;
  wire pixel_on3_carry_i_6_n_0;
  wire pixel_on3_carry_i_7_n_0;
  wire pixel_on3_carry_i_8_n_0;
  wire pixel_on3_carry_n_0;
  wire pixel_on3_carry_n_1;
  wire pixel_on3_carry_n_2;
  wire pixel_on3_carry_n_3;
  wire pixel_on4;
  wire pixel_on40_in;
  wire pixel_on4__6_carry__0_i_2_n_0;
  wire pixel_on4__6_carry__0_n_3;
  wire pixel_on4__6_carry_i_1_n_0;
  wire pixel_on4__6_carry_i_2_n_0;
  wire pixel_on4__6_carry_i_3_n_0;
  wire pixel_on4__6_carry_i_4_n_0;
  wire pixel_on4__6_carry_i_5_n_0;
  wire pixel_on4__6_carry_i_6_n_0;
  wire pixel_on4__6_carry_n_0;
  wire pixel_on4__6_carry_n_1;
  wire pixel_on4__6_carry_n_2;
  wire pixel_on4__6_carry_n_3;
  wire pixel_on4_carry__0_i_1_n_0;
  wire pixel_on4_carry__0_i_2_n_0;
  wire pixel_on4_carry__0_i_3_n_0;
  wire pixel_on4_carry__0_i_4_n_0;
  wire pixel_on4_carry__0_n_2;
  wire pixel_on4_carry__0_n_3;
  wire pixel_on4_carry_i_1_n_0;
  wire pixel_on4_carry_i_2_n_0;
  wire pixel_on4_carry_i_3_n_0;
  wire pixel_on4_carry_i_4_n_0;
  wire pixel_on4_carry_i_5_n_0;
  wire pixel_on4_carry_i_6_n_0;
  wire pixel_on4_carry_i_7_n_0;
  wire pixel_on4_carry_i_8_n_0;
  wire pixel_on4_carry_n_0;
  wire pixel_on4_carry_n_1;
  wire pixel_on4_carry_n_2;
  wire pixel_on4_carry_n_3;
  wire pixel_on8;
  wire pixel_on8_carry__0_i_1_n_0;
  wire pixel_on8_carry__0_i_3_n_0;
  wire pixel_on8_carry__0_i_4_n_0;
  wire pixel_on8_carry__0_n_2;
  wire pixel_on8_carry__0_n_3;
  wire pixel_on8_carry_i_1_n_0;
  wire pixel_on8_carry_i_2_n_0;
  wire pixel_on8_carry_i_3_n_0;
  wire pixel_on8_carry_i_4_n_0;
  wire pixel_on8_carry_i_5_n_0;
  wire pixel_on8_carry_i_6_n_0;
  wire pixel_on8_carry_i_7_n_0;
  wire pixel_on8_carry_n_0;
  wire pixel_on8_carry_n_1;
  wire pixel_on8_carry_n_2;
  wire pixel_on8_carry_n_3;
  wire pixel_on9;
  wire pixel_on99_in;
  wire [11:0]pixel_x;
  wire \pixel_x[1]_0 ;
  wire [0:0]\pixel_x[1]_1 ;
  wire \pixel_x[2]_0 ;
  wire \pixel_x[2]_1 ;
  wire \pixel_x[2]_10 ;
  wire \pixel_x[2]_11 ;
  wire \pixel_x[2]_12 ;
  wire \pixel_x[2]_13 ;
  wire \pixel_x[2]_14 ;
  wire \pixel_x[2]_15 ;
  wire \pixel_x[2]_16 ;
  wire \pixel_x[2]_17 ;
  wire \pixel_x[2]_18 ;
  wire \pixel_x[2]_19 ;
  wire \pixel_x[2]_2 ;
  wire \pixel_x[2]_20 ;
  wire \pixel_x[2]_21 ;
  wire \pixel_x[2]_22 ;
  wire \pixel_x[2]_23 ;
  wire \pixel_x[2]_24 ;
  wire \pixel_x[2]_25 ;
  wire [1:0]\pixel_x[2]_26 ;
  wire \pixel_x[2]_3 ;
  wire \pixel_x[2]_4 ;
  wire \pixel_x[2]_5 ;
  wire \pixel_x[2]_6 ;
  wire \pixel_x[2]_7 ;
  wire \pixel_x[2]_8 ;
  wire \pixel_x[2]_9 ;
  wire \pixel_x[3]_0 ;
  wire \pixel_x[3]_1 ;
  wire \pixel_x[3]_10 ;
  wire \pixel_x[3]_11 ;
  wire \pixel_x[3]_12 ;
  wire [1:0]\pixel_x[3]_13 ;
  wire [1:0]\pixel_x[3]_14 ;
  wire \pixel_x[3]_2 ;
  wire \pixel_x[3]_3 ;
  wire \pixel_x[3]_4 ;
  wire \pixel_x[3]_5 ;
  wire \pixel_x[3]_6 ;
  wire \pixel_x[3]_7 ;
  wire \pixel_x[3]_8 ;
  wire \pixel_x[3]_9 ;
  wire \pixel_x[5]_0 ;
  wire \pixel_x[5]_1 ;
  wire \pixel_x[5]_2 ;
  wire [0:0]\pixel_x[5]_3 ;
  wire pixel_x_1_sn_1;
  wire pixel_x_2_sn_1;
  wire pixel_x_3_sn_1;
  wire pixel_x_4_sn_1;
  wire pixel_x_5_sn_1;
  wire pixel_x_8_sn_1;
  wire [11:0]pixel_y;
  wire \pixel_y[2]_0 ;
  wire \pixel_y[2]_1 ;
  wire \pixel_y[2]_2 ;
  wire \pixel_y[2]_3 ;
  wire \pixel_y[2]_4 ;
  wire \pixel_y[4]_0 ;
  wire \pixel_y[4]_1 ;
  wire \pixel_y[4]_10 ;
  wire \pixel_y[4]_11 ;
  wire \pixel_y[4]_12 ;
  wire \pixel_y[4]_13 ;
  wire \pixel_y[4]_14 ;
  wire \pixel_y[4]_2 ;
  wire \pixel_y[4]_3 ;
  wire \pixel_y[4]_4 ;
  wire \pixel_y[4]_5 ;
  wire \pixel_y[4]_6 ;
  wire \pixel_y[4]_7 ;
  wire \pixel_y[4]_8 ;
  wire \pixel_y[4]_9 ;
  wire \pixel_y[5]_0 ;
  wire \pixel_y[5]_1 ;
  wire \pixel_y[9]_0 ;
  wire \pixel_y[9]_1 ;
  wire pixel_y_2_sn_1;
  wire pixel_y_4_sn_1;
  wire pixel_y_5_sn_1;
  wire pixel_y_6_sn_1;
  wire pixel_y_7_sn_1;
  wire pixel_y_9_sn_1;
  wire [11:0]rgb_in;
  wire \rgb_out[0]_i_2_n_0 ;
  wire \rgb_out[10]_i_4_n_0 ;
  wire \rgb_out[11]_i_2_n_0 ;
  wire \rgb_out[13]_i_2_n_0 ;
  wire \rgb_out[20]_i_4_n_0 ;
  wire \rgb_out[21]_i_3_n_0 ;
  wire \rgb_out[22]_i_4_n_0 ;
  wire \rgb_out[23]_i_1454_n_0 ;
  wire \rgb_out[23]_i_1455_n_0 ;
  wire \rgb_out[23]_i_1456_n_0 ;
  wire \rgb_out[23]_i_1457_n_0 ;
  wire \rgb_out[23]_i_1458_n_0 ;
  wire \rgb_out[23]_i_1459_n_0 ;
  wire \rgb_out[23]_i_1460_n_0 ;
  wire \rgb_out[23]_i_1461_n_0 ;
  wire \rgb_out[23]_i_1462_n_0 ;
  wire \rgb_out[23]_i_1463_n_0 ;
  wire \rgb_out[23]_i_1464_n_0 ;
  wire \rgb_out[23]_i_1465_n_0 ;
  wire \rgb_out[23]_i_1466_n_0 ;
  wire \rgb_out[23]_i_1469_n_0 ;
  wire \rgb_out[23]_i_1470_n_0 ;
  wire \rgb_out[23]_i_1473_n_0 ;
  wire \rgb_out[23]_i_1474_n_0 ;
  wire \rgb_out[23]_i_1475_n_0 ;
  wire \rgb_out[23]_i_1476_n_0 ;
  wire \rgb_out[23]_i_1477_n_0 ;
  wire \rgb_out[23]_i_1478_n_0 ;
  wire \rgb_out[23]_i_1479_n_0 ;
  wire \rgb_out[23]_i_1480_n_0 ;
  wire \rgb_out[23]_i_1481_n_0 ;
  wire \rgb_out[23]_i_1482_n_0 ;
  wire \rgb_out[23]_i_1483_n_0 ;
  wire \rgb_out[23]_i_1484_n_0 ;
  wire \rgb_out[23]_i_1485_n_0 ;
  wire \rgb_out[23]_i_1486_n_0 ;
  wire \rgb_out[23]_i_1487_n_0 ;
  wire \rgb_out[23]_i_1488_n_0 ;
  wire \rgb_out[23]_i_1489_n_0 ;
  wire \rgb_out[23]_i_1490_n_0 ;
  wire \rgb_out[23]_i_1491_n_0 ;
  wire \rgb_out[23]_i_1492_n_0 ;
  wire \rgb_out[23]_i_1493_n_0 ;
  wire \rgb_out[23]_i_1494_n_0 ;
  wire \rgb_out[23]_i_1495_n_0 ;
  wire \rgb_out[23]_i_1496_n_0 ;
  wire \rgb_out[23]_i_17_n_0 ;
  wire \rgb_out[23]_i_18_n_0 ;
  wire \rgb_out[23]_i_216_n_0 ;
  wire \rgb_out[23]_i_494_n_0 ;
  wire \rgb_out[23]_i_496_n_0 ;
  wire \rgb_out[23]_i_497_n_0 ;
  wire \rgb_out[23]_i_498_n_0 ;
  wire \rgb_out[23]_i_499_n_0 ;
  wire \rgb_out[23]_i_503_n_0 ;
  wire \rgb_out[23]_i_504_n_0 ;
  wire \rgb_out[23]_i_505_n_0 ;
  wire \rgb_out[23]_i_506_n_0 ;
  wire \rgb_out[23]_i_508_n_0 ;
  wire \rgb_out[23]_i_509_n_0 ;
  wire \rgb_out[23]_i_510_n_0 ;
  wire \rgb_out[23]_i_513_n_0 ;
  wire \rgb_out[23]_i_514_n_0 ;
  wire \rgb_out[23]_i_515_n_0 ;
  wire \rgb_out[23]_i_516_n_0 ;
  wire \rgb_out[23]_i_56_n_0 ;
  wire \rgb_out[23]_i_57_n_0 ;
  wire \rgb_out[23]_i_59_n_0 ;
  wire \rgb_out[23]_i_62_n_0 ;
  wire \rgb_out[23]_i_63_n_0 ;
  wire \rgb_out[23]_i_64_n_0 ;
  wire \rgb_out[23]_i_7_n_0 ;
  wire \rgb_out[23]_i_845_n_0 ;
  wire \rgb_out[23]_i_846_n_0 ;
  wire \rgb_out[23]_i_847_n_0 ;
  wire \rgb_out[23]_i_848_n_0 ;
  wire \rgb_out[23]_i_849_n_0 ;
  wire \rgb_out[23]_i_850_n_0 ;
  wire \rgb_out[23]_i_851_n_0 ;
  wire \rgb_out[23]_i_853_n_0 ;
  wire \rgb_out[23]_i_854_n_0 ;
  wire \rgb_out[23]_i_858_n_0 ;
  wire \rgb_out[23]_i_859_n_0 ;
  wire \rgb_out[23]_i_860_n_0 ;
  wire \rgb_out[23]_i_861_n_0 ;
  wire \rgb_out[23]_i_863_n_0 ;
  wire \rgb_out[23]_i_864_n_0 ;
  wire \rgb_out[23]_i_865_n_0 ;
  wire \rgb_out[23]_i_866_n_0 ;
  wire \rgb_out[23]_i_867_n_0 ;
  wire \rgb_out[23]_i_868_n_0 ;
  wire \rgb_out[23]_i_869_n_0 ;
  wire \rgb_out[23]_i_870_n_0 ;
  wire \rgb_out[23]_i_871_n_0 ;
  wire \rgb_out[23]_i_872_n_0 ;
  wire \rgb_out[23]_i_873_n_0 ;
  wire \rgb_out[23]_i_874_n_0 ;
  wire \rgb_out[23]_i_875_n_0 ;
  wire \rgb_out[23]_i_876_n_0 ;
  wire \rgb_out[23]_i_877_n_0 ;
  wire \rgb_out[23]_i_878_n_0 ;
  wire \rgb_out[23]_i_879_n_0 ;
  wire \rgb_out[23]_i_882_n_0 ;
  wire \rgb_out[23]_i_883_n_0 ;
  wire \rgb_out[23]_i_884_n_0 ;
  wire \rgb_out[23]_i_885_n_0 ;
  wire \rgb_out[23]_i_887_n_0 ;
  wire \rgb_out[23]_i_888_n_0 ;
  wire \rgb_out[23]_i_892_n_0 ;
  wire \rgb_out[23]_i_893_n_0 ;
  wire \rgb_out[23]_i_894_n_0 ;
  wire \rgb_out[23]_i_895_n_0 ;
  wire \rgb_out[23]_i_897_n_0 ;
  wire \rgb_out[23]_i_898_n_0 ;
  wire \rgb_out[23]_i_899_n_0 ;
  wire \rgb_out[23]_i_900_n_0 ;
  wire \rgb_out[23]_i_902_n_0 ;
  wire \rgb_out[23]_i_903_n_0 ;
  wire \rgb_out[23]_i_904_n_0 ;
  wire \rgb_out[23]_i_906_n_0 ;
  wire \rgb_out[23]_i_907_n_0 ;
  wire \rgb_out[23]_i_908_n_0 ;
  wire \rgb_out[3]_i_2_n_0 ;
  wire \rgb_out[4]_i_2_n_0 ;
  wire \rgb_out[7]_i_2_n_0 ;
  wire \rgb_out[7]_i_3_n_0 ;
  wire \rgb_out[9]_i_2_n_0 ;
  wire [0:0]\rgb_out_reg[20] ;
  wire [0:0]\rgb_out_reg[20]_0 ;
  wire [0:0]\rgb_out_reg[20]_1 ;
  wire [0:0]\rgb_out_reg[20]_2 ;
  wire [0:0]\rgb_out_reg[20]_3 ;
  wire [0:0]\rgb_out_reg[20]_4 ;
  wire [0:0]\rgb_out_reg[20]_5 ;
  wire [0:0]\rgb_out_reg[20]_6 ;
  wire [0:0]\rgb_out_reg[20]_7 ;
  wire \rgb_out_reg[23]_i_193_n_3 ;
  wire \rgb_out_reg[23]_i_194_n_2 ;
  wire \rgb_out_reg[23]_i_194_n_3 ;
  wire \rgb_out_reg[23]_i_197_n_2 ;
  wire \rgb_out_reg[23]_i_197_n_3 ;
  wire \rgb_out_reg[23]_i_198_n_2 ;
  wire \rgb_out_reg[23]_i_198_n_3 ;
  wire \rgb_out_reg[23]_i_201_n_2 ;
  wire \rgb_out_reg[23]_i_201_n_3 ;
  wire \rgb_out_reg[23]_i_492_n_0 ;
  wire \rgb_out_reg[23]_i_492_n_1 ;
  wire \rgb_out_reg[23]_i_492_n_2 ;
  wire \rgb_out_reg[23]_i_492_n_3 ;
  wire \rgb_out_reg[23]_i_495_n_0 ;
  wire \rgb_out_reg[23]_i_495_n_1 ;
  wire \rgb_out_reg[23]_i_495_n_2 ;
  wire \rgb_out_reg[23]_i_495_n_3 ;
  wire \rgb_out_reg[23]_i_500_n_2 ;
  wire \rgb_out_reg[23]_i_500_n_3 ;
  wire \rgb_out_reg[23]_i_501_n_2 ;
  wire \rgb_out_reg[23]_i_501_n_3 ;
  wire \rgb_out_reg[23]_i_502_n_0 ;
  wire \rgb_out_reg[23]_i_502_n_1 ;
  wire \rgb_out_reg[23]_i_502_n_2 ;
  wire \rgb_out_reg[23]_i_502_n_3 ;
  wire \rgb_out_reg[23]_i_507_n_0 ;
  wire \rgb_out_reg[23]_i_507_n_1 ;
  wire \rgb_out_reg[23]_i_507_n_2 ;
  wire \rgb_out_reg[23]_i_507_n_3 ;
  wire \rgb_out_reg[23]_i_511_n_2 ;
  wire \rgb_out_reg[23]_i_511_n_3 ;
  wire \rgb_out_reg[23]_i_512_n_0 ;
  wire \rgb_out_reg[23]_i_512_n_1 ;
  wire \rgb_out_reg[23]_i_512_n_2 ;
  wire \rgb_out_reg[23]_i_512_n_3 ;
  wire \rgb_out_reg[23]_i_517_n_2 ;
  wire \rgb_out_reg[23]_i_517_n_3 ;
  wire \rgb_out_reg[23]_i_518_n_2 ;
  wire \rgb_out_reg[23]_i_518_n_3 ;
  wire \rgb_out_reg[23]_i_519_n_2 ;
  wire \rgb_out_reg[23]_i_519_n_3 ;
  wire \rgb_out_reg[23]_i_520_n_2 ;
  wire \rgb_out_reg[23]_i_520_n_3 ;
  wire \rgb_out_reg[23]_i_857_n_0 ;
  wire \rgb_out_reg[23]_i_857_n_1 ;
  wire \rgb_out_reg[23]_i_857_n_2 ;
  wire \rgb_out_reg[23]_i_857_n_3 ;
  wire \rgb_out_reg[23]_i_862_n_0 ;
  wire \rgb_out_reg[23]_i_862_n_1 ;
  wire \rgb_out_reg[23]_i_862_n_2 ;
  wire \rgb_out_reg[23]_i_862_n_3 ;
  wire \rgb_out_reg[23]_i_880_n_0 ;
  wire \rgb_out_reg[23]_i_880_n_1 ;
  wire \rgb_out_reg[23]_i_880_n_2 ;
  wire \rgb_out_reg[23]_i_880_n_3 ;
  wire \rgb_out_reg[23]_i_891_n_0 ;
  wire \rgb_out_reg[23]_i_891_n_1 ;
  wire \rgb_out_reg[23]_i_891_n_2 ;
  wire \rgb_out_reg[23]_i_891_n_3 ;
  wire \rgb_out_reg[23]_i_896_n_0 ;
  wire \rgb_out_reg[23]_i_896_n_1 ;
  wire \rgb_out_reg[23]_i_896_n_2 ;
  wire \rgb_out_reg[23]_i_896_n_3 ;
  wire \rgb_out_reg[23]_i_901_n_0 ;
  wire \rgb_out_reg[23]_i_901_n_1 ;
  wire \rgb_out_reg[23]_i_901_n_2 ;
  wire \rgb_out_reg[23]_i_901_n_3 ;
  wire \rgb_out_reg[23]_i_905_n_0 ;
  wire \rgb_out_reg[23]_i_905_n_1 ;
  wire \rgb_out_reg[23]_i_905_n_2 ;
  wire \rgb_out_reg[23]_i_905_n_3 ;
  wire \temps_restant[2] ;
  wire [2:2]NLW_local_y_carry__1_CO_UNCONNECTED;
  wire [3:3]NLW_local_y_carry__1_O_UNCONNECTED;
  wire [3:0]NLW_pixel_on3_carry_O_UNCONNECTED;
  wire [3:3]NLW_pixel_on3_carry__0_CO_UNCONNECTED;
  wire [3:0]NLW_pixel_on3_carry__0_O_UNCONNECTED;
  wire [3:0]NLW_pixel_on4__6_carry_O_UNCONNECTED;
  wire [3:2]NLW_pixel_on4__6_carry__0_CO_UNCONNECTED;
  wire [3:0]NLW_pixel_on4__6_carry__0_O_UNCONNECTED;
  wire [3:0]NLW_pixel_on4_carry_O_UNCONNECTED;
  wire [3:3]NLW_pixel_on4_carry__0_CO_UNCONNECTED;
  wire [3:0]NLW_pixel_on4_carry__0_O_UNCONNECTED;
  wire [3:0]NLW_pixel_on8_carry_O_UNCONNECTED;
  wire [3:3]NLW_pixel_on8_carry__0_CO_UNCONNECTED;
  wire [3:0]NLW_pixel_on8_carry__0_O_UNCONNECTED;
  wire [3:1]NLW_pixel_on8_carry__0_i_2_CO_UNCONNECTED;
  wire [3:0]NLW_pixel_on8_carry__0_i_2_O_UNCONNECTED;
  wire [3:2]\NLW_rgb_out_reg[23]_i_193_CO_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_193_O_UNCONNECTED ;
  wire [3:3]\NLW_rgb_out_reg[23]_i_194_CO_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_194_O_UNCONNECTED ;
  wire [3:3]\NLW_rgb_out_reg[23]_i_197_CO_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_197_O_UNCONNECTED ;
  wire [3:3]\NLW_rgb_out_reg[23]_i_198_CO_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_198_O_UNCONNECTED ;
  wire [3:3]\NLW_rgb_out_reg[23]_i_201_CO_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_201_O_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_492_O_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_495_O_UNCONNECTED ;
  wire [3:3]\NLW_rgb_out_reg[23]_i_500_CO_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_500_O_UNCONNECTED ;
  wire [3:3]\NLW_rgb_out_reg[23]_i_501_CO_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_501_O_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_502_O_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_507_O_UNCONNECTED ;
  wire [3:3]\NLW_rgb_out_reg[23]_i_511_CO_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_511_O_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_512_O_UNCONNECTED ;
  wire [3:3]\NLW_rgb_out_reg[23]_i_517_CO_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_517_O_UNCONNECTED ;
  wire [3:3]\NLW_rgb_out_reg[23]_i_518_CO_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_518_O_UNCONNECTED ;
  wire [3:3]\NLW_rgb_out_reg[23]_i_519_CO_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_519_O_UNCONNECTED ;
  wire [3:3]\NLW_rgb_out_reg[23]_i_520_CO_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_520_O_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_857_O_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_862_O_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_880_O_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_891_O_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_896_O_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_901_O_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_905_O_UNCONNECTED ;

  assign decompte_ui_1_sn_1 = decompte_ui_1_sp_1;
  assign mode_ui_0_sn_1 = mode_ui_0_sp_1;
  assign mode_ui_1_sn_1 = mode_ui_1_sp_1;
  assign mode_ui_2_sn_1 = mode_ui_2_sp_1;
  assign pixel_x_1_sn_1 = pixel_x_1_sp_1;
  assign pixel_x_2_sn_1 = pixel_x_2_sp_1;
  assign pixel_x_3_sn_1 = pixel_x_3_sp_1;
  assign pixel_x_4_sn_1 = pixel_x_4_sp_1;
  assign pixel_x_5_sn_1 = pixel_x_5_sp_1;
  assign pixel_x_8_sn_1 = pixel_x_8_sp_1;
  assign pixel_y_2_sn_1 = pixel_y_2_sp_1;
  assign pixel_y_4_sn_1 = pixel_y_4_sp_1;
  assign pixel_y_5_sn_1 = pixel_y_5_sp_1;
  assign pixel_y_6_sn_1 = pixel_y_6_sp_1;
  assign pixel_y_7_sn_1 = pixel_y_7_sp_1;
  assign pixel_y_9_sn_1 = pixel_y_9_sp_1;
  CARRY4 local_x_carry
       (.CI(1'b0),
        .CO({local_x_carry_n_0,local_x_carry_n_1,local_x_carry_n_2,local_x_carry_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,pixel_x[6:5],1'b0}),
        .O(local_x_2[7:4]),
        .S({pixel_x[7],local_x_carry_i_1_n_0,local_x_carry_i_2_n_0,pixel_x[4]}));
  CARRY4 local_x_carry__0
       (.CI(local_x_carry_n_0),
        .CO({local_x_carry__0_n_0,local_x_carry__0_n_1,local_x_carry__0_n_2,local_x_carry__0_n_3}),
        .CYINIT(1'b0),
        .DI({pixel_x[11],1'b0,pixel_x[9],1'b0}),
        .O(local_x_2[11:8]),
        .S({local_x_carry__0_i_1_n_0,pixel_x[10],local_x_carry__0_i_2_n_0,pixel_x[8]}));
  LUT1 #(
    .INIT(2'h1)) 
    local_x_carry__0_i_1
       (.I0(pixel_x[11]),
        .O(local_x_carry__0_i_1_n_0));
  LUT1 #(
    .INIT(2'h1)) 
    local_x_carry__0_i_2
       (.I0(pixel_x[9]),
        .O(local_x_carry__0_i_2_n_0));
  LUT1 #(
    .INIT(2'h1)) 
    local_x_carry_i_1
       (.I0(pixel_x[6]),
        .O(local_x_carry_i_1_n_0));
  LUT1 #(
    .INIT(2'h1)) 
    local_x_carry_i_2
       (.I0(pixel_x[5]),
        .O(local_x_carry_i_2_n_0));
  CARRY4 local_y_carry
       (.CI(1'b0),
        .CO({local_y_carry_n_0,local_y_carry_n_1,local_y_carry_n_2,local_y_carry_n_3}),
        .CYINIT(1'b0),
        .DI({pixel_y[4],1'b0,pixel_y[2],1'b0}),
        .O(local_y_3[4:1]),
        .S({local_y_carry_i_1_n_0,pixel_y[3],local_y_carry_i_2_n_0,pixel_y[1]}));
  CARRY4 local_y_carry__0
       (.CI(local_y_carry_n_0),
        .CO({local_y_carry__0_n_0,local_y_carry__0_n_1,local_y_carry__0_n_2,local_y_carry__0_n_3}),
        .CYINIT(1'b0),
        .DI(pixel_y[8:5]),
        .O(local_y_3[8:5]),
        .S({local_y_carry__0_i_1_n_0,local_y_carry__0_i_2_n_0,local_y_carry__0_i_3_n_0,local_y_carry__0_i_4_n_0}));
  LUT1 #(
    .INIT(2'h1)) 
    local_y_carry__0_i_1
       (.I0(pixel_y[8]),
        .O(local_y_carry__0_i_1_n_0));
  LUT1 #(
    .INIT(2'h1)) 
    local_y_carry__0_i_2
       (.I0(pixel_y[7]),
        .O(local_y_carry__0_i_2_n_0));
  LUT1 #(
    .INIT(2'h1)) 
    local_y_carry__0_i_3
       (.I0(pixel_y[6]),
        .O(local_y_carry__0_i_3_n_0));
  LUT1 #(
    .INIT(2'h1)) 
    local_y_carry__0_i_4
       (.I0(pixel_y[5]),
        .O(local_y_carry__0_i_4_n_0));
  CARRY4 local_y_carry__1
       (.CI(local_y_carry__0_n_0),
        .CO({local_y_carry__1_n_0,NLW_local_y_carry__1_CO_UNCONNECTED[2],local_y_carry__1_n_2,local_y_carry__1_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,pixel_y[11:9]}),
        .O({NLW_local_y_carry__1_O_UNCONNECTED[3],local_y_3[11:9]}),
        .S({1'b1,local_y_carry__1_i_1_n_0,local_y_carry__1_i_2_n_0,local_y_carry__1_i_3_n_0}));
  LUT1 #(
    .INIT(2'h1)) 
    local_y_carry__1_i_1
       (.I0(pixel_y[11]),
        .O(local_y_carry__1_i_1_n_0));
  LUT1 #(
    .INIT(2'h1)) 
    local_y_carry__1_i_2
       (.I0(pixel_y[10]),
        .O(local_y_carry__1_i_2_n_0));
  LUT1 #(
    .INIT(2'h1)) 
    local_y_carry__1_i_3
       (.I0(pixel_y[9]),
        .O(local_y_carry__1_i_3_n_0));
  LUT1 #(
    .INIT(2'h1)) 
    local_y_carry_i_1
       (.I0(pixel_y[4]),
        .O(local_y_carry_i_1_n_0));
  LUT1 #(
    .INIT(2'h1)) 
    local_y_carry_i_2
       (.I0(pixel_y[2]),
        .O(local_y_carry_i_2_n_0));
  CARRY4 pixel_on3_carry
       (.CI(1'b0),
        .CO({pixel_on3_carry_n_0,pixel_on3_carry_n_1,pixel_on3_carry_n_2,pixel_on3_carry_n_3}),
        .CYINIT(1'b1),
        .DI({pixel_on3_carry_i_1_n_0,pixel_on3_carry_i_2_n_0,pixel_on3_carry_i_3_n_0,pixel_on3_carry_i_4_n_0}),
        .O(NLW_pixel_on3_carry_O_UNCONNECTED[3:0]),
        .S({pixel_on3_carry_i_5_n_0,pixel_on3_carry_i_6_n_0,pixel_on3_carry_i_7_n_0,pixel_on3_carry_i_8_n_0}));
  CARRY4 pixel_on3_carry__0
       (.CI(pixel_on3_carry_n_0),
        .CO({NLW_pixel_on3_carry__0_CO_UNCONNECTED[3],pixel_on3,pixel_on3_carry__0_n_2,pixel_on3_carry__0_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,pixel_on3_carry__0_i_1_n_0,pixel_on3_carry__0_i_2_n_0}),
        .O(NLW_pixel_on3_carry__0_O_UNCONNECTED[3:0]),
        .S({1'b0,local_y_carry__1_n_0,pixel_on3_carry__0_i_3_n_0,pixel_on3_carry__0_i_4_n_0}));
  LUT2 #(
    .INIT(4'hE)) 
    pixel_on3_carry__0_i_1
       (.I0(local_y_3[10]),
        .I1(local_y_3[11]),
        .O(pixel_on3_carry__0_i_1_n_0));
  LUT2 #(
    .INIT(4'hE)) 
    pixel_on3_carry__0_i_2
       (.I0(local_y_3[8]),
        .I1(local_y_3[9]),
        .O(pixel_on3_carry__0_i_2_n_0));
  LUT2 #(
    .INIT(4'h1)) 
    pixel_on3_carry__0_i_3
       (.I0(local_y_3[11]),
        .I1(local_y_3[10]),
        .O(pixel_on3_carry__0_i_3_n_0));
  LUT2 #(
    .INIT(4'h1)) 
    pixel_on3_carry__0_i_4
       (.I0(local_y_3[9]),
        .I1(local_y_3[8]),
        .O(pixel_on3_carry__0_i_4_n_0));
  LUT2 #(
    .INIT(4'hE)) 
    pixel_on3_carry_i_1
       (.I0(local_y_3[6]),
        .I1(local_y_3[7]),
        .O(pixel_on3_carry_i_1_n_0));
  LUT2 #(
    .INIT(4'hE)) 
    pixel_on3_carry_i_2
       (.I0(local_y_3[4]),
        .I1(local_y_3[5]),
        .O(pixel_on3_carry_i_2_n_0));
  LUT2 #(
    .INIT(4'hE)) 
    pixel_on3_carry_i_3
       (.I0(local_y_3[2]),
        .I1(local_y_3[3]),
        .O(pixel_on3_carry_i_3_n_0));
  LUT2 #(
    .INIT(4'hE)) 
    pixel_on3_carry_i_4
       (.I0(pixel_y[0]),
        .I1(local_y_3[1]),
        .O(pixel_on3_carry_i_4_n_0));
  LUT2 #(
    .INIT(4'h1)) 
    pixel_on3_carry_i_5
       (.I0(local_y_3[7]),
        .I1(local_y_3[6]),
        .O(pixel_on3_carry_i_5_n_0));
  LUT2 #(
    .INIT(4'h1)) 
    pixel_on3_carry_i_6
       (.I0(local_y_3[5]),
        .I1(local_y_3[4]),
        .O(pixel_on3_carry_i_6_n_0));
  LUT2 #(
    .INIT(4'h1)) 
    pixel_on3_carry_i_7
       (.I0(local_y_3[3]),
        .I1(local_y_3[2]),
        .O(pixel_on3_carry_i_7_n_0));
  LUT2 #(
    .INIT(4'h1)) 
    pixel_on3_carry_i_8
       (.I0(local_y_3[1]),
        .I1(pixel_y[0]),
        .O(pixel_on3_carry_i_8_n_0));
  CARRY4 pixel_on4__6_carry
       (.CI(1'b0),
        .CO({pixel_on4__6_carry_n_0,pixel_on4__6_carry_n_1,pixel_on4__6_carry_n_2,pixel_on4__6_carry_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,pixel_on4__6_carry_i_1_n_0,pixel_on4__6_carry_i_2_n_0}),
        .O(NLW_pixel_on4__6_carry_O_UNCONNECTED[3:0]),
        .S({pixel_on4__6_carry_i_3_n_0,pixel_on4__6_carry_i_4_n_0,pixel_on4__6_carry_i_5_n_0,pixel_on4__6_carry_i_6_n_0}));
  CARRY4 pixel_on4__6_carry__0
       (.CI(pixel_on4__6_carry_n_0),
        .CO({NLW_pixel_on4__6_carry__0_CO_UNCONNECTED[3:2],pixel_on4,pixel_on4__6_carry__0_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,local_x_2[12],1'b0}),
        .O(NLW_pixel_on4__6_carry__0_O_UNCONNECTED[3:0]),
        .S({1'b0,1'b0,CO,pixel_on4__6_carry__0_i_2_n_0}));
  LUT1 #(
    .INIT(2'h1)) 
    pixel_on4__6_carry__0_i_1
       (.I0(CO),
        .O(local_x_2[12]));
  LUT2 #(
    .INIT(4'h1)) 
    pixel_on4__6_carry__0_i_2
       (.I0(local_x_2[11]),
        .I1(local_x_2[10]),
        .O(pixel_on4__6_carry__0_i_2_n_0));
  LUT1 #(
    .INIT(2'h1)) 
    pixel_on4__6_carry_i_1
       (.I0(local_x_2[5]),
        .O(pixel_on4__6_carry_i_1_n_0));
  LUT2 #(
    .INIT(4'h1)) 
    pixel_on4__6_carry_i_2
       (.I0(pixel_x[3]),
        .I1(pixel_x[2]),
        .O(pixel_on4__6_carry_i_2_n_0));
  LUT2 #(
    .INIT(4'h1)) 
    pixel_on4__6_carry_i_3
       (.I0(local_x_2[9]),
        .I1(local_x_2[8]),
        .O(pixel_on4__6_carry_i_3_n_0));
  LUT2 #(
    .INIT(4'h1)) 
    pixel_on4__6_carry_i_4
       (.I0(local_x_2[7]),
        .I1(local_x_2[6]),
        .O(pixel_on4__6_carry_i_4_n_0));
  LUT2 #(
    .INIT(4'h2)) 
    pixel_on4__6_carry_i_5
       (.I0(local_x_2[5]),
        .I1(local_x_2[4]),
        .O(pixel_on4__6_carry_i_5_n_0));
  LUT2 #(
    .INIT(4'h2)) 
    pixel_on4__6_carry_i_6
       (.I0(pixel_x[2]),
        .I1(pixel_x[3]),
        .O(pixel_on4__6_carry_i_6_n_0));
  CARRY4 pixel_on4_carry
       (.CI(1'b0),
        .CO({pixel_on4_carry_n_0,pixel_on4_carry_n_1,pixel_on4_carry_n_2,pixel_on4_carry_n_3}),
        .CYINIT(1'b1),
        .DI({pixel_on4_carry_i_1_n_0,pixel_on4_carry_i_2_n_0,pixel_on4_carry_i_3_n_0,pixel_on4_carry_i_4_n_0}),
        .O(NLW_pixel_on4_carry_O_UNCONNECTED[3:0]),
        .S({pixel_on4_carry_i_5_n_0,pixel_on4_carry_i_6_n_0,pixel_on4_carry_i_7_n_0,pixel_on4_carry_i_8_n_0}));
  CARRY4 pixel_on4_carry__0
       (.CI(pixel_on4_carry_n_0),
        .CO({NLW_pixel_on4_carry__0_CO_UNCONNECTED[3],pixel_on40_in,pixel_on4_carry__0_n_2,pixel_on4_carry__0_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,pixel_on4_carry__0_i_1_n_0,pixel_on4_carry__0_i_2_n_0}),
        .O(NLW_pixel_on4_carry__0_O_UNCONNECTED[3:0]),
        .S({1'b0,CO,pixel_on4_carry__0_i_3_n_0,pixel_on4_carry__0_i_4_n_0}));
  LUT2 #(
    .INIT(4'hE)) 
    pixel_on4_carry__0_i_1
       (.I0(local_x_2[10]),
        .I1(local_x_2[11]),
        .O(pixel_on4_carry__0_i_1_n_0));
  LUT2 #(
    .INIT(4'hE)) 
    pixel_on4_carry__0_i_2
       (.I0(local_x_2[8]),
        .I1(local_x_2[9]),
        .O(pixel_on4_carry__0_i_2_n_0));
  LUT2 #(
    .INIT(4'h1)) 
    pixel_on4_carry__0_i_3
       (.I0(local_x_2[11]),
        .I1(local_x_2[10]),
        .O(pixel_on4_carry__0_i_3_n_0));
  LUT2 #(
    .INIT(4'h1)) 
    pixel_on4_carry__0_i_4
       (.I0(local_x_2[9]),
        .I1(local_x_2[8]),
        .O(pixel_on4_carry__0_i_4_n_0));
  LUT2 #(
    .INIT(4'hE)) 
    pixel_on4_carry_i_1
       (.I0(local_x_2[6]),
        .I1(local_x_2[7]),
        .O(pixel_on4_carry_i_1_n_0));
  LUT2 #(
    .INIT(4'hE)) 
    pixel_on4_carry_i_2
       (.I0(local_x_2[4]),
        .I1(local_x_2[5]),
        .O(pixel_on4_carry_i_2_n_0));
  LUT2 #(
    .INIT(4'hE)) 
    pixel_on4_carry_i_3
       (.I0(pixel_x[2]),
        .I1(pixel_x[3]),
        .O(pixel_on4_carry_i_3_n_0));
  LUT2 #(
    .INIT(4'hE)) 
    pixel_on4_carry_i_4
       (.I0(pixel_x[1]),
        .I1(pixel_x[0]),
        .O(pixel_on4_carry_i_4_n_0));
  LUT2 #(
    .INIT(4'h1)) 
    pixel_on4_carry_i_5
       (.I0(local_x_2[7]),
        .I1(local_x_2[6]),
        .O(pixel_on4_carry_i_5_n_0));
  LUT2 #(
    .INIT(4'h1)) 
    pixel_on4_carry_i_6
       (.I0(local_x_2[5]),
        .I1(local_x_2[4]),
        .O(pixel_on4_carry_i_6_n_0));
  LUT2 #(
    .INIT(4'h1)) 
    pixel_on4_carry_i_7
       (.I0(pixel_x[3]),
        .I1(pixel_x[2]),
        .O(pixel_on4_carry_i_7_n_0));
  LUT2 #(
    .INIT(4'h1)) 
    pixel_on4_carry_i_8
       (.I0(pixel_x[0]),
        .I1(pixel_x[1]),
        .O(pixel_on4_carry_i_8_n_0));
  CARRY4 pixel_on8_carry
       (.CI(1'b0),
        .CO({pixel_on8_carry_n_0,pixel_on8_carry_n_1,pixel_on8_carry_n_2,pixel_on8_carry_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,pixel_on8_carry_i_1_n_0,pixel_on8_carry_i_2_n_0,pixel_on8_carry_i_3_n_0}),
        .O(NLW_pixel_on8_carry_O_UNCONNECTED[3:0]),
        .S({pixel_on8_carry_i_4_n_0,pixel_on8_carry_i_5_n_0,pixel_on8_carry_i_6_n_0,pixel_on8_carry_i_7_n_0}));
  CARRY4 pixel_on8_carry__0
       (.CI(pixel_on8_carry_n_0),
        .CO({NLW_pixel_on8_carry__0_CO_UNCONNECTED[3],pixel_on8,pixel_on8_carry__0_n_2,pixel_on8_carry__0_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,pixel_on8_carry__0_i_1_n_0,1'b0,1'b0}),
        .O(NLW_pixel_on8_carry__0_O_UNCONNECTED[3:0]),
        .S({1'b0,CO,pixel_on8_carry__0_i_3_n_0,pixel_on8_carry__0_i_4_n_0}));
  LUT1 #(
    .INIT(2'h1)) 
    pixel_on8_carry__0_i_1
       (.I0(CO),
        .O(pixel_on8_carry__0_i_1_n_0));
  CARRY4 pixel_on8_carry__0_i_2
       (.CI(local_x_carry__0_n_0),
        .CO({NLW_pixel_on8_carry__0_i_2_CO_UNCONNECTED[3:1],CO}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(NLW_pixel_on8_carry__0_i_2_O_UNCONNECTED[3:0]),
        .S({1'b0,1'b0,1'b0,1'b1}));
  LUT2 #(
    .INIT(4'h1)) 
    pixel_on8_carry__0_i_3
       (.I0(local_x_2[11]),
        .I1(local_x_2[10]),
        .O(pixel_on8_carry__0_i_3_n_0));
  LUT2 #(
    .INIT(4'h1)) 
    pixel_on8_carry__0_i_4
       (.I0(local_x_2[9]),
        .I1(local_x_2[8]),
        .O(pixel_on8_carry__0_i_4_n_0));
  LUT2 #(
    .INIT(4'h1)) 
    pixel_on8_carry_i_1
       (.I0(local_x_2[5]),
        .I1(local_x_2[4]),
        .O(pixel_on8_carry_i_1_n_0));
  LUT2 #(
    .INIT(4'h7)) 
    pixel_on8_carry_i_2
       (.I0(pixel_x[2]),
        .I1(pixel_x[3]),
        .O(pixel_on8_carry_i_2_n_0));
  LUT1 #(
    .INIT(2'h1)) 
    pixel_on8_carry_i_3
       (.I0(pixel_x[1]),
        .O(pixel_on8_carry_i_3_n_0));
  LUT2 #(
    .INIT(4'h1)) 
    pixel_on8_carry_i_4
       (.I0(local_x_2[7]),
        .I1(local_x_2[6]),
        .O(pixel_on8_carry_i_4_n_0));
  LUT2 #(
    .INIT(4'h2)) 
    pixel_on8_carry_i_5
       (.I0(local_x_2[4]),
        .I1(local_x_2[5]),
        .O(pixel_on8_carry_i_5_n_0));
  LUT2 #(
    .INIT(4'h8)) 
    pixel_on8_carry_i_6
       (.I0(pixel_x[3]),
        .I1(pixel_x[2]),
        .O(pixel_on8_carry_i_6_n_0));
  LUT2 #(
    .INIT(4'h2)) 
    pixel_on8_carry_i_7
       (.I0(pixel_x[1]),
        .I1(pixel_x[0]),
        .O(pixel_on8_carry_i_7_n_0));
  LUT5 #(
    .INIT(32'hFFFF44F4)) 
    \rgb_out[0]_i_1 
       (.I0(\rgb_out[0]_i_2_n_0 ),
        .I1(pixel_x_5_sn_1),
        .I2(rgb_in[0]),
        .I3(pixel_x_2_sn_1),
        .I4(\pixel_x[2]_0 ),
        .O(D[0]));
  LUT6 #(
    .INIT(64'h00000888AAAAAAAA)) 
    \rgb_out[0]_i_2 
       (.I0(\rgb_out[7]_i_3_n_0 ),
        .I1(pixel_x_1_sn_1),
        .I2(is_pixel_mur),
        .I3(rgb_in[0]),
        .I4(pixel_y_4_sn_1),
        .I5(\rgb_out[23]_i_18_n_0 ),
        .O(\rgb_out[0]_i_2_n_0 ));
  LUT5 #(
    .INIT(32'hFFF4F4F4)) 
    \rgb_out[10]_i_1 
       (.I0(pixel_x_2_sn_1),
        .I1(rgb_in[6]),
        .I2(\pixel_x[2]_0 ),
        .I3(\rgb_out[10]_i_4_n_0 ),
        .I4(pixel_x_5_sn_1),
        .O(D[10]));
  LUT6 #(
    .INIT(64'h75770000FFFFFFFF)) 
    \rgb_out[10]_i_4 
       (.I0(pixel_x_1_sn_1),
        .I1(\pixel_y[4]_1 ),
        .I2(rgb_in[6]),
        .I3(is_pixel_mur),
        .I4(\rgb_out[23]_i_18_n_0 ),
        .I5(\rgb_out[7]_i_3_n_0 ),
        .O(\rgb_out[10]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hF1F1F1F1FFF1F1F1)) 
    \rgb_out[11]_i_1 
       (.I0(\rgb_out[11]_i_2_n_0 ),
        .I1(pixel_y_9_sn_1),
        .I2(\pixel_x[2]_2 ),
        .I3(rgb_in[7]),
        .I4(mode_ui_2_sn_1),
        .I5(pixel_y_6_sn_1),
        .O(D[11]));
  LUT6 #(
    .INIT(64'h00000800AAAAAAAA)) 
    \rgb_out[11]_i_2 
       (.I0(\rgb_out[7]_i_3_n_0 ),
        .I1(pixel_x_1_sn_1),
        .I2(\pixel_y[4]_0 ),
        .I3(is_pixel_mur),
        .I4(rgb_in[7]),
        .I5(\rgb_out[23]_i_18_n_0 ),
        .O(\rgb_out[11]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFFFD0)) 
    \rgb_out[12]_i_1 
       (.I0(\rgb_out[20]_i_4_n_0 ),
        .I1(\pixel_y[4]_7 ),
        .I2(mode_ui_0_sn_1),
        .I3(\pixel_x[2]_1 ),
        .I4(\pixel_x[2]_10 ),
        .I5(\pixel_x[3]_4 ),
        .O(D[12]));
  LUT6 #(
    .INIT(64'hFFFFFFFFF1FFF1F1)) 
    \rgb_out[13]_i_1 
       (.I0(\rgb_out[13]_i_2_n_0 ),
        .I1(pixel_y_9_sn_1),
        .I2(pixel_x_3_sn_1),
        .I3(\pixel_x[2]_3 ),
        .I4(pixel_y_7_sn_1),
        .I5(\pixel_x[2]_1 ),
        .O(D[13]));
  LUT6 #(
    .INIT(64'h08880000AAAAAAAA)) 
    \rgb_out[13]_i_2 
       (.I0(\rgb_out[7]_i_3_n_0 ),
        .I1(pixel_x_1_sn_1),
        .I2(is_pixel_mur),
        .I3(rgb_in[8]),
        .I4(\pixel_y[4]_2 ),
        .I5(\rgb_out[23]_i_18_n_0 ),
        .O(\rgb_out[13]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFFFD0)) 
    \rgb_out[14]_i_1 
       (.I0(\rgb_out[20]_i_4_n_0 ),
        .I1(\pixel_y[4]_8 ),
        .I2(mode_ui_0_sn_1),
        .I3(\pixel_x[2]_1 ),
        .I4(\pixel_x[2]_11 ),
        .I5(\pixel_x[3]_5 ),
        .O(D[14]));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFFF0D)) 
    \rgb_out[15]_i_1 
       (.I0(\rgb_out[20]_i_4_n_0 ),
        .I1(\pixel_y[4]_9 ),
        .I2(pixel_y_9_sn_1),
        .I3(\pixel_x[2]_5 ),
        .I4(\pixel_x[2]_12 ),
        .I5(\pixel_x[3]_6 ),
        .O(D[15]));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFFF0D)) 
    \rgb_out[16]_i_1 
       (.I0(\rgb_out[20]_i_4_n_0 ),
        .I1(\pixel_y[4]_10 ),
        .I2(pixel_y_9_sn_1),
        .I3(\pixel_x[2]_5 ),
        .I4(\pixel_x[2]_13 ),
        .I5(\pixel_x[3]_7 ),
        .O(D[16]));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFFFD0)) 
    \rgb_out[17]_i_1 
       (.I0(\rgb_out[20]_i_4_n_0 ),
        .I1(\pixel_y[4]_11 ),
        .I2(mode_ui_0_sn_1),
        .I3(\pixel_x[2]_1 ),
        .I4(\pixel_x[2]_14 ),
        .I5(\pixel_x[3]_8 ),
        .O(D[17]));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFFF0D)) 
    \rgb_out[18]_i_1 
       (.I0(\rgb_out[20]_i_4_n_0 ),
        .I1(\pixel_y[4]_12 ),
        .I2(pixel_y_9_sn_1),
        .I3(\pixel_x[2]_5 ),
        .I4(\pixel_x[2]_15 ),
        .I5(\pixel_x[3]_9 ),
        .O(D[18]));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFFF0D)) 
    \rgb_out[19]_i_1 
       (.I0(\rgb_out[20]_i_4_n_0 ),
        .I1(\pixel_y[4]_13 ),
        .I2(pixel_y_9_sn_1),
        .I3(\pixel_x[2]_5 ),
        .I4(\pixel_x[2]_16 ),
        .I5(\pixel_x[3]_10 ),
        .O(D[19]));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFFFD0)) 
    \rgb_out[1]_i_1 
       (.I0(\rgb_out[20]_i_4_n_0 ),
        .I1(\pixel_y[4]_3 ),
        .I2(mode_ui_0_sn_1),
        .I3(\pixel_y[9]_0 ),
        .I4(\pixel_x[2]_4 ),
        .I5(\pixel_x[3]_0 ),
        .O(D[1]));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFFF45)) 
    \rgb_out[20]_i_1 
       (.I0(pixel_y_9_sn_1),
        .I1(\pixel_y[4]_14 ),
        .I2(\rgb_out[20]_i_4_n_0 ),
        .I3(\pixel_x[2]_17 ),
        .I4(\pixel_x[2]_5 ),
        .I5(\pixel_x[3]_11 ),
        .O(D[20]));
  LUT4 #(
    .INIT(16'h0400)) 
    \rgb_out[20]_i_4 
       (.I0(\rgb_out[23]_i_17_n_0 ),
        .I1(\rgb_out[23]_i_18_n_0 ),
        .I2(pixel_x_4_sn_1),
        .I3(pixel_x_1_sn_1),
        .O(\rgb_out[20]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hBFEEAAAABFEEBFEE)) 
    \rgb_out[21]_i_1 
       (.I0(\pixel_x[2]_18 ),
        .I1(mode_ui[0]),
        .I2(mode_ui[2]),
        .I3(mode_ui[1]),
        .I4(\rgb_out[21]_i_3_n_0 ),
        .I5(\pixel_x[1]_0 ),
        .O(D[21]));
  LUT5 #(
    .INIT(32'hBFBBBFBF)) 
    \rgb_out[21]_i_3 
       (.I0(\rgb_out[23]_i_17_n_0 ),
        .I1(\rgb_out[23]_i_18_n_0 ),
        .I2(\pixel_y[4]_0 ),
        .I3(rgb_in[9]),
        .I4(is_pixel_mur),
        .O(\rgb_out[21]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hFFFEFCFCFFFEFFFE)) 
    \rgb_out[22]_i_1 
       (.I0(\mode_ui[0]_0 ),
        .I1(\pixel_x[2]_19 ),
        .I2(\pixel_x[2]_20 ),
        .I3(\pixel_y[9]_1 ),
        .I4(\rgb_out[22]_i_4_n_0 ),
        .I5(\pixel_x[1]_0 ),
        .O(D[22]));
  LUT5 #(
    .INIT(32'hBFBBBFBF)) 
    \rgb_out[22]_i_4 
       (.I0(\rgb_out[23]_i_17_n_0 ),
        .I1(\rgb_out[23]_i_18_n_0 ),
        .I2(\pixel_y[4]_1 ),
        .I3(rgb_in[10]),
        .I4(is_pixel_mur),
        .O(\rgb_out[22]_i_4_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1454 
       (.I0(local_y_3[6]),
        .I1(local_y_3[7]),
        .O(\rgb_out[23]_i_1454_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_1455 
       (.I0(local_y_3[1]),
        .I1(pixel_y[0]),
        .O(\rgb_out[23]_i_1455_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1456 
       (.I0(local_y_3[7]),
        .I1(local_y_3[6]),
        .O(\rgb_out[23]_i_1456_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1457 
       (.I0(local_y_3[4]),
        .I1(local_y_3[5]),
        .O(\rgb_out[23]_i_1457_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_1458 
       (.I0(local_y_3[3]),
        .I1(local_y_3[2]),
        .O(\rgb_out[23]_i_1458_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1459 
       (.I0(local_y_3[1]),
        .I1(pixel_y[0]),
        .O(\rgb_out[23]_i_1459_n_0 ));
  LUT2 #(
    .INIT(4'h7)) 
    \rgb_out[23]_i_1460 
       (.I0(local_y_3[4]),
        .I1(local_y_3[5]),
        .O(\rgb_out[23]_i_1460_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1461 
       (.I0(local_y_3[3]),
        .I1(local_y_3[2]),
        .O(\rgb_out[23]_i_1461_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_1462 
       (.I0(local_y_3[1]),
        .O(\rgb_out[23]_i_1462_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1463 
       (.I0(local_y_3[7]),
        .I1(local_y_3[6]),
        .O(\rgb_out[23]_i_1463_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_1464 
       (.I0(local_y_3[5]),
        .I1(local_y_3[4]),
        .O(\rgb_out[23]_i_1464_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1465 
       (.I0(local_y_3[2]),
        .I1(local_y_3[3]),
        .O(\rgb_out[23]_i_1465_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1466 
       (.I0(local_y_3[1]),
        .I1(pixel_y[0]),
        .O(\rgb_out[23]_i_1466_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1469 
       (.I0(local_x_2[7]),
        .I1(local_x_2[6]),
        .O(\rgb_out[23]_i_1469_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1470 
       (.I0(local_x_2[5]),
        .I1(local_x_2[4]),
        .O(\rgb_out[23]_i_1470_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1473 
       (.I0(local_y_3[6]),
        .I1(local_y_3[7]),
        .O(\rgb_out[23]_i_1473_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_1474 
       (.I0(local_y_3[1]),
        .I1(pixel_y[0]),
        .O(\rgb_out[23]_i_1474_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1475 
       (.I0(local_y_3[7]),
        .I1(local_y_3[6]),
        .O(\rgb_out[23]_i_1475_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_1476 
       (.I0(local_y_3[5]),
        .I1(local_y_3[4]),
        .O(\rgb_out[23]_i_1476_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1477 
       (.I0(local_y_3[2]),
        .I1(local_y_3[3]),
        .O(\rgb_out[23]_i_1477_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1478 
       (.I0(local_y_3[1]),
        .I1(pixel_y[0]),
        .O(\rgb_out[23]_i_1478_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1479 
       (.I0(local_y_3[6]),
        .I1(local_y_3[7]),
        .O(\rgb_out[23]_i_1479_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_1480 
       (.I0(local_y_3[3]),
        .I1(local_y_3[2]),
        .O(\rgb_out[23]_i_1480_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1481 
       (.I0(local_y_3[7]),
        .I1(local_y_3[6]),
        .O(\rgb_out[23]_i_1481_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1482 
       (.I0(local_y_3[4]),
        .I1(local_y_3[5]),
        .O(\rgb_out[23]_i_1482_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1483 
       (.I0(local_y_3[3]),
        .I1(local_y_3[2]),
        .O(\rgb_out[23]_i_1483_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_1484 
       (.I0(local_y_3[1]),
        .I1(pixel_y[0]),
        .O(\rgb_out[23]_i_1484_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_1485 
       (.I0(local_y_3[5]),
        .O(\rgb_out[23]_i_1485_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1486 
       (.I0(local_y_3[1]),
        .I1(pixel_y[0]),
        .O(\rgb_out[23]_i_1486_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1487 
       (.I0(local_y_3[7]),
        .I1(local_y_3[6]),
        .O(\rgb_out[23]_i_1487_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1488 
       (.I0(local_y_3[5]),
        .I1(local_y_3[4]),
        .O(\rgb_out[23]_i_1488_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1489 
       (.I0(local_y_3[3]),
        .I1(local_y_3[2]),
        .O(\rgb_out[23]_i_1489_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1490 
       (.I0(pixel_y[0]),
        .I1(local_y_3[1]),
        .O(\rgb_out[23]_i_1490_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1491 
       (.I0(local_y_3[3]),
        .I1(local_y_3[2]),
        .O(\rgb_out[23]_i_1491_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_1492 
       (.I0(local_y_3[1]),
        .O(\rgb_out[23]_i_1492_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1493 
       (.I0(local_y_3[7]),
        .I1(local_y_3[6]),
        .O(\rgb_out[23]_i_1493_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1494 
       (.I0(local_y_3[5]),
        .I1(local_y_3[4]),
        .O(\rgb_out[23]_i_1494_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1495 
       (.I0(local_y_3[2]),
        .I1(local_y_3[3]),
        .O(\rgb_out[23]_i_1495_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1496 
       (.I0(local_y_3[1]),
        .I1(pixel_y[0]),
        .O(\rgb_out[23]_i_1496_n_0 ));
  LUT6 #(
    .INIT(64'h8A8A8A8A8A8A8A88)) 
    \rgb_out[23]_i_17 
       (.I0(\mode_ui[2]_1 ),
        .I1(num_tm_d),
        .I2(\rgb_out[23]_i_56_n_0 ),
        .I3(\rgb_out[23]_i_57_n_0 ),
        .I4(\pixel_x[5]_0 ),
        .I5(\rgb_out[23]_i_59_n_0 ),
        .O(\rgb_out[23]_i_17_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFEAEAEAEE)) 
    \rgb_out[23]_i_18 
       (.I0(pixel_x_8_sn_1),
        .I1(decompte_ui_1_sn_1),
        .I2(\rgb_out[23]_i_62_n_0 ),
        .I3(\rgb_out[23]_i_63_n_0 ),
        .I4(\rgb_out[23]_i_64_n_0 ),
        .I5(\mode_ui[2]_1 ),
        .O(\rgb_out[23]_i_18_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFCFFFEFEFCFE)) 
    \rgb_out[23]_i_2 
       (.I0(\mode_ui[0]_0 ),
        .I1(\pixel_x[2]_21 ),
        .I2(\pixel_x[2]_22 ),
        .I3(\pixel_x[1]_0 ),
        .I4(\rgb_out[23]_i_7_n_0 ),
        .I5(\pixel_y[9]_1 ),
        .O(D[23]));
  LUT6 #(
    .INIT(64'h0007FFFFFFFFFFFF)) 
    \rgb_out[23]_i_216 
       (.I0(\rgb_out_reg[20]_1 ),
        .I1(\rgb_out_reg[20]_2 ),
        .I2(\rgb_out_reg[20]_3 ),
        .I3(\rgb_out_reg[20]_4 ),
        .I4(pixel_on8),
        .I5(pixel_on9),
        .O(\rgb_out[23]_i_216_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_493 
       (.I0(local_y_carry__1_n_0),
        .O(local_y_3[12]));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_494 
       (.I0(local_y_3[11]),
        .I1(local_y_3[10]),
        .O(\rgb_out[23]_i_494_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_496 
       (.I0(local_x_2[10]),
        .I1(local_x_2[11]),
        .O(\rgb_out[23]_i_496_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_497 
       (.I0(local_x_2[8]),
        .I1(local_x_2[9]),
        .O(\rgb_out[23]_i_497_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_498 
       (.I0(local_x_2[11]),
        .I1(local_x_2[10]),
        .O(\rgb_out[23]_i_498_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_499 
       (.I0(local_x_2[9]),
        .I1(local_x_2[8]),
        .O(\rgb_out[23]_i_499_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_503 
       (.I0(local_y_3[10]),
        .I1(local_y_3[11]),
        .O(\rgb_out[23]_i_503_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_504 
       (.I0(local_y_3[8]),
        .I1(local_y_3[9]),
        .O(\rgb_out[23]_i_504_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_505 
       (.I0(local_y_3[11]),
        .I1(local_y_3[10]),
        .O(\rgb_out[23]_i_505_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_506 
       (.I0(local_y_3[9]),
        .I1(local_y_3[8]),
        .O(\rgb_out[23]_i_506_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_508 
       (.I0(local_y_carry__1_n_0),
        .O(\rgb_out[23]_i_508_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_509 
       (.I0(local_y_3[11]),
        .I1(local_y_3[10]),
        .O(\rgb_out[23]_i_509_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_510 
       (.I0(local_y_3[9]),
        .I1(local_y_3[8]),
        .O(\rgb_out[23]_i_510_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_513 
       (.I0(local_x_2[10]),
        .I1(local_x_2[11]),
        .O(\rgb_out[23]_i_513_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_514 
       (.I0(local_x_2[8]),
        .I1(local_x_2[9]),
        .O(\rgb_out[23]_i_514_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_515 
       (.I0(local_x_2[11]),
        .I1(local_x_2[10]),
        .O(\rgb_out[23]_i_515_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_516 
       (.I0(local_x_2[9]),
        .I1(local_x_2[8]),
        .O(\rgb_out[23]_i_516_n_0 ));
  LUT4 #(
    .INIT(16'h7FFF)) 
    \rgb_out[23]_i_56 
       (.I0(pixel_on2),
        .I1(pixel_on3),
        .I2(pixel_on40_in),
        .I3(pixel_on4),
        .O(\rgb_out[23]_i_56_n_0 ));
  LUT5 #(
    .INIT(32'h8A888888)) 
    \rgb_out[23]_i_57 
       (.I0(pixel_on99_in),
        .I1(pixel_y_2_sn_1),
        .I2(\temps_restant[2] ),
        .I3(\rgb_out_reg[20] ),
        .I4(\rgb_out_reg[20]_0 ),
        .O(\rgb_out[23]_i_57_n_0 ));
  LUT5 #(
    .INIT(32'h88808888)) 
    \rgb_out[23]_i_59 
       (.I0(pixel_on8),
        .I1(pixel_on9),
        .I2(\pixel_y[5]_1 ),
        .I3(\pixel_y[2]_3 ),
        .I4(\pixel_y[2]_4 ),
        .O(\rgb_out[23]_i_59_n_0 ));
  LUT4 #(
    .INIT(16'hFEAA)) 
    \rgb_out[23]_i_62 
       (.I0(\rgb_out[23]_i_56_n_0 ),
        .I1(decompte_ui[2]),
        .I2(decompte_ui[1]),
        .I3(decompte_ui[3]),
        .O(\rgb_out[23]_i_62_n_0 ));
  LUT6 #(
    .INIT(64'hA8A8A8A8A888A8A8)) 
    \rgb_out[23]_i_63 
       (.I0(pixel_on99_in),
        .I1(\pixel_y[5]_0 ),
        .I2(\pixel_y[2]_2 ),
        .I3(decompte_ui[2]),
        .I4(decompte_ui[1]),
        .I5(decompte_ui[0]),
        .O(\rgb_out[23]_i_63_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFF0010)) 
    \rgb_out[23]_i_64 
       (.I0(\pixel_y[2]_0 ),
        .I1(pixel_y_5_sn_1),
        .I2(\pixel_y[2]_1 ),
        .I3(\rgb_out[23]_i_216_n_0 ),
        .I4(\pixel_x[5]_1 ),
        .I5(\pixel_x[5]_2 ),
        .O(\rgb_out[23]_i_64_n_0 ));
  LUT5 #(
    .INIT(32'hBFBBBFBF)) 
    \rgb_out[23]_i_7 
       (.I0(\rgb_out[23]_i_17_n_0 ),
        .I1(\rgb_out[23]_i_18_n_0 ),
        .I2(\pixel_y[4]_1 ),
        .I3(rgb_in[11]),
        .I4(is_pixel_mur),
        .O(\rgb_out[23]_i_7_n_0 ));
  LUT2 #(
    .INIT(4'h7)) 
    \rgb_out[23]_i_845 
       (.I0(local_y_3[4]),
        .I1(local_y_3[5]),
        .O(\rgb_out[23]_i_845_n_0 ));
  LUT2 #(
    .INIT(4'h7)) 
    \rgb_out[23]_i_846 
       (.I0(local_y_3[2]),
        .I1(local_y_3[3]),
        .O(\rgb_out[23]_i_846_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_847 
       (.I0(local_y_3[9]),
        .I1(local_y_3[8]),
        .O(\rgb_out[23]_i_847_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_848 
       (.I0(local_y_3[7]),
        .I1(local_y_3[6]),
        .O(\rgb_out[23]_i_848_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_849 
       (.I0(local_y_3[5]),
        .I1(local_y_3[4]),
        .O(\rgb_out[23]_i_849_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_850 
       (.I0(local_y_3[3]),
        .I1(local_y_3[2]),
        .O(\rgb_out[23]_i_850_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_851 
       (.I0(local_x_2[6]),
        .I1(local_x_2[7]),
        .O(\rgb_out[23]_i_851_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_853 
       (.I0(local_x_2[7]),
        .I1(local_x_2[6]),
        .O(\rgb_out[23]_i_853_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_854 
       (.I0(local_x_2[4]),
        .I1(local_x_2[5]),
        .O(\rgb_out[23]_i_854_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_858 
       (.I0(local_y_3[10]),
        .I1(local_y_3[11]),
        .O(\rgb_out[23]_i_858_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_859 
       (.I0(local_y_3[8]),
        .I1(local_y_3[9]),
        .O(\rgb_out[23]_i_859_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_860 
       (.I0(local_y_3[11]),
        .I1(local_y_3[10]),
        .O(\rgb_out[23]_i_860_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_861 
       (.I0(local_y_3[9]),
        .I1(local_y_3[8]),
        .O(\rgb_out[23]_i_861_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_863 
       (.I0(local_y_carry__1_n_0),
        .O(\rgb_out[23]_i_863_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_864 
       (.I0(local_y_3[11]),
        .I1(local_y_3[10]),
        .O(\rgb_out[23]_i_864_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_865 
       (.I0(local_y_3[9]),
        .I1(local_y_3[8]),
        .O(\rgb_out[23]_i_865_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_866 
       (.I0(local_y_3[6]),
        .I1(local_y_3[7]),
        .O(\rgb_out[23]_i_866_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_867 
       (.I0(local_y_3[4]),
        .I1(local_y_3[5]),
        .O(\rgb_out[23]_i_867_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_868 
       (.I0(local_y_3[1]),
        .I1(pixel_y[0]),
        .O(\rgb_out[23]_i_868_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_869 
       (.I0(local_y_3[7]),
        .I1(local_y_3[6]),
        .O(\rgb_out[23]_i_869_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_870 
       (.I0(local_y_3[5]),
        .I1(local_y_3[4]),
        .O(\rgb_out[23]_i_870_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_871 
       (.I0(local_y_3[2]),
        .I1(local_y_3[3]),
        .O(\rgb_out[23]_i_871_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_872 
       (.I0(local_y_3[1]),
        .I1(pixel_y[0]),
        .O(\rgb_out[23]_i_872_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_873 
       (.I0(local_y_3[5]),
        .I1(local_y_3[4]),
        .O(\rgb_out[23]_i_873_n_0 ));
  LUT2 #(
    .INIT(4'h7)) 
    \rgb_out[23]_i_874 
       (.I0(local_y_3[2]),
        .I1(local_y_3[3]),
        .O(\rgb_out[23]_i_874_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_875 
       (.I0(local_y_3[1]),
        .O(\rgb_out[23]_i_875_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_876 
       (.I0(local_y_3[7]),
        .I1(local_y_3[6]),
        .O(\rgb_out[23]_i_876_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_877 
       (.I0(local_y_3[4]),
        .I1(local_y_3[5]),
        .O(\rgb_out[23]_i_877_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_878 
       (.I0(local_y_3[3]),
        .I1(local_y_3[2]),
        .O(\rgb_out[23]_i_878_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_879 
       (.I0(local_y_3[1]),
        .I1(pixel_y[0]),
        .O(\rgb_out[23]_i_879_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_882 
       (.I0(local_x_2[11]),
        .I1(local_x_2[10]),
        .O(\rgb_out[23]_i_882_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_883 
       (.I0(local_x_2[9]),
        .I1(local_x_2[8]),
        .O(\rgb_out[23]_i_883_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_884 
       (.I0(local_x_2[6]),
        .I1(local_x_2[7]),
        .O(\rgb_out[23]_i_884_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_885 
       (.I0(local_x_2[4]),
        .I1(local_x_2[5]),
        .O(\rgb_out[23]_i_885_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_887 
       (.I0(local_x_2[7]),
        .I1(local_x_2[6]),
        .O(\rgb_out[23]_i_887_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_888 
       (.I0(local_x_2[5]),
        .I1(local_x_2[4]),
        .O(\rgb_out[23]_i_888_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_892 
       (.I0(local_y_3[10]),
        .I1(local_y_3[11]),
        .O(\rgb_out[23]_i_892_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_893 
       (.I0(local_y_3[8]),
        .I1(local_y_3[9]),
        .O(\rgb_out[23]_i_893_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_894 
       (.I0(local_y_3[11]),
        .I1(local_y_3[10]),
        .O(\rgb_out[23]_i_894_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_895 
       (.I0(local_y_3[9]),
        .I1(local_y_3[8]),
        .O(\rgb_out[23]_i_895_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_897 
       (.I0(local_y_3[10]),
        .I1(local_y_3[11]),
        .O(\rgb_out[23]_i_897_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_898 
       (.I0(local_y_3[8]),
        .I1(local_y_3[9]),
        .O(\rgb_out[23]_i_898_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_899 
       (.I0(local_y_3[11]),
        .I1(local_y_3[10]),
        .O(\rgb_out[23]_i_899_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_900 
       (.I0(local_y_3[9]),
        .I1(local_y_3[8]),
        .O(\rgb_out[23]_i_900_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_902 
       (.I0(local_y_carry__1_n_0),
        .O(\rgb_out[23]_i_902_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_903 
       (.I0(local_y_3[11]),
        .I1(local_y_3[10]),
        .O(\rgb_out[23]_i_903_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_904 
       (.I0(local_y_3[9]),
        .I1(local_y_3[8]),
        .O(\rgb_out[23]_i_904_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_906 
       (.I0(local_y_carry__1_n_0),
        .O(\rgb_out[23]_i_906_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_907 
       (.I0(local_y_3[11]),
        .I1(local_y_3[10]),
        .O(\rgb_out[23]_i_907_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_908 
       (.I0(local_y_3[9]),
        .I1(local_y_3[8]),
        .O(\rgb_out[23]_i_908_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFFF0D)) 
    \rgb_out[2]_i_1 
       (.I0(\rgb_out[20]_i_4_n_0 ),
        .I1(\pixel_y[4]_4 ),
        .I2(pixel_y_9_sn_1),
        .I3(\pixel_x[2]_5 ),
        .I4(\pixel_x[2]_6 ),
        .I5(\pixel_x[3]_1 ),
        .O(D[2]));
  LUT5 #(
    .INIT(32'hFFFF44F4)) 
    \rgb_out[3]_i_1 
       (.I0(pixel_x_2_sn_1),
        .I1(rgb_in[1]),
        .I2(pixel_x_5_sn_1),
        .I3(\rgb_out[3]_i_2_n_0 ),
        .I4(\pixel_x[2]_0 ),
        .O(D[3]));
  LUT6 #(
    .INIT(64'h00000800AAAAAAAA)) 
    \rgb_out[3]_i_2 
       (.I0(\rgb_out[7]_i_3_n_0 ),
        .I1(pixel_x_1_sn_1),
        .I2(\pixel_y[4]_0 ),
        .I3(is_pixel_mur),
        .I4(rgb_in[1]),
        .I5(\rgb_out[23]_i_18_n_0 ),
        .O(\rgb_out[3]_i_2_n_0 ));
  LUT5 #(
    .INIT(32'hFFFF44F4)) 
    \rgb_out[4]_i_1 
       (.I0(\rgb_out[4]_i_2_n_0 ),
        .I1(pixel_x_5_sn_1),
        .I2(rgb_in[2]),
        .I3(pixel_x_2_sn_1),
        .I4(\pixel_x[2]_0 ),
        .O(D[4]));
  LUT6 #(
    .INIT(64'h00000888AAAAAAAA)) 
    \rgb_out[4]_i_2 
       (.I0(\rgb_out[7]_i_3_n_0 ),
        .I1(pixel_x_1_sn_1),
        .I2(is_pixel_mur),
        .I3(rgb_in[2]),
        .I4(\pixel_y[4]_0 ),
        .I5(\rgb_out[23]_i_18_n_0 ),
        .O(\rgb_out[4]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFD50000)) 
    \rgb_out[5]_i_1 
       (.I0(\rgb_out[20]_i_4_n_0 ),
        .I1(is_pixel_mur),
        .I2(rgb_in[3]),
        .I3(\pixel_y[4]_1 ),
        .I4(mode_ui_0_sn_1),
        .I5(\pixel_x[2]_7 ),
        .O(D[5]));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFFFD0)) 
    \rgb_out[6]_i_1 
       (.I0(\rgb_out[20]_i_4_n_0 ),
        .I1(\pixel_y[4]_5 ),
        .I2(mode_ui_0_sn_1),
        .I3(\pixel_x[2]_1 ),
        .I4(\pixel_x[2]_8 ),
        .I5(\pixel_x[3]_2 ),
        .O(D[6]));
  LUT6 #(
    .INIT(64'hFFFFFFFF4F444F4F)) 
    \rgb_out[7]_i_1 
       (.I0(pixel_x_2_sn_1),
        .I1(rgb_in[4]),
        .I2(pixel_y_9_sn_1),
        .I3(\rgb_out[7]_i_2_n_0 ),
        .I4(\rgb_out[7]_i_3_n_0 ),
        .I5(\pixel_x[2]_1 ),
        .O(D[7]));
  LUT6 #(
    .INIT(64'h0000A808AAAAAAAA)) 
    \rgb_out[7]_i_2 
       (.I0(\rgb_out[23]_i_18_n_0 ),
        .I1(mode_ui_1_sn_1),
        .I2(is_pixel_mur),
        .I3(rgb_in[4]),
        .I4(\pixel_y[4]_0 ),
        .I5(pixel_x_1_sn_1),
        .O(\rgb_out[7]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h000000000002FFFF)) 
    \rgb_out[7]_i_3 
       (.I0(\pixel_x[2]_23 ),
        .I1(\pixel_x[2]_24 ),
        .I2(\pixel_x[2]_25 ),
        .I3(\pixel_x[3]_12 ),
        .I4(\mode_ui[2]_0 ),
        .I5(\rgb_out[23]_i_17_n_0 ),
        .O(\rgb_out[7]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFFFD0)) 
    \rgb_out[8]_i_1 
       (.I0(\rgb_out[20]_i_4_n_0 ),
        .I1(\pixel_y[4]_6 ),
        .I2(mode_ui_0_sn_1),
        .I3(\pixel_x[2]_1 ),
        .I4(\pixel_x[2]_9 ),
        .I5(\pixel_x[3]_3 ),
        .O(D[8]));
  LUT5 #(
    .INIT(32'hFFFF44F4)) 
    \rgb_out[9]_i_1 
       (.I0(\rgb_out[9]_i_2_n_0 ),
        .I1(pixel_x_5_sn_1),
        .I2(rgb_in[5]),
        .I3(pixel_x_2_sn_1),
        .I4(\pixel_x[2]_0 ),
        .O(D[9]));
  LUT6 #(
    .INIT(64'h80888080AAAAAAAA)) 
    \rgb_out[9]_i_2 
       (.I0(\rgb_out[7]_i_3_n_0 ),
        .I1(pixel_x_1_sn_1),
        .I2(\pixel_y[4]_1 ),
        .I3(rgb_in[5]),
        .I4(is_pixel_mur),
        .I5(\rgb_out[23]_i_18_n_0 ),
        .O(\rgb_out[9]_i_2_n_0 ));
  CARRY4 \rgb_out_reg[23]_i_193 
       (.CI(\rgb_out_reg[23]_i_492_n_0 ),
        .CO({\NLW_rgb_out_reg[23]_i_193_CO_UNCONNECTED [3:2],pixel_on2,\rgb_out_reg[23]_i_193_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,local_y_3[12],1'b0}),
        .O(\NLW_rgb_out_reg[23]_i_193_O_UNCONNECTED [3:0]),
        .S({1'b0,1'b0,local_y_carry__1_n_0,\rgb_out[23]_i_494_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_194 
       (.CI(\rgb_out_reg[23]_i_495_n_0 ),
        .CO({\NLW_rgb_out_reg[23]_i_194_CO_UNCONNECTED [3],pixel_on99_in,\rgb_out_reg[23]_i_194_n_2 ,\rgb_out_reg[23]_i_194_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\rgb_out[23]_i_496_n_0 ,\rgb_out[23]_i_497_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_194_O_UNCONNECTED [3:0]),
        .S({1'b0,CO,\rgb_out[23]_i_498_n_0 ,\rgb_out[23]_i_499_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_197 
       (.CI(\rgb_out_reg[23]_i_502_n_0 ),
        .CO({\NLW_rgb_out_reg[23]_i_197_CO_UNCONNECTED [3],\rgb_out_reg[20] ,\rgb_out_reg[23]_i_197_n_2 ,\rgb_out_reg[23]_i_197_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\rgb_out[23]_i_503_n_0 ,\rgb_out[23]_i_504_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_197_O_UNCONNECTED [3:0]),
        .S({1'b0,local_y_carry__1_n_0,\rgb_out[23]_i_505_n_0 ,\rgb_out[23]_i_506_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_198 
       (.CI(\rgb_out_reg[23]_i_507_n_0 ),
        .CO({\NLW_rgb_out_reg[23]_i_198_CO_UNCONNECTED [3],\rgb_out_reg[20]_0 ,\rgb_out_reg[23]_i_198_n_2 ,\rgb_out_reg[23]_i_198_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,\rgb_out[23]_i_508_n_0 ,1'b0,1'b0}),
        .O(\NLW_rgb_out_reg[23]_i_198_O_UNCONNECTED [3:0]),
        .S({1'b0,local_y_carry__1_n_0,\rgb_out[23]_i_509_n_0 ,\rgb_out[23]_i_510_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_201 
       (.CI(\rgb_out_reg[23]_i_512_n_0 ),
        .CO({\NLW_rgb_out_reg[23]_i_201_CO_UNCONNECTED [3],pixel_on9,\rgb_out_reg[23]_i_201_n_2 ,\rgb_out_reg[23]_i_201_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\rgb_out[23]_i_513_n_0 ,\rgb_out[23]_i_514_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_201_O_UNCONNECTED [3:0]),
        .S({1'b0,CO,\rgb_out[23]_i_515_n_0 ,\rgb_out[23]_i_516_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_492 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_492_n_0 ,\rgb_out_reg[23]_i_492_n_1 ,\rgb_out_reg[23]_i_492_n_2 ,\rgb_out_reg[23]_i_492_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\rgb_out[23]_i_845_n_0 ,\rgb_out[23]_i_846_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_492_O_UNCONNECTED [3:0]),
        .S({\rgb_out[23]_i_847_n_0 ,\rgb_out[23]_i_848_n_0 ,\rgb_out[23]_i_849_n_0 ,\rgb_out[23]_i_850_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_495 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_495_n_0 ,\rgb_out_reg[23]_i_495_n_1 ,\rgb_out_reg[23]_i_495_n_2 ,\rgb_out_reg[23]_i_495_n_3 }),
        .CYINIT(1'b1),
        .DI({\rgb_out[23]_i_851_n_0 ,local_x_2[5],1'b0,DI}),
        .O(\NLW_rgb_out_reg[23]_i_495_O_UNCONNECTED [3:0]),
        .S({\rgb_out[23]_i_853_n_0 ,\rgb_out[23]_i_854_n_0 ,S}));
  CARRY4 \rgb_out_reg[23]_i_500 
       (.CI(\rgb_out_reg[23]_i_857_n_0 ),
        .CO({\NLW_rgb_out_reg[23]_i_500_CO_UNCONNECTED [3],\rgb_out_reg[20]_6 ,\rgb_out_reg[23]_i_500_n_2 ,\rgb_out_reg[23]_i_500_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\rgb_out[23]_i_858_n_0 ,\rgb_out[23]_i_859_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_500_O_UNCONNECTED [3:0]),
        .S({1'b0,local_y_carry__1_n_0,\rgb_out[23]_i_860_n_0 ,\rgb_out[23]_i_861_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_501 
       (.CI(\rgb_out_reg[23]_i_862_n_0 ),
        .CO({\NLW_rgb_out_reg[23]_i_501_CO_UNCONNECTED [3],\rgb_out_reg[20]_5 ,\rgb_out_reg[23]_i_501_n_2 ,\rgb_out_reg[23]_i_501_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,\rgb_out[23]_i_863_n_0 ,1'b0,1'b0}),
        .O(\NLW_rgb_out_reg[23]_i_501_O_UNCONNECTED [3:0]),
        .S({1'b0,local_y_carry__1_n_0,\rgb_out[23]_i_864_n_0 ,\rgb_out[23]_i_865_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_502 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_502_n_0 ,\rgb_out_reg[23]_i_502_n_1 ,\rgb_out_reg[23]_i_502_n_2 ,\rgb_out_reg[23]_i_502_n_3 }),
        .CYINIT(1'b1),
        .DI({\rgb_out[23]_i_866_n_0 ,\rgb_out[23]_i_867_n_0 ,local_y_3[3],\rgb_out[23]_i_868_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_502_O_UNCONNECTED [3:0]),
        .S({\rgb_out[23]_i_869_n_0 ,\rgb_out[23]_i_870_n_0 ,\rgb_out[23]_i_871_n_0 ,\rgb_out[23]_i_872_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_507 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_507_n_0 ,\rgb_out_reg[23]_i_507_n_1 ,\rgb_out_reg[23]_i_507_n_2 ,\rgb_out_reg[23]_i_507_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,\rgb_out[23]_i_873_n_0 ,\rgb_out[23]_i_874_n_0 ,\rgb_out[23]_i_875_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_507_O_UNCONNECTED [3:0]),
        .S({\rgb_out[23]_i_876_n_0 ,\rgb_out[23]_i_877_n_0 ,\rgb_out[23]_i_878_n_0 ,\rgb_out[23]_i_879_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_511 
       (.CI(\rgb_out_reg[23]_i_880_n_0 ),
        .CO({\NLW_rgb_out_reg[23]_i_511_CO_UNCONNECTED [3],\rgb_out_reg[20]_7 ,\rgb_out_reg[23]_i_511_n_2 ,\rgb_out_reg[23]_i_511_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,\pixel_x[5]_3 ,1'b0,1'b0}),
        .O(\NLW_rgb_out_reg[23]_i_511_O_UNCONNECTED [3:0]),
        .S({1'b0,CO,\rgb_out[23]_i_882_n_0 ,\rgb_out[23]_i_883_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_512 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_512_n_0 ,\rgb_out_reg[23]_i_512_n_1 ,\rgb_out_reg[23]_i_512_n_2 ,\rgb_out_reg[23]_i_512_n_3 }),
        .CYINIT(1'b1),
        .DI({\rgb_out[23]_i_884_n_0 ,\rgb_out[23]_i_885_n_0 ,pixel_x[3],\pixel_x[1]_1 }),
        .O(\NLW_rgb_out_reg[23]_i_512_O_UNCONNECTED [3:0]),
        .S({\rgb_out[23]_i_887_n_0 ,\rgb_out[23]_i_888_n_0 ,\pixel_x[3]_13 }));
  CARRY4 \rgb_out_reg[23]_i_517 
       (.CI(\rgb_out_reg[23]_i_891_n_0 ),
        .CO({\NLW_rgb_out_reg[23]_i_517_CO_UNCONNECTED [3],\rgb_out_reg[20]_3 ,\rgb_out_reg[23]_i_517_n_2 ,\rgb_out_reg[23]_i_517_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\rgb_out[23]_i_892_n_0 ,\rgb_out[23]_i_893_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_517_O_UNCONNECTED [3:0]),
        .S({1'b0,local_y_carry__1_n_0,\rgb_out[23]_i_894_n_0 ,\rgb_out[23]_i_895_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_518 
       (.CI(\rgb_out_reg[23]_i_896_n_0 ),
        .CO({\NLW_rgb_out_reg[23]_i_518_CO_UNCONNECTED [3],\rgb_out_reg[20]_2 ,\rgb_out_reg[23]_i_518_n_2 ,\rgb_out_reg[23]_i_518_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\rgb_out[23]_i_897_n_0 ,\rgb_out[23]_i_898_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_518_O_UNCONNECTED [3:0]),
        .S({1'b0,local_y_carry__1_n_0,\rgb_out[23]_i_899_n_0 ,\rgb_out[23]_i_900_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_519 
       (.CI(\rgb_out_reg[23]_i_901_n_0 ),
        .CO({\NLW_rgb_out_reg[23]_i_519_CO_UNCONNECTED [3],\rgb_out_reg[20]_1 ,\rgb_out_reg[23]_i_519_n_2 ,\rgb_out_reg[23]_i_519_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,\rgb_out[23]_i_902_n_0 ,1'b0,1'b0}),
        .O(\NLW_rgb_out_reg[23]_i_519_O_UNCONNECTED [3:0]),
        .S({1'b0,local_y_carry__1_n_0,\rgb_out[23]_i_903_n_0 ,\rgb_out[23]_i_904_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_520 
       (.CI(\rgb_out_reg[23]_i_905_n_0 ),
        .CO({\NLW_rgb_out_reg[23]_i_520_CO_UNCONNECTED [3],\rgb_out_reg[20]_4 ,\rgb_out_reg[23]_i_520_n_2 ,\rgb_out_reg[23]_i_520_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,\rgb_out[23]_i_906_n_0 ,1'b0,1'b0}),
        .O(\NLW_rgb_out_reg[23]_i_520_O_UNCONNECTED [3:0]),
        .S({1'b0,local_y_carry__1_n_0,\rgb_out[23]_i_907_n_0 ,\rgb_out[23]_i_908_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_857 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_857_n_0 ,\rgb_out_reg[23]_i_857_n_1 ,\rgb_out_reg[23]_i_857_n_2 ,\rgb_out_reg[23]_i_857_n_3 }),
        .CYINIT(1'b1),
        .DI({\rgb_out[23]_i_1454_n_0 ,local_y_3[5],1'b0,\rgb_out[23]_i_1455_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_857_O_UNCONNECTED [3:0]),
        .S({\rgb_out[23]_i_1456_n_0 ,\rgb_out[23]_i_1457_n_0 ,\rgb_out[23]_i_1458_n_0 ,\rgb_out[23]_i_1459_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_862 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_862_n_0 ,\rgb_out_reg[23]_i_862_n_1 ,\rgb_out_reg[23]_i_862_n_2 ,\rgb_out_reg[23]_i_862_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,\rgb_out[23]_i_1460_n_0 ,\rgb_out[23]_i_1461_n_0 ,\rgb_out[23]_i_1462_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_862_O_UNCONNECTED [3:0]),
        .S({\rgb_out[23]_i_1463_n_0 ,\rgb_out[23]_i_1464_n_0 ,\rgb_out[23]_i_1465_n_0 ,\rgb_out[23]_i_1466_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_880 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_880_n_0 ,\rgb_out_reg[23]_i_880_n_1 ,\rgb_out_reg[23]_i_880_n_2 ,\rgb_out_reg[23]_i_880_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\pixel_x[2]_26 }),
        .O(\NLW_rgb_out_reg[23]_i_880_O_UNCONNECTED [3:0]),
        .S({\rgb_out[23]_i_1469_n_0 ,\rgb_out[23]_i_1470_n_0 ,\pixel_x[3]_14 }));
  CARRY4 \rgb_out_reg[23]_i_891 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_891_n_0 ,\rgb_out_reg[23]_i_891_n_1 ,\rgb_out_reg[23]_i_891_n_2 ,\rgb_out_reg[23]_i_891_n_3 }),
        .CYINIT(1'b1),
        .DI({\rgb_out[23]_i_1473_n_0 ,1'b0,local_y_3[3],\rgb_out[23]_i_1474_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_891_O_UNCONNECTED [3:0]),
        .S({\rgb_out[23]_i_1475_n_0 ,\rgb_out[23]_i_1476_n_0 ,\rgb_out[23]_i_1477_n_0 ,\rgb_out[23]_i_1478_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_896 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_896_n_0 ,\rgb_out_reg[23]_i_896_n_1 ,\rgb_out_reg[23]_i_896_n_2 ,\rgb_out_reg[23]_i_896_n_3 }),
        .CYINIT(1'b1),
        .DI({\rgb_out[23]_i_1479_n_0 ,local_y_3[5],\rgb_out[23]_i_1480_n_0 ,1'b0}),
        .O(\NLW_rgb_out_reg[23]_i_896_O_UNCONNECTED [3:0]),
        .S({\rgb_out[23]_i_1481_n_0 ,\rgb_out[23]_i_1482_n_0 ,\rgb_out[23]_i_1483_n_0 ,\rgb_out[23]_i_1484_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_901 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_901_n_0 ,\rgb_out_reg[23]_i_901_n_1 ,\rgb_out_reg[23]_i_901_n_2 ,\rgb_out_reg[23]_i_901_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,\rgb_out[23]_i_1485_n_0 ,1'b0,\rgb_out[23]_i_1486_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_901_O_UNCONNECTED [3:0]),
        .S({\rgb_out[23]_i_1487_n_0 ,\rgb_out[23]_i_1488_n_0 ,\rgb_out[23]_i_1489_n_0 ,\rgb_out[23]_i_1490_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_905 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_905_n_0 ,\rgb_out_reg[23]_i_905_n_1 ,\rgb_out_reg[23]_i_905_n_2 ,\rgb_out_reg[23]_i_905_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\rgb_out[23]_i_1491_n_0 ,\rgb_out[23]_i_1492_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_905_O_UNCONNECTED [3:0]),
        .S({\rgb_out[23]_i_1493_n_0 ,\rgb_out[23]_i_1494_n_0 ,\rgb_out[23]_i_1495_n_0 ,\rgb_out[23]_i_1496_n_0 }));
endmodule

module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_compositeur
   (CO,
    de_out,
    hsync_out,
    vsync_out,
    local_y,
    \rgb_out_reg[0]_0 ,
    rgb_out,
    pixel_x,
    pixel_y,
    pixel_clk,
    \pixel_x[1] ,
    \pixel_x[5] ,
    \pixel_y[2] ,
    \pixel_x[1]_0 ,
    \pixel_y[2]_0 ,
    \pixel_x[1]_1 ,
    \pixel_y[2]_1 ,
    \pixel_y[5] ,
    \pixel_x[1]_2 ,
    \pixel_y[2]_2 ,
    local_x,
    \pixel_x[1]_3 ,
    \pixel_y[2]_3 ,
    score_courant,
    \pixel_y[5]_0 ,
    \pixel_x[1]_4 ,
    \pixel_y[2]_4 ,
    \pixel_y[2]_5 ,
    \pixel_x[6] ,
    \pixel_x[1]_5 ,
    \pixel_y[2]_6 ,
    \pixel_y[5]_1 ,
    \pixel_y[2]_7 ,
    \pixel_y[2]_8 ,
    \pixel_x[1]_6 ,
    \pixel_y[2]_9 ,
    \pixel_x[1]_7 ,
    \pixel_y[2]_10 ,
    local_x_0,
    \pixel_x[1]_8 ,
    \pixel_x[7] ,
    \pixel_x[3] ,
    \pixel_y[2]_11 ,
    \pixel_x[3]_0 ,
    \pixel_y[2]_12 ,
    \pixel_x[3]_1 ,
    \pixel_y[2]_13 ,
    \pixel_y[5]_2 ,
    \pixel_x[3]_2 ,
    \pixel_y[5]_3 ,
    \pixel_y[2]_14 ,
    \pixel_y[2]_15 ,
    \pixel_y[2]_16 ,
    local_x_1,
    \pixel_x[3]_3 ,
    \pixel_x[2] ,
    \pixel_x[2]_0 ,
    \pixel_y[1] ,
    \pixel_x[2]_1 ,
    \pixel_y[1]_0 ,
    \pixel_x[2]_2 ,
    \pixel_y[1]_1 ,
    \pixel_y[5]_4 ,
    \pixel_x[7]_0 ,
    \pixel_x[2]_3 ,
    \pixel_y[5]_5 ,
    \pixel_y[1]_2 ,
    \pixel_y[1]_3 ,
    \pixel_y[1]_4 ,
    \pixel_x[5]_0 ,
    \pixel_x[2]_4 ,
    \pixel_y[1]_5 ,
    \pixel_y[5]_6 ,
    score_dernier,
    \pixel_y[1]_6 ,
    \pixel_y[1]_7 ,
    \pixel_x[2]_5 ,
    \pixel_x[2]_6 ,
    \pixel_y[1]_8 ,
    \pixel_y[5]_7 ,
    \pixel_y[1]_9 ,
    \pixel_y[1]_10 ,
    \pixel_x[2]_7 ,
    \pixel_y[1]_11 ,
    \pixel_x[2]_8 ,
    \pixel_y[1]_12 ,
    \pixel_x[2]_9 ,
    \pixel_x[2]_10 ,
    \pixel_y[1]_13 ,
    \pixel_x[2]_11 ,
    \pixel_y[1]_14 ,
    \pixel_x[2]_12 ,
    \pixel_y[1]_15 ,
    \pixel_y[5]_8 ,
    \pixel_x[5]_1 ,
    \pixel_x[2]_13 ,
    \pixel_y[5]_9 ,
    \pixel_y[1]_16 ,
    \pixel_y[1]_17 ,
    \pixel_y[1]_18 ,
    \pixel_x[6]_0 ,
    \pixel_x[2]_14 ,
    \pixel_y[1]_19 ,
    \pixel_y[5]_10 ,
    record_personnel,
    \pixel_y[1]_20 ,
    \pixel_y[1]_21 ,
    \pixel_x[2]_15 ,
    \pixel_x[2]_16 ,
    \pixel_y[1]_22 ,
    \pixel_y[5]_11 ,
    \pixel_y[1]_23 ,
    \pixel_y[1]_24 ,
    \pixel_x[2]_17 ,
    \pixel_y[1]_25 ,
    \pixel_x[2]_18 ,
    \pixel_y[1]_26 ,
    rgb_in,
    is_pixel_mur,
    mode_ui,
    temps_restant,
    flash_on,
    decompte_ui,
    DI,
    S,
    \pixel_x[5]_2 ,
    hsync_in,
    reset,
    vsync_in,
    de_in);
  output [0:0]CO;
  output de_out;
  output hsync_out;
  output vsync_out;
  output [10:0]local_y;
  output [0:0]\rgb_out_reg[0]_0 ;
  output [23:0]rgb_out;
  input [11:0]pixel_x;
  input [11:0]pixel_y;
  input pixel_clk;
  input [0:0]\pixel_x[1] ;
  input [0:0]\pixel_x[5] ;
  input [0:0]\pixel_y[2] ;
  input [0:0]\pixel_x[1]_0 ;
  input [0:0]\pixel_y[2]_0 ;
  input [0:0]\pixel_x[1]_1 ;
  input [0:0]\pixel_y[2]_1 ;
  input [0:0]\pixel_y[5] ;
  input [0:0]\pixel_x[1]_2 ;
  input [0:0]\pixel_y[2]_2 ;
  input [11:0]local_x;
  input [0:0]\pixel_x[1]_3 ;
  input [0:0]\pixel_y[2]_3 ;
  input [3:0]score_courant;
  input [0:0]\pixel_y[5]_0 ;
  input [0:0]\pixel_x[1]_4 ;
  input [0:0]\pixel_y[2]_4 ;
  input [0:0]\pixel_y[2]_5 ;
  input [0:0]\pixel_x[6] ;
  input [0:0]\pixel_x[1]_5 ;
  input [0:0]\pixel_y[2]_6 ;
  input [0:0]\pixel_y[5]_1 ;
  input [0:0]\pixel_y[2]_7 ;
  input [0:0]\pixel_y[2]_8 ;
  input [0:0]\pixel_x[1]_6 ;
  input [0:0]\pixel_y[2]_9 ;
  input [0:0]\pixel_x[1]_7 ;
  input [0:0]\pixel_y[2]_10 ;
  input [11:0]local_x_0;
  input [0:0]\pixel_x[1]_8 ;
  input [0:0]\pixel_x[7] ;
  input [0:0]\pixel_x[3] ;
  input [0:0]\pixel_y[2]_11 ;
  input [0:0]\pixel_x[3]_0 ;
  input [0:0]\pixel_y[2]_12 ;
  input [0:0]\pixel_x[3]_1 ;
  input [0:0]\pixel_y[2]_13 ;
  input [0:0]\pixel_y[5]_2 ;
  input [0:0]\pixel_x[3]_2 ;
  input [0:0]\pixel_y[5]_3 ;
  input [0:0]\pixel_y[2]_14 ;
  input [0:0]\pixel_y[2]_15 ;
  input [0:0]\pixel_y[2]_16 ;
  input [9:0]local_x_1;
  input [0:0]\pixel_x[3]_3 ;
  input [0:0]\pixel_x[2] ;
  input [0:0]\pixel_x[2]_0 ;
  input [0:0]\pixel_y[1] ;
  input [0:0]\pixel_x[2]_1 ;
  input [0:0]\pixel_y[1]_0 ;
  input [0:0]\pixel_x[2]_2 ;
  input [0:0]\pixel_y[1]_1 ;
  input [0:0]\pixel_y[5]_4 ;
  input [0:0]\pixel_x[7]_0 ;
  input [0:0]\pixel_x[2]_3 ;
  input [0:0]\pixel_y[5]_5 ;
  input [0:0]\pixel_y[1]_2 ;
  input [0:0]\pixel_y[1]_3 ;
  input [0:0]\pixel_y[1]_4 ;
  input [0:0]\pixel_x[5]_0 ;
  input [0:0]\pixel_x[2]_4 ;
  input [0:0]\pixel_y[1]_5 ;
  input [0:0]\pixel_y[5]_6 ;
  input [3:0]score_dernier;
  input [0:0]\pixel_y[1]_6 ;
  input [0:0]\pixel_y[1]_7 ;
  input [0:0]\pixel_x[2]_5 ;
  input [0:0]\pixel_x[2]_6 ;
  input [0:0]\pixel_y[1]_8 ;
  input [0:0]\pixel_y[5]_7 ;
  input [0:0]\pixel_y[1]_9 ;
  input [0:0]\pixel_y[1]_10 ;
  input [0:0]\pixel_x[2]_7 ;
  input [0:0]\pixel_y[1]_11 ;
  input [0:0]\pixel_x[2]_8 ;
  input [0:0]\pixel_y[1]_12 ;
  input [0:0]\pixel_x[2]_9 ;
  input [0:0]\pixel_x[2]_10 ;
  input [0:0]\pixel_y[1]_13 ;
  input [0:0]\pixel_x[2]_11 ;
  input [0:0]\pixel_y[1]_14 ;
  input [0:0]\pixel_x[2]_12 ;
  input [0:0]\pixel_y[1]_15 ;
  input [0:0]\pixel_y[5]_8 ;
  input [0:0]\pixel_x[5]_1 ;
  input [0:0]\pixel_x[2]_13 ;
  input [0:0]\pixel_y[5]_9 ;
  input [0:0]\pixel_y[1]_16 ;
  input [0:0]\pixel_y[1]_17 ;
  input [0:0]\pixel_y[1]_18 ;
  input [0:0]\pixel_x[6]_0 ;
  input [0:0]\pixel_x[2]_14 ;
  input [0:0]\pixel_y[1]_19 ;
  input [0:0]\pixel_y[5]_10 ;
  input [3:0]record_personnel;
  input [0:0]\pixel_y[1]_20 ;
  input [0:0]\pixel_y[1]_21 ;
  input [0:0]\pixel_x[2]_15 ;
  input [0:0]\pixel_x[2]_16 ;
  input [0:0]\pixel_y[1]_22 ;
  input [0:0]\pixel_y[5]_11 ;
  input [0:0]\pixel_y[1]_23 ;
  input [0:0]\pixel_y[1]_24 ;
  input [0:0]\pixel_x[2]_17 ;
  input [0:0]\pixel_y[1]_25 ;
  input [0:0]\pixel_x[2]_18 ;
  input [0:0]\pixel_y[1]_26 ;
  input [23:0]rgb_in;
  input is_pixel_mur;
  input [2:0]mode_ui;
  input [3:0]temps_restant;
  input flash_on;
  input [3:0]decompte_ui;
  input [1:0]DI;
  input [1:0]S;
  input [0:0]\pixel_x[5]_2 ;
  input hsync_in;
  input reset;
  input vsync_in;
  input de_in;

  wire [0:0]CO;
  wire [1:0]DI;
  wire [2:1]\LAST_U/segments ;
  wire [2:1]\REC_U/segments ;
  wire [1:0]S;
  wire \SC_D/pixel_on66_in ;
  wire \SC_D/pixel_on7 ;
  wire \SC_D/pixel_on83_in ;
  wire \SC_D/pixel_on9 ;
  wire \SC_U/pixel_on0 ;
  wire \SC_U/pixel_on9 ;
  wire [2:1]\SC_U/segments ;
  wire \TM_D/pixel_on9 ;
  wire TM_U_n_1;
  wire TM_U_n_10;
  wire TM_U_n_11;
  wire TM_U_n_12;
  wire TM_U_n_13;
  wire TM_U_n_14;
  wire TM_U_n_15;
  wire TM_U_n_16;
  wire TM_U_n_17;
  wire TM_U_n_18;
  wire TM_U_n_19;
  wire TM_U_n_2;
  wire TM_U_n_20;
  wire TM_U_n_21;
  wire TM_U_n_22;
  wire TM_U_n_23;
  wire TM_U_n_24;
  wire TM_U_n_3;
  wire TM_U_n_4;
  wire TM_U_n_5;
  wire TM_U_n_6;
  wire TM_U_n_7;
  wire TM_U_n_8;
  wire TM_U_n_9;
  wire de_in;
  wire de_out;
  wire de_out_i_1_n_0;
  wire [3:0]decompte_ui;
  wire dernier_diz;
  wire flash_on;
  wire hsync_in;
  wire hsync_out;
  wire hsync_out_i_1_n_0;
  wire is_pixel_mur;
  wire [11:0]local_x;
  wire [11:0]local_x_0;
  wire [9:0]local_x_1;
  wire [10:0]local_y;
  wire [2:0]mode_ui;
  wire num_last_d;
  wire num_last_u;
  wire num_rec_d;
  wire num_rec_u;
  wire num_sc_d;
  wire num_tm_d;
  wire pixel_clk;
  wire pixel_on22_in;
  wire pixel_on31_in;
  wire pixel_on5;
  wire pixel_on6;
  wire pixel_on66_in;
  wire pixel_on7;
  wire pixel_on712_in;
  wire pixel_on75_in;
  wire pixel_on83_in;
  wire [11:0]pixel_x;
  wire [0:0]\pixel_x[1] ;
  wire [0:0]\pixel_x[1]_0 ;
  wire [0:0]\pixel_x[1]_1 ;
  wire [0:0]\pixel_x[1]_2 ;
  wire [0:0]\pixel_x[1]_3 ;
  wire [0:0]\pixel_x[1]_4 ;
  wire [0:0]\pixel_x[1]_5 ;
  wire [0:0]\pixel_x[1]_6 ;
  wire [0:0]\pixel_x[1]_7 ;
  wire [0:0]\pixel_x[1]_8 ;
  wire [0:0]\pixel_x[2] ;
  wire [0:0]\pixel_x[2]_0 ;
  wire [0:0]\pixel_x[2]_1 ;
  wire [0:0]\pixel_x[2]_10 ;
  wire [0:0]\pixel_x[2]_11 ;
  wire [0:0]\pixel_x[2]_12 ;
  wire [0:0]\pixel_x[2]_13 ;
  wire [0:0]\pixel_x[2]_14 ;
  wire [0:0]\pixel_x[2]_15 ;
  wire [0:0]\pixel_x[2]_16 ;
  wire [0:0]\pixel_x[2]_17 ;
  wire [0:0]\pixel_x[2]_18 ;
  wire [0:0]\pixel_x[2]_2 ;
  wire [0:0]\pixel_x[2]_3 ;
  wire [0:0]\pixel_x[2]_4 ;
  wire [0:0]\pixel_x[2]_5 ;
  wire [0:0]\pixel_x[2]_6 ;
  wire [0:0]\pixel_x[2]_7 ;
  wire [0:0]\pixel_x[2]_8 ;
  wire [0:0]\pixel_x[2]_9 ;
  wire [0:0]\pixel_x[3] ;
  wire [0:0]\pixel_x[3]_0 ;
  wire [0:0]\pixel_x[3]_1 ;
  wire [0:0]\pixel_x[3]_2 ;
  wire [0:0]\pixel_x[3]_3 ;
  wire [0:0]\pixel_x[5] ;
  wire [0:0]\pixel_x[5]_0 ;
  wire [0:0]\pixel_x[5]_1 ;
  wire [0:0]\pixel_x[5]_2 ;
  wire [0:0]\pixel_x[6] ;
  wire [0:0]\pixel_x[6]_0 ;
  wire [0:0]\pixel_x[7] ;
  wire [0:0]\pixel_x[7]_0 ;
  wire [11:0]pixel_y;
  wire [0:0]\pixel_y[1] ;
  wire [0:0]\pixel_y[1]_0 ;
  wire [0:0]\pixel_y[1]_1 ;
  wire [0:0]\pixel_y[1]_10 ;
  wire [0:0]\pixel_y[1]_11 ;
  wire [0:0]\pixel_y[1]_12 ;
  wire [0:0]\pixel_y[1]_13 ;
  wire [0:0]\pixel_y[1]_14 ;
  wire [0:0]\pixel_y[1]_15 ;
  wire [0:0]\pixel_y[1]_16 ;
  wire [0:0]\pixel_y[1]_17 ;
  wire [0:0]\pixel_y[1]_18 ;
  wire [0:0]\pixel_y[1]_19 ;
  wire [0:0]\pixel_y[1]_2 ;
  wire [0:0]\pixel_y[1]_20 ;
  wire [0:0]\pixel_y[1]_21 ;
  wire [0:0]\pixel_y[1]_22 ;
  wire [0:0]\pixel_y[1]_23 ;
  wire [0:0]\pixel_y[1]_24 ;
  wire [0:0]\pixel_y[1]_25 ;
  wire [0:0]\pixel_y[1]_26 ;
  wire [0:0]\pixel_y[1]_3 ;
  wire [0:0]\pixel_y[1]_4 ;
  wire [0:0]\pixel_y[1]_5 ;
  wire [0:0]\pixel_y[1]_6 ;
  wire [0:0]\pixel_y[1]_7 ;
  wire [0:0]\pixel_y[1]_8 ;
  wire [0:0]\pixel_y[1]_9 ;
  wire [0:0]\pixel_y[2] ;
  wire [0:0]\pixel_y[2]_0 ;
  wire [0:0]\pixel_y[2]_1 ;
  wire [0:0]\pixel_y[2]_10 ;
  wire [0:0]\pixel_y[2]_11 ;
  wire [0:0]\pixel_y[2]_12 ;
  wire [0:0]\pixel_y[2]_13 ;
  wire [0:0]\pixel_y[2]_14 ;
  wire [0:0]\pixel_y[2]_15 ;
  wire [0:0]\pixel_y[2]_16 ;
  wire [0:0]\pixel_y[2]_2 ;
  wire [0:0]\pixel_y[2]_3 ;
  wire [0:0]\pixel_y[2]_4 ;
  wire [0:0]\pixel_y[2]_5 ;
  wire [0:0]\pixel_y[2]_6 ;
  wire [0:0]\pixel_y[2]_7 ;
  wire [0:0]\pixel_y[2]_8 ;
  wire [0:0]\pixel_y[2]_9 ;
  wire [0:0]\pixel_y[5] ;
  wire [0:0]\pixel_y[5]_0 ;
  wire [0:0]\pixel_y[5]_1 ;
  wire [0:0]\pixel_y[5]_10 ;
  wire [0:0]\pixel_y[5]_11 ;
  wire [0:0]\pixel_y[5]_2 ;
  wire [0:0]\pixel_y[5]_3 ;
  wire [0:0]\pixel_y[5]_4 ;
  wire [0:0]\pixel_y[5]_5 ;
  wire [0:0]\pixel_y[5]_6 ;
  wire [0:0]\pixel_y[5]_7 ;
  wire [0:0]\pixel_y[5]_8 ;
  wire [0:0]\pixel_y[5]_9 ;
  wire record_diz;
  wire [3:0]record_personnel;
  wire reset;
  wire [23:0]rgb_in;
  wire [23:0]rgb_out;
  wire \rgb_out[0]_i_3_n_0 ;
  wire \rgb_out[10]_i_2_n_0 ;
  wire \rgb_out[10]_i_3_n_0 ;
  wire \rgb_out[10]_i_5_n_0 ;
  wire \rgb_out[11]_i_10_n_0 ;
  wire \rgb_out[11]_i_11_n_0 ;
  wire \rgb_out[11]_i_12_n_0 ;
  wire \rgb_out[11]_i_13_n_0 ;
  wire \rgb_out[11]_i_14_n_0 ;
  wire \rgb_out[11]_i_15_n_0 ;
  wire \rgb_out[11]_i_16_n_0 ;
  wire \rgb_out[11]_i_17_n_0 ;
  wire \rgb_out[11]_i_18_n_0 ;
  wire \rgb_out[11]_i_19_n_0 ;
  wire \rgb_out[11]_i_20_n_0 ;
  wire \rgb_out[11]_i_21_n_0 ;
  wire \rgb_out[11]_i_22_n_0 ;
  wire \rgb_out[11]_i_23_n_0 ;
  wire \rgb_out[11]_i_24_n_0 ;
  wire \rgb_out[11]_i_25_n_0 ;
  wire \rgb_out[11]_i_26_n_0 ;
  wire \rgb_out[11]_i_27_n_0 ;
  wire \rgb_out[11]_i_28_n_0 ;
  wire \rgb_out[11]_i_29_n_0 ;
  wire \rgb_out[11]_i_30_n_0 ;
  wire \rgb_out[11]_i_31_n_0 ;
  wire \rgb_out[11]_i_32_n_0 ;
  wire \rgb_out[11]_i_33_n_0 ;
  wire \rgb_out[11]_i_34_n_0 ;
  wire \rgb_out[11]_i_35_n_0 ;
  wire \rgb_out[11]_i_3_n_0 ;
  wire \rgb_out[11]_i_4_n_0 ;
  wire \rgb_out[11]_i_5_n_0 ;
  wire \rgb_out[11]_i_6_n_0 ;
  wire \rgb_out[11]_i_7_n_0 ;
  wire \rgb_out[11]_i_8_n_0 ;
  wire \rgb_out[11]_i_9_n_0 ;
  wire \rgb_out[12]_i_2_n_0 ;
  wire \rgb_out[12]_i_3_n_0 ;
  wire \rgb_out[12]_i_4_n_0 ;
  wire \rgb_out[13]_i_3_n_0 ;
  wire \rgb_out[13]_i_4_n_0 ;
  wire \rgb_out[13]_i_5_n_0 ;
  wire \rgb_out[14]_i_2_n_0 ;
  wire \rgb_out[14]_i_3_n_0 ;
  wire \rgb_out[14]_i_4_n_0 ;
  wire \rgb_out[14]_i_5_n_0 ;
  wire \rgb_out[15]_i_2_n_0 ;
  wire \rgb_out[15]_i_3_n_0 ;
  wire \rgb_out[15]_i_4_n_0 ;
  wire \rgb_out[15]_i_5_n_0 ;
  wire \rgb_out[16]_i_2_n_0 ;
  wire \rgb_out[16]_i_3_n_0 ;
  wire \rgb_out[16]_i_4_n_0 ;
  wire \rgb_out[16]_i_5_n_0 ;
  wire \rgb_out[17]_i_2_n_0 ;
  wire \rgb_out[17]_i_3_n_0 ;
  wire \rgb_out[17]_i_4_n_0 ;
  wire \rgb_out[17]_i_5_n_0 ;
  wire \rgb_out[17]_i_6_n_0 ;
  wire \rgb_out[17]_i_7_n_0 ;
  wire \rgb_out[18]_i_2_n_0 ;
  wire \rgb_out[18]_i_3_n_0 ;
  wire \rgb_out[18]_i_4_n_0 ;
  wire \rgb_out[19]_i_2_n_0 ;
  wire \rgb_out[19]_i_3_n_0 ;
  wire \rgb_out[19]_i_4_n_0 ;
  wire \rgb_out[1]_i_2_n_0 ;
  wire \rgb_out[1]_i_3_n_0 ;
  wire \rgb_out[1]_i_4_n_0 ;
  wire \rgb_out[1]_i_5_n_0 ;
  wire \rgb_out[20]_i_10_n_0 ;
  wire \rgb_out[20]_i_11_n_0 ;
  wire \rgb_out[20]_i_12_n_0 ;
  wire \rgb_out[20]_i_13_n_0 ;
  wire \rgb_out[20]_i_14_n_0 ;
  wire \rgb_out[20]_i_15_n_0 ;
  wire \rgb_out[20]_i_16_n_0 ;
  wire \rgb_out[20]_i_17_n_0 ;
  wire \rgb_out[20]_i_18_n_0 ;
  wire \rgb_out[20]_i_19_n_0 ;
  wire \rgb_out[20]_i_20_n_0 ;
  wire \rgb_out[20]_i_21_n_0 ;
  wire \rgb_out[20]_i_22_n_0 ;
  wire \rgb_out[20]_i_23_n_0 ;
  wire \rgb_out[20]_i_24_n_0 ;
  wire \rgb_out[20]_i_25_n_0 ;
  wire \rgb_out[20]_i_26_n_0 ;
  wire \rgb_out[20]_i_27_n_0 ;
  wire \rgb_out[20]_i_28_n_0 ;
  wire \rgb_out[20]_i_29_n_0 ;
  wire \rgb_out[20]_i_2_n_0 ;
  wire \rgb_out[20]_i_30_n_0 ;
  wire \rgb_out[20]_i_31_n_0 ;
  wire \rgb_out[20]_i_3_n_0 ;
  wire \rgb_out[20]_i_5_n_0 ;
  wire \rgb_out[20]_i_6_n_0 ;
  wire \rgb_out[20]_i_7_n_0 ;
  wire \rgb_out[20]_i_8_n_0 ;
  wire \rgb_out[20]_i_9_n_0 ;
  wire \rgb_out[21]_i_2_n_0 ;
  wire \rgb_out[21]_i_4_n_0 ;
  wire \rgb_out[21]_i_5_n_0 ;
  wire \rgb_out[21]_i_6_n_0 ;
  wire \rgb_out[21]_i_7_n_0 ;
  wire \rgb_out[22]_i_2_n_0 ;
  wire \rgb_out[22]_i_3_n_0 ;
  wire \rgb_out[23]_i_100_n_0 ;
  wire \rgb_out[23]_i_101_n_0 ;
  wire \rgb_out[23]_i_102_n_0 ;
  wire \rgb_out[23]_i_103_n_0 ;
  wire \rgb_out[23]_i_108_n_0 ;
  wire \rgb_out[23]_i_109_n_0 ;
  wire \rgb_out[23]_i_10_n_0 ;
  wire \rgb_out[23]_i_110_n_0 ;
  wire \rgb_out[23]_i_111_n_0 ;
  wire \rgb_out[23]_i_112_n_0 ;
  wire \rgb_out[23]_i_113_n_0 ;
  wire \rgb_out[23]_i_114_n_0 ;
  wire \rgb_out[23]_i_115_n_0 ;
  wire \rgb_out[23]_i_116_n_0 ;
  wire \rgb_out[23]_i_117_n_0 ;
  wire \rgb_out[23]_i_118_n_0 ;
  wire \rgb_out[23]_i_119_n_0 ;
  wire \rgb_out[23]_i_11_n_0 ;
  wire \rgb_out[23]_i_1206_n_0 ;
  wire \rgb_out[23]_i_1207_n_0 ;
  wire \rgb_out[23]_i_1208_n_0 ;
  wire \rgb_out[23]_i_1209_n_0 ;
  wire \rgb_out[23]_i_120_n_0 ;
  wire \rgb_out[23]_i_1210_n_0 ;
  wire \rgb_out[23]_i_121_n_0 ;
  wire \rgb_out[23]_i_122_n_0 ;
  wire \rgb_out[23]_i_123_n_0 ;
  wire \rgb_out[23]_i_124_n_0 ;
  wire \rgb_out[23]_i_1254_n_0 ;
  wire \rgb_out[23]_i_1255_n_0 ;
  wire \rgb_out[23]_i_1256_n_0 ;
  wire \rgb_out[23]_i_1257_n_0 ;
  wire \rgb_out[23]_i_125_n_0 ;
  wire \rgb_out[23]_i_126_n_0 ;
  wire \rgb_out[23]_i_127_n_0 ;
  wire \rgb_out[23]_i_128_n_0 ;
  wire \rgb_out[23]_i_129_n_0 ;
  wire \rgb_out[23]_i_12_n_0 ;
  wire \rgb_out[23]_i_1309_n_0 ;
  wire \rgb_out[23]_i_130_n_0 ;
  wire \rgb_out[23]_i_1310_n_0 ;
  wire \rgb_out[23]_i_1311_n_0 ;
  wire \rgb_out[23]_i_1312_n_0 ;
  wire \rgb_out[23]_i_1318_n_0 ;
  wire \rgb_out[23]_i_1319_n_0 ;
  wire \rgb_out[23]_i_131_n_0 ;
  wire \rgb_out[23]_i_1320_n_0 ;
  wire \rgb_out[23]_i_1321_n_0 ;
  wire \rgb_out[23]_i_1323_n_0 ;
  wire \rgb_out[23]_i_1324_n_0 ;
  wire \rgb_out[23]_i_1325_n_0 ;
  wire \rgb_out[23]_i_132_n_0 ;
  wire \rgb_out[23]_i_1332_n_0 ;
  wire \rgb_out[23]_i_1333_n_0 ;
  wire \rgb_out[23]_i_1334_n_0 ;
  wire \rgb_out[23]_i_133_n_0 ;
  wire \rgb_out[23]_i_134_n_0 ;
  wire \rgb_out[23]_i_135_n_0 ;
  wire \rgb_out[23]_i_136_n_0 ;
  wire \rgb_out[23]_i_137_n_0 ;
  wire \rgb_out[23]_i_1382_n_0 ;
  wire \rgb_out[23]_i_1383_n_0 ;
  wire \rgb_out[23]_i_1384_n_0 ;
  wire \rgb_out[23]_i_1385_n_0 ;
  wire \rgb_out[23]_i_1386_n_0 ;
  wire \rgb_out[23]_i_1387_n_0 ;
  wire \rgb_out[23]_i_1388_n_0 ;
  wire \rgb_out[23]_i_138_n_0 ;
  wire \rgb_out[23]_i_139_n_0 ;
  wire \rgb_out[23]_i_13_n_0 ;
  wire \rgb_out[23]_i_140_n_0 ;
  wire \rgb_out[23]_i_141_n_0 ;
  wire \rgb_out[23]_i_142_n_0 ;
  wire \rgb_out[23]_i_143_n_0 ;
  wire \rgb_out[23]_i_144_n_0 ;
  wire \rgb_out[23]_i_145_n_0 ;
  wire \rgb_out[23]_i_146_n_0 ;
  wire \rgb_out[23]_i_147_n_0 ;
  wire \rgb_out[23]_i_148_n_0 ;
  wire \rgb_out[23]_i_149_n_0 ;
  wire \rgb_out[23]_i_14_n_0 ;
  wire \rgb_out[23]_i_150_n_0 ;
  wire \rgb_out[23]_i_151_n_0 ;
  wire \rgb_out[23]_i_152_n_0 ;
  wire \rgb_out[23]_i_153_n_0 ;
  wire \rgb_out[23]_i_154_n_0 ;
  wire \rgb_out[23]_i_155_n_0 ;
  wire \rgb_out[23]_i_156_n_0 ;
  wire \rgb_out[23]_i_157_n_0 ;
  wire \rgb_out[23]_i_158_n_0 ;
  wire \rgb_out[23]_i_159_n_0 ;
  wire \rgb_out[23]_i_15_n_0 ;
  wire \rgb_out[23]_i_160_n_0 ;
  wire \rgb_out[23]_i_161_n_0 ;
  wire \rgb_out[23]_i_162_n_0 ;
  wire \rgb_out[23]_i_163_n_0 ;
  wire \rgb_out[23]_i_164_n_0 ;
  wire \rgb_out[23]_i_165_n_0 ;
  wire \rgb_out[23]_i_168_n_0 ;
  wire \rgb_out[23]_i_169_n_0 ;
  wire \rgb_out[23]_i_16_n_0 ;
  wire \rgb_out[23]_i_170_n_0 ;
  wire \rgb_out[23]_i_171_n_0 ;
  wire \rgb_out[23]_i_172_n_0 ;
  wire \rgb_out[23]_i_173_n_0 ;
  wire \rgb_out[23]_i_174_n_0 ;
  wire \rgb_out[23]_i_175_n_0 ;
  wire \rgb_out[23]_i_176_n_0 ;
  wire \rgb_out[23]_i_177_n_0 ;
  wire \rgb_out[23]_i_178_n_0 ;
  wire \rgb_out[23]_i_179_n_0 ;
  wire \rgb_out[23]_i_180_n_0 ;
  wire \rgb_out[23]_i_181_n_0 ;
  wire \rgb_out[23]_i_182_n_0 ;
  wire \rgb_out[23]_i_183_n_0 ;
  wire \rgb_out[23]_i_184_n_0 ;
  wire \rgb_out[23]_i_185_n_0 ;
  wire \rgb_out[23]_i_186_n_0 ;
  wire \rgb_out[23]_i_187_n_0 ;
  wire \rgb_out[23]_i_188_n_0 ;
  wire \rgb_out[23]_i_190_n_0 ;
  wire \rgb_out[23]_i_1928_n_0 ;
  wire \rgb_out[23]_i_1929_n_0 ;
  wire \rgb_out[23]_i_192_n_0 ;
  wire \rgb_out[23]_i_1930_n_0 ;
  wire \rgb_out[23]_i_1931_n_0 ;
  wire \rgb_out[23]_i_1932_n_0 ;
  wire \rgb_out[23]_i_1933_n_0 ;
  wire \rgb_out[23]_i_1934_n_0 ;
  wire \rgb_out[23]_i_195_n_0 ;
  wire \rgb_out[23]_i_196_n_0 ;
  wire \rgb_out[23]_i_1999_n_0 ;
  wire \rgb_out[23]_i_199_n_0 ;
  wire \rgb_out[23]_i_19_n_0 ;
  wire \rgb_out[23]_i_1_n_0 ;
  wire \rgb_out[23]_i_2000_n_0 ;
  wire \rgb_out[23]_i_2001_n_0 ;
  wire \rgb_out[23]_i_2009_n_0 ;
  wire \rgb_out[23]_i_200_n_0 ;
  wire \rgb_out[23]_i_2010_n_0 ;
  wire \rgb_out[23]_i_2012_n_0 ;
  wire \rgb_out[23]_i_2013_n_0 ;
  wire \rgb_out[23]_i_2014_n_0 ;
  wire \rgb_out[23]_i_2015_n_0 ;
  wire \rgb_out[23]_i_2016_n_0 ;
  wire \rgb_out[23]_i_2024_n_0 ;
  wire \rgb_out[23]_i_2025_n_0 ;
  wire \rgb_out[23]_i_2026_n_0 ;
  wire \rgb_out[23]_i_2027_n_0 ;
  wire \rgb_out[23]_i_2028_n_0 ;
  wire \rgb_out[23]_i_2029_n_0 ;
  wire \rgb_out[23]_i_202_n_0 ;
  wire \rgb_out[23]_i_2030_n_0 ;
  wire \rgb_out[23]_i_2031_n_0 ;
  wire \rgb_out[23]_i_2032_n_0 ;
  wire \rgb_out[23]_i_2033_n_0 ;
  wire \rgb_out[23]_i_2034_n_0 ;
  wire \rgb_out[23]_i_2035_n_0 ;
  wire \rgb_out[23]_i_2036_n_0 ;
  wire \rgb_out[23]_i_2037_n_0 ;
  wire \rgb_out[23]_i_203_n_0 ;
  wire \rgb_out[23]_i_2044_n_0 ;
  wire \rgb_out[23]_i_2045_n_0 ;
  wire \rgb_out[23]_i_2046_n_0 ;
  wire \rgb_out[23]_i_2047_n_0 ;
  wire \rgb_out[23]_i_2048_n_0 ;
  wire \rgb_out[23]_i_2049_n_0 ;
  wire \rgb_out[23]_i_204_n_0 ;
  wire \rgb_out[23]_i_2050_n_0 ;
  wire \rgb_out[23]_i_205_n_0 ;
  wire \rgb_out[23]_i_206_n_0 ;
  wire \rgb_out[23]_i_207_n_0 ;
  wire \rgb_out[23]_i_208_n_0 ;
  wire \rgb_out[23]_i_209_n_0 ;
  wire \rgb_out[23]_i_20_n_0 ;
  wire \rgb_out[23]_i_210_n_0 ;
  wire \rgb_out[23]_i_211_n_0 ;
  wire \rgb_out[23]_i_2125_n_0 ;
  wire \rgb_out[23]_i_2126_n_0 ;
  wire \rgb_out[23]_i_2127_n_0 ;
  wire \rgb_out[23]_i_2128_n_0 ;
  wire \rgb_out[23]_i_2129_n_0 ;
  wire \rgb_out[23]_i_212_n_0 ;
  wire \rgb_out[23]_i_2130_n_0 ;
  wire \rgb_out[23]_i_213_n_0 ;
  wire \rgb_out[23]_i_214_n_0 ;
  wire \rgb_out[23]_i_215_n_0 ;
  wire \rgb_out[23]_i_217_n_0 ;
  wire \rgb_out[23]_i_218_n_0 ;
  wire \rgb_out[23]_i_219_n_0 ;
  wire \rgb_out[23]_i_21_n_0 ;
  wire \rgb_out[23]_i_220_n_0 ;
  wire \rgb_out[23]_i_221_n_0 ;
  wire \rgb_out[23]_i_222_n_0 ;
  wire \rgb_out[23]_i_223_n_0 ;
  wire \rgb_out[23]_i_224_n_0 ;
  wire \rgb_out[23]_i_225_n_0 ;
  wire \rgb_out[23]_i_226_n_0 ;
  wire \rgb_out[23]_i_227_n_0 ;
  wire \rgb_out[23]_i_228_n_0 ;
  wire \rgb_out[23]_i_229_n_0 ;
  wire \rgb_out[23]_i_22_n_0 ;
  wire \rgb_out[23]_i_230_n_0 ;
  wire \rgb_out[23]_i_231_n_0 ;
  wire \rgb_out[23]_i_232_n_0 ;
  wire \rgb_out[23]_i_233_n_0 ;
  wire \rgb_out[23]_i_234_n_0 ;
  wire \rgb_out[23]_i_235_n_0 ;
  wire \rgb_out[23]_i_236_n_0 ;
  wire \rgb_out[23]_i_237_n_0 ;
  wire \rgb_out[23]_i_238_n_0 ;
  wire \rgb_out[23]_i_239_n_0 ;
  wire \rgb_out[23]_i_23_n_0 ;
  wire \rgb_out[23]_i_240_n_0 ;
  wire \rgb_out[23]_i_241_n_0 ;
  wire \rgb_out[23]_i_242_n_0 ;
  wire \rgb_out[23]_i_243_n_0 ;
  wire \rgb_out[23]_i_244_n_0 ;
  wire \rgb_out[23]_i_245_n_0 ;
  wire \rgb_out[23]_i_246_n_0 ;
  wire \rgb_out[23]_i_247_n_0 ;
  wire \rgb_out[23]_i_248_n_0 ;
  wire \rgb_out[23]_i_249_n_0 ;
  wire \rgb_out[23]_i_24_n_0 ;
  wire \rgb_out[23]_i_250_n_0 ;
  wire \rgb_out[23]_i_251_n_0 ;
  wire \rgb_out[23]_i_252_n_0 ;
  wire \rgb_out[23]_i_253_n_0 ;
  wire \rgb_out[23]_i_254_n_0 ;
  wire \rgb_out[23]_i_255_n_0 ;
  wire \rgb_out[23]_i_256_n_0 ;
  wire \rgb_out[23]_i_257_n_0 ;
  wire \rgb_out[23]_i_258_n_0 ;
  wire \rgb_out[23]_i_259_n_0 ;
  wire \rgb_out[23]_i_25_n_0 ;
  wire \rgb_out[23]_i_260_n_0 ;
  wire \rgb_out[23]_i_261_n_0 ;
  wire \rgb_out[23]_i_262_n_0 ;
  wire \rgb_out[23]_i_263_n_0 ;
  wire \rgb_out[23]_i_264_n_0 ;
  wire \rgb_out[23]_i_265_n_0 ;
  wire \rgb_out[23]_i_266_n_0 ;
  wire \rgb_out[23]_i_267_n_0 ;
  wire \rgb_out[23]_i_268_n_0 ;
  wire \rgb_out[23]_i_269_n_0 ;
  wire \rgb_out[23]_i_26_n_0 ;
  wire \rgb_out[23]_i_270_n_0 ;
  wire \rgb_out[23]_i_271_n_0 ;
  wire \rgb_out[23]_i_272_n_0 ;
  wire \rgb_out[23]_i_273_n_0 ;
  wire \rgb_out[23]_i_274_n_0 ;
  wire \rgb_out[23]_i_275_n_0 ;
  wire \rgb_out[23]_i_276_n_0 ;
  wire \rgb_out[23]_i_277_n_0 ;
  wire \rgb_out[23]_i_278_n_0 ;
  wire \rgb_out[23]_i_279_n_0 ;
  wire \rgb_out[23]_i_27_n_0 ;
  wire \rgb_out[23]_i_280_n_0 ;
  wire \rgb_out[23]_i_281_n_0 ;
  wire \rgb_out[23]_i_282_n_0 ;
  wire \rgb_out[23]_i_283_n_0 ;
  wire \rgb_out[23]_i_284_n_0 ;
  wire \rgb_out[23]_i_285_n_0 ;
  wire \rgb_out[23]_i_286_n_0 ;
  wire \rgb_out[23]_i_287_n_0 ;
  wire \rgb_out[23]_i_288_n_0 ;
  wire \rgb_out[23]_i_289_n_0 ;
  wire \rgb_out[23]_i_28_n_0 ;
  wire \rgb_out[23]_i_290_n_0 ;
  wire \rgb_out[23]_i_291_n_0 ;
  wire \rgb_out[23]_i_292_n_0 ;
  wire \rgb_out[23]_i_293_n_0 ;
  wire \rgb_out[23]_i_294_n_0 ;
  wire \rgb_out[23]_i_295_n_0 ;
  wire \rgb_out[23]_i_296_n_0 ;
  wire \rgb_out[23]_i_297_n_0 ;
  wire \rgb_out[23]_i_298_n_0 ;
  wire \rgb_out[23]_i_299_n_0 ;
  wire \rgb_out[23]_i_29_n_0 ;
  wire \rgb_out[23]_i_300_n_0 ;
  wire \rgb_out[23]_i_301_n_0 ;
  wire \rgb_out[23]_i_302_n_0 ;
  wire \rgb_out[23]_i_303_n_0 ;
  wire \rgb_out[23]_i_304_n_0 ;
  wire \rgb_out[23]_i_305_n_0 ;
  wire \rgb_out[23]_i_306_n_0 ;
  wire \rgb_out[23]_i_307_n_0 ;
  wire \rgb_out[23]_i_308_n_0 ;
  wire \rgb_out[23]_i_309_n_0 ;
  wire \rgb_out[23]_i_30_n_0 ;
  wire \rgb_out[23]_i_310_n_0 ;
  wire \rgb_out[23]_i_314_n_0 ;
  wire \rgb_out[23]_i_315_n_0 ;
  wire \rgb_out[23]_i_316_n_0 ;
  wire \rgb_out[23]_i_317_n_0 ;
  wire \rgb_out[23]_i_318_n_0 ;
  wire \rgb_out[23]_i_319_n_0 ;
  wire \rgb_out[23]_i_31_n_0 ;
  wire \rgb_out[23]_i_320_n_0 ;
  wire \rgb_out[23]_i_321_n_0 ;
  wire \rgb_out[23]_i_322_n_0 ;
  wire \rgb_out[23]_i_323_n_0 ;
  wire \rgb_out[23]_i_324_n_0 ;
  wire \rgb_out[23]_i_325_n_0 ;
  wire \rgb_out[23]_i_326_n_0 ;
  wire \rgb_out[23]_i_327_n_0 ;
  wire \rgb_out[23]_i_328_n_0 ;
  wire \rgb_out[23]_i_32_n_0 ;
  wire \rgb_out[23]_i_332_n_0 ;
  wire \rgb_out[23]_i_333_n_0 ;
  wire \rgb_out[23]_i_334_n_0 ;
  wire \rgb_out[23]_i_335_n_0 ;
  wire \rgb_out[23]_i_336_n_0 ;
  wire \rgb_out[23]_i_337_n_0 ;
  wire \rgb_out[23]_i_338_n_0 ;
  wire \rgb_out[23]_i_339_n_0 ;
  wire \rgb_out[23]_i_33_n_0 ;
  wire \rgb_out[23]_i_340_n_0 ;
  wire \rgb_out[23]_i_341_n_0 ;
  wire \rgb_out[23]_i_342_n_0 ;
  wire \rgb_out[23]_i_343_n_0 ;
  wire \rgb_out[23]_i_344_n_0 ;
  wire \rgb_out[23]_i_345_n_0 ;
  wire \rgb_out[23]_i_346_n_0 ;
  wire \rgb_out[23]_i_347_n_0 ;
  wire \rgb_out[23]_i_348_n_0 ;
  wire \rgb_out[23]_i_349_n_0 ;
  wire \rgb_out[23]_i_34_n_0 ;
  wire \rgb_out[23]_i_350_n_0 ;
  wire \rgb_out[23]_i_351_n_0 ;
  wire \rgb_out[23]_i_352_n_0 ;
  wire \rgb_out[23]_i_353_n_0 ;
  wire \rgb_out[23]_i_354_n_0 ;
  wire \rgb_out[23]_i_355_n_0 ;
  wire \rgb_out[23]_i_356_n_0 ;
  wire \rgb_out[23]_i_357_n_0 ;
  wire \rgb_out[23]_i_358_n_0 ;
  wire \rgb_out[23]_i_359_n_0 ;
  wire \rgb_out[23]_i_35_n_0 ;
  wire \rgb_out[23]_i_360_n_0 ;
  wire \rgb_out[23]_i_361_n_0 ;
  wire \rgb_out[23]_i_362_n_0 ;
  wire \rgb_out[23]_i_363_n_0 ;
  wire \rgb_out[23]_i_364_n_0 ;
  wire \rgb_out[23]_i_365_n_0 ;
  wire \rgb_out[23]_i_366_n_0 ;
  wire \rgb_out[23]_i_367_n_0 ;
  wire \rgb_out[23]_i_368_n_0 ;
  wire \rgb_out[23]_i_369_n_0 ;
  wire \rgb_out[23]_i_36_n_0 ;
  wire \rgb_out[23]_i_370_n_0 ;
  wire \rgb_out[23]_i_371_n_0 ;
  wire \rgb_out[23]_i_372_n_0 ;
  wire \rgb_out[23]_i_373_n_0 ;
  wire \rgb_out[23]_i_374_n_0 ;
  wire \rgb_out[23]_i_375_n_0 ;
  wire \rgb_out[23]_i_376_n_0 ;
  wire \rgb_out[23]_i_377_n_0 ;
  wire \rgb_out[23]_i_378_n_0 ;
  wire \rgb_out[23]_i_379_n_0 ;
  wire \rgb_out[23]_i_37_n_0 ;
  wire \rgb_out[23]_i_380_n_0 ;
  wire \rgb_out[23]_i_381_n_0 ;
  wire \rgb_out[23]_i_382_n_0 ;
  wire \rgb_out[23]_i_383_n_0 ;
  wire \rgb_out[23]_i_384_n_0 ;
  wire \rgb_out[23]_i_385_n_0 ;
  wire \rgb_out[23]_i_386_n_0 ;
  wire \rgb_out[23]_i_387_n_0 ;
  wire \rgb_out[23]_i_388_n_0 ;
  wire \rgb_out[23]_i_389_n_0 ;
  wire \rgb_out[23]_i_38_n_0 ;
  wire \rgb_out[23]_i_390_n_0 ;
  wire \rgb_out[23]_i_391_n_0 ;
  wire \rgb_out[23]_i_392_n_0 ;
  wire \rgb_out[23]_i_393_n_0 ;
  wire \rgb_out[23]_i_394_n_0 ;
  wire \rgb_out[23]_i_395_n_0 ;
  wire \rgb_out[23]_i_396_n_0 ;
  wire \rgb_out[23]_i_397_n_0 ;
  wire \rgb_out[23]_i_398_n_0 ;
  wire \rgb_out[23]_i_399_n_0 ;
  wire \rgb_out[23]_i_39_n_0 ;
  wire \rgb_out[23]_i_3_n_0 ;
  wire \rgb_out[23]_i_400_n_0 ;
  wire \rgb_out[23]_i_401_n_0 ;
  wire \rgb_out[23]_i_402_n_0 ;
  wire \rgb_out[23]_i_403_n_0 ;
  wire \rgb_out[23]_i_404_n_0 ;
  wire \rgb_out[23]_i_405_n_0 ;
  wire \rgb_out[23]_i_406_n_0 ;
  wire \rgb_out[23]_i_407_n_0 ;
  wire \rgb_out[23]_i_408_n_0 ;
  wire \rgb_out[23]_i_409_n_0 ;
  wire \rgb_out[23]_i_40_n_0 ;
  wire \rgb_out[23]_i_410_n_0 ;
  wire \rgb_out[23]_i_411_n_0 ;
  wire \rgb_out[23]_i_412_n_0 ;
  wire \rgb_out[23]_i_413_n_0 ;
  wire \rgb_out[23]_i_414_n_0 ;
  wire \rgb_out[23]_i_415_n_0 ;
  wire \rgb_out[23]_i_416_n_0 ;
  wire \rgb_out[23]_i_417_n_0 ;
  wire \rgb_out[23]_i_418_n_0 ;
  wire \rgb_out[23]_i_419_n_0 ;
  wire \rgb_out[23]_i_41_n_0 ;
  wire \rgb_out[23]_i_420_n_0 ;
  wire \rgb_out[23]_i_421_n_0 ;
  wire \rgb_out[23]_i_422_n_0 ;
  wire \rgb_out[23]_i_423_n_0 ;
  wire \rgb_out[23]_i_424_n_0 ;
  wire \rgb_out[23]_i_425_n_0 ;
  wire \rgb_out[23]_i_426_n_0 ;
  wire \rgb_out[23]_i_427_n_0 ;
  wire \rgb_out[23]_i_428_n_0 ;
  wire \rgb_out[23]_i_429_n_0 ;
  wire \rgb_out[23]_i_42_n_0 ;
  wire \rgb_out[23]_i_430_n_0 ;
  wire \rgb_out[23]_i_431_n_0 ;
  wire \rgb_out[23]_i_432_n_0 ;
  wire \rgb_out[23]_i_433_n_0 ;
  wire \rgb_out[23]_i_434_n_0 ;
  wire \rgb_out[23]_i_435_n_0 ;
  wire \rgb_out[23]_i_436_n_0 ;
  wire \rgb_out[23]_i_437_n_0 ;
  wire \rgb_out[23]_i_43_n_0 ;
  wire \rgb_out[23]_i_442_n_0 ;
  wire \rgb_out[23]_i_443_n_0 ;
  wire \rgb_out[23]_i_444_n_0 ;
  wire \rgb_out[23]_i_445_n_0 ;
  wire \rgb_out[23]_i_446_n_0 ;
  wire \rgb_out[23]_i_447_n_0 ;
  wire \rgb_out[23]_i_448_n_0 ;
  wire \rgb_out[23]_i_449_n_0 ;
  wire \rgb_out[23]_i_44_n_0 ;
  wire \rgb_out[23]_i_453_n_0 ;
  wire \rgb_out[23]_i_454_n_0 ;
  wire \rgb_out[23]_i_455_n_0 ;
  wire \rgb_out[23]_i_456_n_0 ;
  wire \rgb_out[23]_i_457_n_0 ;
  wire \rgb_out[23]_i_458_n_0 ;
  wire \rgb_out[23]_i_459_n_0 ;
  wire \rgb_out[23]_i_45_n_0 ;
  wire \rgb_out[23]_i_460_n_0 ;
  wire \rgb_out[23]_i_461_n_0 ;
  wire \rgb_out[23]_i_462_n_0 ;
  wire \rgb_out[23]_i_463_n_0 ;
  wire \rgb_out[23]_i_464_n_0 ;
  wire \rgb_out[23]_i_465_n_0 ;
  wire \rgb_out[23]_i_466_n_0 ;
  wire \rgb_out[23]_i_467_n_0 ;
  wire \rgb_out[23]_i_468_n_0 ;
  wire \rgb_out[23]_i_469_n_0 ;
  wire \rgb_out[23]_i_46_n_0 ;
  wire \rgb_out[23]_i_47_n_0 ;
  wire \rgb_out[23]_i_48_n_0 ;
  wire \rgb_out[23]_i_49_n_0 ;
  wire \rgb_out[23]_i_4_n_0 ;
  wire \rgb_out[23]_i_50_n_0 ;
  wire \rgb_out[23]_i_51_n_0 ;
  wire \rgb_out[23]_i_521_n_0 ;
  wire \rgb_out[23]_i_522_n_0 ;
  wire \rgb_out[23]_i_523_n_0 ;
  wire \rgb_out[23]_i_524_n_0 ;
  wire \rgb_out[23]_i_525_n_0 ;
  wire \rgb_out[23]_i_526_n_0 ;
  wire \rgb_out[23]_i_527_n_0 ;
  wire \rgb_out[23]_i_528_n_0 ;
  wire \rgb_out[23]_i_529_n_0 ;
  wire \rgb_out[23]_i_52_n_0 ;
  wire \rgb_out[23]_i_530_n_0 ;
  wire \rgb_out[23]_i_531_n_0 ;
  wire \rgb_out[23]_i_532_n_0 ;
  wire \rgb_out[23]_i_533_n_0 ;
  wire \rgb_out[23]_i_534_n_0 ;
  wire \rgb_out[23]_i_535_n_0 ;
  wire \rgb_out[23]_i_536_n_0 ;
  wire \rgb_out[23]_i_537_n_0 ;
  wire \rgb_out[23]_i_538_n_0 ;
  wire \rgb_out[23]_i_539_n_0 ;
  wire \rgb_out[23]_i_53_n_0 ;
  wire \rgb_out[23]_i_540_n_0 ;
  wire \rgb_out[23]_i_541_n_0 ;
  wire \rgb_out[23]_i_542_n_0 ;
  wire \rgb_out[23]_i_543_n_0 ;
  wire \rgb_out[23]_i_544_n_0 ;
  wire \rgb_out[23]_i_545_n_0 ;
  wire \rgb_out[23]_i_546_n_0 ;
  wire \rgb_out[23]_i_547_n_0 ;
  wire \rgb_out[23]_i_548_n_0 ;
  wire \rgb_out[23]_i_549_n_0 ;
  wire \rgb_out[23]_i_54_n_0 ;
  wire \rgb_out[23]_i_550_n_0 ;
  wire \rgb_out[23]_i_551_n_0 ;
  wire \rgb_out[23]_i_552_n_0 ;
  wire \rgb_out[23]_i_553_n_0 ;
  wire \rgb_out[23]_i_554_n_0 ;
  wire \rgb_out[23]_i_555_n_0 ;
  wire \rgb_out[23]_i_556_n_0 ;
  wire \rgb_out[23]_i_557_n_0 ;
  wire \rgb_out[23]_i_558_n_0 ;
  wire \rgb_out[23]_i_559_n_0 ;
  wire \rgb_out[23]_i_560_n_0 ;
  wire \rgb_out[23]_i_561_n_0 ;
  wire \rgb_out[23]_i_562_n_0 ;
  wire \rgb_out[23]_i_563_n_0 ;
  wire \rgb_out[23]_i_564_n_0 ;
  wire \rgb_out[23]_i_565_n_0 ;
  wire \rgb_out[23]_i_566_n_0 ;
  wire \rgb_out[23]_i_567_n_0 ;
  wire \rgb_out[23]_i_568_n_0 ;
  wire \rgb_out[23]_i_569_n_0 ;
  wire \rgb_out[23]_i_570_n_0 ;
  wire \rgb_out[23]_i_571_n_0 ;
  wire \rgb_out[23]_i_572_n_0 ;
  wire \rgb_out[23]_i_573_n_0 ;
  wire \rgb_out[23]_i_574_n_0 ;
  wire \rgb_out[23]_i_575_n_0 ;
  wire \rgb_out[23]_i_576_n_0 ;
  wire \rgb_out[23]_i_577_n_0 ;
  wire \rgb_out[23]_i_578_n_0 ;
  wire \rgb_out[23]_i_579_n_0 ;
  wire \rgb_out[23]_i_58_n_0 ;
  wire \rgb_out[23]_i_5_n_0 ;
  wire \rgb_out[23]_i_60_n_0 ;
  wire \rgb_out[23]_i_610_n_0 ;
  wire \rgb_out[23]_i_615_n_0 ;
  wire \rgb_out[23]_i_618_n_0 ;
  wire \rgb_out[23]_i_619_n_0 ;
  wire \rgb_out[23]_i_61_n_0 ;
  wire \rgb_out[23]_i_621_n_0 ;
  wire \rgb_out[23]_i_623_n_0 ;
  wire \rgb_out[23]_i_625_n_0 ;
  wire \rgb_out[23]_i_627_n_0 ;
  wire \rgb_out[23]_i_636_n_0 ;
  wire \rgb_out[23]_i_641_n_0 ;
  wire \rgb_out[23]_i_644_n_0 ;
  wire \rgb_out[23]_i_645_n_0 ;
  wire \rgb_out[23]_i_647_n_0 ;
  wire \rgb_out[23]_i_649_n_0 ;
  wire \rgb_out[23]_i_651_n_0 ;
  wire \rgb_out[23]_i_653_n_0 ;
  wire \rgb_out[23]_i_65_n_0 ;
  wire \rgb_out[23]_i_66_n_0 ;
  wire \rgb_out[23]_i_676_n_0 ;
  wire \rgb_out[23]_i_677_n_0 ;
  wire \rgb_out[23]_i_678_n_0 ;
  wire \rgb_out[23]_i_679_n_0 ;
  wire \rgb_out[23]_i_67_n_0 ;
  wire \rgb_out[23]_i_680_n_0 ;
  wire \rgb_out[23]_i_681_n_0 ;
  wire \rgb_out[23]_i_682_n_0 ;
  wire \rgb_out[23]_i_683_n_0 ;
  wire \rgb_out[23]_i_684_n_0 ;
  wire \rgb_out[23]_i_685_n_0 ;
  wire \rgb_out[23]_i_686_n_0 ;
  wire \rgb_out[23]_i_687_n_0 ;
  wire \rgb_out[23]_i_688_n_0 ;
  wire \rgb_out[23]_i_689_n_0 ;
  wire \rgb_out[23]_i_68_n_0 ;
  wire \rgb_out[23]_i_690_n_0 ;
  wire \rgb_out[23]_i_691_n_0 ;
  wire \rgb_out[23]_i_692_n_0 ;
  wire \rgb_out[23]_i_693_n_0 ;
  wire \rgb_out[23]_i_694_n_0 ;
  wire \rgb_out[23]_i_695_n_0 ;
  wire \rgb_out[23]_i_696_n_0 ;
  wire \rgb_out[23]_i_697_n_0 ;
  wire \rgb_out[23]_i_698_n_0 ;
  wire \rgb_out[23]_i_699_n_0 ;
  wire \rgb_out[23]_i_69_n_0 ;
  wire \rgb_out[23]_i_6_n_0 ;
  wire \rgb_out[23]_i_700_n_0 ;
  wire \rgb_out[23]_i_701_n_0 ;
  wire \rgb_out[23]_i_702_n_0 ;
  wire \rgb_out[23]_i_703_n_0 ;
  wire \rgb_out[23]_i_704_n_0 ;
  wire \rgb_out[23]_i_705_n_0 ;
  wire \rgb_out[23]_i_706_n_0 ;
  wire \rgb_out[23]_i_707_n_0 ;
  wire \rgb_out[23]_i_708_n_0 ;
  wire \rgb_out[23]_i_709_n_0 ;
  wire \rgb_out[23]_i_70_n_0 ;
  wire \rgb_out[23]_i_710_n_0 ;
  wire \rgb_out[23]_i_711_n_0 ;
  wire \rgb_out[23]_i_712_n_0 ;
  wire \rgb_out[23]_i_713_n_0 ;
  wire \rgb_out[23]_i_71_n_0 ;
  wire \rgb_out[23]_i_72_n_0 ;
  wire \rgb_out[23]_i_734_n_0 ;
  wire \rgb_out[23]_i_736_n_0 ;
  wire \rgb_out[23]_i_738_n_0 ;
  wire \rgb_out[23]_i_73_n_0 ;
  wire \rgb_out[23]_i_744_n_0 ;
  wire \rgb_out[23]_i_749_n_0 ;
  wire \rgb_out[23]_i_74_n_0 ;
  wire \rgb_out[23]_i_75_n_0 ;
  wire \rgb_out[23]_i_76_n_0 ;
  wire \rgb_out[23]_i_772_n_0 ;
  wire \rgb_out[23]_i_773_n_0 ;
  wire \rgb_out[23]_i_774_n_0 ;
  wire \rgb_out[23]_i_775_n_0 ;
  wire \rgb_out[23]_i_776_n_0 ;
  wire \rgb_out[23]_i_77_n_0 ;
  wire \rgb_out[23]_i_788_n_0 ;
  wire \rgb_out[23]_i_789_n_0 ;
  wire \rgb_out[23]_i_78_n_0 ;
  wire \rgb_out[23]_i_790_n_0 ;
  wire \rgb_out[23]_i_791_n_0 ;
  wire \rgb_out[23]_i_79_n_0 ;
  wire \rgb_out[23]_i_80_n_0 ;
  wire \rgb_out[23]_i_81_n_0 ;
  wire \rgb_out[23]_i_82_n_0 ;
  wire \rgb_out[23]_i_83_n_0 ;
  wire \rgb_out[23]_i_84_n_0 ;
  wire \rgb_out[23]_i_852_n_0 ;
  wire \rgb_out[23]_i_855_n_0 ;
  wire \rgb_out[23]_i_856_n_0 ;
  wire \rgb_out[23]_i_85_n_0 ;
  wire \rgb_out[23]_i_86_n_0 ;
  wire \rgb_out[23]_i_87_n_0 ;
  wire \rgb_out[23]_i_886_n_0 ;
  wire \rgb_out[23]_i_889_n_0 ;
  wire \rgb_out[23]_i_88_n_0 ;
  wire \rgb_out[23]_i_890_n_0 ;
  wire \rgb_out[23]_i_89_n_0 ;
  wire \rgb_out[23]_i_8_n_0 ;
  wire \rgb_out[23]_i_909_n_0 ;
  wire \rgb_out[23]_i_90_n_0 ;
  wire \rgb_out[23]_i_910_n_0 ;
  wire \rgb_out[23]_i_911_n_0 ;
  wire \rgb_out[23]_i_912_n_0 ;
  wire \rgb_out[23]_i_913_n_0 ;
  wire \rgb_out[23]_i_914_n_0 ;
  wire \rgb_out[23]_i_915_n_0 ;
  wire \rgb_out[23]_i_916_n_0 ;
  wire \rgb_out[23]_i_917_n_0 ;
  wire \rgb_out[23]_i_918_n_0 ;
  wire \rgb_out[23]_i_919_n_0 ;
  wire \rgb_out[23]_i_91_n_0 ;
  wire \rgb_out[23]_i_920_n_0 ;
  wire \rgb_out[23]_i_921_n_0 ;
  wire \rgb_out[23]_i_922_n_0 ;
  wire \rgb_out[23]_i_923_n_0 ;
  wire \rgb_out[23]_i_924_n_0 ;
  wire \rgb_out[23]_i_925_n_0 ;
  wire \rgb_out[23]_i_926_n_0 ;
  wire \rgb_out[23]_i_92_n_0 ;
  wire \rgb_out[23]_i_93_n_0 ;
  wire \rgb_out[23]_i_94_n_0 ;
  wire \rgb_out[23]_i_95_n_0 ;
  wire \rgb_out[23]_i_96_n_0 ;
  wire \rgb_out[23]_i_97_n_0 ;
  wire \rgb_out[23]_i_98_n_0 ;
  wire \rgb_out[23]_i_99_n_0 ;
  wire \rgb_out[23]_i_9_n_0 ;
  wire \rgb_out[2]_i_2_n_0 ;
  wire \rgb_out[2]_i_3_n_0 ;
  wire \rgb_out[2]_i_4_n_0 ;
  wire \rgb_out[5]_i_2_n_0 ;
  wire \rgb_out[5]_i_3_n_0 ;
  wire \rgb_out[6]_i_2_n_0 ;
  wire \rgb_out[6]_i_3_n_0 ;
  wire \rgb_out[6]_i_4_n_0 ;
  wire \rgb_out[7]_i_10_n_0 ;
  wire \rgb_out[7]_i_11_n_0 ;
  wire \rgb_out[7]_i_12_n_0 ;
  wire \rgb_out[7]_i_13_n_0 ;
  wire \rgb_out[7]_i_14_n_0 ;
  wire \rgb_out[7]_i_15_n_0 ;
  wire \rgb_out[7]_i_16_n_0 ;
  wire \rgb_out[7]_i_17_n_0 ;
  wire \rgb_out[7]_i_18_n_0 ;
  wire \rgb_out[7]_i_19_n_0 ;
  wire \rgb_out[7]_i_20_n_0 ;
  wire \rgb_out[7]_i_21_n_0 ;
  wire \rgb_out[7]_i_22_n_0 ;
  wire \rgb_out[7]_i_23_n_0 ;
  wire \rgb_out[7]_i_24_n_0 ;
  wire \rgb_out[7]_i_25_n_0 ;
  wire \rgb_out[7]_i_26_n_0 ;
  wire \rgb_out[7]_i_27_n_0 ;
  wire \rgb_out[7]_i_28_n_0 ;
  wire \rgb_out[7]_i_29_n_0 ;
  wire \rgb_out[7]_i_30_n_0 ;
  wire \rgb_out[7]_i_31_n_0 ;
  wire \rgb_out[7]_i_32_n_0 ;
  wire \rgb_out[7]_i_33_n_0 ;
  wire \rgb_out[7]_i_34_n_0 ;
  wire \rgb_out[7]_i_35_n_0 ;
  wire \rgb_out[7]_i_36_n_0 ;
  wire \rgb_out[7]_i_37_n_0 ;
  wire \rgb_out[7]_i_38_n_0 ;
  wire \rgb_out[7]_i_39_n_0 ;
  wire \rgb_out[7]_i_40_n_0 ;
  wire \rgb_out[7]_i_41_n_0 ;
  wire \rgb_out[7]_i_42_n_0 ;
  wire \rgb_out[7]_i_43_n_0 ;
  wire \rgb_out[7]_i_44_n_0 ;
  wire \rgb_out[7]_i_45_n_0 ;
  wire \rgb_out[7]_i_46_n_0 ;
  wire \rgb_out[7]_i_47_n_0 ;
  wire \rgb_out[7]_i_48_n_0 ;
  wire \rgb_out[7]_i_49_n_0 ;
  wire \rgb_out[7]_i_4_n_0 ;
  wire \rgb_out[7]_i_50_n_0 ;
  wire \rgb_out[7]_i_51_n_0 ;
  wire \rgb_out[7]_i_52_n_0 ;
  wire \rgb_out[7]_i_53_n_0 ;
  wire \rgb_out[7]_i_54_n_0 ;
  wire \rgb_out[7]_i_55_n_0 ;
  wire \rgb_out[7]_i_56_n_0 ;
  wire \rgb_out[7]_i_57_n_0 ;
  wire \rgb_out[7]_i_58_n_0 ;
  wire \rgb_out[7]_i_59_n_0 ;
  wire \rgb_out[7]_i_5_n_0 ;
  wire \rgb_out[7]_i_60_n_0 ;
  wire \rgb_out[7]_i_61_n_0 ;
  wire \rgb_out[7]_i_62_n_0 ;
  wire \rgb_out[7]_i_63_n_0 ;
  wire \rgb_out[7]_i_64_n_0 ;
  wire \rgb_out[7]_i_65_n_0 ;
  wire \rgb_out[7]_i_66_n_0 ;
  wire \rgb_out[7]_i_67_n_0 ;
  wire \rgb_out[7]_i_68_n_0 ;
  wire \rgb_out[7]_i_69_n_0 ;
  wire \rgb_out[7]_i_6_n_0 ;
  wire \rgb_out[7]_i_70_n_0 ;
  wire \rgb_out[7]_i_71_n_0 ;
  wire \rgb_out[7]_i_72_n_0 ;
  wire \rgb_out[7]_i_73_n_0 ;
  wire \rgb_out[7]_i_74_n_0 ;
  wire \rgb_out[7]_i_75_n_0 ;
  wire \rgb_out[7]_i_76_n_0 ;
  wire \rgb_out[7]_i_77_n_0 ;
  wire \rgb_out[7]_i_78_n_0 ;
  wire \rgb_out[7]_i_79_n_0 ;
  wire \rgb_out[7]_i_7_n_0 ;
  wire \rgb_out[7]_i_80_n_0 ;
  wire \rgb_out[7]_i_81_n_0 ;
  wire \rgb_out[7]_i_82_n_0 ;
  wire \rgb_out[7]_i_83_n_0 ;
  wire \rgb_out[7]_i_84_n_0 ;
  wire \rgb_out[7]_i_85_n_0 ;
  wire \rgb_out[7]_i_8_n_0 ;
  wire \rgb_out[7]_i_9_n_0 ;
  wire \rgb_out[8]_i_2_n_0 ;
  wire \rgb_out[8]_i_3_n_0 ;
  wire \rgb_out[8]_i_4_n_0 ;
  wire [0:0]\rgb_out_reg[0]_0 ;
  wire \rgb_out_reg[23]_i_1253_n_0 ;
  wire \rgb_out_reg[23]_i_1253_n_1 ;
  wire \rgb_out_reg[23]_i_1253_n_2 ;
  wire \rgb_out_reg[23]_i_1253_n_3 ;
  wire \rgb_out_reg[23]_i_1300_n_2 ;
  wire \rgb_out_reg[23]_i_1300_n_3 ;
  wire \rgb_out_reg[23]_i_1308_n_0 ;
  wire \rgb_out_reg[23]_i_1308_n_1 ;
  wire \rgb_out_reg[23]_i_1308_n_2 ;
  wire \rgb_out_reg[23]_i_1308_n_3 ;
  wire \rgb_out_reg[23]_i_1317_n_0 ;
  wire \rgb_out_reg[23]_i_1317_n_1 ;
  wire \rgb_out_reg[23]_i_1317_n_2 ;
  wire \rgb_out_reg[23]_i_1317_n_3 ;
  wire \rgb_out_reg[23]_i_1322_n_0 ;
  wire \rgb_out_reg[23]_i_1322_n_1 ;
  wire \rgb_out_reg[23]_i_1322_n_2 ;
  wire \rgb_out_reg[23]_i_1322_n_3 ;
  wire \rgb_out_reg[23]_i_1331_n_0 ;
  wire \rgb_out_reg[23]_i_1331_n_1 ;
  wire \rgb_out_reg[23]_i_1331_n_2 ;
  wire \rgb_out_reg[23]_i_1331_n_3 ;
  wire \rgb_out_reg[23]_i_1998_n_0 ;
  wire \rgb_out_reg[23]_i_1998_n_1 ;
  wire \rgb_out_reg[23]_i_1998_n_2 ;
  wire \rgb_out_reg[23]_i_1998_n_3 ;
  wire \rgb_out_reg[23]_i_2003_n_0 ;
  wire \rgb_out_reg[23]_i_2003_n_1 ;
  wire \rgb_out_reg[23]_i_2003_n_2 ;
  wire \rgb_out_reg[23]_i_2003_n_3 ;
  wire \rgb_out_reg[23]_i_472_n_2 ;
  wire \rgb_out_reg[23]_i_472_n_3 ;
  wire \rgb_out_reg[23]_i_733_n_2 ;
  wire \rgb_out_reg[23]_i_733_n_3 ;
  wire \rgb_out_reg[23]_i_752_n_2 ;
  wire \rgb_out_reg[23]_i_752_n_3 ;
  wire \rgb_out_reg[23]_i_754_n_2 ;
  wire \rgb_out_reg[23]_i_754_n_3 ;
  wire \rgb_out_reg[23]_i_755_n_2 ;
  wire \rgb_out_reg[23]_i_755_n_3 ;
  wire \rgb_out_reg[23]_i_757_n_2 ;
  wire \rgb_out_reg[23]_i_757_n_3 ;
  wire \rgb_out_reg[23]_i_787_n_0 ;
  wire \rgb_out_reg[23]_i_787_n_1 ;
  wire \rgb_out_reg[23]_i_787_n_2 ;
  wire \rgb_out_reg[23]_i_787_n_3 ;
  wire [3:0]score_courant;
  wire [3:0]score_dernier;
  wire score_diz;
  wire [3:0]temps_restant;
  wire vsync_in;
  wire vsync_out;
  wire vsync_out_i_1_n_0;
  wire [3:0]\NLW_rgb_out_reg[23]_i_1253_O_UNCONNECTED ;
  wire [2:2]\NLW_rgb_out_reg[23]_i_1300_CO_UNCONNECTED ;
  wire [3:3]\NLW_rgb_out_reg[23]_i_1300_O_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_1308_O_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_1317_O_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_1322_O_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_1331_O_UNCONNECTED ;
  wire [3:3]\NLW_rgb_out_reg[23]_i_472_CO_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_472_O_UNCONNECTED ;
  wire [3:3]\NLW_rgb_out_reg[23]_i_733_CO_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_733_O_UNCONNECTED ;
  wire [3:3]\NLW_rgb_out_reg[23]_i_752_CO_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_752_O_UNCONNECTED ;
  wire [3:3]\NLW_rgb_out_reg[23]_i_754_CO_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_754_O_UNCONNECTED ;
  wire [3:3]\NLW_rgb_out_reg[23]_i_755_CO_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_755_O_UNCONNECTED ;
  wire [3:3]\NLW_rgb_out_reg[23]_i_757_CO_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_757_O_UNCONNECTED ;
  wire [3:0]\NLW_rgb_out_reg[23]_i_787_O_UNCONNECTED ;

  decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_chiffre_7seg__parameterized2 TM_U
       (.CO(CO),
        .D({TM_U_n_1,TM_U_n_2,TM_U_n_3,TM_U_n_4,TM_U_n_5,TM_U_n_6,TM_U_n_7,TM_U_n_8,TM_U_n_9,TM_U_n_10,TM_U_n_11,TM_U_n_12,TM_U_n_13,TM_U_n_14,TM_U_n_15,TM_U_n_16,TM_U_n_17,TM_U_n_18,TM_U_n_19,TM_U_n_20,TM_U_n_21,TM_U_n_22,TM_U_n_23,TM_U_n_24}),
        .DI(\rgb_out[23]_i_852_n_0 ),
        .S({\rgb_out[23]_i_855_n_0 ,\rgb_out[23]_i_856_n_0 }),
        .decompte_ui(decompte_ui),
        .decompte_ui_1_sp_1(\rgb_out[23]_i_61_n_0 ),
        .is_pixel_mur(is_pixel_mur),
        .mode_ui(mode_ui),
        .\mode_ui[0]_0 (\rgb_out[23]_i_3_n_0 ),
        .\mode_ui[2]_0 (\rgb_out[7]_i_8_n_0 ),
        .\mode_ui[2]_1 (\rgb_out[23]_i_54_n_0 ),
        .mode_ui_0_sp_1(\rgb_out[17]_i_3_n_0 ),
        .mode_ui_1_sp_1(\rgb_out[14]_i_5_n_0 ),
        .mode_ui_2_sp_1(\rgb_out[11]_i_4_n_0 ),
        .num_tm_d(num_tm_d),
        .pixel_x(pixel_x),
        .\pixel_x[1]_0 (\rgb_out[23]_i_6_n_0 ),
        .\pixel_x[1]_1 (\rgb_out[23]_i_886_n_0 ),
        .\pixel_x[2]_0 (\rgb_out[10]_i_3_n_0 ),
        .\pixel_x[2]_1 (\rgb_out[17]_i_4_n_0 ),
        .\pixel_x[2]_10 (\rgb_out[12]_i_3_n_0 ),
        .\pixel_x[2]_11 (\rgb_out[14]_i_3_n_0 ),
        .\pixel_x[2]_12 (\rgb_out[15]_i_3_n_0 ),
        .\pixel_x[2]_13 (\rgb_out[16]_i_3_n_0 ),
        .\pixel_x[2]_14 (\rgb_out[17]_i_5_n_0 ),
        .\pixel_x[2]_15 (\rgb_out[18]_i_3_n_0 ),
        .\pixel_x[2]_16 (\rgb_out[19]_i_3_n_0 ),
        .\pixel_x[2]_17 (\rgb_out[20]_i_5_n_0 ),
        .\pixel_x[2]_18 (\rgb_out[21]_i_2_n_0 ),
        .\pixel_x[2]_19 (\rgb_out[22]_i_2_n_0 ),
        .\pixel_x[2]_2 (\rgb_out[11]_i_3_n_0 ),
        .\pixel_x[2]_20 (\rgb_out[22]_i_3_n_0 ),
        .\pixel_x[2]_21 (\rgb_out[23]_i_4_n_0 ),
        .\pixel_x[2]_22 (\rgb_out[23]_i_5_n_0 ),
        .\pixel_x[2]_23 (\rgb_out[7]_i_4_n_0 ),
        .\pixel_x[2]_24 (\rgb_out[7]_i_5_n_0 ),
        .\pixel_x[2]_25 (\rgb_out[7]_i_6_n_0 ),
        .\pixel_x[2]_26 (DI),
        .\pixel_x[2]_3 (\rgb_out[13]_i_4_n_0 ),
        .\pixel_x[2]_4 (\rgb_out[1]_i_4_n_0 ),
        .\pixel_x[2]_5 (\rgb_out[20]_i_6_n_0 ),
        .\pixel_x[2]_6 (\rgb_out[2]_i_3_n_0 ),
        .\pixel_x[2]_7 (\rgb_out[5]_i_3_n_0 ),
        .\pixel_x[2]_8 (\rgb_out[6]_i_3_n_0 ),
        .\pixel_x[2]_9 (\rgb_out[8]_i_3_n_0 ),
        .\pixel_x[3]_0 (\rgb_out[1]_i_5_n_0 ),
        .\pixel_x[3]_1 (\rgb_out[2]_i_4_n_0 ),
        .\pixel_x[3]_10 (\rgb_out[19]_i_4_n_0 ),
        .\pixel_x[3]_11 (\rgb_out[20]_i_7_n_0 ),
        .\pixel_x[3]_12 (\rgb_out[7]_i_7_n_0 ),
        .\pixel_x[3]_13 ({\rgb_out[23]_i_889_n_0 ,\rgb_out[23]_i_890_n_0 }),
        .\pixel_x[3]_14 (S),
        .\pixel_x[3]_2 (\rgb_out[6]_i_4_n_0 ),
        .\pixel_x[3]_3 (\rgb_out[8]_i_4_n_0 ),
        .\pixel_x[3]_4 (\rgb_out[12]_i_4_n_0 ),
        .\pixel_x[3]_5 (\rgb_out[14]_i_4_n_0 ),
        .\pixel_x[3]_6 (\rgb_out[15]_i_4_n_0 ),
        .\pixel_x[3]_7 (\rgb_out[16]_i_4_n_0 ),
        .\pixel_x[3]_8 (\rgb_out[17]_i_6_n_0 ),
        .\pixel_x[3]_9 (\rgb_out[18]_i_4_n_0 ),
        .\pixel_x[5]_0 (\rgb_out[23]_i_58_n_0 ),
        .\pixel_x[5]_1 (\rgb_out[23]_i_217_n_0 ),
        .\pixel_x[5]_2 (\rgb_out[23]_i_218_n_0 ),
        .\pixel_x[5]_3 (\pixel_x[5]_2 ),
        .pixel_x_1_sp_1(\rgb_out[23]_i_15_n_0 ),
        .pixel_x_2_sp_1(\rgb_out[10]_i_2_n_0 ),
        .pixel_x_3_sp_1(\rgb_out[13]_i_3_n_0 ),
        .pixel_x_4_sp_1(\rgb_out[23]_i_16_n_0 ),
        .pixel_x_5_sp_1(\rgb_out[10]_i_5_n_0 ),
        .pixel_x_8_sp_1(\rgb_out[23]_i_60_n_0 ),
        .pixel_y(pixel_y),
        .\pixel_y[2]_0 (\rgb_out[23]_i_213_n_0 ),
        .\pixel_y[2]_1 (\rgb_out[23]_i_215_n_0 ),
        .\pixel_y[2]_2 (\rgb_out[23]_i_212_n_0 ),
        .\pixel_y[2]_3 (\rgb_out[23]_i_203_n_0 ),
        .\pixel_y[2]_4 (\rgb_out[23]_i_204_n_0 ),
        .\pixel_y[4]_0 (\rgb_out[21]_i_5_n_0 ),
        .\pixel_y[4]_1 (\rgb_out[5]_i_2_n_0 ),
        .\pixel_y[4]_10 (\rgb_out[16]_i_2_n_0 ),
        .\pixel_y[4]_11 (\rgb_out[17]_i_2_n_0 ),
        .\pixel_y[4]_12 (\rgb_out[18]_i_2_n_0 ),
        .\pixel_y[4]_13 (\rgb_out[19]_i_2_n_0 ),
        .\pixel_y[4]_14 (\rgb_out[20]_i_3_n_0 ),
        .\pixel_y[4]_2 (\rgb_out[15]_i_5_n_0 ),
        .\pixel_y[4]_3 (\rgb_out[1]_i_2_n_0 ),
        .\pixel_y[4]_4 (\rgb_out[2]_i_2_n_0 ),
        .\pixel_y[4]_5 (\rgb_out[6]_i_2_n_0 ),
        .\pixel_y[4]_6 (\rgb_out[8]_i_2_n_0 ),
        .\pixel_y[4]_7 (\rgb_out[12]_i_2_n_0 ),
        .\pixel_y[4]_8 (\rgb_out[14]_i_2_n_0 ),
        .\pixel_y[4]_9 (\rgb_out[15]_i_2_n_0 ),
        .\pixel_y[5]_0 (\rgb_out[23]_i_211_n_0 ),
        .\pixel_y[5]_1 (\rgb_out[23]_i_202_n_0 ),
        .\pixel_y[9]_0 (\rgb_out[1]_i_3_n_0 ),
        .\pixel_y[9]_1 (\rgb_out[23]_i_8_n_0 ),
        .pixel_y_2_sp_1(\rgb_out[23]_i_195_n_0 ),
        .pixel_y_4_sp_1(\rgb_out[0]_i_3_n_0 ),
        .pixel_y_5_sp_1(\rgb_out[23]_i_214_n_0 ),
        .pixel_y_6_sp_1(\rgb_out[11]_i_5_n_0 ),
        .pixel_y_7_sp_1(\rgb_out[13]_i_5_n_0 ),
        .pixel_y_9_sp_1(\rgb_out[20]_i_2_n_0 ),
        .rgb_in({rgb_in[23:21],rgb_in[13],rgb_in[11:9],rgb_in[7],rgb_in[5:3],rgb_in[0]}),
        .\rgb_out_reg[20] (pixel_on83_in),
        .\rgb_out_reg[20]_0 (pixel_on7),
        .\rgb_out_reg[20]_1 (pixel_on22_in),
        .\rgb_out_reg[20]_2 (pixel_on31_in),
        .\rgb_out_reg[20]_3 (pixel_on5),
        .\rgb_out_reg[20]_4 (pixel_on712_in),
        .\rgb_out_reg[20]_5 (pixel_on66_in),
        .\rgb_out_reg[20]_6 (pixel_on75_in),
        .\rgb_out_reg[20]_7 (pixel_on6),
        .\temps_restant[2] (\rgb_out[23]_i_196_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    de_out_i_1
       (.I0(de_in),
        .I1(reset),
        .O(de_out_i_1_n_0));
  FDRE de_out_reg
       (.C(pixel_clk),
        .CE(1'b1),
        .D(de_out_i_1_n_0),
        .Q(de_out),
        .R(1'b0));
  (* SOFT_HLUTNM = "soft_lutpair128" *) 
  LUT2 #(
    .INIT(4'h2)) 
    hsync_out_i_1
       (.I0(hsync_in),
        .I1(reset),
        .O(hsync_out_i_1_n_0));
  FDRE hsync_out_reg
       (.C(pixel_clk),
        .CE(1'b1),
        .D(hsync_out_i_1_n_0),
        .Q(hsync_out),
        .R(1'b0));
  LUT6 #(
    .INIT(64'hAAAAAAAABAAAAAEE)) 
    \rgb_out[0]_i_3 
       (.I0(\rgb_out[21]_i_5_n_0 ),
        .I1(mode_ui[1]),
        .I2(flash_on),
        .I3(mode_ui[0]),
        .I4(mode_ui[2]),
        .I5(is_pixel_mur),
        .O(\rgb_out[0]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hBFFEBFFEBFCEBFFE)) 
    \rgb_out[10]_i_2 
       (.I0(\rgb_out[11]_i_5_n_0 ),
        .I1(mode_ui[0]),
        .I2(mode_ui[2]),
        .I3(mode_ui[1]),
        .I4(\rgb_out[23]_i_11_n_0 ),
        .I5(\rgb_out[23]_i_12_n_0 ),
        .O(\rgb_out[10]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFFF008500850085)) 
    \rgb_out[10]_i_3 
       (.I0(mode_ui[1]),
        .I1(mode_ui[2]),
        .I2(mode_ui[0]),
        .I3(\rgb_out[23]_i_10_n_0 ),
        .I4(\rgb_out[1]_i_3_n_0 ),
        .I5(\rgb_out[20]_i_8_n_0 ),
        .O(\rgb_out[10]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair3" *) 
  LUT4 #(
    .INIT(16'h3F8C)) 
    \rgb_out[10]_i_5 
       (.I0(\rgb_out[20]_i_8_n_0 ),
        .I1(mode_ui[1]),
        .I2(mode_ui[2]),
        .I3(mode_ui[0]),
        .O(\rgb_out[10]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'h2222222222222220)) 
    \rgb_out[11]_i_10 
       (.I0(\rgb_out[11]_i_18_n_0 ),
        .I1(\rgb_out[11]_i_19_n_0 ),
        .I2(pixel_x[11]),
        .I3(pixel_x[9]),
        .I4(pixel_x[8]),
        .I5(\rgb_out[11]_i_20_n_0 ),
        .O(\rgb_out[11]_i_10_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[11]_i_11 
       (.I0(pixel_x[11]),
        .I1(pixel_x[10]),
        .O(\rgb_out[11]_i_11_n_0 ));
  LUT6 #(
    .INIT(64'h0002000300000003)) 
    \rgb_out[11]_i_12 
       (.I0(\rgb_out[23]_i_225_n_0 ),
        .I1(pixel_x[6]),
        .I2(pixel_x[7]),
        .I3(pixel_x[8]),
        .I4(pixel_x[5]),
        .I5(\rgb_out[23]_i_223_n_0 ),
        .O(\rgb_out[11]_i_12_n_0 ));
  LUT6 #(
    .INIT(64'hEAAAAAAAAAAAAAAA)) 
    \rgb_out[11]_i_13 
       (.I0(\rgb_out[23]_i_224_n_0 ),
        .I1(pixel_x[5]),
        .I2(\rgb_out[11]_i_21_n_0 ),
        .I3(pixel_x[4]),
        .I4(pixel_x[3]),
        .I5(\rgb_out[11]_i_22_n_0 ),
        .O(\rgb_out[11]_i_13_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFF00D0FFD0)) 
    \rgb_out[11]_i_14 
       (.I0(\rgb_out[11]_i_23_n_0 ),
        .I1(\rgb_out[11]_i_24_n_0 ),
        .I2(\rgb_out[23]_i_40_n_0 ),
        .I3(pixel_y[9]),
        .I4(\rgb_out[11]_i_25_n_0 ),
        .I5(\rgb_out[11]_i_26_n_0 ),
        .O(\rgb_out[11]_i_14_n_0 ));
  LUT6 #(
    .INIT(64'h00007FFFFFFFFFFF)) 
    \rgb_out[11]_i_15 
       (.I0(pixel_x[4]),
        .I1(pixel_x[3]),
        .I2(pixel_x[2]),
        .I3(pixel_x[1]),
        .I4(pixel_x[5]),
        .I5(pixel_x[7]),
        .O(\rgb_out[11]_i_15_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFAAAAEAAA)) 
    \rgb_out[11]_i_16 
       (.I0(\rgb_out[11]_i_27_n_0 ),
        .I1(\rgb_out[11]_i_28_n_0 ),
        .I2(pixel_x[9]),
        .I3(pixel_x[5]),
        .I4(\rgb_out[11]_i_29_n_0 ),
        .I5(\rgb_out[11]_i_30_n_0 ),
        .O(\rgb_out[11]_i_16_n_0 ));
  LUT6 #(
    .INIT(64'h5544544454445444)) 
    \rgb_out[11]_i_17 
       (.I0(\rgb_out[23]_i_40_n_0 ),
        .I1(pixel_y[6]),
        .I2(pixel_y[4]),
        .I3(pixel_y[5]),
        .I4(pixel_y[3]),
        .I5(\rgb_out[11]_i_31_n_0 ),
        .O(\rgb_out[11]_i_17_n_0 ));
  LUT6 #(
    .INIT(64'h030733FFFFFFFFFF)) 
    \rgb_out[11]_i_18 
       (.I0(pixel_x[6]),
        .I1(\rgb_out[11]_i_32_n_0 ),
        .I2(pixel_x[7]),
        .I3(pixel_x[9]),
        .I4(pixel_x[8]),
        .I5(pixel_x[10]),
        .O(\rgb_out[11]_i_18_n_0 ));
  LUT6 #(
    .INIT(64'hDDCCDDCFDDCCDDCC)) 
    \rgb_out[11]_i_19 
       (.I0(\rgb_out[11]_i_33_n_0 ),
        .I1(pixel_x[11]),
        .I2(pixel_x[5]),
        .I3(pixel_x[6]),
        .I4(\rgb_out[11]_i_22_n_0 ),
        .I5(\rgb_out[23]_i_335_n_0 ),
        .O(\rgb_out[11]_i_19_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair17" *) 
  LUT5 #(
    .INIT(32'hFFFFFFF8)) 
    \rgb_out[11]_i_20 
       (.I0(pixel_x[4]),
        .I1(pixel_x[3]),
        .I2(pixel_x[6]),
        .I3(pixel_x[7]),
        .I4(pixel_x[5]),
        .O(\rgb_out[11]_i_20_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair127" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[11]_i_21 
       (.I0(pixel_x[6]),
        .I1(pixel_x[7]),
        .O(\rgb_out[11]_i_21_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair134" *) 
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[11]_i_22 
       (.I0(pixel_x[1]),
        .I1(pixel_x[2]),
        .O(\rgb_out[11]_i_22_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair46" *) 
  LUT4 #(
    .INIT(16'hEAAA)) 
    \rgb_out[11]_i_23 
       (.I0(pixel_y[3]),
        .I1(pixel_y[1]),
        .I2(pixel_y[0]),
        .I3(pixel_y[2]),
        .O(\rgb_out[11]_i_23_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair73" *) 
  LUT4 #(
    .INIT(16'h7FFF)) 
    \rgb_out[11]_i_24 
       (.I0(pixel_y[4]),
        .I1(pixel_y[5]),
        .I2(pixel_y[6]),
        .I3(pixel_y[8]),
        .O(\rgb_out[11]_i_24_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000FF2FFF)) 
    \rgb_out[11]_i_25 
       (.I0(\rgb_out[7]_i_37_n_0 ),
        .I1(pixel_y[2]),
        .I2(pixel_y[3]),
        .I3(pixel_y[5]),
        .I4(pixel_y[4]),
        .I5(\rgb_out[23]_i_67_n_0 ),
        .O(\rgb_out[11]_i_25_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair104" *) 
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[11]_i_26 
       (.I0(pixel_y[11]),
        .I1(pixel_y[10]),
        .O(\rgb_out[11]_i_26_n_0 ));
  LUT6 #(
    .INIT(64'hFFBFBFBFBFBFBFBF)) 
    \rgb_out[11]_i_27 
       (.I0(\rgb_out[21]_i_6_n_0 ),
        .I1(pixel_x[9]),
        .I2(\rgb_out[11]_i_11_n_0 ),
        .I3(pixel_x[8]),
        .I4(pixel_x[7]),
        .I5(pixel_x[6]),
        .O(\rgb_out[11]_i_27_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair74" *) 
  LUT4 #(
    .INIT(16'hFFFE)) 
    \rgb_out[11]_i_28 
       (.I0(pixel_x[2]),
        .I1(pixel_x[1]),
        .I2(pixel_x[4]),
        .I3(pixel_x[3]),
        .O(\rgb_out[11]_i_28_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair117" *) 
  LUT2 #(
    .INIT(4'h7)) 
    \rgb_out[11]_i_29 
       (.I0(pixel_x[7]),
        .I1(pixel_x[8]),
        .O(\rgb_out[11]_i_29_n_0 ));
  LUT6 #(
    .INIT(64'h0F00004F0000000F)) 
    \rgb_out[11]_i_3 
       (.I0(\rgb_out[23]_i_12_n_0 ),
        .I1(rgb_in[11]),
        .I2(\rgb_out[23]_i_10_n_0 ),
        .I3(mode_ui[1]),
        .I4(mode_ui[0]),
        .I5(mode_ui[2]),
        .O(\rgb_out[11]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hFFFF00F400440044)) 
    \rgb_out[11]_i_30 
       (.I0(\rgb_out[11]_i_31_n_0 ),
        .I1(\rgb_out[23]_i_540_n_0 ),
        .I2(\rgb_out[11]_i_34_n_0 ),
        .I3(pixel_y[5]),
        .I4(\rgb_out[11]_i_35_n_0 ),
        .I5(\rgb_out[23]_i_40_n_0 ),
        .O(\rgb_out[11]_i_30_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair115" *) 
  LUT3 #(
    .INIT(8'hFE)) 
    \rgb_out[11]_i_31 
       (.I0(pixel_y[0]),
        .I1(pixel_y[1]),
        .I2(pixel_y[2]),
        .O(\rgb_out[11]_i_31_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair80" *) 
  LUT4 #(
    .INIT(16'hFFFE)) 
    \rgb_out[11]_i_32 
       (.I0(pixel_x[5]),
        .I1(pixel_x[9]),
        .I2(pixel_x[4]),
        .I3(pixel_x[3]),
        .O(\rgb_out[11]_i_32_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair44" *) 
  LUT4 #(
    .INIT(16'h7FFF)) 
    \rgb_out[11]_i_33 
       (.I0(pixel_x[2]),
        .I1(pixel_x[1]),
        .I2(pixel_x[10]),
        .I3(pixel_x[8]),
        .O(\rgb_out[11]_i_33_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair137" *) 
  LUT2 #(
    .INIT(4'h7)) 
    \rgb_out[11]_i_34 
       (.I0(pixel_y[4]),
        .I1(pixel_y[3]),
        .O(\rgb_out[11]_i_34_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair98" *) 
  LUT2 #(
    .INIT(4'h7)) 
    \rgb_out[11]_i_35 
       (.I0(pixel_y[8]),
        .I1(pixel_y[6]),
        .O(\rgb_out[11]_i_35_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT3 #(
    .INIT(8'h81)) 
    \rgb_out[11]_i_4 
       (.I0(mode_ui[1]),
        .I1(mode_ui[0]),
        .I2(mode_ui[2]),
        .O(\rgb_out[11]_i_4_n_0 ));
  LUT5 #(
    .INIT(32'hFFFFAEEE)) 
    \rgb_out[11]_i_5 
       (.I0(\rgb_out[11]_i_6_n_0 ),
        .I1(\rgb_out[11]_i_7_n_0 ),
        .I2(pixel_y[8]),
        .I3(\rgb_out[11]_i_8_n_0 ),
        .I4(\rgb_out[11]_i_9_n_0 ),
        .O(\rgb_out[11]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'h00000000EE2E2222)) 
    \rgb_out[11]_i_6 
       (.I0(\rgb_out[11]_i_10_n_0 ),
        .I1(\rgb_out[11]_i_11_n_0 ),
        .I2(pixel_x[9]),
        .I3(\rgb_out[11]_i_12_n_0 ),
        .I4(\rgb_out[11]_i_13_n_0 ),
        .I5(\rgb_out[11]_i_14_n_0 ),
        .O(\rgb_out[11]_i_6_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair14" *) 
  LUT5 #(
    .INIT(32'h00000515)) 
    \rgb_out[11]_i_7 
       (.I0(\rgb_out[21]_i_6_n_0 ),
        .I1(pixel_y[7]),
        .I2(pixel_y[8]),
        .I3(pixel_y[6]),
        .I4(\rgb_out[23]_i_38_n_0 ),
        .O(\rgb_out[11]_i_7_n_0 ));
  LUT6 #(
    .INIT(64'hAAAAAAAAAAAA8000)) 
    \rgb_out[11]_i_8 
       (.I0(pixel_y[5]),
        .I1(pixel_y[2]),
        .I2(pixel_y[0]),
        .I3(pixel_y[1]),
        .I4(pixel_y[4]),
        .I5(pixel_y[3]),
        .O(\rgb_out[11]_i_8_n_0 ));
  LUT6 #(
    .INIT(64'h000000000000FDDD)) 
    \rgb_out[11]_i_9 
       (.I0(\rgb_out[11]_i_15_n_0 ),
        .I1(pixel_x[8]),
        .I2(pixel_x[7]),
        .I3(pixel_x[6]),
        .I4(\rgb_out[11]_i_16_n_0 ),
        .I5(\rgb_out[11]_i_17_n_0 ),
        .O(\rgb_out[11]_i_9_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair105" *) 
  LUT3 #(
    .INIT(8'h0D)) 
    \rgb_out[12]_i_2 
       (.I0(is_pixel_mur),
        .I1(rgb_in[12]),
        .I2(\rgb_out[5]_i_2_n_0 ),
        .O(\rgb_out[12]_i_2_n_0 ));
  LUT5 #(
    .INIT(32'hBFBBAAAA)) 
    \rgb_out[12]_i_3 
       (.I0(\rgb_out[1]_i_3_n_0 ),
        .I1(\rgb_out[23]_i_11_n_0 ),
        .I2(\rgb_out[23]_i_12_n_0 ),
        .I3(rgb_in[12]),
        .I4(\rgb_out[23]_i_13_n_0 ),
        .O(\rgb_out[12]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h0000810081818181)) 
    \rgb_out[12]_i_4 
       (.I0(mode_ui[2]),
        .I1(mode_ui[0]),
        .I2(mode_ui[1]),
        .I3(rgb_in[12]),
        .I4(\rgb_out[11]_i_5_n_0 ),
        .I5(\rgb_out[23]_i_9_n_0 ),
        .O(\rgb_out[12]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hA8000000000000A8)) 
    \rgb_out[13]_i_3 
       (.I0(\rgb_out[23]_i_9_n_0 ),
        .I1(rgb_in[13]),
        .I2(\rgb_out[11]_i_5_n_0 ),
        .I3(mode_ui[1]),
        .I4(mode_ui[0]),
        .I5(mode_ui[2]),
        .O(\rgb_out[13]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair79" *) 
  LUT4 #(
    .INIT(16'hFBFF)) 
    \rgb_out[13]_i_4 
       (.I0(mode_ui[0]),
        .I1(mode_ui[2]),
        .I2(mode_ui[1]),
        .I3(\rgb_out[23]_i_11_n_0 ),
        .O(\rgb_out[13]_i_4_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[13]_i_5 
       (.I0(rgb_in[13]),
        .I1(\rgb_out[23]_i_12_n_0 ),
        .O(\rgb_out[13]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'h00000000BBBB8B88)) 
    \rgb_out[14]_i_2 
       (.I0(rgb_in[14]),
        .I1(is_pixel_mur),
        .I2(mode_ui[2]),
        .I3(mode_ui[0]),
        .I4(\rgb_out[14]_i_5_n_0 ),
        .I5(\rgb_out[21]_i_5_n_0 ),
        .O(\rgb_out[14]_i_2_n_0 ));
  LUT5 #(
    .INIT(32'hBFBBAAAA)) 
    \rgb_out[14]_i_3 
       (.I0(\rgb_out[1]_i_3_n_0 ),
        .I1(\rgb_out[23]_i_11_n_0 ),
        .I2(\rgb_out[23]_i_12_n_0 ),
        .I3(rgb_in[14]),
        .I4(\rgb_out[23]_i_13_n_0 ),
        .O(\rgb_out[14]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h0000810081818181)) 
    \rgb_out[14]_i_4 
       (.I0(mode_ui[2]),
        .I1(mode_ui[0]),
        .I2(mode_ui[1]),
        .I3(rgb_in[14]),
        .I4(\rgb_out[11]_i_5_n_0 ),
        .I5(\rgb_out[23]_i_9_n_0 ),
        .O(\rgb_out[14]_i_4_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair94" *) 
  LUT4 #(
    .INIT(16'hF27F)) 
    \rgb_out[14]_i_5 
       (.I0(mode_ui[0]),
        .I1(flash_on),
        .I2(mode_ui[2]),
        .I3(mode_ui[1]),
        .O(\rgb_out[14]_i_5_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair97" *) 
  LUT3 #(
    .INIT(8'h8A)) 
    \rgb_out[15]_i_2 
       (.I0(\rgb_out[15]_i_5_n_0 ),
        .I1(rgb_in[15]),
        .I2(is_pixel_mur),
        .O(\rgb_out[15]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h0000040004040404)) 
    \rgb_out[15]_i_3 
       (.I0(mode_ui[0]),
        .I1(mode_ui[2]),
        .I2(mode_ui[1]),
        .I3(rgb_in[15]),
        .I4(\rgb_out[23]_i_12_n_0 ),
        .I5(\rgb_out[23]_i_11_n_0 ),
        .O(\rgb_out[15]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h0000810081818181)) 
    \rgb_out[15]_i_4 
       (.I0(mode_ui[2]),
        .I1(mode_ui[0]),
        .I2(mode_ui[1]),
        .I3(rgb_in[15]),
        .I4(\rgb_out[11]_i_5_n_0 ),
        .I5(\rgb_out[23]_i_9_n_0 ),
        .O(\rgb_out[15]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h5555555510000000)) 
    \rgb_out[15]_i_5 
       (.I0(\rgb_out[21]_i_5_n_0 ),
        .I1(mode_ui[2]),
        .I2(mode_ui[0]),
        .I3(mode_ui[1]),
        .I4(flash_on),
        .I5(is_pixel_mur),
        .O(\rgb_out[15]_i_5_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair107" *) 
  LUT3 #(
    .INIT(8'h8A)) 
    \rgb_out[16]_i_2 
       (.I0(\rgb_out[16]_i_5_n_0 ),
        .I1(rgb_in[16]),
        .I2(is_pixel_mur),
        .O(\rgb_out[16]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h0000040004040404)) 
    \rgb_out[16]_i_3 
       (.I0(mode_ui[0]),
        .I1(mode_ui[2]),
        .I2(mode_ui[1]),
        .I3(rgb_in[16]),
        .I4(\rgb_out[23]_i_12_n_0 ),
        .I5(\rgb_out[23]_i_11_n_0 ),
        .O(\rgb_out[16]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h0000810081818181)) 
    \rgb_out[16]_i_4 
       (.I0(mode_ui[2]),
        .I1(mode_ui[0]),
        .I2(mode_ui[1]),
        .I3(rgb_in[16]),
        .I4(\rgb_out[11]_i_5_n_0 ),
        .I5(\rgb_out[23]_i_9_n_0 ),
        .O(\rgb_out[16]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h4444554554444444)) 
    \rgb_out[16]_i_5 
       (.I0(\rgb_out[21]_i_5_n_0 ),
        .I1(is_pixel_mur),
        .I2(mode_ui[0]),
        .I3(flash_on),
        .I4(mode_ui[2]),
        .I5(mode_ui[1]),
        .O(\rgb_out[16]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'h00000000DDDD8DDD)) 
    \rgb_out[17]_i_2 
       (.I0(is_pixel_mur),
        .I1(rgb_in[17]),
        .I2(flash_on),
        .I3(mode_ui[1]),
        .I4(\rgb_out[17]_i_7_n_0 ),
        .I5(\rgb_out[21]_i_5_n_0 ),
        .O(\rgb_out[17]_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair116" *) 
  LUT3 #(
    .INIT(8'h7A)) 
    \rgb_out[17]_i_3 
       (.I0(mode_ui[1]),
        .I1(mode_ui[2]),
        .I2(mode_ui[0]),
        .O(\rgb_out[17]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair79" *) 
  LUT4 #(
    .INIT(16'h4011)) 
    \rgb_out[17]_i_4 
       (.I0(\rgb_out[23]_i_10_n_0 ),
        .I1(mode_ui[0]),
        .I2(mode_ui[2]),
        .I3(mode_ui[1]),
        .O(\rgb_out[17]_i_4_n_0 ));
  LUT5 #(
    .INIT(32'hBFBBAAAA)) 
    \rgb_out[17]_i_5 
       (.I0(\rgb_out[1]_i_3_n_0 ),
        .I1(\rgb_out[23]_i_11_n_0 ),
        .I2(\rgb_out[23]_i_12_n_0 ),
        .I3(rgb_in[17]),
        .I4(\rgb_out[23]_i_13_n_0 ),
        .O(\rgb_out[17]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'h0000810081818181)) 
    \rgb_out[17]_i_6 
       (.I0(mode_ui[2]),
        .I1(mode_ui[0]),
        .I2(mode_ui[1]),
        .I3(rgb_in[17]),
        .I4(\rgb_out[11]_i_5_n_0 ),
        .I5(\rgb_out[23]_i_9_n_0 ),
        .O(\rgb_out[17]_i_6_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair116" *) 
  LUT2 #(
    .INIT(4'hB)) 
    \rgb_out[17]_i_7 
       (.I0(mode_ui[2]),
        .I1(mode_ui[0]),
        .O(\rgb_out[17]_i_7_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair105" *) 
  LUT3 #(
    .INIT(8'hEA)) 
    \rgb_out[18]_i_2 
       (.I0(\rgb_out[5]_i_2_n_0 ),
        .I1(rgb_in[18]),
        .I2(is_pixel_mur),
        .O(\rgb_out[18]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h0000040004040404)) 
    \rgb_out[18]_i_3 
       (.I0(mode_ui[0]),
        .I1(mode_ui[2]),
        .I2(mode_ui[1]),
        .I3(rgb_in[18]),
        .I4(\rgb_out[23]_i_12_n_0 ),
        .I5(\rgb_out[23]_i_11_n_0 ),
        .O(\rgb_out[18]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h0000810081818181)) 
    \rgb_out[18]_i_4 
       (.I0(mode_ui[2]),
        .I1(mode_ui[0]),
        .I2(mode_ui[1]),
        .I3(rgb_in[18]),
        .I4(\rgb_out[11]_i_5_n_0 ),
        .I5(\rgb_out[23]_i_9_n_0 ),
        .O(\rgb_out[18]_i_4_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair102" *) 
  LUT3 #(
    .INIT(8'h08)) 
    \rgb_out[19]_i_2 
       (.I0(rgb_in[19]),
        .I1(is_pixel_mur),
        .I2(\rgb_out[21]_i_5_n_0 ),
        .O(\rgb_out[19]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h0000040004040404)) 
    \rgb_out[19]_i_3 
       (.I0(mode_ui[0]),
        .I1(mode_ui[2]),
        .I2(mode_ui[1]),
        .I3(rgb_in[19]),
        .I4(\rgb_out[23]_i_12_n_0 ),
        .I5(\rgb_out[23]_i_11_n_0 ),
        .O(\rgb_out[19]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h0000810081818181)) 
    \rgb_out[19]_i_4 
       (.I0(mode_ui[2]),
        .I1(mode_ui[0]),
        .I2(mode_ui[1]),
        .I3(rgb_in[19]),
        .I4(\rgb_out[11]_i_5_n_0 ),
        .I5(\rgb_out[23]_i_9_n_0 ),
        .O(\rgb_out[19]_i_4_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair107" *) 
  LUT3 #(
    .INIT(8'h0D)) 
    \rgb_out[1]_i_2 
       (.I0(is_pixel_mur),
        .I1(rgb_in[1]),
        .I2(\rgb_out[21]_i_5_n_0 ),
        .O(\rgb_out[1]_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair52" *) 
  LUT4 #(
    .INIT(16'h2000)) 
    \rgb_out[1]_i_3 
       (.I0(mode_ui[2]),
        .I1(mode_ui[0]),
        .I2(mode_ui[1]),
        .I3(\rgb_out[23]_i_19_n_0 ),
        .O(\rgb_out[1]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h1FFF1F1F11111111)) 
    \rgb_out[1]_i_4 
       (.I0(\rgb_out[17]_i_3_n_0 ),
        .I1(\rgb_out[23]_i_10_n_0 ),
        .I2(\rgb_out[23]_i_11_n_0 ),
        .I3(\rgb_out[23]_i_12_n_0 ),
        .I4(rgb_in[1]),
        .I5(\rgb_out[23]_i_13_n_0 ),
        .O(\rgb_out[1]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h0000810081818181)) 
    \rgb_out[1]_i_5 
       (.I0(mode_ui[2]),
        .I1(mode_ui[0]),
        .I2(mode_ui[1]),
        .I3(rgb_in[1]),
        .I4(\rgb_out[11]_i_5_n_0 ),
        .I5(\rgb_out[23]_i_9_n_0 ),
        .O(\rgb_out[1]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'h00000000A0A03000)) 
    \rgb_out[20]_i_10 
       (.I0(\rgb_out[20]_i_15_n_0 ),
        .I1(\rgb_out[20]_i_16_n_0 ),
        .I2(pixel_y[8]),
        .I3(\rgb_out[20]_i_17_n_0 ),
        .I4(pixel_y[7]),
        .I5(\rgb_out[21]_i_6_n_0 ),
        .O(\rgb_out[20]_i_10_n_0 ));
  LUT6 #(
    .INIT(64'hAF23AFAFAFA0AFAF)) 
    \rgb_out[20]_i_11 
       (.I0(\rgb_out[20]_i_18_n_0 ),
        .I1(pixel_x[2]),
        .I2(\rgb_out[23]_i_71_n_0 ),
        .I3(\rgb_out[20]_i_19_n_0 ),
        .I4(\rgb_out[20]_i_20_n_0 ),
        .I5(\rgb_out[20]_i_21_n_0 ),
        .O(\rgb_out[20]_i_11_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFF08880808)) 
    \rgb_out[20]_i_12 
       (.I0(\rgb_out[20]_i_22_n_0 ),
        .I1(\rgb_out[11]_i_11_n_0 ),
        .I2(\rgb_out[20]_i_23_n_0 ),
        .I3(\rgb_out[20]_i_24_n_0 ),
        .I4(\rgb_out[20]_i_25_n_0 ),
        .I5(\rgb_out[20]_i_26_n_0 ),
        .O(\rgb_out[20]_i_12_n_0 ));
  LUT6 #(
    .INIT(64'h0000080000000000)) 
    \rgb_out[20]_i_13 
       (.I0(\rgb_out[23]_i_266_n_0 ),
        .I1(pixel_y[6]),
        .I2(\rgb_out[20]_i_27_n_0 ),
        .I3(pixel_y[8]),
        .I4(\rgb_out[20]_i_17_n_0 ),
        .I5(\rgb_out[23]_i_540_n_0 ),
        .O(\rgb_out[20]_i_13_n_0 ));
  LUT6 #(
    .INIT(64'h0013001300130010)) 
    \rgb_out[20]_i_14 
       (.I0(\rgb_out[23]_i_266_n_0 ),
        .I1(\rgb_out[20]_i_28_n_0 ),
        .I2(\rgb_out[23]_i_239_n_0 ),
        .I3(\rgb_out[20]_i_29_n_0 ),
        .I4(\rgb_out[23]_i_41_n_0 ),
        .I5(\rgb_out[20]_i_30_n_0 ),
        .O(\rgb_out[20]_i_14_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000000001)) 
    \rgb_out[20]_i_15 
       (.I0(pixel_y[5]),
        .I1(pixel_y[6]),
        .I2(pixel_y[4]),
        .I3(pixel_y[3]),
        .I4(pixel_y[2]),
        .I5(pixel_y[1]),
        .O(\rgb_out[20]_i_15_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair125" *) 
  LUT3 #(
    .INIT(8'h7F)) 
    \rgb_out[20]_i_16 
       (.I0(pixel_y[4]),
        .I1(pixel_y[5]),
        .I2(pixel_y[6]),
        .O(\rgb_out[20]_i_16_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair87" *) 
  LUT3 #(
    .INIT(8'h80)) 
    \rgb_out[20]_i_17 
       (.I0(pixel_y[1]),
        .I1(pixel_y[3]),
        .I2(pixel_y[2]),
        .O(\rgb_out[20]_i_17_n_0 ));
  LUT6 #(
    .INIT(64'hFC00EC00FFFFFFFF)) 
    \rgb_out[20]_i_18 
       (.I0(\rgb_out[20]_i_31_n_0 ),
        .I1(pixel_x[7]),
        .I2(pixel_x[6]),
        .I3(\rgb_out[20]_i_23_n_0 ),
        .I4(pixel_x[5]),
        .I5(\rgb_out[11]_i_11_n_0 ),
        .O(\rgb_out[20]_i_18_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair35" *) 
  LUT4 #(
    .INIT(16'h0111)) 
    \rgb_out[20]_i_19 
       (.I0(pixel_x[10]),
        .I1(pixel_x[11]),
        .I2(pixel_x[8]),
        .I3(pixel_x[9]),
        .O(\rgb_out[20]_i_19_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair93" *) 
  LUT4 #(
    .INIT(16'h00C5)) 
    \rgb_out[20]_i_2 
       (.I0(mode_ui[0]),
        .I1(mode_ui[2]),
        .I2(mode_ui[1]),
        .I3(\rgb_out[23]_i_8_n_0 ),
        .O(\rgb_out[20]_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair37" *) 
  LUT4 #(
    .INIT(16'hFFFE)) 
    \rgb_out[20]_i_20 
       (.I0(pixel_x[7]),
        .I1(pixel_x[6]),
        .I2(pixel_x[10]),
        .I3(pixel_x[11]),
        .O(\rgb_out[20]_i_20_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000000001)) 
    \rgb_out[20]_i_21 
       (.I0(pixel_x[7]),
        .I1(pixel_x[11]),
        .I2(pixel_x[10]),
        .I3(pixel_x[5]),
        .I4(pixel_x[4]),
        .I5(pixel_x[3]),
        .O(\rgb_out[20]_i_21_n_0 ));
  LUT6 #(
    .INIT(64'hF0F0F0F0F0F0F0E0)) 
    \rgb_out[20]_i_22 
       (.I0(pixel_x[4]),
        .I1(\rgb_out[23]_i_346_n_0 ),
        .I2(\rgb_out[20]_i_23_n_0 ),
        .I3(pixel_x[5]),
        .I4(pixel_x[7]),
        .I5(pixel_x[6]),
        .O(\rgb_out[20]_i_22_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[20]_i_23 
       (.I0(pixel_x[9]),
        .I1(pixel_x[8]),
        .O(\rgb_out[20]_i_23_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair120" *) 
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[20]_i_24 
       (.I0(pixel_x[6]),
        .I1(pixel_x[7]),
        .O(\rgb_out[20]_i_24_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair135" *) 
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[20]_i_25 
       (.I0(pixel_x[5]),
        .I1(pixel_x[4]),
        .O(\rgb_out[20]_i_25_n_0 ));
  LUT6 #(
    .INIT(64'h8000000000000000)) 
    \rgb_out[20]_i_26 
       (.I0(pixel_x[9]),
        .I1(pixel_x[5]),
        .I2(\rgb_out[11]_i_21_n_0 ),
        .I3(\rgb_out[23]_i_392_n_0 ),
        .I4(pixel_x[2]),
        .I5(\rgb_out[20]_i_19_n_0 ),
        .O(\rgb_out[20]_i_26_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair137" *) 
  LUT2 #(
    .INIT(4'h7)) 
    \rgb_out[20]_i_27 
       (.I0(pixel_y[5]),
        .I1(pixel_y[4]),
        .O(\rgb_out[20]_i_27_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair34" *) 
  LUT5 #(
    .INIT(32'hFEFFFFFF)) 
    \rgb_out[20]_i_28 
       (.I0(pixel_y[11]),
        .I1(pixel_y[10]),
        .I2(pixel_y[9]),
        .I3(pixel_y[7]),
        .I4(pixel_y[8]),
        .O(\rgb_out[20]_i_28_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair73" *) 
  LUT3 #(
    .INIT(8'hFE)) 
    \rgb_out[20]_i_29 
       (.I0(pixel_y[4]),
        .I1(pixel_y[5]),
        .I2(pixel_y[6]),
        .O(\rgb_out[20]_i_29_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair102" *) 
  LUT3 #(
    .INIT(8'hEA)) 
    \rgb_out[20]_i_3 
       (.I0(\rgb_out[21]_i_5_n_0 ),
        .I1(rgb_in[20]),
        .I2(is_pixel_mur),
        .O(\rgb_out[20]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair121" *) 
  LUT3 #(
    .INIT(8'hFE)) 
    \rgb_out[20]_i_30 
       (.I0(pixel_y[6]),
        .I1(pixel_y[1]),
        .I2(pixel_y[2]),
        .O(\rgb_out[20]_i_30_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair67" *) 
  LUT3 #(
    .INIT(8'hA8)) 
    \rgb_out[20]_i_31 
       (.I0(pixel_x[4]),
        .I1(pixel_x[2]),
        .I2(pixel_x[3]),
        .O(\rgb_out[20]_i_31_n_0 ));
  LUT6 #(
    .INIT(64'h0000040004040404)) 
    \rgb_out[20]_i_5 
       (.I0(mode_ui[0]),
        .I1(mode_ui[2]),
        .I2(mode_ui[1]),
        .I3(rgb_in[20]),
        .I4(\rgb_out[23]_i_12_n_0 ),
        .I5(\rgb_out[23]_i_11_n_0 ),
        .O(\rgb_out[20]_i_5_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair3" *) 
  LUT5 #(
    .INIT(32'h0040C073)) 
    \rgb_out[20]_i_6 
       (.I0(\rgb_out[20]_i_8_n_0 ),
        .I1(mode_ui[1]),
        .I2(mode_ui[2]),
        .I3(mode_ui[0]),
        .I4(\rgb_out[23]_i_10_n_0 ),
        .O(\rgb_out[20]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'h0000810081818181)) 
    \rgb_out[20]_i_7 
       (.I0(mode_ui[2]),
        .I1(mode_ui[0]),
        .I2(mode_ui[1]),
        .I3(rgb_in[20]),
        .I4(\rgb_out[11]_i_5_n_0 ),
        .I5(\rgb_out[23]_i_9_n_0 ),
        .O(\rgb_out[20]_i_7_n_0 ));
  LUT6 #(
    .INIT(64'h0000000044445545)) 
    \rgb_out[20]_i_8 
       (.I0(\rgb_out[23]_i_45_n_0 ),
        .I1(\rgb_out[20]_i_9_n_0 ),
        .I2(\rgb_out[20]_i_10_n_0 ),
        .I3(\rgb_out[20]_i_11_n_0 ),
        .I4(\rgb_out[20]_i_12_n_0 ),
        .I5(\rgb_out[23]_i_43_n_0 ),
        .O(\rgb_out[20]_i_8_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair16" *) 
  LUT5 #(
    .INIT(32'h00000001)) 
    \rgb_out[20]_i_9 
       (.I0(\rgb_out[23]_i_87_n_0 ),
        .I1(\rgb_out[23]_i_151_n_0 ),
        .I2(\rgb_out[20]_i_10_n_0 ),
        .I3(\rgb_out[20]_i_13_n_0 ),
        .I4(\rgb_out[20]_i_14_n_0 ),
        .O(\rgb_out[20]_i_9_n_0 ));
  LUT5 #(
    .INIT(32'hEFEEEFEF)) 
    \rgb_out[21]_i_2 
       (.I0(\rgb_out[21]_i_4_n_0 ),
        .I1(\rgb_out[1]_i_3_n_0 ),
        .I2(\rgb_out[17]_i_3_n_0 ),
        .I3(rgb_in[21]),
        .I4(\rgb_out[23]_i_10_n_0 ),
        .O(\rgb_out[21]_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT5 #(
    .INIT(32'hC00A000C)) 
    \rgb_out[21]_i_4 
       (.I0(\rgb_out[23]_i_12_n_0 ),
        .I1(\rgb_out[11]_i_5_n_0 ),
        .I2(mode_ui[1]),
        .I3(mode_ui[0]),
        .I4(mode_ui[2]),
        .O(\rgb_out[21]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h0000000101010101)) 
    \rgb_out[21]_i_5 
       (.I0(pixel_y[8]),
        .I1(pixel_y[7]),
        .I2(\rgb_out[21]_i_6_n_0 ),
        .I3(pixel_y[5]),
        .I4(\rgb_out[21]_i_7_n_0 ),
        .I5(pixel_y[6]),
        .O(\rgb_out[21]_i_5_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair104" *) 
  LUT3 #(
    .INIT(8'hFE)) 
    \rgb_out[21]_i_6 
       (.I0(pixel_y[9]),
        .I1(pixel_y[10]),
        .I2(pixel_y[11]),
        .O(\rgb_out[21]_i_6_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair87" *) 
  LUT4 #(
    .INIT(16'hE000)) 
    \rgb_out[21]_i_7 
       (.I0(pixel_y[1]),
        .I1(pixel_y[2]),
        .I2(pixel_y[3]),
        .I3(pixel_y[4]),
        .O(\rgb_out[21]_i_7_n_0 ));
  LUT5 #(
    .INIT(32'h20AAAAAA)) 
    \rgb_out[22]_i_2 
       (.I0(\rgb_out[11]_i_4_n_0 ),
        .I1(\rgb_out[11]_i_5_n_0 ),
        .I2(rgb_in[22]),
        .I3(\rgb_out[23]_i_9_n_0 ),
        .I4(\rgb_out[23]_i_10_n_0 ),
        .O(\rgb_out[22]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hBFBFFFBFAAAAAAAA)) 
    \rgb_out[22]_i_3 
       (.I0(\rgb_out[23]_i_14_n_0 ),
        .I1(\rgb_out[23]_i_10_n_0 ),
        .I2(\rgb_out[23]_i_11_n_0 ),
        .I3(rgb_in[22]),
        .I4(\rgb_out[23]_i_12_n_0 ),
        .I5(\rgb_out[23]_i_13_n_0 ),
        .O(\rgb_out[22]_i_3_n_0 ));
  LUT2 #(
    .INIT(4'hB)) 
    \rgb_out[23]_i_1 
       (.I0(reset),
        .I1(de_in),
        .O(\rgb_out[23]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000000002)) 
    \rgb_out[23]_i_10 
       (.I0(\rgb_out[23]_i_26_n_0 ),
        .I1(\rgb_out[23]_i_27_n_0 ),
        .I2(\rgb_out[23]_i_28_n_0 ),
        .I3(\rgb_out[23]_i_29_n_0 ),
        .I4(\rgb_out[23]_i_30_n_0 ),
        .I5(\rgb_out[23]_i_31_n_0 ),
        .O(\rgb_out[23]_i_10_n_0 ));
  LUT6 #(
    .INIT(64'h888888880C080808)) 
    \rgb_out[23]_i_100 
       (.I0(\rgb_out[23]_i_306_n_0 ),
        .I1(\rgb_out[23]_i_219_n_0 ),
        .I2(pixel_x[6]),
        .I3(\rgb_out[23]_i_307_n_0 ),
        .I4(pixel_x[5]),
        .I5(\rgb_out[11]_i_29_n_0 ),
        .O(\rgb_out[23]_i_100_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair136" *) 
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_101 
       (.I0(\rgb_out[23]_i_280_n_0 ),
        .I1(\rgb_out[23]_i_299_n_0 ),
        .O(\rgb_out[23]_i_101_n_0 ));
  LUT5 #(
    .INIT(32'h88808A8A)) 
    \rgb_out[23]_i_102 
       (.I0(\rgb_out[23]_i_93_n_0 ),
        .I1(\rgb_out[23]_i_298_n_0 ),
        .I2(\rgb_out[23]_i_297_n_0 ),
        .I3(pixel_x[11]),
        .I4(\rgb_out[23]_i_308_n_0 ),
        .O(\rgb_out[23]_i_102_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_103 
       (.I0(\rgb_out[23]_i_278_n_0 ),
        .I1(\rgb_out[23]_i_275_n_0 ),
        .O(\rgb_out[23]_i_103_n_0 ));
  LUT6 #(
    .INIT(64'h00000000EAEEEAEA)) 
    \rgb_out[23]_i_104 
       (.I0(\rgb_out[23]_i_309_n_0 ),
        .I1(\rgb_out[23]_i_310_n_0 ),
        .I2(\pixel_x[2]_9 ),
        .I3(record_diz),
        .I4(\pixel_x[2]_10 ),
        .I5(\rgb_out[23]_i_314_n_0 ),
        .O(num_rec_d));
  LUT6 #(
    .INIT(64'hAAAAAAAAAAAAAAA8)) 
    \rgb_out[23]_i_105 
       (.I0(\rgb_out[23]_i_315_n_0 ),
        .I1(\rgb_out[23]_i_316_n_0 ),
        .I2(\rgb_out[23]_i_317_n_0 ),
        .I3(\rgb_out[23]_i_318_n_0 ),
        .I4(\rgb_out[23]_i_319_n_0 ),
        .I5(\rgb_out[23]_i_320_n_0 ),
        .O(num_last_u));
  LUT6 #(
    .INIT(64'hAAAAAAAAAAAAAAA8)) 
    \rgb_out[23]_i_106 
       (.I0(\rgb_out[23]_i_321_n_0 ),
        .I1(\rgb_out[23]_i_322_n_0 ),
        .I2(\rgb_out[23]_i_323_n_0 ),
        .I3(\rgb_out[23]_i_324_n_0 ),
        .I4(\rgb_out[23]_i_325_n_0 ),
        .I5(\rgb_out[23]_i_326_n_0 ),
        .O(num_rec_u));
  LUT6 #(
    .INIT(64'h00000000EAEEEAEA)) 
    \rgb_out[23]_i_107 
       (.I0(\rgb_out[23]_i_327_n_0 ),
        .I1(\rgb_out[23]_i_328_n_0 ),
        .I2(\pixel_x[2] ),
        .I3(dernier_diz),
        .I4(\pixel_x[2]_0 ),
        .I5(\rgb_out[23]_i_332_n_0 ),
        .O(num_last_d));
  LUT6 #(
    .INIT(64'h08FFFFFF08FF0000)) 
    \rgb_out[23]_i_108 
       (.I0(\rgb_out[23]_i_333_n_0 ),
        .I1(pixel_x[4]),
        .I2(\rgb_out[23]_i_334_n_0 ),
        .I3(\rgb_out[23]_i_335_n_0 ),
        .I4(\rgb_out[23]_i_297_n_0 ),
        .I5(\rgb_out[23]_i_308_n_0 ),
        .O(\rgb_out[23]_i_108_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFAAAABAAA)) 
    \rgb_out[23]_i_109 
       (.I0(\rgb_out[23]_i_336_n_0 ),
        .I1(\rgb_out[23]_i_337_n_0 ),
        .I2(\rgb_out[23]_i_338_n_0 ),
        .I3(\rgb_out[23]_i_339_n_0 ),
        .I4(\rgb_out[23]_i_340_n_0 ),
        .I5(\rgb_out[23]_i_341_n_0 ),
        .O(\rgb_out[23]_i_109_n_0 ));
  LUT6 #(
    .INIT(64'h0000000010111010)) 
    \rgb_out[23]_i_11 
       (.I0(\rgb_out[23]_i_32_n_0 ),
        .I1(\rgb_out[23]_i_33_n_0 ),
        .I2(\rgb_out[23]_i_34_n_0 ),
        .I3(\rgb_out[23]_i_35_n_0 ),
        .I4(\rgb_out[23]_i_36_n_0 ),
        .I5(\rgb_out[23]_i_37_n_0 ),
        .O(\rgb_out[23]_i_11_n_0 ));
  LUT6 #(
    .INIT(64'hEEEEEEEFEEEEEEEE)) 
    \rgb_out[23]_i_110 
       (.I0(\rgb_out[23]_i_342_n_0 ),
        .I1(\rgb_out[23]_i_343_n_0 ),
        .I2(pixel_x[11]),
        .I3(pixel_x[9]),
        .I4(pixel_x[8]),
        .I5(\rgb_out[20]_i_25_n_0 ),
        .O(\rgb_out[23]_i_110_n_0 ));
  LUT6 #(
    .INIT(64'h0000000020200020)) 
    \rgb_out[23]_i_111 
       (.I0(\rgb_out[23]_i_300_n_0 ),
        .I1(\rgb_out[23]_i_344_n_0 ),
        .I2(\rgb_out[23]_i_345_n_0 ),
        .I3(\rgb_out[23]_i_346_n_0 ),
        .I4(\rgb_out[23]_i_347_n_0 ),
        .I5(\rgb_out[23]_i_348_n_0 ),
        .O(\rgb_out[23]_i_111_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000000010)) 
    \rgb_out[23]_i_112 
       (.I0(\rgb_out[21]_i_6_n_0 ),
        .I1(\rgb_out[23]_i_40_n_0 ),
        .I2(pixel_y[4]),
        .I3(\rgb_out[23]_i_237_n_0 ),
        .I4(\rgb_out[23]_i_267_n_0 ),
        .I5(\rgb_out[23]_i_349_n_0 ),
        .O(\rgb_out[23]_i_112_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000F20000)) 
    \rgb_out[23]_i_113 
       (.I0(\rgb_out[23]_i_293_n_0 ),
        .I1(\rgb_out[23]_i_287_n_0 ),
        .I2(\rgb_out[23]_i_280_n_0 ),
        .I3(\rgb_out[23]_i_350_n_0 ),
        .I4(\rgb_out[23]_i_351_n_0 ),
        .I5(\rgb_out[23]_i_352_n_0 ),
        .O(\rgb_out[23]_i_113_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFEFFFAAAAAAAA)) 
    \rgb_out[23]_i_114 
       (.I0(\rgb_out[23]_i_337_n_0 ),
        .I1(pixel_x[4]),
        .I2(\rgb_out[23]_i_334_n_0 ),
        .I3(pixel_x[5]),
        .I4(\rgb_out[23]_i_353_n_0 ),
        .I5(\rgb_out[23]_i_354_n_0 ),
        .O(\rgb_out[23]_i_114_n_0 ));
  LUT6 #(
    .INIT(64'h0000002000000000)) 
    \rgb_out[23]_i_115 
       (.I0(\rgb_out[23]_i_349_n_0 ),
        .I1(\rgb_out[23]_i_267_n_0 ),
        .I2(\rgb_out[11]_i_23_n_0 ),
        .I3(\rgb_out[21]_i_6_n_0 ),
        .I4(\rgb_out[23]_i_40_n_0 ),
        .I5(pixel_y[4]),
        .O(\rgb_out[23]_i_115_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFFFFE)) 
    \rgb_out[23]_i_116 
       (.I0(\rgb_out[23]_i_355_n_0 ),
        .I1(\rgb_out[23]_i_356_n_0 ),
        .I2(\rgb_out[23]_i_357_n_0 ),
        .I3(\rgb_out[23]_i_290_n_0 ),
        .I4(\rgb_out[23]_i_289_n_0 ),
        .I5(\rgb_out[23]_i_109_n_0 ),
        .O(\rgb_out[23]_i_116_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFF3704F7F4)) 
    \rgb_out[23]_i_117 
       (.I0(pixel_x[11]),
        .I1(\rgb_out[23]_i_358_n_0 ),
        .I2(\rgb_out[23]_i_359_n_0 ),
        .I3(\rgb_out[23]_i_343_n_0 ),
        .I4(\rgb_out[23]_i_360_n_0 ),
        .I5(\rgb_out[23]_i_361_n_0 ),
        .O(\rgb_out[23]_i_117_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair18" *) 
  LUT5 #(
    .INIT(32'h00550155)) 
    \rgb_out[23]_i_118 
       (.I0(pixel_x[11]),
        .I1(pixel_x[9]),
        .I2(pixel_x[8]),
        .I3(pixel_x[10]),
        .I4(pixel_x[7]),
        .O(\rgb_out[23]_i_118_n_0 ));
  LUT6 #(
    .INIT(64'h00C000C000E0FFEE)) 
    \rgb_out[23]_i_119 
       (.I0(\rgb_out[11]_i_21_n_0 ),
        .I1(\rgb_out[23]_i_362_n_0 ),
        .I2(\rgb_out[23]_i_363_n_0 ),
        .I3(\rgb_out[23]_i_364_n_0 ),
        .I4(\rgb_out[23]_i_365_n_0 ),
        .I5(\rgb_out[23]_i_366_n_0 ),
        .O(\rgb_out[23]_i_119_n_0 ));
  LUT6 #(
    .INIT(64'hBBBBBBBBAAAAABAA)) 
    \rgb_out[23]_i_12 
       (.I0(\rgb_out[11]_i_6_n_0 ),
        .I1(\rgb_out[23]_i_38_n_0 ),
        .I2(\rgb_out[23]_i_39_n_0 ),
        .I3(\rgb_out[23]_i_40_n_0 ),
        .I4(\rgb_out[23]_i_41_n_0 ),
        .I5(\rgb_out[23]_i_42_n_0 ),
        .O(\rgb_out[23]_i_12_n_0 ));
  LUT6 #(
    .INIT(64'h80FFFFFF80FF80FF)) 
    \rgb_out[23]_i_120 
       (.I0(\rgb_out[23]_i_351_n_0 ),
        .I1(pixel_x[5]),
        .I2(\rgb_out[23]_i_230_n_0 ),
        .I3(\rgb_out[23]_i_343_n_0 ),
        .I4(\rgb_out[23]_i_224_n_0 ),
        .I5(\rgb_out[23]_i_367_n_0 ),
        .O(\rgb_out[23]_i_120_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFEFFFEFFFE)) 
    \rgb_out[23]_i_1206 
       (.I0(pixel_x[11]),
        .I1(pixel_x[10]),
        .I2(pixel_x[6]),
        .I3(pixel_x[7]),
        .I4(pixel_x[4]),
        .I5(pixel_x[5]),
        .O(\rgb_out[23]_i_1206_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair6" *) 
  LUT4 #(
    .INIT(16'hEAAA)) 
    \rgb_out[23]_i_1207 
       (.I0(pixel_x[6]),
        .I1(pixel_x[5]),
        .I2(pixel_x[4]),
        .I3(pixel_x[3]),
        .O(\rgb_out[23]_i_1207_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair48" *) 
  LUT5 #(
    .INIT(32'hFFFFFFFE)) 
    \rgb_out[23]_i_1208 
       (.I0(pixel_x[7]),
        .I1(pixel_x[9]),
        .I2(pixel_x[6]),
        .I3(pixel_x[5]),
        .I4(pixel_x[4]),
        .O(\rgb_out[23]_i_1208_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair21" *) 
  LUT5 #(
    .INIT(32'h00000001)) 
    \rgb_out[23]_i_1209 
       (.I0(pixel_x[4]),
        .I1(pixel_x[9]),
        .I2(pixel_x[6]),
        .I3(pixel_x[11]),
        .I4(pixel_x[7]),
        .O(\rgb_out[23]_i_1209_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFF0001FFFF)) 
    \rgb_out[23]_i_121 
       (.I0(pixel_y[2]),
        .I1(pixel_y[6]),
        .I2(pixel_y[7]),
        .I3(\rgb_out[23]_i_41_n_0 ),
        .I4(\rgb_out[23]_i_368_n_0 ),
        .I5(\rgb_out[23]_i_369_n_0 ),
        .O(\rgb_out[23]_i_121_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair54" *) 
  LUT4 #(
    .INIT(16'hAAA8)) 
    \rgb_out[23]_i_1210 
       (.I0(pixel_x[4]),
        .I1(pixel_x[1]),
        .I2(pixel_x[3]),
        .I3(pixel_x[2]),
        .O(\rgb_out[23]_i_1210_n_0 ));
  LUT6 #(
    .INIT(64'h1DDD00001DDD1DDD)) 
    \rgb_out[23]_i_122 
       (.I0(\rgb_out[23]_i_370_n_0 ),
        .I1(pixel_x[8]),
        .I2(\rgb_out[11]_i_22_n_0 ),
        .I3(pixel_x[9]),
        .I4(\rgb_out[20]_i_26_n_0 ),
        .I5(\rgb_out[23]_i_371_n_0 ),
        .O(\rgb_out[23]_i_122_n_0 ));
  LUT6 #(
    .INIT(64'h00000000AAA8A8A8)) 
    \rgb_out[23]_i_123 
       (.I0(\rgb_out[7]_i_55_n_0 ),
        .I1(pixel_x[2]),
        .I2(pixel_x[3]),
        .I3(pixel_x[1]),
        .I4(pixel_x[0]),
        .I5(\rgb_out[23]_i_372_n_0 ),
        .O(\rgb_out[23]_i_123_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFF1FFFFFFFFF)) 
    \rgb_out[23]_i_124 
       (.I0(\rgb_out[11]_i_28_n_0 ),
        .I1(pixel_x[5]),
        .I2(\rgb_out[23]_i_373_n_0 ),
        .I3(\rgb_out[20]_i_20_n_0 ),
        .I4(\rgb_out[23]_i_300_n_0 ),
        .I5(\rgb_out[20]_i_23_n_0 ),
        .O(\rgb_out[23]_i_124_n_0 ));
  LUT6 #(
    .INIT(64'h1000FFFF10001000)) 
    \rgb_out[23]_i_125 
       (.I0(\rgb_out[23]_i_374_n_0 ),
        .I1(\rgb_out[23]_i_375_n_0 ),
        .I2(\rgb_out[20]_i_23_n_0 ),
        .I3(\rgb_out[23]_i_253_n_0 ),
        .I4(\rgb_out[23]_i_36_n_0 ),
        .I5(\rgb_out[23]_i_184_n_0 ),
        .O(\rgb_out[23]_i_125_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1254 
       (.I0(local_x_0[10]),
        .I1(local_x_0[11]),
        .O(\rgb_out[23]_i_1254_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1255 
       (.I0(local_x_0[8]),
        .I1(local_x_0[9]),
        .O(\rgb_out[23]_i_1255_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1256 
       (.I0(local_x_0[11]),
        .I1(local_x_0[10]),
        .O(\rgb_out[23]_i_1256_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1257 
       (.I0(local_x_0[9]),
        .I1(local_x_0[8]),
        .O(\rgb_out[23]_i_1257_n_0 ));
  LUT6 #(
    .INIT(64'h0808080008080808)) 
    \rgb_out[23]_i_126 
       (.I0(\rgb_out[23]_i_376_n_0 ),
        .I1(\rgb_out[23]_i_76_n_0 ),
        .I2(\rgb_out[7]_i_40_n_0 ),
        .I3(pixel_x[0]),
        .I4(pixel_x[7]),
        .I5(\rgb_out[23]_i_377_n_0 ),
        .O(\rgb_out[23]_i_126_n_0 ));
  LUT3 #(
    .INIT(8'hAE)) 
    \rgb_out[23]_i_127 
       (.I0(\rgb_out[23]_i_378_n_0 ),
        .I1(\rgb_out[7]_i_41_n_0 ),
        .I2(\rgb_out[7]_i_42_n_0 ),
        .O(\rgb_out[23]_i_127_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair8" *) 
  LUT5 #(
    .INIT(32'h00AA0080)) 
    \rgb_out[23]_i_128 
       (.I0(\rgb_out[23]_i_379_n_0 ),
        .I1(pixel_x[1]),
        .I2(pixel_x[0]),
        .I3(\rgb_out[23]_i_380_n_0 ),
        .I4(pixel_x[2]),
        .O(\rgb_out[23]_i_128_n_0 ));
  LUT6 #(
    .INIT(64'h0000000004000000)) 
    \rgb_out[23]_i_129 
       (.I0(\rgb_out[20]_i_24_n_0 ),
        .I1(\rgb_out[11]_i_11_n_0 ),
        .I2(pixel_x[4]),
        .I3(pixel_x[5]),
        .I4(\rgb_out[20]_i_23_n_0 ),
        .I5(\rgb_out[23]_i_381_n_0 ),
        .O(\rgb_out[23]_i_129_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair93" *) 
  LUT3 #(
    .INIT(8'h04)) 
    \rgb_out[23]_i_13 
       (.I0(mode_ui[1]),
        .I1(mode_ui[2]),
        .I2(mode_ui[0]),
        .O(\rgb_out[23]_i_13_n_0 ));
  LUT6 #(
    .INIT(64'h0000000070000000)) 
    \rgb_out[23]_i_130 
       (.I0(\rgb_out[23]_i_334_n_0 ),
        .I1(\rgb_out[23]_i_370_n_0 ),
        .I2(pixel_x[4]),
        .I3(\rgb_out[23]_i_382_n_0 ),
        .I4(\rgb_out[23]_i_383_n_0 ),
        .I5(\rgb_out[20]_i_19_n_0 ),
        .O(\rgb_out[23]_i_130_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1309 
       (.I0(local_x[10]),
        .I1(local_x[11]),
        .O(\rgb_out[23]_i_1309_n_0 ));
  LUT6 #(
    .INIT(64'h00000000A8A800A8)) 
    \rgb_out[23]_i_131 
       (.I0(\rgb_out[23]_i_384_n_0 ),
        .I1(\rgb_out[20]_i_19_n_0 ),
        .I2(\rgb_out[23]_i_383_n_0 ),
        .I3(\rgb_out[23]_i_382_n_0 ),
        .I4(\rgb_out[23]_i_385_n_0 ),
        .I5(\rgb_out[23]_i_386_n_0 ),
        .O(\rgb_out[23]_i_131_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1310 
       (.I0(local_x[8]),
        .I1(local_x[9]),
        .O(\rgb_out[23]_i_1310_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1311 
       (.I0(local_x[11]),
        .I1(local_x[10]),
        .O(\rgb_out[23]_i_1311_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1312 
       (.I0(local_x[9]),
        .I1(local_x[8]),
        .O(\rgb_out[23]_i_1312_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1318 
       (.I0(local_y[9]),
        .I1(local_y[10]),
        .O(\rgb_out[23]_i_1318_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1319 
       (.I0(local_y[7]),
        .I1(local_y[8]),
        .O(\rgb_out[23]_i_1319_n_0 ));
  LUT6 #(
    .INIT(64'hAAA2AAA20000AAA2)) 
    \rgb_out[23]_i_132 
       (.I0(\rgb_out[23]_i_387_n_0 ),
        .I1(\rgb_out[23]_i_370_n_0 ),
        .I2(\rgb_out[23]_i_388_n_0 ),
        .I3(\rgb_out[23]_i_389_n_0 ),
        .I4(\rgb_out[23]_i_390_n_0 ),
        .I5(\rgb_out[23]_i_379_n_0 ),
        .O(\rgb_out[23]_i_132_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1320 
       (.I0(local_y[10]),
        .I1(local_y[9]),
        .O(\rgb_out[23]_i_1320_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1321 
       (.I0(local_y[8]),
        .I1(local_y[7]),
        .O(\rgb_out[23]_i_1321_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_1323 
       (.I0(\rgb_out_reg[0]_0 ),
        .O(\rgb_out[23]_i_1323_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1324 
       (.I0(local_y[10]),
        .I1(local_y[9]),
        .O(\rgb_out[23]_i_1324_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1325 
       (.I0(local_y[8]),
        .I1(local_y[7]),
        .O(\rgb_out[23]_i_1325_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000000111)) 
    \rgb_out[23]_i_133 
       (.I0(\rgb_out[23]_i_267_n_0 ),
        .I1(pixel_y[7]),
        .I2(pixel_y[1]),
        .I3(pixel_y[0]),
        .I4(pixel_y[2]),
        .I5(pixel_y[3]),
        .O(\rgb_out[23]_i_133_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_1332 
       (.I0(\rgb_out_reg[0]_0 ),
        .O(\rgb_out[23]_i_1332_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1333 
       (.I0(local_y[10]),
        .I1(local_y[9]),
        .O(\rgb_out[23]_i_1333_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1334 
       (.I0(local_y[8]),
        .I1(local_y[7]),
        .O(\rgb_out[23]_i_1334_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair24" *) 
  LUT5 #(
    .INIT(32'hAAAAAAA8)) 
    \rgb_out[23]_i_134 
       (.I0(pixel_y[8]),
        .I1(pixel_y[5]),
        .I2(pixel_y[4]),
        .I3(pixel_y[7]),
        .I4(pixel_y[6]),
        .O(\rgb_out[23]_i_134_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair53" *) 
  LUT4 #(
    .INIT(16'h0001)) 
    \rgb_out[23]_i_135 
       (.I0(pixel_y[10]),
        .I1(pixel_y[11]),
        .I2(pixel_y[8]),
        .I3(pixel_y[9]),
        .O(\rgb_out[23]_i_135_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair68" *) 
  LUT4 #(
    .INIT(16'hFEAA)) 
    \rgb_out[23]_i_136 
       (.I0(pixel_y[3]),
        .I1(pixel_y[1]),
        .I2(pixel_y[0]),
        .I3(pixel_y[2]),
        .O(\rgb_out[23]_i_136_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair121" *) 
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_137 
       (.I0(pixel_y[2]),
        .I1(pixel_y[1]),
        .O(\rgb_out[23]_i_137_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair113" *) 
  LUT3 #(
    .INIT(8'h7F)) 
    \rgb_out[23]_i_138 
       (.I0(pixel_y[6]),
        .I1(pixel_y[7]),
        .I2(pixel_y[5]),
        .O(\rgb_out[23]_i_138_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1382 
       (.I0(local_x_1[4]),
        .I1(local_x_1[5]),
        .O(\rgb_out[23]_i_1382_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1383 
       (.I0(local_x_1[2]),
        .I1(local_x_1[3]),
        .O(\rgb_out[23]_i_1383_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_1384 
       (.I0(pixel_x[0]),
        .I1(pixel_x[1]),
        .O(\rgb_out[23]_i_1384_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1385 
       (.I0(local_x_1[5]),
        .I1(local_x_1[4]),
        .O(\rgb_out[23]_i_1385_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1386 
       (.I0(local_x_1[3]),
        .I1(local_x_1[2]),
        .O(\rgb_out[23]_i_1386_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1387 
       (.I0(local_x_1[0]),
        .I1(local_x_1[1]),
        .O(\rgb_out[23]_i_1387_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1388 
       (.I0(pixel_x[1]),
        .I1(pixel_x[0]),
        .O(\rgb_out[23]_i_1388_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair108" *) 
  LUT3 #(
    .INIT(8'hFE)) 
    \rgb_out[23]_i_139 
       (.I0(\rgb_out[23]_i_391_n_0 ),
        .I1(\rgb_out[23]_i_253_n_0 ),
        .I2(\rgb_out[23]_i_76_n_0 ),
        .O(\rgb_out[23]_i_139_n_0 ));
  LUT6 #(
    .INIT(64'h2020202020002020)) 
    \rgb_out[23]_i_14 
       (.I0(mode_ui[2]),
        .I1(mode_ui[0]),
        .I2(mode_ui[1]),
        .I3(\rgb_out[23]_i_43_n_0 ),
        .I4(\rgb_out[23]_i_44_n_0 ),
        .I5(\rgb_out[23]_i_45_n_0 ),
        .O(\rgb_out[23]_i_14_n_0 ));
  LUT6 #(
    .INIT(64'h8000808080008000)) 
    \rgb_out[23]_i_140 
       (.I0(\rgb_out[20]_i_23_n_0 ),
        .I1(pixel_x[6]),
        .I2(pixel_x[7]),
        .I3(pixel_x[5]),
        .I4(\rgb_out[23]_i_223_n_0 ),
        .I5(\rgb_out[23]_i_392_n_0 ),
        .O(\rgb_out[23]_i_140_n_0 ));
  LUT6 #(
    .INIT(64'h7F3FFF3FFF3FFF3F)) 
    \rgb_out[23]_i_141 
       (.I0(\rgb_out[11]_i_28_n_0 ),
        .I1(pixel_x[9]),
        .I2(\rgb_out[11]_i_11_n_0 ),
        .I3(\rgb_out[23]_i_393_n_0 ),
        .I4(pixel_x[5]),
        .I5(pixel_x[6]),
        .O(\rgb_out[23]_i_141_n_0 ));
  LUT6 #(
    .INIT(64'h01000F0000000000)) 
    \rgb_out[23]_i_142 
       (.I0(pixel_x[5]),
        .I1(\rgb_out[23]_i_230_n_0 ),
        .I2(\rgb_out[20]_i_24_n_0 ),
        .I3(\rgb_out[11]_i_11_n_0 ),
        .I4(\rgb_out[23]_i_300_n_0 ),
        .I5(\rgb_out[20]_i_23_n_0 ),
        .O(\rgb_out[23]_i_142_n_0 ));
  LUT5 #(
    .INIT(32'h00020000)) 
    \rgb_out[23]_i_143 
       (.I0(\rgb_out[11]_i_11_n_0 ),
        .I1(\rgb_out[20]_i_24_n_0 ),
        .I2(pixel_x[3]),
        .I3(\rgb_out[23]_i_233_n_0 ),
        .I4(\rgb_out[20]_i_23_n_0 ),
        .O(\rgb_out[23]_i_143_n_0 ));
  LUT6 #(
    .INIT(64'h1000000000000000)) 
    \rgb_out[23]_i_144 
       (.I0(pixel_x[2]),
        .I1(\rgb_out[23]_i_394_n_0 ),
        .I2(pixel_x[5]),
        .I3(pixel_x[4]),
        .I4(pixel_x[3]),
        .I5(\rgb_out[20]_i_23_n_0 ),
        .O(\rgb_out[23]_i_144_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair66" *) 
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_145 
       (.I0(\rgb_out[20]_i_10_n_0 ),
        .I1(\rgb_out[23]_i_252_n_0 ),
        .O(\rgb_out[23]_i_145_n_0 ));
  LUT5 #(
    .INIT(32'hAAAAA8AA)) 
    \rgb_out[23]_i_146 
       (.I0(\rgb_out[23]_i_87_n_0 ),
        .I1(\rgb_out[23]_i_269_n_0 ),
        .I2(\rgb_out[23]_i_395_n_0 ),
        .I3(\rgb_out[23]_i_231_n_0 ),
        .I4(\rgb_out[23]_i_261_n_0 ),
        .O(\rgb_out[23]_i_146_n_0 ));
  LUT6 #(
    .INIT(64'hAAAAAAAA2AAA2A0A)) 
    \rgb_out[23]_i_147 
       (.I0(\rgb_out[23]_i_252_n_0 ),
        .I1(\rgb_out[20]_i_18_n_0 ),
        .I2(\rgb_out[23]_i_396_n_0 ),
        .I3(\rgb_out[23]_i_71_n_0 ),
        .I4(\rgb_out[7]_i_42_n_0 ),
        .I5(\rgb_out[23]_i_397_n_0 ),
        .O(\rgb_out[23]_i_147_n_0 ));
  LUT6 #(
    .INIT(64'hF7F7F7F7F7F3F700)) 
    \rgb_out[23]_i_148 
       (.I0(\rgb_out[23]_i_150_n_0 ),
        .I1(\rgb_out[23]_i_396_n_0 ),
        .I2(\rgb_out[23]_i_261_n_0 ),
        .I3(\rgb_out[20]_i_14_n_0 ),
        .I4(\rgb_out[23]_i_151_n_0 ),
        .I5(\rgb_out[20]_i_13_n_0 ),
        .O(\rgb_out[23]_i_148_n_0 ));
  LUT5 #(
    .INIT(32'hFFF88888)) 
    \rgb_out[23]_i_149 
       (.I0(\rgb_out[23]_i_398_n_0 ),
        .I1(\rgb_out[23]_i_241_n_0 ),
        .I2(\rgb_out[23]_i_399_n_0 ),
        .I3(\rgb_out[23]_i_240_n_0 ),
        .I4(\rgb_out[23]_i_262_n_0 ),
        .O(\rgb_out[23]_i_149_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000000002)) 
    \rgb_out[23]_i_15 
       (.I0(\rgb_out[23]_i_46_n_0 ),
        .I1(\rgb_out[23]_i_47_n_0 ),
        .I2(\rgb_out[23]_i_48_n_0 ),
        .I3(\rgb_out[23]_i_49_n_0 ),
        .I4(\rgb_out[23]_i_50_n_0 ),
        .I5(\rgb_out[23]_i_51_n_0 ),
        .O(\rgb_out[23]_i_15_n_0 ));
  LUT6 #(
    .INIT(64'h5555555555554555)) 
    \rgb_out[23]_i_150 
       (.I0(\rgb_out[23]_i_400_n_0 ),
        .I1(\rgb_out[20]_i_20_n_0 ),
        .I2(\rgb_out[23]_i_401_n_0 ),
        .I3(\rgb_out[23]_i_380_n_0 ),
        .I4(pixel_x[5]),
        .I5(\rgb_out[20]_i_19_n_0 ),
        .O(\rgb_out[23]_i_150_n_0 ));
  LUT6 #(
    .INIT(64'h0004000000000400)) 
    \rgb_out[23]_i_151 
       (.I0(\rgb_out[21]_i_6_n_0 ),
        .I1(\rgb_out[23]_i_40_n_0 ),
        .I2(\rgb_out[11]_i_24_n_0 ),
        .I3(pixel_y[3]),
        .I4(pixel_y[1]),
        .I5(pixel_y[2]),
        .O(\rgb_out[23]_i_151_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000000002)) 
    \rgb_out[23]_i_152 
       (.I0(\rgb_out[23]_i_402_n_0 ),
        .I1(\rgb_out[23]_i_403_n_0 ),
        .I2(\rgb_out[23]_i_404_n_0 ),
        .I3(\rgb_out[23]_i_405_n_0 ),
        .I4(\rgb_out[23]_i_406_n_0 ),
        .I5(\rgb_out[23]_i_407_n_0 ),
        .O(\rgb_out[23]_i_152_n_0 ));
  LUT6 #(
    .INIT(64'h8888800000000000)) 
    \rgb_out[23]_i_153 
       (.I0(\rgb_out[23]_i_408_n_0 ),
        .I1(\rgb_out[23]_i_135_n_0 ),
        .I2(pixel_y[1]),
        .I3(pixel_y[2]),
        .I4(pixel_y[3]),
        .I5(pixel_y[4]),
        .O(\rgb_out[23]_i_153_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFF00000200)) 
    \rgb_out[23]_i_154 
       (.I0(\rgb_out[23]_i_137_n_0 ),
        .I1(pixel_y[3]),
        .I2(pixel_y[4]),
        .I3(pixel_y[5]),
        .I4(\rgb_out[23]_i_409_n_0 ),
        .I5(\rgb_out[23]_i_179_n_0 ),
        .O(\rgb_out[23]_i_154_n_0 ));
  LUT6 #(
    .INIT(64'h000000000000FFAB)) 
    \rgb_out[23]_i_155 
       (.I0(\rgb_out[23]_i_159_n_0 ),
        .I1(\rgb_out[23]_i_156_n_0 ),
        .I2(\rgb_out[23]_i_179_n_0 ),
        .I3(\rgb_out[23]_i_410_n_0 ),
        .I4(\rgb_out[23]_i_411_n_0 ),
        .I5(\rgb_out[23]_i_412_n_0 ),
        .O(\rgb_out[23]_i_155_n_0 ));
  LUT6 #(
    .INIT(64'h0800000000000000)) 
    \rgb_out[23]_i_156 
       (.I0(pixel_y[1]),
        .I1(\rgb_out[23]_i_408_n_0 ),
        .I2(pixel_y[2]),
        .I3(pixel_y[3]),
        .I4(pixel_y[4]),
        .I5(\rgb_out[23]_i_135_n_0 ),
        .O(\rgb_out[23]_i_156_n_0 ));
  LUT6 #(
    .INIT(64'h0000000007000707)) 
    \rgb_out[23]_i_157 
       (.I0(\rgb_out[23]_i_156_n_0 ),
        .I1(\rgb_out[23]_i_407_n_0 ),
        .I2(\rgb_out[23]_i_413_n_0 ),
        .I3(\rgb_out[23]_i_414_n_0 ),
        .I4(\rgb_out[23]_i_415_n_0 ),
        .I5(\rgb_out[23]_i_416_n_0 ),
        .O(\rgb_out[23]_i_157_n_0 ));
  LUT6 #(
    .INIT(64'hFFFF10F010F010F0)) 
    \rgb_out[23]_i_158 
       (.I0(\rgb_out[23]_i_417_n_0 ),
        .I1(\rgb_out[23]_i_418_n_0 ),
        .I2(\rgb_out[23]_i_419_n_0 ),
        .I3(\rgb_out[23]_i_420_n_0 ),
        .I4(\rgb_out[23]_i_416_n_0 ),
        .I5(\rgb_out[23]_i_421_n_0 ),
        .O(\rgb_out[23]_i_158_n_0 ));
  LUT6 #(
    .INIT(64'h0001000F0F0F0F0F)) 
    \rgb_out[23]_i_159 
       (.I0(\rgb_out[23]_i_226_n_0 ),
        .I1(pixel_x[7]),
        .I2(pixel_x[11]),
        .I3(pixel_x[9]),
        .I4(pixel_x[8]),
        .I5(pixel_x[10]),
        .O(\rgb_out[23]_i_159_n_0 ));
  LUT6 #(
    .INIT(64'hAAAAAAA8AAAAAAAA)) 
    \rgb_out[23]_i_16 
       (.I0(\rgb_out[7]_i_8_n_0 ),
        .I1(\rgb_out[7]_i_7_n_0 ),
        .I2(\rgb_out[23]_i_52_n_0 ),
        .I3(\rgb_out[23]_i_53_n_0 ),
        .I4(\rgb_out[7]_i_5_n_0 ),
        .I5(\rgb_out[7]_i_4_n_0 ),
        .O(\rgb_out[23]_i_16_n_0 ));
  LUT6 #(
    .INIT(64'h00000000FFFF2A22)) 
    \rgb_out[23]_i_160 
       (.I0(\rgb_out[23]_i_422_n_0 ),
        .I1(\rgb_out[23]_i_423_n_0 ),
        .I2(\rgb_out[23]_i_424_n_0 ),
        .I3(\rgb_out[23]_i_425_n_0 ),
        .I4(\rgb_out[23]_i_426_n_0 ),
        .I5(\rgb_out[23]_i_427_n_0 ),
        .O(\rgb_out[23]_i_160_n_0 ));
  LUT6 #(
    .INIT(64'h80AA8080AAAAAAAA)) 
    \rgb_out[23]_i_161 
       (.I0(\rgb_out[23]_i_428_n_0 ),
        .I1(\rgb_out[23]_i_173_n_0 ),
        .I2(\rgb_out[23]_i_424_n_0 ),
        .I3(\rgb_out[23]_i_429_n_0 ),
        .I4(\rgb_out[23]_i_430_n_0 ),
        .I5(\rgb_out[23]_i_431_n_0 ),
        .O(\rgb_out[23]_i_161_n_0 ));
  LUT3 #(
    .INIT(8'hFE)) 
    \rgb_out[23]_i_162 
       (.I0(\rgb_out[23]_i_179_n_0 ),
        .I1(\rgb_out[23]_i_432_n_0 ),
        .I2(\rgb_out[23]_i_156_n_0 ),
        .O(\rgb_out[23]_i_162_n_0 ));
  LUT6 #(
    .INIT(64'hBFBFBFBB80808088)) 
    \rgb_out[23]_i_163 
       (.I0(\rgb_out[23]_i_433_n_0 ),
        .I1(\rgb_out[23]_i_352_n_0 ),
        .I2(\rgb_out[23]_i_434_n_0 ),
        .I3(\rgb_out[23]_i_334_n_0 ),
        .I4(\rgb_out[23]_i_233_n_0 ),
        .I5(\rgb_out[23]_i_435_n_0 ),
        .O(\rgb_out[23]_i_163_n_0 ));
  LUT6 #(
    .INIT(64'h8000000000000000)) 
    \rgb_out[23]_i_164 
       (.I0(pixel_x[2]),
        .I1(pixel_x[1]),
        .I2(pixel_x[3]),
        .I3(pixel_x[6]),
        .I4(\rgb_out[23]_i_436_n_0 ),
        .I5(\rgb_out[23]_i_437_n_0 ),
        .O(\rgb_out[23]_i_164_n_0 ));
  LUT4 #(
    .INIT(16'h8000)) 
    \rgb_out[23]_i_165 
       (.I0(\pixel_x[1]_6 ),
        .I1(\pixel_y[2]_9 ),
        .I2(\pixel_x[1]_7 ),
        .I3(\pixel_y[2]_10 ),
        .O(\rgb_out[23]_i_165_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFEFEE)) 
    \rgb_out[23]_i_166 
       (.I0(\rgb_out[23]_i_442_n_0 ),
        .I1(\rgb_out[23]_i_443_n_0 ),
        .I2(\rgb_out[23]_i_444_n_0 ),
        .I3(\rgb_out[23]_i_445_n_0 ),
        .I4(\rgb_out[23]_i_446_n_0 ),
        .I5(\rgb_out[23]_i_447_n_0 ),
        .O(\SC_U/pixel_on0 ));
  LUT6 #(
    .INIT(64'h00000000EAEEEAEA)) 
    \rgb_out[23]_i_167 
       (.I0(\rgb_out[23]_i_448_n_0 ),
        .I1(\rgb_out[23]_i_449_n_0 ),
        .I2(\pixel_x[1] ),
        .I3(score_diz),
        .I4(\pixel_x[5] ),
        .I5(\rgb_out[23]_i_453_n_0 ),
        .O(num_sc_d));
  LUT6 #(
    .INIT(64'h2000000000000000)) 
    \rgb_out[23]_i_168 
       (.I0(\rgb_out[23]_i_454_n_0 ),
        .I1(\rgb_out[23]_i_455_n_0 ),
        .I2(pixel_y[1]),
        .I3(pixel_y[2]),
        .I4(pixel_y[3]),
        .I5(pixel_y[4]),
        .O(\rgb_out[23]_i_168_n_0 ));
  LUT3 #(
    .INIT(8'h8A)) 
    \rgb_out[23]_i_169 
       (.I0(\rgb_out[23]_i_456_n_0 ),
        .I1(\rgb_out[23]_i_457_n_0 ),
        .I2(\rgb_out[23]_i_431_n_0 ),
        .O(\rgb_out[23]_i_169_n_0 ));
  LUT6 #(
    .INIT(64'hABABAB00ABABABAB)) 
    \rgb_out[23]_i_170 
       (.I0(\rgb_out[23]_i_458_n_0 ),
        .I1(\rgb_out[23]_i_224_n_0 ),
        .I2(\rgb_out[23]_i_390_n_0 ),
        .I3(\rgb_out[23]_i_223_n_0 ),
        .I4(\rgb_out[23]_i_233_n_0 ),
        .I5(\rgb_out[23]_i_174_n_0 ),
        .O(\rgb_out[23]_i_170_n_0 ));
  LUT6 #(
    .INIT(64'h80808000AAAAAAAA)) 
    \rgb_out[23]_i_171 
       (.I0(\rgb_out[23]_i_431_n_0 ),
        .I1(pixel_x[3]),
        .I2(pixel_x[6]),
        .I3(pixel_x[2]),
        .I4(pixel_x[1]),
        .I5(\rgb_out[23]_i_430_n_0 ),
        .O(\rgb_out[23]_i_171_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair29" *) 
  LUT5 #(
    .INIT(32'h00008000)) 
    \rgb_out[23]_i_172 
       (.I0(pixel_y[4]),
        .I1(pixel_y[3]),
        .I2(pixel_y[2]),
        .I3(pixel_y[1]),
        .I4(\rgb_out[23]_i_455_n_0 ),
        .O(\rgb_out[23]_i_172_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000000004)) 
    \rgb_out[23]_i_173 
       (.I0(pixel_x[9]),
        .I1(\rgb_out[11]_i_11_n_0 ),
        .I2(pixel_x[7]),
        .I3(pixel_x[8]),
        .I4(pixel_x[6]),
        .I5(pixel_x[5]),
        .O(\rgb_out[23]_i_173_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000000001)) 
    \rgb_out[23]_i_174 
       (.I0(pixel_x[7]),
        .I1(pixel_x[11]),
        .I2(pixel_x[10]),
        .I3(pixel_x[9]),
        .I4(pixel_x[8]),
        .I5(pixel_x[6]),
        .O(\rgb_out[23]_i_174_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair96" *) 
  LUT3 #(
    .INIT(8'h80)) 
    \rgb_out[23]_i_175 
       (.I0(pixel_x[5]),
        .I1(pixel_x[2]),
        .I2(pixel_x[1]),
        .O(\rgb_out[23]_i_175_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair100" *) 
  LUT3 #(
    .INIT(8'hA8)) 
    \rgb_out[23]_i_176 
       (.I0(pixel_x[5]),
        .I1(pixel_x[4]),
        .I2(pixel_x[3]),
        .O(\rgb_out[23]_i_176_n_0 ));
  LUT6 #(
    .INIT(64'hCCCFCCCF888F8888)) 
    \rgb_out[23]_i_177 
       (.I0(\rgb_out[23]_i_456_n_0 ),
        .I1(\rgb_out[23]_i_454_n_0 ),
        .I2(\rgb_out[23]_i_459_n_0 ),
        .I3(\rgb_out[23]_i_435_n_0 ),
        .I4(\rgb_out[23]_i_432_n_0 ),
        .I5(\rgb_out[23]_i_421_n_0 ),
        .O(\rgb_out[23]_i_177_n_0 ));
  LUT6 #(
    .INIT(64'hBF00BFBFBFBFBFBF)) 
    \rgb_out[23]_i_178 
       (.I0(\rgb_out[23]_i_460_n_0 ),
        .I1(\rgb_out[23]_i_423_n_0 ),
        .I2(\rgb_out[23]_i_461_n_0 ),
        .I3(\rgb_out[23]_i_462_n_0 ),
        .I4(\rgb_out[23]_i_179_n_0 ),
        .I5(\rgb_out[23]_i_463_n_0 ),
        .O(\rgb_out[23]_i_178_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair29" *) 
  LUT5 #(
    .INIT(32'h00100000)) 
    \rgb_out[23]_i_179 
       (.I0(\rgb_out[23]_i_455_n_0 ),
        .I1(pixel_y[3]),
        .I2(pixel_y[4]),
        .I3(pixel_y[1]),
        .I4(pixel_y[2]),
        .O(\rgb_out[23]_i_179_n_0 ));
  LUT6 #(
    .INIT(64'h00000000D5550000)) 
    \rgb_out[23]_i_180 
       (.I0(\rgb_out[23]_i_430_n_0 ),
        .I1(\rgb_out[11]_i_22_n_0 ),
        .I2(pixel_x[6]),
        .I3(pixel_x[3]),
        .I4(\rgb_out[23]_i_431_n_0 ),
        .I5(\rgb_out[23]_i_464_n_0 ),
        .O(\rgb_out[23]_i_180_n_0 ));
  LUT6 #(
    .INIT(64'hD5555555FFFFFFFF)) 
    \rgb_out[23]_i_181 
       (.I0(\rgb_out[23]_i_465_n_0 ),
        .I1(\rgb_out[23]_i_466_n_0 ),
        .I2(\rgb_out[23]_i_346_n_0 ),
        .I3(\rgb_out[20]_i_23_n_0 ),
        .I4(pixel_x[5]),
        .I5(\rgb_out[23]_i_390_n_0 ),
        .O(\rgb_out[23]_i_181_n_0 ));
  LUT5 #(
    .INIT(32'h55105555)) 
    \rgb_out[23]_i_182 
       (.I0(\rgb_out[23]_i_378_n_0 ),
        .I1(\rgb_out[23]_i_379_n_0 ),
        .I2(\rgb_out[23]_i_390_n_0 ),
        .I3(\rgb_out[23]_i_467_n_0 ),
        .I4(\rgb_out[23]_i_387_n_0 ),
        .O(\rgb_out[23]_i_182_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_183 
       (.I0(\rgb_out[23]_i_124_n_0 ),
        .I1(\rgb_out[23]_i_131_n_0 ),
        .O(\rgb_out[23]_i_183_n_0 ));
  LUT6 #(
    .INIT(64'h0040404000400040)) 
    \rgb_out[23]_i_184 
       (.I0(\rgb_out[20]_i_22_n_0 ),
        .I1(\rgb_out[20]_i_23_n_0 ),
        .I2(\rgb_out[11]_i_11_n_0 ),
        .I3(\rgb_out[23]_i_468_n_0 ),
        .I4(\rgb_out[23]_i_223_n_0 ),
        .I5(pixel_x[0]),
        .O(\rgb_out[23]_i_184_n_0 ));
  LUT6 #(
    .INIT(64'h000A000A00030000)) 
    \rgb_out[23]_i_185 
       (.I0(\rgb_out[20]_i_22_n_0 ),
        .I1(\rgb_out[20]_i_19_n_0 ),
        .I2(pixel_x[5]),
        .I3(\rgb_out[20]_i_20_n_0 ),
        .I4(\rgb_out[23]_i_382_n_0 ),
        .I5(\rgb_out[23]_i_469_n_0 ),
        .O(\rgb_out[23]_i_185_n_0 ));
  LUT3 #(
    .INIT(8'hFE)) 
    \rgb_out[23]_i_186 
       (.I0(\rgb_out[7]_i_47_n_0 ),
        .I1(\rgb_out[23]_i_129_n_0 ),
        .I2(\rgb_out[23]_i_79_n_0 ),
        .O(\rgb_out[23]_i_186_n_0 ));
  LUT5 #(
    .INIT(32'hE0000000)) 
    \rgb_out[23]_i_187 
       (.I0(\pixel_y[2]_13 ),
        .I1(\pixel_y[5]_2 ),
        .I2(\rgb_out[23]_i_190_n_0 ),
        .I3(\TM_D/pixel_on9 ),
        .I4(\pixel_x[3]_2 ),
        .O(\rgb_out[23]_i_187_n_0 ));
  LUT4 #(
    .INIT(16'hF888)) 
    \rgb_out[23]_i_188 
       (.I0(\pixel_y[5]_3 ),
        .I1(\pixel_y[2]_14 ),
        .I2(\pixel_y[2]_15 ),
        .I3(\pixel_y[2]_16 ),
        .O(\rgb_out[23]_i_188_n_0 ));
  LUT6 #(
    .INIT(64'h00000000000008AA)) 
    \rgb_out[23]_i_19 
       (.I0(\rgb_out[23]_i_65_n_0 ),
        .I1(\rgb_out[23]_i_66_n_0 ),
        .I2(\rgb_out[23]_i_67_n_0 ),
        .I3(pixel_y[9]),
        .I4(\rgb_out[23]_i_68_n_0 ),
        .I5(\rgb_out[23]_i_69_n_0 ),
        .O(\rgb_out[23]_i_19_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair45" *) 
  LUT3 #(
    .INIT(8'h57)) 
    \rgb_out[23]_i_190 
       (.I0(temps_restant[3]),
        .I1(temps_restant[1]),
        .I2(temps_restant[2]),
        .O(\rgb_out[23]_i_190_n_0 ));
  LUT4 #(
    .INIT(16'h7FFF)) 
    \rgb_out[23]_i_192 
       (.I0(\pixel_y[2]_11 ),
        .I1(\pixel_x[3]_0 ),
        .I2(\pixel_y[2]_12 ),
        .I3(\pixel_x[3]_1 ),
        .O(\rgb_out[23]_i_192_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1928 
       (.I0(local_x_0[6]),
        .I1(local_x_0[7]),
        .O(\rgb_out[23]_i_1928_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_1929 
       (.I0(local_x_0[5]),
        .I1(local_x_0[4]),
        .O(\rgb_out[23]_i_1929_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_1930 
       (.I0(local_x_0[0]),
        .I1(local_x_0[1]),
        .O(\rgb_out[23]_i_1930_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1931 
       (.I0(local_x_0[7]),
        .I1(local_x_0[6]),
        .O(\rgb_out[23]_i_1931_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_1932 
       (.I0(local_x_0[4]),
        .I1(local_x_0[5]),
        .O(\rgb_out[23]_i_1932_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1933 
       (.I0(local_x_0[2]),
        .I1(local_x_0[3]),
        .O(\rgb_out[23]_i_1933_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_1934 
       (.I0(local_x_0[1]),
        .I1(local_x_0[0]),
        .O(\rgb_out[23]_i_1934_n_0 ));
  LUT6 #(
    .INIT(64'h8888808888808888)) 
    \rgb_out[23]_i_195 
       (.I0(pixel_on75_in),
        .I1(pixel_on66_in),
        .I2(temps_restant[0]),
        .I3(temps_restant[3]),
        .I4(temps_restant[1]),
        .I5(temps_restant[2]),
        .O(\rgb_out[23]_i_195_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair41" *) 
  LUT4 #(
    .INIT(16'h9200)) 
    \rgb_out[23]_i_196 
       (.I0(temps_restant[0]),
        .I1(temps_restant[3]),
        .I2(temps_restant[1]),
        .I3(temps_restant[2]),
        .O(\rgb_out[23]_i_196_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair92" *) 
  LUT4 #(
    .INIT(16'hF7FF)) 
    \rgb_out[23]_i_199 
       (.I0(pixel_on75_in),
        .I1(pixel_on66_in),
        .I2(temps_restant[0]),
        .I3(pixel_on6),
        .O(\rgb_out[23]_i_199_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_1999 
       (.I0(pixel_y[11]),
        .O(\rgb_out[23]_i_1999_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFAABA)) 
    \rgb_out[23]_i_20 
       (.I0(\rgb_out[23]_i_70_n_0 ),
        .I1(\rgb_out[23]_i_71_n_0 ),
        .I2(\rgb_out[23]_i_72_n_0 ),
        .I3(\rgb_out[20]_i_9_n_0 ),
        .I4(\rgb_out[23]_i_73_n_0 ),
        .I5(\rgb_out[23]_i_74_n_0 ),
        .O(\rgb_out[23]_i_20_n_0 ));
  LUT3 #(
    .INIT(8'h80)) 
    \rgb_out[23]_i_200 
       (.I0(pixel_on6),
        .I1(pixel_on83_in),
        .I2(pixel_on7),
        .O(\rgb_out[23]_i_200_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_2000 
       (.I0(pixel_y[10]),
        .O(\rgb_out[23]_i_2000_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_2001 
       (.I0(pixel_y[9]),
        .O(\rgb_out[23]_i_2001_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_2009 
       (.I0(local_x[6]),
        .I1(local_x[7]),
        .O(\rgb_out[23]_i_2009_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_2010 
       (.I0(local_x[4]),
        .I1(local_x[5]),
        .O(\rgb_out[23]_i_2010_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_2012 
       (.I0(local_x[0]),
        .I1(local_x[1]),
        .O(\rgb_out[23]_i_2012_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_2013 
       (.I0(local_x[7]),
        .I1(local_x[6]),
        .O(\rgb_out[23]_i_2013_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_2014 
       (.I0(local_x[5]),
        .I1(local_x[4]),
        .O(\rgb_out[23]_i_2014_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_2015 
       (.I0(local_x[2]),
        .I1(local_x[3]),
        .O(\rgb_out[23]_i_2015_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_2016 
       (.I0(local_x[1]),
        .I1(local_x[0]),
        .O(\rgb_out[23]_i_2016_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair41" *) 
  LUT5 #(
    .INIT(32'h82A82AA2)) 
    \rgb_out[23]_i_202 
       (.I0(pixel_on5),
        .I1(temps_restant[0]),
        .I2(temps_restant[3]),
        .I3(temps_restant[1]),
        .I4(temps_restant[2]),
        .O(\rgb_out[23]_i_202_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_2024 
       (.I0(local_y[5]),
        .I1(local_y[6]),
        .O(\rgb_out[23]_i_2024_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_2025 
       (.I0(local_y[3]),
        .I1(local_y[4]),
        .O(\rgb_out[23]_i_2025_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_2026 
       (.I0(pixel_y[0]),
        .I1(local_y[0]),
        .O(\rgb_out[23]_i_2026_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_2027 
       (.I0(local_y[6]),
        .I1(local_y[5]),
        .O(\rgb_out[23]_i_2027_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_2028 
       (.I0(local_y[4]),
        .I1(local_y[3]),
        .O(\rgb_out[23]_i_2028_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_2029 
       (.I0(local_y[1]),
        .I1(local_y[2]),
        .O(\rgb_out[23]_i_2029_n_0 ));
  LUT6 #(
    .INIT(64'h8088088080888880)) 
    \rgb_out[23]_i_203 
       (.I0(pixel_on31_in),
        .I1(pixel_on22_in),
        .I2(temps_restant[2]),
        .I3(temps_restant[1]),
        .I4(temps_restant[3]),
        .I5(temps_restant[0]),
        .O(\rgb_out[23]_i_203_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_2030 
       (.I0(local_y[0]),
        .I1(pixel_y[0]),
        .O(\rgb_out[23]_i_2030_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_2031 
       (.I0(local_y[4]),
        .I1(local_y[3]),
        .O(\rgb_out[23]_i_2031_n_0 ));
  LUT2 #(
    .INIT(4'h7)) 
    \rgb_out[23]_i_2032 
       (.I0(local_y[1]),
        .I1(local_y[2]),
        .O(\rgb_out[23]_i_2032_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_2033 
       (.I0(local_y[0]),
        .O(\rgb_out[23]_i_2033_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_2034 
       (.I0(local_y[6]),
        .I1(local_y[5]),
        .O(\rgb_out[23]_i_2034_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_2035 
       (.I0(local_y[3]),
        .I1(local_y[4]),
        .O(\rgb_out[23]_i_2035_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_2036 
       (.I0(local_y[2]),
        .I1(local_y[1]),
        .O(\rgb_out[23]_i_2036_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_2037 
       (.I0(local_y[0]),
        .I1(pixel_y[0]),
        .O(\rgb_out[23]_i_2037_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair45" *) 
  LUT5 #(
    .INIT(32'h7557D55D)) 
    \rgb_out[23]_i_204 
       (.I0(pixel_on712_in),
        .I1(temps_restant[0]),
        .I2(temps_restant[3]),
        .I3(temps_restant[1]),
        .I4(temps_restant[2]),
        .O(\rgb_out[23]_i_204_n_0 ));
  LUT2 #(
    .INIT(4'h7)) 
    \rgb_out[23]_i_2044 
       (.I0(local_y[3]),
        .I1(local_y[4]),
        .O(\rgb_out[23]_i_2044_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_2045 
       (.I0(local_y[2]),
        .I1(local_y[1]),
        .O(\rgb_out[23]_i_2045_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_2046 
       (.I0(local_y[0]),
        .O(\rgb_out[23]_i_2046_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_2047 
       (.I0(local_y[6]),
        .I1(local_y[5]),
        .O(\rgb_out[23]_i_2047_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_2048 
       (.I0(local_y[4]),
        .I1(local_y[3]),
        .O(\rgb_out[23]_i_2048_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_2049 
       (.I0(local_y[1]),
        .I1(local_y[2]),
        .O(\rgb_out[23]_i_2049_n_0 ));
  LUT6 #(
    .INIT(64'h2A000000FFFFFFFF)) 
    \rgb_out[23]_i_205 
       (.I0(\rgb_out[23]_i_521_n_0 ),
        .I1(\rgb_out[23]_i_522_n_0 ),
        .I2(\rgb_out[23]_i_523_n_0 ),
        .I3(\rgb_out[23]_i_524_n_0 ),
        .I4(\rgb_out[23]_i_525_n_0 ),
        .I5(\rgb_out[23]_i_526_n_0 ),
        .O(\rgb_out[23]_i_205_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_2050 
       (.I0(local_y[0]),
        .I1(pixel_y[0]),
        .O(\rgb_out[23]_i_2050_n_0 ));
  LUT6 #(
    .INIT(64'h0000FFBAFFBAFFBA)) 
    \rgb_out[23]_i_206 
       (.I0(\rgb_out[23]_i_527_n_0 ),
        .I1(\rgb_out[23]_i_528_n_0 ),
        .I2(\rgb_out[23]_i_529_n_0 ),
        .I3(\rgb_out[23]_i_530_n_0 ),
        .I4(\rgb_out[23]_i_531_n_0 ),
        .I5(\rgb_out[23]_i_524_n_0 ),
        .O(\rgb_out[23]_i_206_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFD0D0FFD0)) 
    \rgb_out[23]_i_207 
       (.I0(\rgb_out[23]_i_521_n_0 ),
        .I1(\rgb_out[23]_i_532_n_0 ),
        .I2(\rgb_out[23]_i_530_n_0 ),
        .I3(\rgb_out[23]_i_533_n_0 ),
        .I4(\rgb_out[23]_i_531_n_0 ),
        .I5(\rgb_out[23]_i_61_n_0 ),
        .O(\rgb_out[23]_i_207_n_0 ));
  LUT6 #(
    .INIT(64'hAAAAAAAA88888A88)) 
    \rgb_out[23]_i_208 
       (.I0(\rgb_out[23]_i_532_n_0 ),
        .I1(\rgb_out[23]_i_533_n_0 ),
        .I2(\rgb_out[23]_i_528_n_0 ),
        .I3(\rgb_out[11]_i_25_n_0 ),
        .I4(\rgb_out[21]_i_6_n_0 ),
        .I5(\rgb_out[23]_i_526_n_0 ),
        .O(\rgb_out[23]_i_208_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFEEEEEFEE)) 
    \rgb_out[23]_i_209 
       (.I0(\rgb_out[23]_i_533_n_0 ),
        .I1(\rgb_out[23]_i_527_n_0 ),
        .I2(\rgb_out[23]_i_528_n_0 ),
        .I3(\rgb_out[11]_i_25_n_0 ),
        .I4(\rgb_out[21]_i_6_n_0 ),
        .I5(\rgb_out[23]_i_530_n_0 ),
        .O(\rgb_out[23]_i_209_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_21 
       (.I0(\rgb_out[7]_i_19_n_0 ),
        .I1(\rgb_out[23]_i_75_n_0 ),
        .O(\rgb_out[23]_i_21_n_0 ));
  LUT6 #(
    .INIT(64'hEEFEEEFEEEFE0000)) 
    \rgb_out[23]_i_210 
       (.I0(pixel_x[11]),
        .I1(\rgb_out[23]_i_534_n_0 ),
        .I2(pixel_x[10]),
        .I3(\rgb_out[23]_i_535_n_0 ),
        .I4(\rgb_out[23]_i_536_n_0 ),
        .I5(\rgb_out[23]_i_537_n_0 ),
        .O(\rgb_out[23]_i_210_n_0 ));
  LUT6 #(
    .INIT(64'h8880808888888888)) 
    \rgb_out[23]_i_211 
       (.I0(pixel_on83_in),
        .I1(pixel_on7),
        .I2(decompte_ui[3]),
        .I3(decompte_ui[0]),
        .I4(decompte_ui[1]),
        .I5(decompte_ui[2]),
        .O(\rgb_out[23]_i_211_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair92" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_212 
       (.I0(pixel_on66_in),
        .I1(pixel_on75_in),
        .O(\rgb_out[23]_i_212_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_2125 
       (.I0(pixel_y[8]),
        .O(\rgb_out[23]_i_2125_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_2126 
       (.I0(pixel_y[7]),
        .O(\rgb_out[23]_i_2126_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_2127 
       (.I0(pixel_y[6]),
        .O(\rgb_out[23]_i_2127_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_2128 
       (.I0(pixel_y[5]),
        .O(\rgb_out[23]_i_2128_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_2129 
       (.I0(pixel_y[4]),
        .O(\rgb_out[23]_i_2129_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair42" *) 
  LUT5 #(
    .INIT(32'h00101010)) 
    \rgb_out[23]_i_213 
       (.I0(decompte_ui[0]),
        .I1(decompte_ui[1]),
        .I2(decompte_ui[2]),
        .I3(pixel_on22_in),
        .I4(pixel_on31_in),
        .O(\rgb_out[23]_i_213_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \rgb_out[23]_i_2130 
       (.I0(pixel_y[2]),
        .O(\rgb_out[23]_i_2130_n_0 ));
  LUT6 #(
    .INIT(64'h00000000000000F1)) 
    \rgb_out[23]_i_214 
       (.I0(pixel_on5),
        .I1(pixel_on712_in),
        .I2(decompte_ui[0]),
        .I3(decompte_ui[3]),
        .I4(decompte_ui[2]),
        .I5(decompte_ui[1]),
        .O(\rgb_out[23]_i_214_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair82" *) 
  LUT4 #(
    .INIT(16'hF7FF)) 
    \rgb_out[23]_i_215 
       (.I0(decompte_ui[0]),
        .I1(decompte_ui[1]),
        .I2(pixel_on712_in),
        .I3(decompte_ui[2]),
        .O(\rgb_out[23]_i_215_n_0 ));
  LUT6 #(
    .INIT(64'h0800080000000800)) 
    \rgb_out[23]_i_217 
       (.I0(pixel_on75_in),
        .I1(pixel_on66_in),
        .I2(decompte_ui[0]),
        .I3(pixel_on6),
        .I4(decompte_ui[2]),
        .I5(decompte_ui[1]),
        .O(\rgb_out[23]_i_217_n_0 ));
  LUT6 #(
    .INIT(64'h8080800080808080)) 
    \rgb_out[23]_i_218 
       (.I0(pixel_on7),
        .I1(pixel_on83_in),
        .I2(pixel_on6),
        .I3(decompte_ui[3]),
        .I4(\rgb_out[23]_i_538_n_0 ),
        .I5(\rgb_out[23]_i_539_n_0 ),
        .O(\rgb_out[23]_i_218_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair123" *) 
  LUT3 #(
    .INIT(8'h01)) 
    \rgb_out[23]_i_219 
       (.I0(pixel_x[10]),
        .I1(pixel_x[11]),
        .I2(pixel_x[9]),
        .O(\rgb_out[23]_i_219_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair65" *) 
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_22 
       (.I0(\rgb_out[23]_i_76_n_0 ),
        .I1(\rgb_out[23]_i_77_n_0 ),
        .O(\rgb_out[23]_i_22_n_0 ));
  LUT6 #(
    .INIT(64'h0002000200020202)) 
    \rgb_out[23]_i_220 
       (.I0(\rgb_out[23]_i_540_n_0 ),
        .I1(pixel_y[5]),
        .I2(pixel_y[4]),
        .I3(pixel_y[3]),
        .I4(pixel_y[1]),
        .I5(pixel_y[2]),
        .O(\rgb_out[23]_i_220_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair123" *) 
  LUT3 #(
    .INIT(8'h01)) 
    \rgb_out[23]_i_221 
       (.I0(pixel_x[10]),
        .I1(pixel_x[11]),
        .I2(pixel_x[7]),
        .O(\rgb_out[23]_i_221_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair80" *) 
  LUT3 #(
    .INIT(8'h80)) 
    \rgb_out[23]_i_222 
       (.I0(pixel_x[3]),
        .I1(pixel_x[4]),
        .I2(pixel_x[5]),
        .O(\rgb_out[23]_i_222_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair96" *) 
  LUT2 #(
    .INIT(4'h7)) 
    \rgb_out[23]_i_223 
       (.I0(pixel_x[1]),
        .I1(pixel_x[2]),
        .O(\rgb_out[23]_i_223_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair118" *) 
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_224 
       (.I0(pixel_x[9]),
        .I1(pixel_x[8]),
        .O(\rgb_out[23]_i_224_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair133" *) 
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_225 
       (.I0(pixel_x[3]),
        .I1(pixel_x[4]),
        .O(\rgb_out[23]_i_225_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair131" *) 
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_226 
       (.I0(pixel_x[6]),
        .I1(pixel_x[5]),
        .O(\rgb_out[23]_i_226_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFF020000)) 
    \rgb_out[23]_i_227 
       (.I0(\rgb_out[7]_i_73_n_0 ),
        .I1(pixel_x[0]),
        .I2(\rgb_out[11]_i_22_n_0 ),
        .I3(\rgb_out[23]_i_541_n_0 ),
        .I4(\rgb_out[7]_i_72_n_0 ),
        .I5(\rgb_out[23]_i_129_n_0 ),
        .O(\rgb_out[23]_i_227_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair46" *) 
  LUT5 #(
    .INIT(32'h0000557F)) 
    \rgb_out[23]_i_228 
       (.I0(pixel_y[3]),
        .I1(pixel_y[0]),
        .I2(pixel_y[1]),
        .I3(pixel_y[2]),
        .I4(\rgb_out[23]_i_256_n_0 ),
        .O(\rgb_out[23]_i_228_n_0 ));
  LUT5 #(
    .INIT(32'h00001011)) 
    \rgb_out[23]_i_229 
       (.I0(\rgb_out[23]_i_257_n_0 ),
        .I1(\rgb_out[23]_i_77_n_0 ),
        .I2(\rgb_out[23]_i_256_n_0 ),
        .I3(\rgb_out[23]_i_349_n_0 ),
        .I4(\rgb_out[23]_i_264_n_0 ),
        .O(\rgb_out[23]_i_229_n_0 ));
  LUT5 #(
    .INIT(32'hFFFFEAEE)) 
    \rgb_out[23]_i_23 
       (.I0(\rgb_out[23]_i_78_n_0 ),
        .I1(\rgb_out[23]_i_76_n_0 ),
        .I2(\rgb_out[23]_i_79_n_0 ),
        .I3(\rgb_out[23]_i_80_n_0 ),
        .I4(\rgb_out[23]_i_81_n_0 ),
        .O(\rgb_out[23]_i_23_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair28" *) 
  LUT3 #(
    .INIT(8'hEA)) 
    \rgb_out[23]_i_230 
       (.I0(pixel_x[4]),
        .I1(pixel_x[2]),
        .I2(pixel_x[3]),
        .O(\rgb_out[23]_i_230_n_0 ));
  LUT6 #(
    .INIT(64'h3F000000AAAAAAAA)) 
    \rgb_out[23]_i_231 
       (.I0(\rgb_out[23]_i_387_n_0 ),
        .I1(\rgb_out[11]_i_20_n_0 ),
        .I2(\rgb_out[20]_i_23_n_0 ),
        .I3(\rgb_out[11]_i_11_n_0 ),
        .I4(\rgb_out[23]_i_384_n_0 ),
        .I5(\rgb_out[23]_i_379_n_0 ),
        .O(\rgb_out[23]_i_231_n_0 ));
  LUT6 #(
    .INIT(64'hAAAAAAAAABABAAAB)) 
    \rgb_out[23]_i_232 
       (.I0(\rgb_out[23]_i_255_n_0 ),
        .I1(\rgb_out[7]_i_26_n_0 ),
        .I2(\rgb_out[7]_i_25_n_0 ),
        .I3(pixel_x[2]),
        .I4(\rgb_out[23]_i_370_n_0 ),
        .I5(pixel_x[3]),
        .O(\rgb_out[23]_i_232_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair135" *) 
  LUT2 #(
    .INIT(4'h7)) 
    \rgb_out[23]_i_233 
       (.I0(pixel_x[5]),
        .I1(pixel_x[4]),
        .O(\rgb_out[23]_i_233_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair8" *) 
  LUT3 #(
    .INIT(8'hA8)) 
    \rgb_out[23]_i_234 
       (.I0(pixel_x[2]),
        .I1(pixel_x[1]),
        .I2(pixel_x[0]),
        .O(\rgb_out[23]_i_234_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair119" *) 
  LUT3 #(
    .INIT(8'hFE)) 
    \rgb_out[23]_i_235 
       (.I0(pixel_x[8]),
        .I1(pixel_x[10]),
        .I2(pixel_x[11]),
        .O(\rgb_out[23]_i_235_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair113" *) 
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_236 
       (.I0(pixel_y[7]),
        .I1(pixel_y[6]),
        .O(\rgb_out[23]_i_236_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair68" *) 
  LUT4 #(
    .INIT(16'h8000)) 
    \rgb_out[23]_i_237 
       (.I0(pixel_y[3]),
        .I1(pixel_y[2]),
        .I2(pixel_y[0]),
        .I3(pixel_y[1]),
        .O(\rgb_out[23]_i_237_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair78" *) 
  LUT4 #(
    .INIT(16'h8000)) 
    \rgb_out[23]_i_238 
       (.I0(pixel_y[4]),
        .I1(pixel_y[5]),
        .I2(pixel_y[7]),
        .I3(pixel_y[6]),
        .O(\rgb_out[23]_i_238_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair95" *) 
  LUT3 #(
    .INIT(8'hEA)) 
    \rgb_out[23]_i_239 
       (.I0(pixel_y[3]),
        .I1(pixel_y[1]),
        .I2(pixel_y[2]),
        .O(\rgb_out[23]_i_239_n_0 ));
  LUT4 #(
    .INIT(16'hFFFE)) 
    \rgb_out[23]_i_24 
       (.I0(\rgb_out[23]_i_82_n_0 ),
        .I1(\rgb_out[23]_i_83_n_0 ),
        .I2(\rgb_out[23]_i_84_n_0 ),
        .I3(\rgb_out[23]_i_85_n_0 ),
        .O(\rgb_out[23]_i_24_n_0 ));
  LUT6 #(
    .INIT(64'h0F000F0400000000)) 
    \rgb_out[23]_i_240 
       (.I0(\rgb_out[23]_i_233_n_0 ),
        .I1(\rgb_out[11]_i_21_n_0 ),
        .I2(\rgb_out[23]_i_219_n_0 ),
        .I3(\rgb_out[23]_i_235_n_0 ),
        .I4(\rgb_out[23]_i_334_n_0 ),
        .I5(\rgb_out[7]_i_55_n_0 ),
        .O(\rgb_out[23]_i_240_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair129" *) 
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_241 
       (.I0(\rgb_out[20]_i_14_n_0 ),
        .I1(\rgb_out[23]_i_252_n_0 ),
        .O(\rgb_out[23]_i_241_n_0 ));
  LUT6 #(
    .INIT(64'h00000000000000FB)) 
    \rgb_out[23]_i_242 
       (.I0(pixel_y[6]),
        .I1(\rgb_out[23]_i_137_n_0 ),
        .I2(\rgb_out[23]_i_41_n_0 ),
        .I3(\rgb_out[20]_i_29_n_0 ),
        .I4(\rgb_out[23]_i_239_n_0 ),
        .I5(\rgb_out[20]_i_28_n_0 ),
        .O(\rgb_out[23]_i_242_n_0 ));
  LUT6 #(
    .INIT(64'h0000000055D5FFFF)) 
    \rgb_out[23]_i_243 
       (.I0(\rgb_out[7]_i_73_n_0 ),
        .I1(\rgb_out[20]_i_23_n_0 ),
        .I2(pixel_x[3]),
        .I3(\rgb_out[23]_i_233_n_0 ),
        .I4(\rgb_out[7]_i_72_n_0 ),
        .I5(\rgb_out[23]_i_399_n_0 ),
        .O(\rgb_out[23]_i_243_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair16" *) 
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_244 
       (.I0(\rgb_out[23]_i_87_n_0 ),
        .I1(\rgb_out[23]_i_151_n_0 ),
        .O(\rgb_out[23]_i_244_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair22" *) 
  LUT4 #(
    .INIT(16'h8000)) 
    \rgb_out[23]_i_245 
       (.I0(pixel_x[7]),
        .I1(pixel_x[6]),
        .I2(pixel_x[5]),
        .I3(pixel_x[9]),
        .O(\rgb_out[23]_i_245_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair59" *) 
  LUT4 #(
    .INIT(16'h8000)) 
    \rgb_out[23]_i_246 
       (.I0(pixel_x[2]),
        .I1(pixel_x[3]),
        .I2(pixel_x[1]),
        .I3(pixel_x[0]),
        .O(\rgb_out[23]_i_246_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair120" *) 
  LUT3 #(
    .INIT(8'h7F)) 
    \rgb_out[23]_i_247 
       (.I0(pixel_x[9]),
        .I1(pixel_x[7]),
        .I2(pixel_x[6]),
        .O(\rgb_out[23]_i_247_n_0 ));
  LUT6 #(
    .INIT(64'h0000000015000000)) 
    \rgb_out[23]_i_248 
       (.I0(pixel_x[3]),
        .I1(pixel_x[1]),
        .I2(pixel_x[2]),
        .I3(\rgb_out[20]_i_25_n_0 ),
        .I4(\rgb_out[11]_i_11_n_0 ),
        .I5(pixel_x[8]),
        .O(\rgb_out[23]_i_248_n_0 ));
  LUT6 #(
    .INIT(64'h8080800080008000)) 
    \rgb_out[23]_i_249 
       (.I0(\rgb_out[11]_i_21_n_0 ),
        .I1(pixel_x[3]),
        .I2(pixel_x[9]),
        .I3(pixel_x[2]),
        .I4(pixel_x[1]),
        .I5(pixel_x[0]),
        .O(\rgb_out[23]_i_249_n_0 ));
  LUT4 #(
    .INIT(16'hFFAE)) 
    \rgb_out[23]_i_25 
       (.I0(\rgb_out[23]_i_86_n_0 ),
        .I1(\rgb_out[23]_i_87_n_0 ),
        .I2(\rgb_out[23]_i_88_n_0 ),
        .I3(\rgb_out[23]_i_89_n_0 ),
        .O(\rgb_out[23]_i_25_n_0 ));
  LUT6 #(
    .INIT(64'h0000000080000000)) 
    \rgb_out[23]_i_250 
       (.I0(pixel_y[4]),
        .I1(pixel_y[5]),
        .I2(pixel_y[7]),
        .I3(pixel_y[6]),
        .I4(\rgb_out[23]_i_135_n_0 ),
        .I5(\rgb_out[23]_i_136_n_0 ),
        .O(\rgb_out[23]_i_250_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000000020)) 
    \rgb_out[23]_i_251 
       (.I0(\rgb_out[20]_i_23_n_0 ),
        .I1(\rgb_out[20]_i_20_n_0 ),
        .I2(pixel_x[2]),
        .I3(pixel_x[3]),
        .I4(pixel_x[5]),
        .I5(pixel_x[4]),
        .O(\rgb_out[23]_i_251_n_0 ));
  LUT6 #(
    .INIT(64'h0000005100000000)) 
    \rgb_out[23]_i_252 
       (.I0(\rgb_out[23]_i_542_n_0 ),
        .I1(\rgb_out[23]_i_239_n_0 ),
        .I2(\rgb_out[11]_i_24_n_0 ),
        .I3(pixel_y[7]),
        .I4(\rgb_out[21]_i_6_n_0 ),
        .I5(pixel_y[8]),
        .O(\rgb_out[23]_i_252_n_0 ));
  LUT6 #(
    .INIT(64'h0002000000000000)) 
    \rgb_out[23]_i_253 
       (.I0(\rgb_out[23]_i_135_n_0 ),
        .I1(\rgb_out[23]_i_237_n_0 ),
        .I2(\rgb_out[23]_i_138_n_0 ),
        .I3(\rgb_out[23]_i_137_n_0 ),
        .I4(pixel_y[3]),
        .I5(pixel_y[4]),
        .O(\rgb_out[23]_i_253_n_0 ));
  LUT6 #(
    .INIT(64'hAAAAAAAABBBBABBB)) 
    \rgb_out[23]_i_254 
       (.I0(\rgb_out[23]_i_255_n_0 ),
        .I1(\rgb_out[7]_i_28_n_0 ),
        .I2(pixel_x[6]),
        .I3(pixel_x[4]),
        .I4(\rgb_out[7]_i_85_n_0 ),
        .I5(\rgb_out[7]_i_25_n_0 ),
        .O(\rgb_out[23]_i_254_n_0 ));
  LUT6 #(
    .INIT(64'hF200F2000000F200)) 
    \rgb_out[23]_i_255 
       (.I0(\rgb_out[23]_i_543_n_0 ),
        .I1(\rgb_out[7]_i_69_n_0 ),
        .I2(\rgb_out[23]_i_544_n_0 ),
        .I3(\rgb_out[11]_i_11_n_0 ),
        .I4(\rgb_out[23]_i_545_n_0 ),
        .I5(\rgb_out[23]_i_546_n_0 ),
        .O(\rgb_out[23]_i_255_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFDDDDDFFF)) 
    \rgb_out[23]_i_256 
       (.I0(\rgb_out[23]_i_135_n_0 ),
        .I1(pixel_y[4]),
        .I2(pixel_y[2]),
        .I3(pixel_y[1]),
        .I4(pixel_y[3]),
        .I5(\rgb_out[23]_i_138_n_0 ),
        .O(\rgb_out[23]_i_256_n_0 ));
  LUT6 #(
    .INIT(64'h1310000030300000)) 
    \rgb_out[23]_i_257 
       (.I0(\rgb_out[23]_i_237_n_0 ),
        .I1(\rgb_out[23]_i_138_n_0 ),
        .I2(\rgb_out[21]_i_7_n_0 ),
        .I3(\rgb_out[23]_i_136_n_0 ),
        .I4(\rgb_out[23]_i_135_n_0 ),
        .I5(pixel_y[4]),
        .O(\rgb_out[23]_i_257_n_0 ));
  LUT5 #(
    .INIT(32'h00800000)) 
    \rgb_out[23]_i_258 
       (.I0(pixel_x[5]),
        .I1(\rgb_out[23]_i_346_n_0 ),
        .I2(\rgb_out[20]_i_23_n_0 ),
        .I3(\rgb_out[20]_i_24_n_0 ),
        .I4(\rgb_out[11]_i_11_n_0 ),
        .O(\rgb_out[23]_i_258_n_0 ));
  LUT6 #(
    .INIT(64'h5555555555555515)) 
    \rgb_out[23]_i_259 
       (.I0(\rgb_out[23]_i_399_n_0 ),
        .I1(\rgb_out[20]_i_23_n_0 ),
        .I2(pixel_x[3]),
        .I3(\rgb_out[23]_i_233_n_0 ),
        .I4(\rgb_out[23]_i_394_n_0 ),
        .I5(pixel_x[2]),
        .O(\rgb_out[23]_i_259_n_0 ));
  LUT6 #(
    .INIT(64'h0000000002020002)) 
    \rgb_out[23]_i_26 
       (.I0(\rgb_out[23]_i_90_n_0 ),
        .I1(\rgb_out[23]_i_91_n_0 ),
        .I2(\rgb_out[23]_i_92_n_0 ),
        .I3(\rgb_out[23]_i_93_n_0 ),
        .I4(\rgb_out[23]_i_94_n_0 ),
        .I5(\rgb_out[23]_i_95_n_0 ),
        .O(\rgb_out[23]_i_26_n_0 ));
  LUT6 #(
    .INIT(64'h0000000001000010)) 
    \rgb_out[23]_i_260 
       (.I0(pixel_y[4]),
        .I1(\rgb_out[23]_i_267_n_0 ),
        .I2(pixel_y[3]),
        .I3(pixel_y[1]),
        .I4(pixel_y[2]),
        .I5(\rgb_out[20]_i_28_n_0 ),
        .O(\rgb_out[23]_i_260_n_0 ));
  LUT6 #(
    .INIT(64'h0002000200000002)) 
    \rgb_out[23]_i_261 
       (.I0(pixel_x[2]),
        .I1(pixel_x[3]),
        .I2(\rgb_out[23]_i_235_n_0 ),
        .I3(pixel_x[4]),
        .I4(\rgb_out[20]_i_19_n_0 ),
        .I5(\rgb_out[23]_i_245_n_0 ),
        .O(\rgb_out[23]_i_261_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_262 
       (.I0(\rgb_out[20]_i_13_n_0 ),
        .I1(\rgb_out[23]_i_151_n_0 ),
        .O(\rgb_out[23]_i_262_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair129" *) 
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_263 
       (.I0(\rgb_out[20]_i_14_n_0 ),
        .I1(\rgb_out[20]_i_13_n_0 ),
        .O(\rgb_out[23]_i_263_n_0 ));
  LUT5 #(
    .INIT(32'h00300050)) 
    \rgb_out[23]_i_264 
       (.I0(\rgb_out[23]_i_349_n_0 ),
        .I1(\rgb_out[23]_i_136_n_0 ),
        .I2(\rgb_out[23]_i_135_n_0 ),
        .I3(\rgb_out[23]_i_138_n_0 ),
        .I4(pixel_y[4]),
        .O(\rgb_out[23]_i_264_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair108" *) 
  LUT3 #(
    .INIT(8'h01)) 
    \rgb_out[23]_i_265 
       (.I0(\rgb_out[23]_i_77_n_0 ),
        .I1(\rgb_out[23]_i_76_n_0 ),
        .I2(\rgb_out[23]_i_257_n_0 ),
        .O(\rgb_out[23]_i_265_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair95" *) 
  LUT3 #(
    .INIT(8'hA8)) 
    \rgb_out[23]_i_266 
       (.I0(pixel_y[3]),
        .I1(pixel_y[1]),
        .I2(pixel_y[2]),
        .O(\rgb_out[23]_i_266_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_267 
       (.I0(pixel_y[6]),
        .I1(pixel_y[5]),
        .O(\rgb_out[23]_i_267_n_0 ));
  LUT6 #(
    .INIT(64'h7FFF7F5555555555)) 
    \rgb_out[23]_i_268 
       (.I0(\rgb_out[20]_i_19_n_0 ),
        .I1(\rgb_out[23]_i_372_n_0 ),
        .I2(\rgb_out[23]_i_547_n_0 ),
        .I3(\rgb_out[23]_i_548_n_0 ),
        .I4(pixel_x[4]),
        .I5(\rgb_out[23]_i_549_n_0 ),
        .O(\rgb_out[23]_i_268_n_0 ));
  LUT3 #(
    .INIT(8'hFE)) 
    \rgb_out[23]_i_269 
       (.I0(\rgb_out[23]_i_143_n_0 ),
        .I1(\rgb_out[23]_i_144_n_0 ),
        .I2(\rgb_out[23]_i_399_n_0 ),
        .O(\rgb_out[23]_i_269_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFF4F44444444)) 
    \rgb_out[23]_i_27 
       (.I0(\rgb_out[23]_i_96_n_0 ),
        .I1(\rgb_out[23]_i_97_n_0 ),
        .I2(\rgb_out[23]_i_98_n_0 ),
        .I3(\rgb_out[23]_i_99_n_0 ),
        .I4(\rgb_out[23]_i_100_n_0 ),
        .I5(\rgb_out[23]_i_101_n_0 ),
        .O(\rgb_out[23]_i_27_n_0 ));
  LUT6 #(
    .INIT(64'hFFFEFFFEFFFFFFFE)) 
    \rgb_out[23]_i_270 
       (.I0(\rgb_out[23]_i_115_n_0 ),
        .I1(\rgb_out[23]_i_278_n_0 ),
        .I2(\rgb_out[23]_i_279_n_0 ),
        .I3(\rgb_out[23]_i_112_n_0 ),
        .I4(\rgb_out[23]_i_550_n_0 ),
        .I5(\rgb_out[23]_i_285_n_0 ),
        .O(\rgb_out[23]_i_270_n_0 ));
  LUT6 #(
    .INIT(64'h00F2000000220000)) 
    \rgb_out[23]_i_271 
       (.I0(\rgb_out[23]_i_278_n_0 ),
        .I1(\rgb_out[23]_i_551_n_0 ),
        .I2(\rgb_out[23]_i_279_n_0 ),
        .I3(\rgb_out[23]_i_552_n_0 ),
        .I4(\rgb_out[23]_i_219_n_0 ),
        .I5(\rgb_out[23]_i_553_n_0 ),
        .O(\rgb_out[23]_i_271_n_0 ));
  LUT6 #(
    .INIT(64'h0000001000000000)) 
    \rgb_out[23]_i_272 
       (.I0(pixel_x[4]),
        .I1(pixel_x[3]),
        .I2(pixel_x[2]),
        .I3(\rgb_out[23]_i_226_n_0 ),
        .I4(\rgb_out[11]_i_29_n_0 ),
        .I5(\rgb_out[23]_i_219_n_0 ),
        .O(\rgb_out[23]_i_272_n_0 ));
  LUT6 #(
    .INIT(64'h2A2A2A2A2A2A2AAA)) 
    \rgb_out[23]_i_273 
       (.I0(\rgb_out[23]_i_219_n_0 ),
        .I1(pixel_x[7]),
        .I2(pixel_x[8]),
        .I3(pixel_x[4]),
        .I4(pixel_x[5]),
        .I5(pixel_x[6]),
        .O(\rgb_out[23]_i_273_n_0 ));
  LUT6 #(
    .INIT(64'hFFABAAAAAAAAAAAA)) 
    \rgb_out[23]_i_274 
       (.I0(\rgb_out[23]_i_554_n_0 ),
        .I1(\rgb_out[23]_i_401_n_0 ),
        .I2(pixel_x[6]),
        .I3(\rgb_out[11]_i_29_n_0 ),
        .I4(\rgb_out[23]_i_219_n_0 ),
        .I5(\rgb_out[23]_i_115_n_0 ),
        .O(\rgb_out[23]_i_274_n_0 ));
  LUT6 #(
    .INIT(64'hEEEEEEEEEEEEE0EE)) 
    \rgb_out[23]_i_275 
       (.I0(\rgb_out[23]_i_308_n_0 ),
        .I1(\rgb_out[23]_i_297_n_0 ),
        .I2(\rgb_out[23]_i_555_n_0 ),
        .I3(\rgb_out[23]_i_556_n_0 ),
        .I4(\rgb_out[23]_i_352_n_0 ),
        .I5(\rgb_out[23]_i_351_n_0 ),
        .O(\rgb_out[23]_i_275_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000F70000)) 
    \rgb_out[23]_i_276 
       (.I0(\rgb_out[23]_i_557_n_0 ),
        .I1(pixel_x[2]),
        .I2(\rgb_out[23]_i_339_n_0 ),
        .I3(\rgb_out[23]_i_111_n_0 ),
        .I4(\rgb_out[23]_i_558_n_0 ),
        .I5(\rgb_out[23]_i_341_n_0 ),
        .O(\rgb_out[23]_i_276_n_0 ));
  LUT6 #(
    .INIT(64'hABBBBBBBBBBBBBBB)) 
    \rgb_out[23]_i_277 
       (.I0(\rgb_out[23]_i_559_n_0 ),
        .I1(\rgb_out[23]_i_560_n_0 ),
        .I2(pixel_x[10]),
        .I3(pixel_x[6]),
        .I4(\rgb_out[23]_i_543_n_0 ),
        .I5(pixel_x[7]),
        .O(\rgb_out[23]_i_277_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000000704)) 
    \rgb_out[23]_i_278 
       (.I0(\rgb_out[23]_i_561_n_0 ),
        .I1(pixel_y[4]),
        .I2(\rgb_out[23]_i_267_n_0 ),
        .I3(\rgb_out[23]_i_237_n_0 ),
        .I4(\rgb_out[23]_i_40_n_0 ),
        .I5(\rgb_out[21]_i_6_n_0 ),
        .O(\rgb_out[23]_i_278_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000000080)) 
    \rgb_out[23]_i_279 
       (.I0(\rgb_out[23]_i_561_n_0 ),
        .I1(\rgb_out[23]_i_562_n_0 ),
        .I2(pixel_y[4]),
        .I3(\rgb_out[23]_i_40_n_0 ),
        .I4(\rgb_out[21]_i_6_n_0 ),
        .I5(\rgb_out[23]_i_267_n_0 ),
        .O(\rgb_out[23]_i_279_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFFFFE)) 
    \rgb_out[23]_i_28 
       (.I0(\rgb_out[23]_i_102_n_0 ),
        .I1(\rgb_out[23]_i_103_n_0 ),
        .I2(num_rec_d),
        .I3(num_last_u),
        .I4(num_rec_u),
        .I5(num_last_d),
        .O(\rgb_out[23]_i_28_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000000002)) 
    \rgb_out[23]_i_280 
       (.I0(pixel_y[5]),
        .I1(\rgb_out[23]_i_563_n_0 ),
        .I2(\rgb_out[21]_i_6_n_0 ),
        .I3(pixel_y[6]),
        .I4(\rgb_out[11]_i_8_n_0 ),
        .I5(\rgb_out[23]_i_40_n_0 ),
        .O(\rgb_out[23]_i_280_n_0 ));
  LUT6 #(
    .INIT(64'h000000000000000E)) 
    \rgb_out[23]_i_281 
       (.I0(\rgb_out[23]_i_401_n_0 ),
        .I1(\rgb_out[23]_i_564_n_0 ),
        .I2(\rgb_out[23]_i_392_n_0 ),
        .I3(pixel_x[5]),
        .I4(\rgb_out[23]_i_337_n_0 ),
        .I5(\rgb_out[23]_i_353_n_0 ),
        .O(\rgb_out[23]_i_281_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT5 #(
    .INIT(32'hEAAAAAAA)) 
    \rgb_out[23]_i_282 
       (.I0(pixel_x[6]),
        .I1(pixel_x[5]),
        .I2(pixel_x[4]),
        .I3(pixel_x[3]),
        .I4(pixel_x[2]),
        .O(\rgb_out[23]_i_282_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFAEFFFFFF)) 
    \rgb_out[23]_i_283 
       (.I0(\rgb_out[23]_i_565_n_0 ),
        .I1(pixel_x[6]),
        .I2(\rgb_out[20]_i_25_n_0 ),
        .I3(\rgb_out[23]_i_219_n_0 ),
        .I4(pixel_x[8]),
        .I5(pixel_x[7]),
        .O(\rgb_out[23]_i_283_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000010000)) 
    \rgb_out[23]_i_284 
       (.I0(\rgb_out[23]_i_340_n_0 ),
        .I1(\rgb_out[23]_i_353_n_0 ),
        .I2(pixel_x[3]),
        .I3(pixel_x[4]),
        .I4(pixel_x[5]),
        .I5(\rgb_out[23]_i_337_n_0 ),
        .O(\rgb_out[23]_i_284_n_0 ));
  LUT6 #(
    .INIT(64'h0000EF00FFFFFFFF)) 
    \rgb_out[23]_i_285 
       (.I0(\rgb_out[23]_i_566_n_0 ),
        .I1(pixel_y[4]),
        .I2(\rgb_out[7]_i_37_n_0 ),
        .I3(pixel_y[5]),
        .I4(\rgb_out[23]_i_40_n_0 ),
        .I5(\rgb_out[7]_i_32_n_0 ),
        .O(\rgb_out[23]_i_285_n_0 ));
  LUT6 #(
    .INIT(64'h0000000008000000)) 
    \rgb_out[23]_i_286 
       (.I0(\rgb_out[23]_i_557_n_0 ),
        .I1(pixel_x[3]),
        .I2(\rgb_out[23]_i_233_n_0 ),
        .I3(pixel_x[8]),
        .I4(pixel_x[6]),
        .I5(pixel_x[2]),
        .O(\rgb_out[23]_i_286_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFFBFF)) 
    \rgb_out[23]_i_287 
       (.I0(\rgb_out[23]_i_366_n_0 ),
        .I1(\rgb_out[20]_i_25_n_0 ),
        .I2(\rgb_out[23]_i_567_n_0 ),
        .I3(\rgb_out[23]_i_334_n_0 ),
        .I4(pixel_x[11]),
        .I5(pixel_x[8]),
        .O(\rgb_out[23]_i_287_n_0 ));
  LUT6 #(
    .INIT(64'hAAAAEAAAAAAAAAAA)) 
    \rgb_out[23]_i_288 
       (.I0(\rgb_out[23]_i_341_n_0 ),
        .I1(\rgb_out[20]_i_25_n_0 ),
        .I2(\rgb_out[23]_i_346_n_0 ),
        .I3(pixel_x[6]),
        .I4(\rgb_out[11]_i_29_n_0 ),
        .I5(\rgb_out[23]_i_219_n_0 ),
        .O(\rgb_out[23]_i_288_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000040404)) 
    \rgb_out[23]_i_289 
       (.I0(\rgb_out[11]_i_11_n_0 ),
        .I1(\rgb_out[23]_i_568_n_0 ),
        .I2(\rgb_out[23]_i_569_n_0 ),
        .I3(\rgb_out[23]_i_570_n_0 ),
        .I4(\rgb_out[23]_i_351_n_0 ),
        .I5(\rgb_out[23]_i_352_n_0 ),
        .O(\rgb_out[23]_i_289_n_0 ));
  LUT6 #(
    .INIT(64'hFFDFFF0FFFDF0000)) 
    \rgb_out[23]_i_29 
       (.I0(\rgb_out[23]_i_108_n_0 ),
        .I1(\rgb_out[23]_i_109_n_0 ),
        .I2(\rgb_out[23]_i_110_n_0 ),
        .I3(\rgb_out[23]_i_111_n_0 ),
        .I4(\rgb_out[23]_i_112_n_0 ),
        .I5(\rgb_out[23]_i_97_n_0 ),
        .O(\rgb_out[23]_i_29_n_0 ));
  LUT6 #(
    .INIT(64'h0000000004000000)) 
    \rgb_out[23]_i_290 
       (.I0(pixel_x[2]),
        .I1(\rgb_out[23]_i_219_n_0 ),
        .I2(\rgb_out[11]_i_29_n_0 ),
        .I3(pixel_x[6]),
        .I4(\rgb_out[23]_i_392_n_0 ),
        .I5(pixel_x[5]),
        .O(\rgb_out[23]_i_290_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFF1500)) 
    \rgb_out[23]_i_291 
       (.I0(\rgb_out[23]_i_352_n_0 ),
        .I1(\rgb_out[23]_i_351_n_0 ),
        .I2(\rgb_out[23]_i_226_n_0 ),
        .I3(\rgb_out[23]_i_571_n_0 ),
        .I4(\rgb_out[23]_i_304_n_0 ),
        .I5(\rgb_out[23]_i_281_n_0 ),
        .O(\rgb_out[23]_i_291_n_0 ));
  LUT6 #(
    .INIT(64'hFFF1FFF1FFFFFFF1)) 
    \rgb_out[23]_i_292 
       (.I0(\rgb_out[23]_i_572_n_0 ),
        .I1(\rgb_out[23]_i_352_n_0 ),
        .I2(\rgb_out[23]_i_573_n_0 ),
        .I3(\rgb_out[23]_i_574_n_0 ),
        .I4(\rgb_out[23]_i_575_n_0 ),
        .I5(\rgb_out[23]_i_576_n_0 ),
        .O(\rgb_out[23]_i_292_n_0 ));
  LUT6 #(
    .INIT(64'hAAAAAAAAFBFFFAAF)) 
    \rgb_out[23]_i_293 
       (.I0(\rgb_out[23]_i_278_n_0 ),
        .I1(pixel_y[3]),
        .I2(\rgb_out[7]_i_37_n_0 ),
        .I3(pixel_y[2]),
        .I4(\rgb_out[23]_i_267_n_0 ),
        .I5(\rgb_out[23]_i_577_n_0 ),
        .O(\rgb_out[23]_i_293_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000001000)) 
    \rgb_out[23]_i_294 
       (.I0(pixel_x[3]),
        .I1(\rgb_out[23]_i_233_n_0 ),
        .I2(\rgb_out[23]_i_578_n_0 ),
        .I3(\rgb_out[23]_i_219_n_0 ),
        .I4(\rgb_out[11]_i_29_n_0 ),
        .I5(pixel_x[6]),
        .O(\rgb_out[23]_i_294_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFFFBF)) 
    \rgb_out[23]_i_295 
       (.I0(\rgb_out[23]_i_352_n_0 ),
        .I1(pixel_x[7]),
        .I2(pixel_x[10]),
        .I3(pixel_x[4]),
        .I4(pixel_x[5]),
        .I5(pixel_x[6]),
        .O(\rgb_out[23]_i_295_n_0 ));
  LUT6 #(
    .INIT(64'hCCCCCCCCC8C0C0C0)) 
    \rgb_out[23]_i_296 
       (.I0(\rgb_out[23]_i_230_n_0 ),
        .I1(pixel_x[10]),
        .I2(\rgb_out[23]_i_224_n_0 ),
        .I3(pixel_x[6]),
        .I4(pixel_x[5]),
        .I5(pixel_x[7]),
        .O(\rgb_out[23]_i_296_n_0 ));
  LUT6 #(
    .INIT(64'hFF00FF00FF008000)) 
    \rgb_out[23]_i_297 
       (.I0(pixel_x[6]),
        .I1(pixel_x[5]),
        .I2(pixel_x[4]),
        .I3(pixel_x[10]),
        .I4(pixel_x[7]),
        .I5(\rgb_out[23]_i_224_n_0 ),
        .O(\rgb_out[23]_i_297_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000005457)) 
    \rgb_out[23]_i_298 
       (.I0(pixel_x[10]),
        .I1(\rgb_out[23]_i_224_n_0 ),
        .I2(pixel_x[7]),
        .I3(\rgb_out[23]_i_334_n_0 ),
        .I4(pixel_x[11]),
        .I5(\rgb_out[23]_i_556_n_0 ),
        .O(\rgb_out[23]_i_298_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000000001)) 
    \rgb_out[23]_i_299 
       (.I0(pixel_y[4]),
        .I1(\rgb_out[23]_i_237_n_0 ),
        .I2(\rgb_out[21]_i_6_n_0 ),
        .I3(\rgb_out[23]_i_349_n_0 ),
        .I4(\rgb_out[23]_i_267_n_0 ),
        .I5(\rgb_out[23]_i_40_n_0 ),
        .O(\rgb_out[23]_i_299_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair103" *) 
  LUT3 #(
    .INIT(8'h72)) 
    \rgb_out[23]_i_3 
       (.I0(mode_ui[1]),
        .I1(mode_ui[2]),
        .I2(mode_ui[0]),
        .O(\rgb_out[23]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFEFAAAAAAAAAA)) 
    \rgb_out[23]_i_30 
       (.I0(\rgb_out[23]_i_113_n_0 ),
        .I1(\rgb_out[23]_i_99_n_0 ),
        .I2(\rgb_out[23]_i_114_n_0 ),
        .I3(\rgb_out[23]_i_115_n_0 ),
        .I4(\rgb_out[23]_i_116_n_0 ),
        .I5(\rgb_out[23]_i_97_n_0 ),
        .O(\rgb_out[23]_i_30_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair100" *) 
  LUT3 #(
    .INIT(8'hFE)) 
    \rgb_out[23]_i_300 
       (.I0(pixel_x[3]),
        .I1(pixel_x[4]),
        .I2(pixel_x[5]),
        .O(\rgb_out[23]_i_300_n_0 ));
  LUT6 #(
    .INIT(64'hFEFFFFFFFFFFFFFF)) 
    \rgb_out[23]_i_301 
       (.I0(pixel_x[10]),
        .I1(pixel_x[11]),
        .I2(pixel_x[9]),
        .I3(pixel_x[6]),
        .I4(pixel_x[7]),
        .I5(pixel_x[8]),
        .O(\rgb_out[23]_i_301_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFDFFFFFFFFFF)) 
    \rgb_out[23]_i_302 
       (.I0(\rgb_out[23]_i_346_n_0 ),
        .I1(\rgb_out[11]_i_29_n_0 ),
        .I2(pixel_x[6]),
        .I3(pixel_x[5]),
        .I4(pixel_x[4]),
        .I5(\rgb_out[23]_i_219_n_0 ),
        .O(\rgb_out[23]_i_302_n_0 ));
  LUT6 #(
    .INIT(64'h0002000000000000)) 
    \rgb_out[23]_i_303 
       (.I0(\rgb_out[23]_i_219_n_0 ),
        .I1(\rgb_out[11]_i_29_n_0 ),
        .I2(pixel_x[6]),
        .I3(pixel_x[5]),
        .I4(\rgb_out[23]_i_392_n_0 ),
        .I5(pixel_x[2]),
        .O(\rgb_out[23]_i_303_n_0 ));
  LUT6 #(
    .INIT(64'h000000E000000000)) 
    \rgb_out[23]_i_304 
       (.I0(pixel_x[6]),
        .I1(\rgb_out[23]_i_537_n_0 ),
        .I2(\rgb_out[11]_i_11_n_0 ),
        .I3(pixel_x[9]),
        .I4(\rgb_out[11]_i_29_n_0 ),
        .I5(\rgb_out[23]_i_367_n_0 ),
        .O(\rgb_out[23]_i_304_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair67" *) 
  LUT4 #(
    .INIT(16'h0001)) 
    \rgb_out[23]_i_305 
       (.I0(pixel_x[2]),
        .I1(pixel_x[3]),
        .I2(pixel_x[4]),
        .I3(pixel_x[5]),
        .O(\rgb_out[23]_i_305_n_0 ));
  LUT6 #(
    .INIT(64'h00000000005CCCCC)) 
    \rgb_out[23]_i_306 
       (.I0(pixel_x[2]),
        .I1(pixel_x[6]),
        .I2(pixel_x[3]),
        .I3(pixel_x[4]),
        .I4(pixel_x[5]),
        .I5(\rgb_out[11]_i_29_n_0 ),
        .O(\rgb_out[23]_i_306_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair114" *) 
  LUT3 #(
    .INIT(8'h01)) 
    \rgb_out[23]_i_307 
       (.I0(pixel_x[2]),
        .I1(pixel_x[3]),
        .I2(pixel_x[4]),
        .O(\rgb_out[23]_i_307_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFBFFFFFF)) 
    \rgb_out[23]_i_308 
       (.I0(\rgb_out[23]_i_579_n_0 ),
        .I1(pixel_x[10]),
        .I2(pixel_x[11]),
        .I3(pixel_x[5]),
        .I4(pixel_x[6]),
        .I5(\rgb_out[23]_i_346_n_0 ),
        .O(\rgb_out[23]_i_308_n_0 ));
  LUT5 #(
    .INIT(32'h0000E000)) 
    \rgb_out[23]_i_309 
       (.I0(\pixel_y[1]_15 ),
        .I1(\pixel_y[5]_8 ),
        .I2(\pixel_x[5]_1 ),
        .I3(\pixel_x[2]_13 ),
        .I4(record_diz),
        .O(\rgb_out[23]_i_309_n_0 ));
  LUT6 #(
    .INIT(64'h8888888A8A8A8A8A)) 
    \rgb_out[23]_i_31 
       (.I0(\rgb_out[23]_i_101_n_0 ),
        .I1(\rgb_out[23]_i_117_n_0 ),
        .I2(\rgb_out[23]_i_118_n_0 ),
        .I3(pixel_x[11]),
        .I4(\rgb_out[23]_i_119_n_0 ),
        .I5(\rgb_out[23]_i_120_n_0 ),
        .O(\rgb_out[23]_i_31_n_0 ));
  LUT4 #(
    .INIT(16'hF888)) 
    \rgb_out[23]_i_310 
       (.I0(\pixel_y[5]_9 ),
        .I1(\pixel_y[1]_16 ),
        .I2(\pixel_y[1]_17 ),
        .I3(\pixel_y[1]_18 ),
        .O(\rgb_out[23]_i_310_n_0 ));
  LUT3 #(
    .INIT(8'hE0)) 
    \rgb_out[23]_i_312 
       (.I0(record_personnel[2]),
        .I1(record_personnel[1]),
        .I2(record_personnel[3]),
        .O(record_diz));
  LUT4 #(
    .INIT(16'h7FFF)) 
    \rgb_out[23]_i_314 
       (.I0(\pixel_y[1]_13 ),
        .I1(\pixel_x[2]_11 ),
        .I2(\pixel_y[1]_14 ),
        .I3(\pixel_x[2]_12 ),
        .O(\rgb_out[23]_i_314_n_0 ));
  LUT4 #(
    .INIT(16'h8000)) 
    \rgb_out[23]_i_315 
       (.I0(\pixel_x[2]_7 ),
        .I1(\pixel_y[1]_11 ),
        .I2(\pixel_x[2]_8 ),
        .I3(\pixel_y[1]_12 ),
        .O(\rgb_out[23]_i_315_n_0 ));
  LUT6 #(
    .INIT(64'h8888800080008000)) 
    \rgb_out[23]_i_316 
       (.I0(\pixel_y[1]_6 ),
        .I1(\pixel_y[1]_7 ),
        .I2(\LAST_U/segments [2]),
        .I3(\pixel_x[2]_5 ),
        .I4(\rgb_out[23]_i_610_n_0 ),
        .I5(\pixel_x[2]_6 ),
        .O(\rgb_out[23]_i_316_n_0 ));
  LUT6 #(
    .INIT(64'h8888800080008000)) 
    \rgb_out[23]_i_317 
       (.I0(\pixel_y[1]_8 ),
        .I1(\pixel_y[5]_7 ),
        .I2(\LAST_U/segments [1]),
        .I3(\pixel_x[2]_5 ),
        .I4(\rgb_out[23]_i_615_n_0 ),
        .I5(\pixel_x[2]_6 ),
        .O(\rgb_out[23]_i_317_n_0 ));
  LUT6 #(
    .INIT(64'h0000000080880000)) 
    \rgb_out[23]_i_318 
       (.I0(\pixel_x[5]_0 ),
        .I1(\pixel_x[2]_4 ),
        .I2(\rgb_out[23]_i_618_n_0 ),
        .I3(\rgb_out[23]_i_619_n_0 ),
        .I4(\pixel_y[1]_5 ),
        .I5(\rgb_out[23]_i_621_n_0 ),
        .O(\rgb_out[23]_i_318_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000800000)) 
    \rgb_out[23]_i_319 
       (.I0(\pixel_y[1]_9 ),
        .I1(\pixel_x[2]_4 ),
        .I2(\pixel_x[5]_0 ),
        .I3(\rgb_out[23]_i_623_n_0 ),
        .I4(\pixel_y[1]_10 ),
        .I5(\rgb_out[23]_i_625_n_0 ),
        .O(\rgb_out[23]_i_319_n_0 ));
  LUT6 #(
    .INIT(64'h7777777077777777)) 
    \rgb_out[23]_i_32 
       (.I0(\rgb_out[23]_i_36_n_0 ),
        .I1(\rgb_out[23]_i_121_n_0 ),
        .I2(\rgb_out[23]_i_122_n_0 ),
        .I3(\rgb_out[23]_i_75_n_0 ),
        .I4(\rgb_out[23]_i_123_n_0 ),
        .I5(\rgb_out[23]_i_124_n_0 ),
        .O(\rgb_out[23]_i_32_n_0 ));
  LUT4 #(
    .INIT(16'h8000)) 
    \rgb_out[23]_i_320 
       (.I0(\pixel_y[5]_6 ),
        .I1(\pixel_x[2]_4 ),
        .I2(\pixel_x[5]_0 ),
        .I3(\rgb_out[23]_i_627_n_0 ),
        .O(\rgb_out[23]_i_320_n_0 ));
  LUT4 #(
    .INIT(16'h8000)) 
    \rgb_out[23]_i_321 
       (.I0(\pixel_x[2]_17 ),
        .I1(\pixel_y[1]_25 ),
        .I2(\pixel_x[2]_18 ),
        .I3(\pixel_y[1]_26 ),
        .O(\rgb_out[23]_i_321_n_0 ));
  LUT6 #(
    .INIT(64'h8888800080008000)) 
    \rgb_out[23]_i_322 
       (.I0(\pixel_y[1]_20 ),
        .I1(\pixel_y[1]_21 ),
        .I2(\REC_U/segments [2]),
        .I3(\pixel_x[2]_15 ),
        .I4(\rgb_out[23]_i_636_n_0 ),
        .I5(\pixel_x[2]_16 ),
        .O(\rgb_out[23]_i_322_n_0 ));
  LUT6 #(
    .INIT(64'h8888800080008000)) 
    \rgb_out[23]_i_323 
       (.I0(\pixel_y[1]_22 ),
        .I1(\pixel_y[5]_11 ),
        .I2(\REC_U/segments [1]),
        .I3(\pixel_x[2]_15 ),
        .I4(\rgb_out[23]_i_641_n_0 ),
        .I5(\pixel_x[2]_16 ),
        .O(\rgb_out[23]_i_323_n_0 ));
  LUT6 #(
    .INIT(64'h0000000080880000)) 
    \rgb_out[23]_i_324 
       (.I0(\pixel_x[6]_0 ),
        .I1(\pixel_x[2]_14 ),
        .I2(\rgb_out[23]_i_644_n_0 ),
        .I3(\rgb_out[23]_i_645_n_0 ),
        .I4(\pixel_y[1]_19 ),
        .I5(\rgb_out[23]_i_647_n_0 ),
        .O(\rgb_out[23]_i_324_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000800000)) 
    \rgb_out[23]_i_325 
       (.I0(\pixel_y[1]_23 ),
        .I1(\pixel_x[2]_14 ),
        .I2(\pixel_x[6]_0 ),
        .I3(\rgb_out[23]_i_649_n_0 ),
        .I4(\pixel_y[1]_24 ),
        .I5(\rgb_out[23]_i_651_n_0 ),
        .O(\rgb_out[23]_i_325_n_0 ));
  LUT4 #(
    .INIT(16'h8000)) 
    \rgb_out[23]_i_326 
       (.I0(\pixel_y[5]_10 ),
        .I1(\pixel_x[2]_14 ),
        .I2(\pixel_x[6]_0 ),
        .I3(\rgb_out[23]_i_653_n_0 ),
        .O(\rgb_out[23]_i_326_n_0 ));
  LUT5 #(
    .INIT(32'h0000E000)) 
    \rgb_out[23]_i_327 
       (.I0(\pixel_y[1]_1 ),
        .I1(\pixel_y[5]_4 ),
        .I2(\pixel_x[7]_0 ),
        .I3(\pixel_x[2]_3 ),
        .I4(dernier_diz),
        .O(\rgb_out[23]_i_327_n_0 ));
  LUT4 #(
    .INIT(16'hF888)) 
    \rgb_out[23]_i_328 
       (.I0(\pixel_y[5]_5 ),
        .I1(\pixel_y[1]_2 ),
        .I2(\pixel_y[1]_3 ),
        .I3(\pixel_y[1]_4 ),
        .O(\rgb_out[23]_i_328_n_0 ));
  LUT6 #(
    .INIT(64'hFAFFFFFFFAFEFAFE)) 
    \rgb_out[23]_i_33 
       (.I0(\rgb_out[23]_i_125_n_0 ),
        .I1(\rgb_out[7]_i_15_n_0 ),
        .I2(\rgb_out[23]_i_126_n_0 ),
        .I3(\rgb_out[23]_i_121_n_0 ),
        .I4(\rgb_out[23]_i_36_n_0 ),
        .I5(\rgb_out[23]_i_127_n_0 ),
        .O(\rgb_out[23]_i_33_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair110" *) 
  LUT3 #(
    .INIT(8'hE0)) 
    \rgb_out[23]_i_330 
       (.I0(score_dernier[1]),
        .I1(score_dernier[2]),
        .I2(score_dernier[3]),
        .O(dernier_diz));
  LUT4 #(
    .INIT(16'h7FFF)) 
    \rgb_out[23]_i_332 
       (.I0(\pixel_y[1] ),
        .I1(\pixel_x[2]_1 ),
        .I2(\pixel_y[1]_0 ),
        .I3(\pixel_x[2]_2 ),
        .O(\rgb_out[23]_i_332_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair130" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_333 
       (.I0(pixel_x[6]),
        .I1(pixel_x[5]),
        .O(\rgb_out[23]_i_333_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair114" *) 
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_334 
       (.I0(pixel_x[3]),
        .I1(pixel_x[2]),
        .O(\rgb_out[23]_i_334_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair11" *) 
  LUT4 #(
    .INIT(16'h0001)) 
    \rgb_out[23]_i_335 
       (.I0(pixel_x[8]),
        .I1(pixel_x[7]),
        .I2(pixel_x[9]),
        .I3(pixel_x[11]),
        .O(\rgb_out[23]_i_335_n_0 ));
  LUT6 #(
    .INIT(64'h0006000000000000)) 
    \rgb_out[23]_i_336 
       (.I0(pixel_x[3]),
        .I1(pixel_x[4]),
        .I2(pixel_x[5]),
        .I3(\rgb_out[23]_i_676_n_0 ),
        .I4(\rgb_out[23]_i_219_n_0 ),
        .I5(pixel_x[2]),
        .O(\rgb_out[23]_i_336_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair35" *) 
  LUT5 #(
    .INIT(32'hFFFEFEFE)) 
    \rgb_out[23]_i_337 
       (.I0(pixel_x[10]),
        .I1(pixel_x[11]),
        .I2(pixel_x[9]),
        .I3(pixel_x[8]),
        .I4(pixel_x[7]),
        .O(\rgb_out[23]_i_337_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT4 #(
    .INIT(16'h8000)) 
    \rgb_out[23]_i_338 
       (.I0(pixel_x[4]),
        .I1(pixel_x[5]),
        .I2(pixel_x[8]),
        .I3(pixel_x[6]),
        .O(\rgb_out[23]_i_338_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair10" *) 
  LUT5 #(
    .INIT(32'h7FFFFFFF)) 
    \rgb_out[23]_i_339 
       (.I0(pixel_x[3]),
        .I1(pixel_x[4]),
        .I2(pixel_x[5]),
        .I3(pixel_x[8]),
        .I4(pixel_x[6]),
        .O(\rgb_out[23]_i_339_n_0 ));
  LUT5 #(
    .INIT(32'h00000001)) 
    \rgb_out[23]_i_34 
       (.I0(\rgb_out[23]_i_128_n_0 ),
        .I1(\rgb_out[23]_i_129_n_0 ),
        .I2(\rgb_out[23]_i_130_n_0 ),
        .I3(\rgb_out[23]_i_131_n_0 ),
        .I4(\rgb_out[23]_i_132_n_0 ),
        .O(\rgb_out[23]_i_34_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000000001)) 
    \rgb_out[23]_i_340 
       (.I0(pixel_x[2]),
        .I1(pixel_x[3]),
        .I2(pixel_x[11]),
        .I3(pixel_x[10]),
        .I4(pixel_x[9]),
        .I5(pixel_x[7]),
        .O(\rgb_out[23]_i_340_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000000E00)) 
    \rgb_out[23]_i_341 
       (.I0(\rgb_out[23]_i_564_n_0 ),
        .I1(\rgb_out[23]_i_346_n_0 ),
        .I2(pixel_x[4]),
        .I3(pixel_x[5]),
        .I4(\rgb_out[23]_i_353_n_0 ),
        .I5(\rgb_out[23]_i_337_n_0 ),
        .O(\rgb_out[23]_i_341_n_0 ));
  LUT6 #(
    .INIT(64'h5554555544444444)) 
    \rgb_out[23]_i_342 
       (.I0(\rgb_out[23]_i_569_n_0 ),
        .I1(pixel_x[11]),
        .I2(pixel_x[9]),
        .I3(pixel_x[8]),
        .I4(\rgb_out[20]_i_25_n_0 ),
        .I5(pixel_x[10]),
        .O(\rgb_out[23]_i_342_n_0 ));
  LUT6 #(
    .INIT(64'h0001010155555555)) 
    \rgb_out[23]_i_343 
       (.I0(pixel_x[11]),
        .I1(pixel_x[9]),
        .I2(pixel_x[8]),
        .I3(pixel_x[6]),
        .I4(pixel_x[7]),
        .I5(pixel_x[10]),
        .O(\rgb_out[23]_i_343_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair72" *) 
  LUT4 #(
    .INIT(16'hFFEF)) 
    \rgb_out[23]_i_344 
       (.I0(pixel_x[8]),
        .I1(pixel_x[9]),
        .I2(pixel_x[10]),
        .I3(pixel_x[11]),
        .O(\rgb_out[23]_i_344_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair11" *) 
  LUT5 #(
    .INIT(32'hFFFEFEFE)) 
    \rgb_out[23]_i_345 
       (.I0(pixel_x[11]),
        .I1(pixel_x[9]),
        .I2(pixel_x[8]),
        .I3(pixel_x[7]),
        .I4(pixel_x[6]),
        .O(\rgb_out[23]_i_345_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair39" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_346 
       (.I0(pixel_x[3]),
        .I1(pixel_x[2]),
        .O(\rgb_out[23]_i_346_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair122" *) 
  LUT3 #(
    .INIT(8'h7F)) 
    \rgb_out[23]_i_347 
       (.I0(pixel_x[10]),
        .I1(pixel_x[7]),
        .I2(pixel_x[6]),
        .O(\rgb_out[23]_i_347_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair26" *) 
  LUT5 #(
    .INIT(32'hE0000000)) 
    \rgb_out[23]_i_348 
       (.I0(pixel_x[5]),
        .I1(pixel_x[4]),
        .I2(pixel_x[6]),
        .I3(pixel_x[10]),
        .I4(pixel_x[7]),
        .O(\rgb_out[23]_i_348_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair76" *) 
  LUT4 #(
    .INIT(16'h15FF)) 
    \rgb_out[23]_i_349 
       (.I0(pixel_y[2]),
        .I1(pixel_y[1]),
        .I2(pixel_y[0]),
        .I3(pixel_y[3]),
        .O(\rgb_out[23]_i_349_n_0 ));
  LUT6 #(
    .INIT(64'h0000002A00000000)) 
    \rgb_out[23]_i_35 
       (.I0(\rgb_out[23]_i_42_n_0 ),
        .I1(pixel_y[4]),
        .I2(pixel_y[3]),
        .I3(pixel_y[5]),
        .I4(\rgb_out[23]_i_133_n_0 ),
        .I5(\rgb_out[23]_i_134_n_0 ),
        .O(\rgb_out[23]_i_35_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair49" *) 
  LUT3 #(
    .INIT(8'hFE)) 
    \rgb_out[23]_i_350 
       (.I0(pixel_x[4]),
        .I1(pixel_x[5]),
        .I2(pixel_x[6]),
        .O(\rgb_out[23]_i_350_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair122" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_351 
       (.I0(pixel_x[7]),
        .I1(pixel_x[10]),
        .O(\rgb_out[23]_i_351_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair57" *) 
  LUT4 #(
    .INIT(16'hFEAA)) 
    \rgb_out[23]_i_352 
       (.I0(pixel_x[11]),
        .I1(pixel_x[9]),
        .I2(pixel_x[8]),
        .I3(pixel_x[10]),
        .O(\rgb_out[23]_i_352_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair131" *) 
  LUT2 #(
    .INIT(4'h7)) 
    \rgb_out[23]_i_353 
       (.I0(pixel_x[6]),
        .I1(pixel_x[8]),
        .O(\rgb_out[23]_i_353_n_0 ));
  LUT6 #(
    .INIT(64'hF307F3FFFFFFFFFF)) 
    \rgb_out[23]_i_354 
       (.I0(pixel_x[2]),
        .I1(\rgb_out[23]_i_392_n_0 ),
        .I2(pixel_x[5]),
        .I3(pixel_x[6]),
        .I4(pixel_x[7]),
        .I5(pixel_x[8]),
        .O(\rgb_out[23]_i_354_n_0 ));
  LUT6 #(
    .INIT(64'h0000008000000000)) 
    \rgb_out[23]_i_355 
       (.I0(\rgb_out[23]_i_334_n_0 ),
        .I1(\rgb_out[23]_i_219_n_0 ),
        .I2(pixel_x[6]),
        .I3(\rgb_out[11]_i_29_n_0 ),
        .I4(pixel_x[5]),
        .I5(pixel_x[4]),
        .O(\rgb_out[23]_i_355_n_0 ));
  LUT6 #(
    .INIT(64'hA080AA8AAA8AAA8A)) 
    \rgb_out[23]_i_356 
       (.I0(\rgb_out[23]_i_677_n_0 ),
        .I1(\rgb_out[23]_i_224_n_0 ),
        .I2(\rgb_out[20]_i_25_n_0 ),
        .I3(\rgb_out[23]_i_346_n_0 ),
        .I4(pixel_x[6]),
        .I5(\rgb_out[23]_i_351_n_0 ),
        .O(\rgb_out[23]_i_356_n_0 ));
  LUT6 #(
    .INIT(64'h0F0F0FFF00000040)) 
    \rgb_out[23]_i_357 
       (.I0(pixel_x[2]),
        .I1(pixel_x[3]),
        .I2(\rgb_out[23]_i_557_n_0 ),
        .I3(\rgb_out[23]_i_353_n_0 ),
        .I4(\rgb_out[23]_i_233_n_0 ),
        .I5(\rgb_out[23]_i_340_n_0 ),
        .O(\rgb_out[23]_i_357_n_0 ));
  LUT6 #(
    .INIT(64'h555555557F777F7F)) 
    \rgb_out[23]_i_358 
       (.I0(pixel_x[10]),
        .I1(pixel_x[7]),
        .I2(pixel_x[6]),
        .I3(\rgb_out[23]_i_233_n_0 ),
        .I4(\rgb_out[23]_i_346_n_0 ),
        .I5(\rgb_out[23]_i_224_n_0 ),
        .O(\rgb_out[23]_i_358_n_0 ));
  LUT6 #(
    .INIT(64'h1115151515151515)) 
    \rgb_out[23]_i_359 
       (.I0(\rgb_out[23]_i_352_n_0 ),
        .I1(\rgb_out[23]_i_351_n_0 ),
        .I2(pixel_x[6]),
        .I3(pixel_x[5]),
        .I4(pixel_x[4]),
        .I5(pixel_x[3]),
        .O(\rgb_out[23]_i_359_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFF7F7FFF7F)) 
    \rgb_out[23]_i_36 
       (.I0(\rgb_out[23]_i_135_n_0 ),
        .I1(\rgb_out[23]_i_136_n_0 ),
        .I2(pixel_y[4]),
        .I3(pixel_y[3]),
        .I4(\rgb_out[23]_i_137_n_0 ),
        .I5(\rgb_out[23]_i_138_n_0 ),
        .O(\rgb_out[23]_i_36_n_0 ));
  LUT6 #(
    .INIT(64'h1111111111111F11)) 
    \rgb_out[23]_i_360 
       (.I0(\rgb_out[23]_i_678_n_0 ),
        .I1(\rgb_out[23]_i_352_n_0 ),
        .I2(\rgb_out[23]_i_567_n_0 ),
        .I3(\rgb_out[23]_i_334_n_0 ),
        .I4(pixel_x[11]),
        .I5(pixel_x[8]),
        .O(\rgb_out[23]_i_360_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFF1110)) 
    \rgb_out[23]_i_361 
       (.I0(\rgb_out[11]_i_11_n_0 ),
        .I1(\rgb_out[23]_i_679_n_0 ),
        .I2(\rgb_out[23]_i_345_n_0 ),
        .I3(\rgb_out[23]_i_680_n_0 ),
        .I4(\rgb_out[23]_i_681_n_0 ),
        .I5(\rgb_out[23]_i_682_n_0 ),
        .O(\rgb_out[23]_i_361_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair47" *) 
  LUT5 #(
    .INIT(32'h00000001)) 
    \rgb_out[23]_i_362 
       (.I0(pixel_x[6]),
        .I1(pixel_x[5]),
        .I2(pixel_x[9]),
        .I3(pixel_x[8]),
        .I4(pixel_x[11]),
        .O(\rgb_out[23]_i_362_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair132" *) 
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_363 
       (.I0(pixel_x[11]),
        .I1(pixel_x[6]),
        .O(\rgb_out[23]_i_363_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFEEEEEEEEE)) 
    \rgb_out[23]_i_364 
       (.I0(pixel_x[8]),
        .I1(pixel_x[9]),
        .I2(pixel_x[2]),
        .I3(pixel_x[3]),
        .I4(pixel_x[4]),
        .I5(pixel_x[5]),
        .O(\rgb_out[23]_i_364_n_0 ));
  LUT6 #(
    .INIT(64'h0000000101010101)) 
    \rgb_out[23]_i_365 
       (.I0(pixel_x[8]),
        .I1(pixel_x[9]),
        .I2(pixel_x[6]),
        .I3(pixel_x[3]),
        .I4(pixel_x[4]),
        .I5(pixel_x[5]),
        .O(\rgb_out[23]_i_365_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair71" *) 
  LUT4 #(
    .INIT(16'h01FF)) 
    \rgb_out[23]_i_366 
       (.I0(pixel_x[9]),
        .I1(pixel_x[8]),
        .I2(pixel_x[7]),
        .I3(pixel_x[10]),
        .O(\rgb_out[23]_i_366_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair17" *) 
  LUT4 #(
    .INIT(16'h0155)) 
    \rgb_out[23]_i_367 
       (.I0(pixel_x[6]),
        .I1(pixel_x[3]),
        .I2(pixel_x[4]),
        .I3(pixel_x[5]),
        .O(\rgb_out[23]_i_367_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair25" *) 
  LUT5 #(
    .INIT(32'h01FF0000)) 
    \rgb_out[23]_i_368 
       (.I0(pixel_y[0]),
        .I1(pixel_y[1]),
        .I2(pixel_y[2]),
        .I3(pixel_y[3]),
        .I4(\rgb_out[23]_i_683_n_0 ),
        .O(\rgb_out[23]_i_368_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair53" *) 
  LUT4 #(
    .INIT(16'hFEFF)) 
    \rgb_out[23]_i_369 
       (.I0(pixel_y[11]),
        .I1(pixel_y[10]),
        .I2(pixel_y[9]),
        .I3(pixel_y[8]),
        .O(\rgb_out[23]_i_369_n_0 ));
  LUT6 #(
    .INIT(64'hFFFCFFFCFFF44444)) 
    \rgb_out[23]_i_37 
       (.I0(\rgb_out[23]_i_121_n_0 ),
        .I1(\rgb_out[23]_i_128_n_0 ),
        .I2(\rgb_out[23]_i_123_n_0 ),
        .I3(\rgb_out[23]_i_127_n_0 ),
        .I4(\rgb_out[23]_i_35_n_0 ),
        .I5(\rgb_out[23]_i_139_n_0 ),
        .O(\rgb_out[23]_i_37_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_370 
       (.I0(pixel_x[0]),
        .I1(pixel_x[1]),
        .O(\rgb_out[23]_i_370_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFDFFF)) 
    \rgb_out[23]_i_371 
       (.I0(\rgb_out[20]_i_23_n_0 ),
        .I1(pixel_x[3]),
        .I2(\rgb_out[20]_i_25_n_0 ),
        .I3(\rgb_out[11]_i_11_n_0 ),
        .I4(pixel_x[6]),
        .I5(pixel_x[7]),
        .O(\rgb_out[23]_i_371_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair12" *) 
  LUT5 #(
    .INIT(32'h7FFFFFFF)) 
    \rgb_out[23]_i_372 
       (.I0(pixel_x[4]),
        .I1(pixel_x[5]),
        .I2(pixel_x[6]),
        .I3(pixel_x[7]),
        .I4(pixel_x[9]),
        .O(\rgb_out[23]_i_372_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair9" *) 
  LUT5 #(
    .INIT(32'h7FFFFFFF)) 
    \rgb_out[23]_i_373 
       (.I0(pixel_x[2]),
        .I1(pixel_x[1]),
        .I2(pixel_x[9]),
        .I3(pixel_x[8]),
        .I4(pixel_x[0]),
        .O(\rgb_out[23]_i_373_n_0 ));
  LUT6 #(
    .INIT(64'h0E000000FFFFFFFF)) 
    \rgb_out[23]_i_374 
       (.I0(pixel_x[0]),
        .I1(\rgb_out[11]_i_22_n_0 ),
        .I2(\rgb_out[23]_i_233_n_0 ),
        .I3(pixel_x[3]),
        .I4(\rgb_out[20]_i_23_n_0 ),
        .I5(\rgb_out[7]_i_73_n_0 ),
        .O(\rgb_out[23]_i_374_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair56" *) 
  LUT4 #(
    .INIT(16'h1FFF)) 
    \rgb_out[23]_i_375 
       (.I0(pixel_x[2]),
        .I1(pixel_x[3]),
        .I2(pixel_x[4]),
        .I3(pixel_x[5]),
        .O(\rgb_out[23]_i_375_n_0 ));
  LUT6 #(
    .INIT(64'h0000000080000000)) 
    \rgb_out[23]_i_376 
       (.I0(pixel_x[9]),
        .I1(pixel_x[8]),
        .I2(pixel_x[3]),
        .I3(pixel_x[4]),
        .I4(pixel_x[5]),
        .I5(\rgb_out[23]_i_394_n_0 ),
        .O(\rgb_out[23]_i_376_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair15" *) 
  LUT3 #(
    .INIT(8'h01)) 
    \rgb_out[23]_i_377 
       (.I0(pixel_x[1]),
        .I1(pixel_x[2]),
        .I2(pixel_x[6]),
        .O(\rgb_out[23]_i_377_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000002220)) 
    \rgb_out[23]_i_378 
       (.I0(pixel_x[5]),
        .I1(\rgb_out[20]_i_20_n_0 ),
        .I2(pixel_x[4]),
        .I3(\rgb_out[23]_i_246_n_0 ),
        .I4(\rgb_out[20]_i_19_n_0 ),
        .I5(\rgb_out[23]_i_684_n_0 ),
        .O(\rgb_out[23]_i_378_n_0 ));
  LUT6 #(
    .INIT(64'h77770000777F0000)) 
    \rgb_out[23]_i_379 
       (.I0(pixel_x[9]),
        .I1(pixel_x[8]),
        .I2(pixel_x[7]),
        .I3(pixel_x[6]),
        .I4(\rgb_out[11]_i_11_n_0 ),
        .I5(pixel_x[5]),
        .O(\rgb_out[23]_i_379_n_0 ));
  LUT6 #(
    .INIT(64'hFEEEFEFEFEFEFEFE)) 
    \rgb_out[23]_i_38 
       (.I0(\rgb_out[23]_i_140_n_0 ),
        .I1(\rgb_out[23]_i_141_n_0 ),
        .I2(\rgb_out[23]_i_135_n_0 ),
        .I3(\rgb_out[23]_i_66_n_0 ),
        .I4(pixel_y[7]),
        .I5(pixel_y[6]),
        .O(\rgb_out[23]_i_38_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair32" *) 
  LUT4 #(
    .INIT(16'h7FFF)) 
    \rgb_out[23]_i_380 
       (.I0(pixel_x[3]),
        .I1(pixel_x[9]),
        .I2(pixel_x[4]),
        .I3(pixel_x[8]),
        .O(\rgb_out[23]_i_380_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair38" *) 
  LUT4 #(
    .INIT(16'hFEAA)) 
    \rgb_out[23]_i_381 
       (.I0(pixel_x[3]),
        .I1(pixel_x[0]),
        .I2(pixel_x[1]),
        .I3(pixel_x[2]),
        .O(\rgb_out[23]_i_381_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair74" *) 
  LUT4 #(
    .INIT(16'h15FF)) 
    \rgb_out[23]_i_382 
       (.I0(pixel_x[3]),
        .I1(pixel_x[1]),
        .I2(pixel_x[2]),
        .I3(pixel_x[4]),
        .O(\rgb_out[23]_i_382_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair37" *) 
  LUT5 #(
    .INIT(32'h00000001)) 
    \rgb_out[23]_i_383 
       (.I0(pixel_x[5]),
        .I1(pixel_x[11]),
        .I2(pixel_x[10]),
        .I3(pixel_x[6]),
        .I4(pixel_x[7]),
        .O(\rgb_out[23]_i_383_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair32" *) 
  LUT5 #(
    .INIT(32'h7FFFFFFF)) 
    \rgb_out[23]_i_384 
       (.I0(pixel_x[8]),
        .I1(pixel_x[4]),
        .I2(pixel_x[9]),
        .I3(pixel_x[3]),
        .I4(pixel_x[2]),
        .O(\rgb_out[23]_i_384_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair30" *) 
  LUT3 #(
    .INIT(8'hFE)) 
    \rgb_out[23]_i_385 
       (.I0(pixel_x[5]),
        .I1(pixel_x[7]),
        .I2(pixel_x[6]),
        .O(\rgb_out[23]_i_385_n_0 ));
  LUT6 #(
    .INIT(64'h8000FFFFFFFFFFFF)) 
    \rgb_out[23]_i_386 
       (.I0(pixel_x[3]),
        .I1(pixel_x[4]),
        .I2(pixel_x[0]),
        .I3(pixel_x[1]),
        .I4(pixel_x[8]),
        .I5(pixel_x[9]),
        .O(\rgb_out[23]_i_386_n_0 ));
  LUT6 #(
    .INIT(64'hEAEAEAEAEAEAEAAA)) 
    \rgb_out[23]_i_387 
       (.I0(\rgb_out[23]_i_394_n_0 ),
        .I1(\rgb_out[20]_i_23_n_0 ),
        .I2(pixel_x[5]),
        .I3(pixel_x[4]),
        .I4(pixel_x[3]),
        .I5(pixel_x[2]),
        .O(\rgb_out[23]_i_387_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_388 
       (.I0(pixel_x[3]),
        .I1(pixel_x[7]),
        .O(\rgb_out[23]_i_388_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair127" *) 
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_389 
       (.I0(pixel_x[6]),
        .I1(pixel_x[4]),
        .O(\rgb_out[23]_i_389_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair76" *) 
  LUT3 #(
    .INIT(8'hA8)) 
    \rgb_out[23]_i_39 
       (.I0(pixel_y[2]),
        .I1(pixel_y[0]),
        .I2(pixel_y[1]),
        .O(\rgb_out[23]_i_39_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFEFFFEFFFEF)) 
    \rgb_out[23]_i_390 
       (.I0(pixel_x[7]),
        .I1(pixel_x[6]),
        .I2(\rgb_out[11]_i_11_n_0 ),
        .I3(pixel_x[4]),
        .I4(\rgb_out[11]_i_22_n_0 ),
        .I5(pixel_x[3]),
        .O(\rgb_out[23]_i_390_n_0 ));
  LUT6 #(
    .INIT(64'h4540555000000000)) 
    \rgb_out[23]_i_391 
       (.I0(\rgb_out[21]_i_6_n_0 ),
        .I1(\rgb_out[20]_i_17_n_0 ),
        .I2(\rgb_out[23]_i_683_n_0 ),
        .I3(\rgb_out[23]_i_133_n_0 ),
        .I4(\rgb_out[7]_i_66_n_0 ),
        .I5(pixel_y[8]),
        .O(\rgb_out[23]_i_391_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair133" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_392 
       (.I0(pixel_x[3]),
        .I1(pixel_x[4]),
        .O(\rgb_out[23]_i_392_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair111" *) 
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_393 
       (.I0(pixel_x[7]),
        .I1(pixel_x[8]),
        .O(\rgb_out[23]_i_393_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFE000)) 
    \rgb_out[23]_i_394 
       (.I0(pixel_x[6]),
        .I1(pixel_x[7]),
        .I2(pixel_x[9]),
        .I3(pixel_x[8]),
        .I4(pixel_x[11]),
        .I5(pixel_x[10]),
        .O(\rgb_out[23]_i_394_n_0 ));
  LUT5 #(
    .INIT(32'hAEFFFEFF)) 
    \rgb_out[23]_i_395 
       (.I0(\rgb_out[23]_i_397_n_0 ),
        .I1(\rgb_out[7]_i_42_n_0 ),
        .I2(\rgb_out[23]_i_71_n_0 ),
        .I3(\rgb_out[23]_i_396_n_0 ),
        .I4(\rgb_out[20]_i_18_n_0 ),
        .O(\rgb_out[23]_i_395_n_0 ));
  LUT6 #(
    .INIT(64'hFBFFFFFFFFFFFFFF)) 
    \rgb_out[23]_i_396 
       (.I0(\rgb_out[23]_i_300_n_0 ),
        .I1(\rgb_out[11]_i_11_n_0 ),
        .I2(pixel_x[7]),
        .I3(pixel_x[2]),
        .I4(pixel_x[6]),
        .I5(\rgb_out[20]_i_23_n_0 ),
        .O(\rgb_out[23]_i_396_n_0 ));
  LUT6 #(
    .INIT(64'h0000000008000000)) 
    \rgb_out[23]_i_397 
       (.I0(\rgb_out[20]_i_23_n_0 ),
        .I1(pixel_x[6]),
        .I2(\rgb_out[23]_i_570_n_0 ),
        .I3(\rgb_out[23]_i_401_n_0 ),
        .I4(\rgb_out[11]_i_11_n_0 ),
        .I5(pixel_x[7]),
        .O(\rgb_out[23]_i_397_n_0 ));
  LUT6 #(
    .INIT(64'h8000000000000000)) 
    \rgb_out[23]_i_398 
       (.I0(\rgb_out[7]_i_73_n_0 ),
        .I1(\rgb_out[20]_i_23_n_0 ),
        .I2(pixel_x[2]),
        .I3(pixel_x[3]),
        .I4(pixel_x[4]),
        .I5(pixel_x[5]),
        .O(\rgb_out[23]_i_398_n_0 ));
  LUT6 #(
    .INIT(64'h0000200000000000)) 
    \rgb_out[23]_i_399 
       (.I0(\rgb_out[23]_i_346_n_0 ),
        .I1(pixel_x[4]),
        .I2(\rgb_out[20]_i_23_n_0 ),
        .I3(pixel_x[5]),
        .I4(\rgb_out[20]_i_24_n_0 ),
        .I5(\rgb_out[11]_i_11_n_0 ),
        .O(\rgb_out[23]_i_399_n_0 ));
  LUT5 #(
    .INIT(32'h20AAAAAA)) 
    \rgb_out[23]_i_4 
       (.I0(\rgb_out[11]_i_4_n_0 ),
        .I1(\rgb_out[11]_i_5_n_0 ),
        .I2(rgb_in[23]),
        .I3(\rgb_out[23]_i_9_n_0 ),
        .I4(\rgb_out[23]_i_10_n_0 ),
        .O(\rgb_out[23]_i_4_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair58" *) 
  LUT2 #(
    .INIT(4'h7)) 
    \rgb_out[23]_i_40 
       (.I0(pixel_y[8]),
        .I1(pixel_y[7]),
        .O(\rgb_out[23]_i_40_n_0 ));
  LUT6 #(
    .INIT(64'h0000000002000000)) 
    \rgb_out[23]_i_400 
       (.I0(pixel_x[2]),
        .I1(pixel_x[3]),
        .I2(pixel_x[4]),
        .I3(pixel_x[5]),
        .I4(\rgb_out[20]_i_23_n_0 ),
        .I5(\rgb_out[23]_i_394_n_0 ),
        .O(\rgb_out[23]_i_400_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair55" *) 
  LUT4 #(
    .INIT(16'hFEAA)) 
    \rgb_out[23]_i_401 
       (.I0(pixel_x[5]),
        .I1(pixel_x[3]),
        .I2(pixel_x[2]),
        .I3(pixel_x[4]),
        .O(\rgb_out[23]_i_401_n_0 ));
  LUT6 #(
    .INIT(64'h40554040FFFFFFFF)) 
    \rgb_out[23]_i_402 
       (.I0(\rgb_out[23]_i_685_n_0 ),
        .I1(\rgb_out[23]_i_392_n_0 ),
        .I2(\rgb_out[23]_i_175_n_0 ),
        .I3(\rgb_out[23]_i_282_n_0 ),
        .I4(\rgb_out[23]_i_686_n_0 ),
        .I5(\rgb_out[23]_i_174_n_0 ),
        .O(\rgb_out[23]_i_402_n_0 ));
  LUT6 #(
    .INIT(64'h000000007F000000)) 
    \rgb_out[23]_i_403 
       (.I0(pixel_x[6]),
        .I1(pixel_x[4]),
        .I2(pixel_x[3]),
        .I3(\rgb_out[23]_i_687_n_0 ),
        .I4(\rgb_out[23]_i_219_n_0 ),
        .I5(\rgb_out[23]_i_415_n_0 ),
        .O(\rgb_out[23]_i_403_n_0 ));
  LUT6 #(
    .INIT(64'h0080000000000000)) 
    \rgb_out[23]_i_404 
       (.I0(\rgb_out[23]_i_174_n_0 ),
        .I1(pixel_x[2]),
        .I2(pixel_x[1]),
        .I3(pixel_x[4]),
        .I4(pixel_x[5]),
        .I5(pixel_x[3]),
        .O(\rgb_out[23]_i_404_n_0 ));
  LUT6 #(
    .INIT(64'hE0E0E00000000000)) 
    \rgb_out[23]_i_405 
       (.I0(pixel_x[11]),
        .I1(\rgb_out[23]_i_688_n_0 ),
        .I2(\rgb_out[23]_i_352_n_0 ),
        .I3(\rgb_out[23]_i_689_n_0 ),
        .I4(\rgb_out[23]_i_382_n_0 ),
        .I5(\rgb_out[23]_i_159_n_0 ),
        .O(\rgb_out[23]_i_405_n_0 ));
  LUT6 #(
    .INIT(64'h0000008000000000)) 
    \rgb_out[23]_i_406 
       (.I0(\rgb_out[23]_i_174_n_0 ),
        .I1(pixel_x[3]),
        .I2(pixel_x[5]),
        .I3(pixel_x[4]),
        .I4(pixel_x[1]),
        .I5(pixel_x[2]),
        .O(\rgb_out[23]_i_406_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFAAAAFBAA)) 
    \rgb_out[23]_i_407 
       (.I0(\rgb_out[23]_i_454_n_0 ),
        .I1(\rgb_out[23]_i_425_n_0 ),
        .I2(\rgb_out[23]_i_690_n_0 ),
        .I3(\rgb_out[23]_i_423_n_0 ),
        .I4(\rgb_out[23]_i_691_n_0 ),
        .I5(\rgb_out[23]_i_692_n_0 ),
        .O(\rgb_out[23]_i_407_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair89" *) 
  LUT3 #(
    .INIT(8'h01)) 
    \rgb_out[23]_i_408 
       (.I0(pixel_y[7]),
        .I1(pixel_y[5]),
        .I2(pixel_y[6]),
        .O(\rgb_out[23]_i_408_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFFFFE)) 
    \rgb_out[23]_i_409 
       (.I0(pixel_y[11]),
        .I1(pixel_y[10]),
        .I2(pixel_y[9]),
        .I3(pixel_y[7]),
        .I4(pixel_y[6]),
        .I5(pixel_y[8]),
        .O(\rgb_out[23]_i_409_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFFFFE)) 
    \rgb_out[23]_i_41 
       (.I0(pixel_y[11]),
        .I1(pixel_y[10]),
        .I2(pixel_y[9]),
        .I3(pixel_y[5]),
        .I4(pixel_y[4]),
        .I5(pixel_y[3]),
        .O(\rgb_out[23]_i_41_n_0 ));
  LUT6 #(
    .INIT(64'h000E0E0E0E0E0E0E)) 
    \rgb_out[23]_i_410 
       (.I0(\rgb_out[23]_i_693_n_0 ),
        .I1(\rgb_out[23]_i_694_n_0 ),
        .I2(\rgb_out[23]_i_695_n_0 ),
        .I3(\rgb_out[23]_i_696_n_0 ),
        .I4(\rgb_out[23]_i_697_n_0 ),
        .I5(\rgb_out[23]_i_698_n_0 ),
        .O(\rgb_out[23]_i_410_n_0 ));
  LUT6 #(
    .INIT(64'hEEFEEEFEEEFEEEEE)) 
    \rgb_out[23]_i_411 
       (.I0(\rgb_out[23]_i_699_n_0 ),
        .I1(\rgb_out[23]_i_700_n_0 ),
        .I2(\rgb_out[23]_i_696_n_0 ),
        .I3(\rgb_out[23]_i_701_n_0 ),
        .I4(\rgb_out[23]_i_537_n_0 ),
        .I5(\rgb_out[23]_i_434_n_0 ),
        .O(\rgb_out[23]_i_411_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000000888)) 
    \rgb_out[23]_i_412 
       (.I0(\rgb_out[23]_i_421_n_0 ),
        .I1(\rgb_out[23]_i_698_n_0 ),
        .I2(\rgb_out[23]_i_702_n_0 ),
        .I3(pixel_x[5]),
        .I4(\rgb_out[23]_i_703_n_0 ),
        .I5(\rgb_out[23]_i_694_n_0 ),
        .O(\rgb_out[23]_i_412_n_0 ));
  LUT6 #(
    .INIT(64'h00FF00FFE0FFE0E0)) 
    \rgb_out[23]_i_413 
       (.I0(\rgb_out[23]_i_224_n_0 ),
        .I1(pixel_x[6]),
        .I2(\rgb_out[23]_i_414_n_0 ),
        .I3(\rgb_out[23]_i_436_n_0 ),
        .I4(\rgb_out[23]_i_174_n_0 ),
        .I5(\rgb_out[23]_i_704_n_0 ),
        .O(\rgb_out[23]_i_413_n_0 ));
  LUT6 #(
    .INIT(64'h0000222AAAAAAAAA)) 
    \rgb_out[23]_i_414 
       (.I0(\rgb_out[23]_i_686_n_0 ),
        .I1(pixel_x[4]),
        .I2(pixel_x[2]),
        .I3(pixel_x[3]),
        .I4(pixel_x[5]),
        .I5(pixel_x[6]),
        .O(\rgb_out[23]_i_414_n_0 ));
  LUT6 #(
    .INIT(64'h22222AAA222222AA)) 
    \rgb_out[23]_i_415 
       (.I0(\rgb_out[23]_i_686_n_0 ),
        .I1(pixel_x[6]),
        .I2(pixel_x[3]),
        .I3(pixel_x[4]),
        .I4(pixel_x[5]),
        .I5(\rgb_out[23]_i_223_n_0 ),
        .O(\rgb_out[23]_i_415_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair15" *) 
  LUT5 #(
    .INIT(32'h80000000)) 
    \rgb_out[23]_i_416 
       (.I0(\rgb_out[23]_i_436_n_0 ),
        .I1(pixel_x[6]),
        .I2(pixel_x[3]),
        .I3(pixel_x[1]),
        .I4(pixel_x[2]),
        .O(\rgb_out[23]_i_416_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFEFEFEEE)) 
    \rgb_out[23]_i_417 
       (.I0(pixel_x[2]),
        .I1(pixel_x[1]),
        .I2(pixel_x[8]),
        .I3(pixel_x[7]),
        .I4(pixel_x[6]),
        .I5(pixel_x[9]),
        .O(\rgb_out[23]_i_417_n_0 ));
  LUT6 #(
    .INIT(64'hF7FFFFFFFFFFFFFF)) 
    \rgb_out[23]_i_418 
       (.I0(pixel_x[5]),
        .I1(pixel_x[8]),
        .I2(pixel_x[11]),
        .I3(pixel_x[10]),
        .I4(pixel_x[4]),
        .I5(pixel_x[3]),
        .O(\rgb_out[23]_i_418_n_0 ));
  LUT6 #(
    .INIT(64'h80A0000000000000)) 
    \rgb_out[23]_i_419 
       (.I0(pixel_y[4]),
        .I1(pixel_y[3]),
        .I2(pixel_y[2]),
        .I3(pixel_y[1]),
        .I4(\rgb_out[23]_i_135_n_0 ),
        .I5(\rgb_out[23]_i_408_n_0 ),
        .O(\rgb_out[23]_i_419_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000000037)) 
    \rgb_out[23]_i_42 
       (.I0(pixel_y[6]),
        .I1(pixel_y[8]),
        .I2(pixel_y[7]),
        .I3(pixel_y[9]),
        .I4(pixel_y[10]),
        .I5(pixel_y[11]),
        .O(\rgb_out[23]_i_42_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFF7FFF)) 
    \rgb_out[23]_i_420 
       (.I0(pixel_x[1]),
        .I1(pixel_x[2]),
        .I2(\rgb_out[23]_i_174_n_0 ),
        .I3(pixel_x[5]),
        .I4(pixel_x[4]),
        .I5(pixel_x[3]),
        .O(\rgb_out[23]_i_420_n_0 ));
  LUT6 #(
    .INIT(64'h1000000080000000)) 
    \rgb_out[23]_i_421 
       (.I0(pixel_y[1]),
        .I1(pixel_y[2]),
        .I2(pixel_y[4]),
        .I3(\rgb_out[23]_i_135_n_0 ),
        .I4(\rgb_out[23]_i_408_n_0 ),
        .I5(pixel_y[3]),
        .O(\rgb_out[23]_i_421_n_0 ));
  LUT6 #(
    .INIT(64'h4FFF4FFF4FFFFFFF)) 
    \rgb_out[23]_i_422 
       (.I0(\rgb_out[11]_i_22_n_0 ),
        .I1(\rgb_out[23]_i_705_n_0 ),
        .I2(\rgb_out[23]_i_352_n_0 ),
        .I3(\rgb_out[23]_i_706_n_0 ),
        .I4(\rgb_out[23]_i_707_n_0 ),
        .I5(\rgb_out[23]_i_708_n_0 ),
        .O(\rgb_out[23]_i_422_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair124" *) 
  LUT3 #(
    .INIT(8'hA8)) 
    \rgb_out[23]_i_423 
       (.I0(pixel_x[10]),
        .I1(pixel_x[8]),
        .I2(pixel_x[9]),
        .O(\rgb_out[23]_i_423_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair54" *) 
  LUT4 #(
    .INIT(16'h8000)) 
    \rgb_out[23]_i_424 
       (.I0(pixel_x[4]),
        .I1(pixel_x[3]),
        .I2(pixel_x[2]),
        .I3(pixel_x[1]),
        .O(\rgb_out[23]_i_424_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair48" *) 
  LUT4 #(
    .INIT(16'h0001)) 
    \rgb_out[23]_i_425 
       (.I0(pixel_x[7]),
        .I1(pixel_x[6]),
        .I2(pixel_x[5]),
        .I3(pixel_x[9]),
        .O(\rgb_out[23]_i_425_n_0 ));
  LUT6 #(
    .INIT(64'hBFFFFFFFFFFFFFFF)) 
    \rgb_out[23]_i_426 
       (.I0(pixel_y[3]),
        .I1(\rgb_out[23]_i_408_n_0 ),
        .I2(\rgb_out[23]_i_135_n_0 ),
        .I3(pixel_y[4]),
        .I4(pixel_y[2]),
        .I5(pixel_y[1]),
        .O(\rgb_out[23]_i_426_n_0 ));
  LUT6 #(
    .INIT(64'h000000000E000000)) 
    \rgb_out[23]_i_427 
       (.I0(\rgb_out[23]_i_709_n_0 ),
        .I1(\rgb_out[23]_i_156_n_0 ),
        .I2(pixel_x[1]),
        .I3(pixel_x[2]),
        .I4(\rgb_out[23]_i_392_n_0 ),
        .I5(\rgb_out[23]_i_689_n_0 ),
        .O(\rgb_out[23]_i_427_n_0 ));
  LUT6 #(
    .INIT(64'h0300000000000C22)) 
    \rgb_out[23]_i_428 
       (.I0(\rgb_out[23]_i_710_n_0 ),
        .I1(pixel_y[3]),
        .I2(\rgb_out[23]_i_455_n_0 ),
        .I3(pixel_y[4]),
        .I4(pixel_y[2]),
        .I5(pixel_y[1]),
        .O(\rgb_out[23]_i_428_n_0 ));
  LUT6 #(
    .INIT(64'h808F808080808080)) 
    \rgb_out[23]_i_429 
       (.I0(pixel_x[6]),
        .I1(pixel_x[3]),
        .I2(pixel_x[2]),
        .I3(pixel_x[1]),
        .I4(\rgb_out[20]_i_25_n_0 ),
        .I5(\rgb_out[23]_i_686_n_0 ),
        .O(\rgb_out[23]_i_429_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFD0000)) 
    \rgb_out[23]_i_43 
       (.I0(\rgb_out[23]_i_88_n_0 ),
        .I1(\rgb_out[23]_i_142_n_0 ),
        .I2(\rgb_out[23]_i_143_n_0 ),
        .I3(\rgb_out[23]_i_144_n_0 ),
        .I4(\rgb_out[23]_i_145_n_0 ),
        .I5(\rgb_out[23]_i_146_n_0 ),
        .O(\rgb_out[23]_i_43_n_0 ));
  LUT6 #(
    .INIT(64'h00000000AAAAAAA2)) 
    \rgb_out[23]_i_430 
       (.I0(\rgb_out[23]_i_436_n_0 ),
        .I1(\rgb_out[23]_i_686_n_0 ),
        .I2(pixel_x[5]),
        .I3(pixel_x[4]),
        .I4(pixel_x[3]),
        .I5(\rgb_out[23]_i_174_n_0 ),
        .O(\rgb_out[23]_i_430_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFF1000FFFF)) 
    \rgb_out[23]_i_431 
       (.I0(pixel_x[5]),
        .I1(pixel_x[9]),
        .I2(\rgb_out[11]_i_11_n_0 ),
        .I3(\rgb_out[23]_i_711_n_0 ),
        .I4(\rgb_out[23]_i_712_n_0 ),
        .I5(\rgb_out[23]_i_174_n_0 ),
        .O(\rgb_out[23]_i_431_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000000004)) 
    \rgb_out[23]_i_432 
       (.I0(\rgb_out[23]_i_409_n_0 ),
        .I1(pixel_y[5]),
        .I2(pixel_y[4]),
        .I3(pixel_y[3]),
        .I4(pixel_y[2]),
        .I5(pixel_y[1]),
        .O(\rgb_out[23]_i_432_n_0 ));
  LUT6 #(
    .INIT(64'h0005555501055555)) 
    \rgb_out[23]_i_433 
       (.I0(pixel_x[11]),
        .I1(\rgb_out[20]_i_24_n_0 ),
        .I2(pixel_x[9]),
        .I3(pixel_x[8]),
        .I4(pixel_x[10]),
        .I5(\rgb_out[23]_i_222_n_0 ),
        .O(\rgb_out[23]_i_433_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair21" *) 
  LUT4 #(
    .INIT(16'hFFFE)) 
    \rgb_out[23]_i_434 
       (.I0(pixel_x[7]),
        .I1(pixel_x[11]),
        .I2(pixel_x[6]),
        .I3(pixel_x[9]),
        .O(\rgb_out[23]_i_434_n_0 ));
  LUT6 #(
    .INIT(64'h5555555555554044)) 
    \rgb_out[23]_i_435 
       (.I0(\rgb_out[23]_i_159_n_0 ),
        .I1(pixel_x[4]),
        .I2(pixel_x[1]),
        .I3(\rgb_out[23]_i_334_n_0 ),
        .I4(\rgb_out[20]_i_24_n_0 ),
        .I5(\rgb_out[23]_i_713_n_0 ),
        .O(\rgb_out[23]_i_435_n_0 ));
  LUT6 #(
    .INIT(64'h0003010300000000)) 
    \rgb_out[23]_i_436 
       (.I0(pixel_x[5]),
        .I1(pixel_x[7]),
        .I2(pixel_x[8]),
        .I3(pixel_x[6]),
        .I4(pixel_x[4]),
        .I5(\rgb_out[23]_i_219_n_0 ),
        .O(\rgb_out[23]_i_436_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair40" *) 
  LUT5 #(
    .INIT(32'h80000000)) 
    \rgb_out[23]_i_437 
       (.I0(\rgb_out[23]_i_408_n_0 ),
        .I1(\rgb_out[23]_i_135_n_0 ),
        .I2(pixel_y[2]),
        .I3(pixel_y[3]),
        .I4(pixel_y[4]),
        .O(\rgb_out[23]_i_437_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair66" *) 
  LUT4 #(
    .INIT(16'hAAFB)) 
    \rgb_out[23]_i_44 
       (.I0(\rgb_out[20]_i_9_n_0 ),
        .I1(\rgb_out[20]_i_10_n_0 ),
        .I2(\rgb_out[20]_i_11_n_0 ),
        .I3(\rgb_out[20]_i_12_n_0 ),
        .O(\rgb_out[23]_i_44_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair62" *) 
  LUT4 #(
    .INIT(16'h8000)) 
    \rgb_out[23]_i_442 
       (.I0(\pixel_y[5]_0 ),
        .I1(\pixel_x[1]_4 ),
        .I2(\SC_U/pixel_on9 ),
        .I3(\rgb_out[23]_i_734_n_0 ),
        .O(\rgb_out[23]_i_442_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000800000)) 
    \rgb_out[23]_i_443 
       (.I0(\pixel_y[2]_7 ),
        .I1(\pixel_x[1]_4 ),
        .I2(\SC_U/pixel_on9 ),
        .I3(\rgb_out[23]_i_736_n_0 ),
        .I4(\pixel_y[2]_8 ),
        .I5(\rgb_out[23]_i_738_n_0 ),
        .O(\rgb_out[23]_i_443_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair20" *) 
  LUT5 #(
    .INIT(32'h7557D55D)) 
    \rgb_out[23]_i_444 
       (.I0(\pixel_y[2]_3 ),
        .I1(score_courant[0]),
        .I2(score_courant[1]),
        .I3(score_courant[3]),
        .I4(score_courant[2]),
        .O(\rgb_out[23]_i_444_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair62" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_445 
       (.I0(\pixel_x[1]_4 ),
        .I1(\SC_U/pixel_on9 ),
        .O(\rgb_out[23]_i_445_n_0 ));
  LUT6 #(
    .INIT(64'h8888800080008000)) 
    \rgb_out[23]_i_446 
       (.I0(\pixel_y[2]_6 ),
        .I1(\pixel_y[5]_1 ),
        .I2(\SC_U/segments [1]),
        .I3(\pixel_x[6] ),
        .I4(\rgb_out[23]_i_744_n_0 ),
        .I5(\pixel_x[1]_5 ),
        .O(\rgb_out[23]_i_446_n_0 ));
  LUT6 #(
    .INIT(64'h8888800080008000)) 
    \rgb_out[23]_i_447 
       (.I0(\pixel_y[2]_4 ),
        .I1(\pixel_y[2]_5 ),
        .I2(\SC_U/segments [2]),
        .I3(\pixel_x[6] ),
        .I4(\rgb_out[23]_i_749_n_0 ),
        .I5(\pixel_x[1]_5 ),
        .O(\rgb_out[23]_i_447_n_0 ));
  LUT5 #(
    .INIT(32'h0000E000)) 
    \rgb_out[23]_i_448 
       (.I0(\pixel_y[2]_1 ),
        .I1(\pixel_y[5] ),
        .I2(\SC_D/pixel_on9 ),
        .I3(\pixel_x[1]_2 ),
        .I4(score_diz),
        .O(\rgb_out[23]_i_448_n_0 ));
  LUT4 #(
    .INIT(16'hF888)) 
    \rgb_out[23]_i_449 
       (.I0(\SC_D/pixel_on83_in ),
        .I1(\SC_D/pixel_on7 ),
        .I2(\pixel_y[2]_2 ),
        .I3(\SC_D/pixel_on66_in ),
        .O(\rgb_out[23]_i_449_n_0 ));
  LUT6 #(
    .INIT(64'hFEFFFEFFFEFFFEFE)) 
    \rgb_out[23]_i_45 
       (.I0(\rgb_out[23]_i_147_n_0 ),
        .I1(\rgb_out[23]_i_148_n_0 ),
        .I2(\rgb_out[23]_i_149_n_0 ),
        .I3(\rgb_out[23]_i_150_n_0 ),
        .I4(\rgb_out[23]_i_145_n_0 ),
        .I5(\rgb_out[23]_i_151_n_0 ),
        .O(\rgb_out[23]_i_45_n_0 ));
  LUT3 #(
    .INIT(8'hE0)) 
    \rgb_out[23]_i_451 
       (.I0(score_courant[2]),
        .I1(score_courant[1]),
        .I2(score_courant[3]),
        .O(score_diz));
  LUT4 #(
    .INIT(16'h7FFF)) 
    \rgb_out[23]_i_453 
       (.I0(\pixel_y[2] ),
        .I1(\pixel_x[1]_0 ),
        .I2(\pixel_y[2]_0 ),
        .I3(\pixel_x[1]_1 ),
        .O(\rgb_out[23]_i_453_n_0 ));
  LUT6 #(
    .INIT(64'h00000000000000D0)) 
    \rgb_out[23]_i_454 
       (.I0(\rgb_out[23]_i_705_n_0 ),
        .I1(\rgb_out[23]_i_230_n_0 ),
        .I2(\rgb_out[23]_i_352_n_0 ),
        .I3(\rgb_out[23]_i_702_n_0 ),
        .I4(\rgb_out[23]_i_713_n_0 ),
        .I5(\rgb_out[23]_i_772_n_0 ),
        .O(\rgb_out[23]_i_454_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair89" *) 
  LUT4 #(
    .INIT(16'hFEFF)) 
    \rgb_out[23]_i_455 
       (.I0(pixel_y[7]),
        .I1(pixel_y[5]),
        .I2(pixel_y[6]),
        .I3(\rgb_out[23]_i_135_n_0 ),
        .O(\rgb_out[23]_i_455_n_0 ));
  LUT6 #(
    .INIT(64'h0000800000000000)) 
    \rgb_out[23]_i_456 
       (.I0(\rgb_out[23]_i_408_n_0 ),
        .I1(pixel_y[4]),
        .I2(pixel_y[3]),
        .I3(pixel_y[2]),
        .I4(pixel_y[1]),
        .I5(\rgb_out[23]_i_135_n_0 ),
        .O(\rgb_out[23]_i_456_n_0 ));
  LUT6 #(
    .INIT(64'h0000000080000000)) 
    \rgb_out[23]_i_457 
       (.I0(\rgb_out[23]_i_686_n_0 ),
        .I1(pixel_x[6]),
        .I2(\rgb_out[20]_i_25_n_0 ),
        .I3(pixel_x[2]),
        .I4(pixel_x[1]),
        .I5(pixel_x[3]),
        .O(\rgb_out[23]_i_457_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFDDD5D5D5)) 
    \rgb_out[23]_i_458 
       (.I0(\rgb_out[23]_i_174_n_0 ),
        .I1(pixel_x[5]),
        .I2(pixel_x[4]),
        .I3(pixel_x[2]),
        .I4(pixel_x[3]),
        .I5(\rgb_out[23]_i_173_n_0 ),
        .O(\rgb_out[23]_i_458_n_0 ));
  LUT6 #(
    .INIT(64'h000400FFFFFFFFFF)) 
    \rgb_out[23]_i_459 
       (.I0(pixel_x[7]),
        .I1(\rgb_out[23]_i_233_n_0 ),
        .I2(pixel_x[6]),
        .I3(pixel_x[9]),
        .I4(pixel_x[8]),
        .I5(pixel_x[10]),
        .O(\rgb_out[23]_i_459_n_0 ));
  LUT6 #(
    .INIT(64'hAF03AF0300000F03)) 
    \rgb_out[23]_i_46 
       (.I0(\rgb_out[23]_i_152_n_0 ),
        .I1(\rgb_out[23]_i_153_n_0 ),
        .I2(\rgb_out[23]_i_154_n_0 ),
        .I3(\rgb_out[23]_i_155_n_0 ),
        .I4(\rgb_out[23]_i_156_n_0 ),
        .I5(\rgb_out[23]_i_157_n_0 ),
        .O(\rgb_out[23]_i_46_n_0 ));
  LUT6 #(
    .INIT(64'hF5F5F5F5F5F5F5F7)) 
    \rgb_out[23]_i_460 
       (.I0(\rgb_out[11]_i_33_n_0 ),
        .I1(pixel_x[7]),
        .I2(pixel_x[11]),
        .I3(pixel_x[2]),
        .I4(pixel_x[6]),
        .I5(\rgb_out[11]_i_32_n_0 ),
        .O(\rgb_out[23]_i_460_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000000001)) 
    \rgb_out[23]_i_461 
       (.I0(pixel_x[7]),
        .I1(pixel_x[6]),
        .I2(pixel_x[3]),
        .I3(pixel_x[4]),
        .I4(pixel_x[9]),
        .I5(pixel_x[5]),
        .O(\rgb_out[23]_i_461_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair72" *) 
  LUT4 #(
    .INIT(16'hDDDF)) 
    \rgb_out[23]_i_462 
       (.I0(pixel_x[10]),
        .I1(pixel_x[11]),
        .I2(pixel_x[8]),
        .I3(pixel_x[9]),
        .O(\rgb_out[23]_i_462_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFAAAAAAFE)) 
    \rgb_out[23]_i_463 
       (.I0(\rgb_out[23]_i_773_n_0 ),
        .I1(pixel_x[11]),
        .I2(pixel_x[1]),
        .I3(pixel_x[7]),
        .I4(\rgb_out[23]_i_774_n_0 ),
        .I5(\rgb_out[23]_i_775_n_0 ),
        .O(\rgb_out[23]_i_463_n_0 ));
  LUT6 #(
    .INIT(64'h22FF333320203030)) 
    \rgb_out[23]_i_464 
       (.I0(\rgb_out[23]_i_223_n_0 ),
        .I1(\rgb_out[23]_i_712_n_0 ),
        .I2(\rgb_out[23]_i_174_n_0 ),
        .I3(\rgb_out[7]_i_70_n_0 ),
        .I4(pixel_x[6]),
        .I5(\rgb_out[23]_i_776_n_0 ),
        .O(\rgb_out[23]_i_464_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000004000)) 
    \rgb_out[23]_i_465 
       (.I0(pixel_x[4]),
        .I1(\rgb_out[11]_i_11_n_0 ),
        .I2(\rgb_out[20]_i_23_n_0 ),
        .I3(pixel_x[5]),
        .I4(pixel_x[7]),
        .I5(pixel_x[6]),
        .O(\rgb_out[23]_i_465_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair134" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_466 
       (.I0(pixel_x[0]),
        .I1(pixel_x[1]),
        .O(\rgb_out[23]_i_466_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000000001)) 
    \rgb_out[23]_i_467 
       (.I0(pixel_x[1]),
        .I1(pixel_x[0]),
        .I2(pixel_x[3]),
        .I3(pixel_x[7]),
        .I4(pixel_x[6]),
        .I5(pixel_x[4]),
        .O(\rgb_out[23]_i_467_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000000010)) 
    \rgb_out[23]_i_468 
       (.I0(pixel_x[7]),
        .I1(pixel_x[6]),
        .I2(\rgb_out[11]_i_11_n_0 ),
        .I3(pixel_x[5]),
        .I4(pixel_x[4]),
        .I5(pixel_x[3]),
        .O(\rgb_out[23]_i_468_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair38" *) 
  LUT5 #(
    .INIT(32'h0001FFFF)) 
    \rgb_out[23]_i_469 
       (.I0(pixel_x[3]),
        .I1(pixel_x[2]),
        .I2(pixel_x[0]),
        .I3(pixel_x[1]),
        .I4(pixel_x[4]),
        .O(\rgb_out[23]_i_469_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFAEFFAEFFAE)) 
    \rgb_out[23]_i_47 
       (.I0(\rgb_out[23]_i_158_n_0 ),
        .I1(\rgb_out[23]_i_159_n_0 ),
        .I2(\rgb_out[23]_i_160_n_0 ),
        .I3(\rgb_out[23]_i_161_n_0 ),
        .I4(\rgb_out[23]_i_162_n_0 ),
        .I5(\rgb_out[23]_i_163_n_0 ),
        .O(\rgb_out[23]_i_47_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFFFEA)) 
    \rgb_out[23]_i_48 
       (.I0(\rgb_out[23]_i_164_n_0 ),
        .I1(\rgb_out[23]_i_165_n_0 ),
        .I2(\SC_U/pixel_on0 ),
        .I3(num_sc_d),
        .I4(\rgb_out[23]_i_168_n_0 ),
        .I5(\rgb_out[23]_i_169_n_0 ),
        .O(\rgb_out[23]_i_48_n_0 ));
  LUT4 #(
    .INIT(16'h4F44)) 
    \rgb_out[23]_i_49 
       (.I0(\rgb_out[23]_i_170_n_0 ),
        .I1(\rgb_out[23]_i_153_n_0 ),
        .I2(\rgb_out[23]_i_171_n_0 ),
        .I3(\rgb_out[23]_i_172_n_0 ),
        .O(\rgb_out[23]_i_49_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFF77F70000)) 
    \rgb_out[23]_i_5 
       (.I0(\rgb_out[23]_i_10_n_0 ),
        .I1(\rgb_out[23]_i_11_n_0 ),
        .I2(rgb_in[23]),
        .I3(\rgb_out[23]_i_12_n_0 ),
        .I4(\rgb_out[23]_i_13_n_0 ),
        .I5(\rgb_out[23]_i_14_n_0 ),
        .O(\rgb_out[23]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFF00040000)) 
    \rgb_out[23]_i_50 
       (.I0(\rgb_out[23]_i_173_n_0 ),
        .I1(\rgb_out[23]_i_174_n_0 ),
        .I2(\rgb_out[23]_i_175_n_0 ),
        .I3(\rgb_out[23]_i_176_n_0 ),
        .I4(\rgb_out[23]_i_162_n_0 ),
        .I5(\rgb_out[23]_i_177_n_0 ),
        .O(\rgb_out[23]_i_50_n_0 ));
  LUT6 #(
    .INIT(64'h00FC00FCFFFFAAFE)) 
    \rgb_out[23]_i_51 
       (.I0(\rgb_out[23]_i_156_n_0 ),
        .I1(\rgb_out[23]_i_153_n_0 ),
        .I2(\rgb_out[23]_i_154_n_0 ),
        .I3(\rgb_out[23]_i_178_n_0 ),
        .I4(\rgb_out[23]_i_179_n_0 ),
        .I5(\rgb_out[23]_i_180_n_0 ),
        .O(\rgb_out[23]_i_51_n_0 ));
  LUT6 #(
    .INIT(64'h77FF70FF77FF7070)) 
    \rgb_out[23]_i_52 
       (.I0(\rgb_out[23]_i_181_n_0 ),
        .I1(\rgb_out[23]_i_182_n_0 ),
        .I2(\rgb_out[7]_i_9_n_0 ),
        .I3(\rgb_out[23]_i_183_n_0 ),
        .I4(\rgb_out[7]_i_12_n_0 ),
        .I5(\rgb_out[7]_i_13_n_0 ),
        .O(\rgb_out[23]_i_52_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFEFFFF)) 
    \rgb_out[23]_i_521 
       (.I0(\rgb_out[23]_i_522_n_0 ),
        .I1(pixel_x[11]),
        .I2(pixel_x[5]),
        .I3(pixel_x[9]),
        .I4(\rgb_out[23]_i_225_n_0 ),
        .I5(pixel_x[6]),
        .O(\rgb_out[23]_i_521_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair4" *) 
  LUT5 #(
    .INIT(32'h000F070F)) 
    \rgb_out[23]_i_522 
       (.I0(pixel_x[7]),
        .I1(pixel_x[8]),
        .I2(pixel_x[11]),
        .I3(pixel_x[10]),
        .I4(pixel_x[9]),
        .O(\rgb_out[23]_i_522_n_0 ));
  LUT6 #(
    .INIT(64'h8000000000000000)) 
    \rgb_out[23]_i_523 
       (.I0(pixel_x[4]),
        .I1(pixel_x[6]),
        .I2(pixel_x[5]),
        .I3(pixel_x[10]),
        .I4(pixel_x[8]),
        .I5(\rgb_out[23]_i_346_n_0 ),
        .O(\rgb_out[23]_i_523_n_0 ));
  LUT6 #(
    .INIT(64'hFFBAFFBAFFFFFFBA)) 
    \rgb_out[23]_i_524 
       (.I0(\rgb_out[23]_i_909_n_0 ),
        .I1(\rgb_out[23]_i_910_n_0 ),
        .I2(pixel_x[8]),
        .I3(\rgb_out[23]_i_911_n_0 ),
        .I4(\rgb_out[23]_i_423_n_0 ),
        .I5(\rgb_out[23]_i_912_n_0 ),
        .O(\rgb_out[23]_i_524_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFBABB)) 
    \rgb_out[23]_i_525 
       (.I0(\rgb_out[23]_i_522_n_0 ),
        .I1(\rgb_out[23]_i_913_n_0 ),
        .I2(\rgb_out[23]_i_334_n_0 ),
        .I3(pixel_x[4]),
        .I4(\rgb_out[23]_i_914_n_0 ),
        .I5(\rgb_out[23]_i_713_n_0 ),
        .O(\rgb_out[23]_i_525_n_0 ));
  LUT6 #(
    .INIT(64'h10FF101010101010)) 
    \rgb_out[23]_i_526 
       (.I0(\rgb_out[23]_i_409_n_0 ),
        .I1(\rgb_out[7]_i_34_n_0 ),
        .I2(\rgb_out[23]_i_915_n_0 ),
        .I3(\rgb_out[23]_i_916_n_0 ),
        .I4(\rgb_out[23]_i_135_n_0 ),
        .I5(\rgb_out[23]_i_408_n_0 ),
        .O(\rgb_out[23]_i_526_n_0 ));
  LUT6 #(
    .INIT(64'h1001000000000000)) 
    \rgb_out[23]_i_527 
       (.I0(\rgb_out[23]_i_917_n_0 ),
        .I1(\rgb_out[21]_i_6_n_0 ),
        .I2(\rgb_out[7]_i_37_n_0 ),
        .I3(pixel_y[2]),
        .I4(pixel_y[5]),
        .I5(pixel_y[3]),
        .O(\rgb_out[23]_i_527_n_0 ));
  LUT6 #(
    .INIT(64'h0000004F00000044)) 
    \rgb_out[23]_i_528 
       (.I0(pixel_y[5]),
        .I1(\rgb_out[23]_i_135_n_0 ),
        .I2(pixel_y[8]),
        .I3(pixel_y[6]),
        .I4(pixel_y[7]),
        .I5(\rgb_out[23]_i_562_n_0 ),
        .O(\rgb_out[23]_i_528_n_0 ));
  LUT6 #(
    .INIT(64'h0000000015150515)) 
    \rgb_out[23]_i_529 
       (.I0(\rgb_out[23]_i_67_n_0 ),
        .I1(pixel_y[4]),
        .I2(pixel_y[5]),
        .I3(pixel_y[3]),
        .I4(\rgb_out[23]_i_918_n_0 ),
        .I5(\rgb_out[21]_i_6_n_0 ),
        .O(\rgb_out[23]_i_529_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFEAAFFAAFEAA)) 
    \rgb_out[23]_i_53 
       (.I0(\rgb_out[7]_i_18_n_0 ),
        .I1(\rgb_out[23]_i_184_n_0 ),
        .I2(\rgb_out[23]_i_185_n_0 ),
        .I3(\rgb_out[7]_i_14_n_0 ),
        .I4(\rgb_out[23]_i_186_n_0 ),
        .I5(\rgb_out[7]_i_13_n_0 ),
        .O(\rgb_out[23]_i_53_n_0 ));
  LUT6 #(
    .INIT(64'h0000000010010000)) 
    \rgb_out[23]_i_530 
       (.I0(pixel_y[4]),
        .I1(pixel_y[3]),
        .I2(pixel_y[2]),
        .I3(\rgb_out[7]_i_37_n_0 ),
        .I4(pixel_y[5]),
        .I5(\rgb_out[23]_i_409_n_0 ),
        .O(\rgb_out[23]_i_530_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFF5DFFFF)) 
    \rgb_out[23]_i_531 
       (.I0(\rgb_out[23]_i_556_n_0 ),
        .I1(\rgb_out[7]_i_76_n_0 ),
        .I2(\rgb_out[23]_i_919_n_0 ),
        .I3(\rgb_out[23]_i_351_n_0 ),
        .I4(\rgb_out[23]_i_224_n_0 ),
        .I5(\rgb_out[23]_i_713_n_0 ),
        .O(\rgb_out[23]_i_531_n_0 ));
  LUT6 #(
    .INIT(64'h000B000000000000)) 
    \rgb_out[23]_i_532 
       (.I0(\rgb_out[23]_i_920_n_0 ),
        .I1(\rgb_out[23]_i_553_n_0 ),
        .I2(\rgb_out[23]_i_921_n_0 ),
        .I3(\rgb_out[23]_i_922_n_0 ),
        .I4(\rgb_out[20]_i_25_n_0 ),
        .I5(pixel_x[3]),
        .O(\rgb_out[23]_i_532_n_0 ));
  LUT6 #(
    .INIT(64'h00000000000000F7)) 
    \rgb_out[23]_i_533 
       (.I0(\rgb_out[23]_i_135_n_0 ),
        .I1(\rgb_out[23]_i_408_n_0 ),
        .I2(\rgb_out[23]_i_923_n_0 ),
        .I3(\rgb_out[23]_i_409_n_0 ),
        .I4(\rgb_out[23]_i_924_n_0 ),
        .I5(\rgb_out[23]_i_925_n_0 ),
        .O(\rgb_out[23]_i_533_n_0 ));
  LUT6 #(
    .INIT(64'h004F00FFFFFFFFFF)) 
    \rgb_out[23]_i_534 
       (.I0(pixel_x[6]),
        .I1(\rgb_out[20]_i_25_n_0 ),
        .I2(pixel_x[7]),
        .I3(pixel_x[9]),
        .I4(pixel_x[8]),
        .I5(pixel_x[10]),
        .O(\rgb_out[23]_i_534_n_0 ));
  LUT6 #(
    .INIT(64'h3031303030313031)) 
    \rgb_out[23]_i_535 
       (.I0(pixel_x[6]),
        .I1(pixel_x[9]),
        .I2(\rgb_out[11]_i_29_n_0 ),
        .I3(pixel_x[5]),
        .I4(\rgb_out[23]_i_334_n_0 ),
        .I5(pixel_x[4]),
        .O(\rgb_out[23]_i_535_n_0 ));
  LUT6 #(
    .INIT(64'hFBFFFFFFFFFFFFFF)) 
    \rgb_out[23]_i_536 
       (.I0(\rgb_out[23]_i_713_n_0 ),
        .I1(pixel_x[8]),
        .I2(pixel_x[6]),
        .I3(pixel_x[10]),
        .I4(pixel_x[7]),
        .I5(\rgb_out[23]_i_913_n_0 ),
        .O(\rgb_out[23]_i_536_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair55" *) 
  LUT4 #(
    .INIT(16'hAAA8)) 
    \rgb_out[23]_i_537 
       (.I0(pixel_x[5]),
        .I1(pixel_x[4]),
        .I2(pixel_x[3]),
        .I3(pixel_x[2]),
        .O(\rgb_out[23]_i_537_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_538 
       (.I0(decompte_ui[1]),
        .I1(decompte_ui[0]),
        .O(\rgb_out[23]_i_538_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair42" *) 
  LUT3 #(
    .INIT(8'h8F)) 
    \rgb_out[23]_i_539 
       (.I0(decompte_ui[0]),
        .I1(decompte_ui[1]),
        .I2(decompte_ui[2]),
        .O(\rgb_out[23]_i_539_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair94" *) 
  LUT3 #(
    .INIT(8'hFB)) 
    \rgb_out[23]_i_54 
       (.I0(mode_ui[1]),
        .I1(mode_ui[0]),
        .I2(mode_ui[2]),
        .O(\rgb_out[23]_i_54_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair34" *) 
  LUT4 #(
    .INIT(16'h0001)) 
    \rgb_out[23]_i_540 
       (.I0(pixel_y[7]),
        .I1(pixel_y[11]),
        .I2(pixel_y[10]),
        .I3(pixel_y[9]),
        .O(\rgb_out[23]_i_540_n_0 ));
  LUT6 #(
    .INIT(64'h2AAAAAAAAAAAAAAA)) 
    \rgb_out[23]_i_541 
       (.I0(\rgb_out[7]_i_73_n_0 ),
        .I1(pixel_x[9]),
        .I2(pixel_x[8]),
        .I3(pixel_x[3]),
        .I4(pixel_x[4]),
        .I5(pixel_x[5]),
        .O(\rgb_out[23]_i_541_n_0 ));
  LUT6 #(
    .INIT(64'h7F7F7F7F7F7F7FFF)) 
    \rgb_out[23]_i_542 
       (.I0(pixel_y[6]),
        .I1(pixel_y[5]),
        .I2(pixel_y[4]),
        .I3(pixel_y[2]),
        .I4(pixel_y[3]),
        .I5(pixel_y[1]),
        .O(\rgb_out[23]_i_542_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair56" *) 
  LUT4 #(
    .INIT(16'hEAAA)) 
    \rgb_out[23]_i_543 
       (.I0(pixel_x[5]),
        .I1(pixel_x[3]),
        .I2(pixel_x[4]),
        .I3(pixel_x[2]),
        .O(\rgb_out[23]_i_543_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair117" *) 
  LUT3 #(
    .INIT(8'h80)) 
    \rgb_out[23]_i_544 
       (.I0(pixel_x[7]),
        .I1(pixel_x[8]),
        .I2(pixel_x[9]),
        .O(\rgb_out[23]_i_544_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFFFFE)) 
    \rgb_out[23]_i_545 
       (.I0(pixel_x[3]),
        .I1(pixel_x[4]),
        .I2(pixel_x[1]),
        .I3(pixel_x[2]),
        .I4(pixel_x[7]),
        .I5(pixel_x[0]),
        .O(\rgb_out[23]_i_545_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair19" *) 
  LUT5 #(
    .INIT(32'h07FFFFFF)) 
    \rgb_out[23]_i_546 
       (.I0(pixel_x[6]),
        .I1(pixel_x[5]),
        .I2(pixel_x[7]),
        .I3(pixel_x[8]),
        .I4(pixel_x[9]),
        .O(\rgb_out[23]_i_546_n_0 ));
  LUT6 #(
    .INIT(64'hEEFFAAFFEEFFA0FF)) 
    \rgb_out[23]_i_547 
       (.I0(\rgb_out[23]_i_245_n_0 ),
        .I1(pixel_x[9]),
        .I2(pixel_x[4]),
        .I3(\rgb_out[11]_i_11_n_0 ),
        .I4(pixel_x[8]),
        .I5(pixel_x[3]),
        .O(\rgb_out[23]_i_547_n_0 ));
  LUT6 #(
    .INIT(64'h7FFFFFFFFFFFFFFF)) 
    \rgb_out[23]_i_548 
       (.I0(pixel_x[3]),
        .I1(pixel_x[2]),
        .I2(pixel_x[5]),
        .I3(pixel_x[6]),
        .I4(pixel_x[7]),
        .I5(pixel_x[9]),
        .O(\rgb_out[23]_i_548_n_0 ));
  LUT6 #(
    .INIT(64'h0C550C0CCCCCCCCC)) 
    \rgb_out[23]_i_549 
       (.I0(\rgb_out[23]_i_334_n_0 ),
        .I1(\rgb_out[11]_i_11_n_0 ),
        .I2(pixel_x[8]),
        .I3(\rgb_out[23]_i_233_n_0 ),
        .I4(\rgb_out[11]_i_21_n_0 ),
        .I5(pixel_x[9]),
        .O(\rgb_out[23]_i_549_n_0 ));
  LUT6 #(
    .INIT(64'h00000000EEEAEAEA)) 
    \rgb_out[23]_i_55 
       (.I0(\rgb_out[23]_i_187_n_0 ),
        .I1(\rgb_out[23]_i_188_n_0 ),
        .I2(\pixel_x[7] ),
        .I3(\rgb_out[23]_i_190_n_0 ),
        .I4(\pixel_x[3] ),
        .I5(\rgb_out[23]_i_192_n_0 ),
        .O(num_tm_d));
  LUT6 #(
    .INIT(64'hFFFFFFFF0000FFF8)) 
    \rgb_out[23]_i_550 
       (.I0(\rgb_out[23]_i_237_n_0 ),
        .I1(pixel_y[4]),
        .I2(pixel_y[5]),
        .I3(pixel_y[6]),
        .I4(\rgb_out[23]_i_40_n_0 ),
        .I5(\rgb_out[21]_i_6_n_0 ),
        .O(\rgb_out[23]_i_550_n_0 ));
  LUT6 #(
    .INIT(64'h0F00FFFF0F000100)) 
    \rgb_out[23]_i_551 
       (.I0(pixel_x[6]),
        .I1(\rgb_out[23]_i_300_n_0 ),
        .I2(pixel_x[9]),
        .I3(\rgb_out[11]_i_11_n_0 ),
        .I4(\rgb_out[11]_i_29_n_0 ),
        .I5(\rgb_out[23]_i_346_n_0 ),
        .O(\rgb_out[23]_i_551_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair49" *) 
  LUT5 #(
    .INIT(32'hFE000000)) 
    \rgb_out[23]_i_552 
       (.I0(pixel_x[6]),
        .I1(pixel_x[5]),
        .I2(pixel_x[4]),
        .I3(pixel_x[8]),
        .I4(pixel_x[7]),
        .O(\rgb_out[23]_i_552_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair63" *) 
  LUT4 #(
    .INIT(16'h8000)) 
    \rgb_out[23]_i_553 
       (.I0(pixel_x[2]),
        .I1(pixel_x[3]),
        .I2(pixel_x[8]),
        .I3(pixel_x[7]),
        .O(\rgb_out[23]_i_553_n_0 ));
  LUT6 #(
    .INIT(64'h4444044444000400)) 
    \rgb_out[23]_i_554 
       (.I0(\rgb_out[23]_i_226_n_0 ),
        .I1(\rgb_out[23]_i_219_n_0 ),
        .I2(pixel_x[4]),
        .I3(pixel_x[3]),
        .I4(\rgb_out[11]_i_29_n_0 ),
        .I5(pixel_x[2]),
        .O(\rgb_out[23]_i_554_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair13" *) 
  LUT4 #(
    .INIT(16'h8000)) 
    \rgb_out[23]_i_555 
       (.I0(pixel_x[2]),
        .I1(pixel_x[3]),
        .I2(pixel_x[4]),
        .I3(pixel_x[5]),
        .O(\rgb_out[23]_i_555_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair6" *) 
  LUT5 #(
    .INIT(32'h80000000)) 
    \rgb_out[23]_i_556 
       (.I0(pixel_x[5]),
        .I1(pixel_x[4]),
        .I2(pixel_x[3]),
        .I3(pixel_x[10]),
        .I4(pixel_x[6]),
        .O(\rgb_out[23]_i_556_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair33" *) 
  LUT5 #(
    .INIT(32'h00010101)) 
    \rgb_out[23]_i_557 
       (.I0(pixel_x[9]),
        .I1(pixel_x[11]),
        .I2(pixel_x[10]),
        .I3(pixel_x[8]),
        .I4(pixel_x[7]),
        .O(\rgb_out[23]_i_557_n_0 ));
  LUT6 #(
    .INIT(64'hDFFFFFFFFFFFFFFF)) 
    \rgb_out[23]_i_558 
       (.I0(\rgb_out[23]_i_219_n_0 ),
        .I1(\rgb_out[11]_i_29_n_0 ),
        .I2(pixel_x[6]),
        .I3(pixel_x[2]),
        .I4(pixel_x[3]),
        .I5(\rgb_out[20]_i_25_n_0 ),
        .O(\rgb_out[23]_i_558_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000080000)) 
    \rgb_out[23]_i_559 
       (.I0(pixel_x[2]),
        .I1(\rgb_out[23]_i_392_n_0 ),
        .I2(pixel_x[5]),
        .I3(\rgb_out[23]_i_676_n_0 ),
        .I4(\rgb_out[11]_i_11_n_0 ),
        .I5(pixel_x[9]),
        .O(\rgb_out[23]_i_559_n_0 ));
  LUT6 #(
    .INIT(64'hABFFABFFABFFFFFF)) 
    \rgb_out[23]_i_560 
       (.I0(\rgb_out[23]_i_352_n_0 ),
        .I1(\rgb_out[23]_i_392_n_0 ),
        .I2(pixel_x[5]),
        .I3(\rgb_out[23]_i_351_n_0 ),
        .I4(pixel_x[6]),
        .I5(\rgb_out[23]_i_224_n_0 ),
        .O(\rgb_out[23]_i_560_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair75" *) 
  LUT4 #(
    .INIT(16'hFEEE)) 
    \rgb_out[23]_i_561 
       (.I0(pixel_y[3]),
        .I1(pixel_y[2]),
        .I2(pixel_y[0]),
        .I3(pixel_y[1]),
        .O(\rgb_out[23]_i_561_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair75" *) 
  LUT4 #(
    .INIT(16'h007F)) 
    \rgb_out[23]_i_562 
       (.I0(pixel_y[2]),
        .I1(pixel_y[0]),
        .I2(pixel_y[1]),
        .I3(pixel_y[3]),
        .O(\rgb_out[23]_i_562_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair23" *) 
  LUT5 #(
    .INIT(32'h00010101)) 
    \rgb_out[23]_i_563 
       (.I0(pixel_y[2]),
        .I1(pixel_y[3]),
        .I2(pixel_y[4]),
        .I3(pixel_y[0]),
        .I4(pixel_y[1]),
        .O(\rgb_out[23]_i_563_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair91" *) 
  LUT4 #(
    .INIT(16'hFFFE)) 
    \rgb_out[23]_i_564 
       (.I0(pixel_x[7]),
        .I1(pixel_x[9]),
        .I2(pixel_x[10]),
        .I3(pixel_x[11]),
        .O(\rgb_out[23]_i_564_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair85" *) 
  LUT3 #(
    .INIT(8'h80)) 
    \rgb_out[23]_i_565 
       (.I0(pixel_x[3]),
        .I1(pixel_x[6]),
        .I2(pixel_x[2]),
        .O(\rgb_out[23]_i_565_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair40" *) 
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_566 
       (.I0(pixel_y[2]),
        .I1(pixel_y[3]),
        .O(\rgb_out[23]_i_566_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair126" *) 
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_567 
       (.I0(pixel_x[9]),
        .I1(pixel_x[6]),
        .O(\rgb_out[23]_i_567_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair27" *) 
  LUT5 #(
    .INIT(32'hFFFFFFFE)) 
    \rgb_out[23]_i_568 
       (.I0(pixel_x[11]),
        .I1(pixel_x[9]),
        .I2(pixel_x[8]),
        .I3(pixel_x[4]),
        .I4(pixel_x[5]),
        .O(\rgb_out[23]_i_568_n_0 ));
  LUT6 #(
    .INIT(64'h0000000700000005)) 
    \rgb_out[23]_i_569 
       (.I0(\rgb_out[11]_i_21_n_0 ),
        .I1(pixel_x[5]),
        .I2(pixel_x[8]),
        .I3(pixel_x[9]),
        .I4(pixel_x[11]),
        .I5(\rgb_out[23]_i_334_n_0 ),
        .O(\rgb_out[23]_i_569_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair10" *) 
  LUT4 #(
    .INIT(16'hAA80)) 
    \rgb_out[23]_i_570 
       (.I0(pixel_x[6]),
        .I1(pixel_x[3]),
        .I2(pixel_x[4]),
        .I3(pixel_x[5]),
        .O(\rgb_out[23]_i_570_n_0 ));
  LUT6 #(
    .INIT(64'h00E0E0E0E0E0E0E0)) 
    \rgb_out[23]_i_571 
       (.I0(\rgb_out[23]_i_708_n_0 ),
        .I1(pixel_x[8]),
        .I2(\rgb_out[23]_i_351_n_0 ),
        .I3(pixel_x[4]),
        .I4(pixel_x[3]),
        .I5(pixel_x[2]),
        .O(\rgb_out[23]_i_571_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair30" *) 
  LUT5 #(
    .INIT(32'h7FFFFFFF)) 
    \rgb_out[23]_i_572 
       (.I0(pixel_x[5]),
        .I1(pixel_x[6]),
        .I2(pixel_x[7]),
        .I3(pixel_x[10]),
        .I4(\rgb_out[23]_i_334_n_0 ),
        .O(\rgb_out[23]_i_572_n_0 ));
  LUT6 #(
    .INIT(64'h1000000000000000)) 
    \rgb_out[23]_i_573 
       (.I0(\rgb_out[23]_i_337_n_0 ),
        .I1(pixel_x[6]),
        .I2(pixel_x[8]),
        .I3(pixel_x[4]),
        .I4(pixel_x[5]),
        .I5(\rgb_out[23]_i_346_n_0 ),
        .O(\rgb_out[23]_i_573_n_0 ));
  LUT6 #(
    .INIT(64'h0000000002800000)) 
    \rgb_out[23]_i_574 
       (.I0(\rgb_out[23]_i_351_n_0 ),
        .I1(pixel_x[5]),
        .I2(pixel_x[4]),
        .I3(pixel_x[6]),
        .I4(\rgb_out[23]_i_334_n_0 ),
        .I5(\rgb_out[23]_i_926_n_0 ),
        .O(\rgb_out[23]_i_574_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair5" *) 
  LUT5 #(
    .INIT(32'hFFFFFFF8)) 
    \rgb_out[23]_i_575 
       (.I0(pixel_x[3]),
        .I1(pixel_x[2]),
        .I2(pixel_x[4]),
        .I3(pixel_x[7]),
        .I4(pixel_x[5]),
        .O(\rgb_out[23]_i_575_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFBFFFFF)) 
    \rgb_out[23]_i_576 
       (.I0(pixel_x[4]),
        .I1(\rgb_out[23]_i_219_n_0 ),
        .I2(pixel_x[8]),
        .I3(pixel_x[7]),
        .I4(pixel_x[6]),
        .I5(pixel_x[5]),
        .O(\rgb_out[23]_i_576_n_0 ));
  LUT6 #(
    .INIT(64'hFEFFFFFFFFFFFFFF)) 
    \rgb_out[23]_i_577 
       (.I0(pixel_y[5]),
        .I1(pixel_y[6]),
        .I2(\rgb_out[21]_i_6_n_0 ),
        .I3(pixel_y[8]),
        .I4(pixel_y[7]),
        .I5(pixel_y[4]),
        .O(\rgb_out[23]_i_577_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair85" *) 
  LUT4 #(
    .INIT(16'hFFFE)) 
    \rgb_out[23]_i_578 
       (.I0(pixel_x[6]),
        .I1(pixel_x[9]),
        .I2(pixel_x[2]),
        .I3(pixel_x[3]),
        .O(\rgb_out[23]_i_578_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000000001)) 
    \rgb_out[23]_i_579 
       (.I0(pixel_x[11]),
        .I1(pixel_x[9]),
        .I2(pixel_x[7]),
        .I3(pixel_x[8]),
        .I4(pixel_x[4]),
        .I5(pixel_x[3]),
        .O(\rgb_out[23]_i_579_n_0 ));
  LUT6 #(
    .INIT(64'hD75DF7DF15511551)) 
    \rgb_out[23]_i_58 
       (.I0(\rgb_out[23]_i_199_n_0 ),
        .I1(temps_restant[2]),
        .I2(temps_restant[1]),
        .I3(temps_restant[3]),
        .I4(temps_restant[0]),
        .I5(\rgb_out[23]_i_200_n_0 ),
        .O(\rgb_out[23]_i_58_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_6 
       (.I0(\rgb_out[23]_i_15_n_0 ),
        .I1(\rgb_out[23]_i_16_n_0 ),
        .O(\rgb_out[23]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'h0002000200000002)) 
    \rgb_out[23]_i_60 
       (.I0(\rgb_out[23]_i_205_n_0 ),
        .I1(\rgb_out[23]_i_206_n_0 ),
        .I2(\rgb_out[23]_i_207_n_0 ),
        .I3(\rgb_out[23]_i_208_n_0 ),
        .I4(\rgb_out[23]_i_209_n_0 ),
        .I5(\rgb_out[23]_i_210_n_0 ),
        .O(\rgb_out[23]_i_60_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair61" *) 
  LUT4 #(
    .INIT(16'h1455)) 
    \rgb_out[23]_i_608 
       (.I0(score_dernier[0]),
        .I1(score_dernier[1]),
        .I2(score_dernier[3]),
        .I3(score_dernier[2]),
        .O(\LAST_U/segments [2]));
  (* SOFT_HLUTNM = "soft_lutpair82" *) 
  LUT4 #(
    .INIT(16'hFFFE)) 
    \rgb_out[23]_i_61 
       (.I0(decompte_ui[2]),
        .I1(decompte_ui[3]),
        .I2(decompte_ui[0]),
        .I3(decompte_ui[1]),
        .O(\rgb_out[23]_i_61_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair83" *) 
  LUT4 #(
    .INIT(16'hFBEF)) 
    \rgb_out[23]_i_610 
       (.I0(score_dernier[0]),
        .I1(score_dernier[2]),
        .I2(score_dernier[1]),
        .I3(score_dernier[3]),
        .O(\rgb_out[23]_i_610_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair83" *) 
  LUT4 #(
    .INIT(16'hD34D)) 
    \rgb_out[23]_i_614 
       (.I0(score_dernier[0]),
        .I1(score_dernier[2]),
        .I2(score_dernier[1]),
        .I3(score_dernier[3]),
        .O(\LAST_U/segments [1]));
  (* SOFT_HLUTNM = "soft_lutpair61" *) 
  LUT4 #(
    .INIT(16'h7FB7)) 
    \rgb_out[23]_i_615 
       (.I0(score_dernier[0]),
        .I1(score_dernier[2]),
        .I2(score_dernier[1]),
        .I3(score_dernier[3]),
        .O(\rgb_out[23]_i_615_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair110" *) 
  LUT3 #(
    .INIT(8'h7D)) 
    \rgb_out[23]_i_618 
       (.I0(score_dernier[2]),
        .I1(score_dernier[3]),
        .I2(score_dernier[1]),
        .O(\rgb_out[23]_i_618_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair60" *) 
  LUT4 #(
    .INIT(16'h00FD)) 
    \rgb_out[23]_i_619 
       (.I0(score_dernier[3]),
        .I1(score_dernier[1]),
        .I2(score_dernier[2]),
        .I3(score_dernier[0]),
        .O(\rgb_out[23]_i_619_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair90" *) 
  LUT4 #(
    .INIT(16'h4100)) 
    \rgb_out[23]_i_621 
       (.I0(score_dernier[2]),
        .I1(score_dernier[3]),
        .I2(score_dernier[1]),
        .I3(score_dernier[0]),
        .O(\rgb_out[23]_i_621_n_0 ));
  LUT3 #(
    .INIT(8'h09)) 
    \rgb_out[23]_i_623 
       (.I0(score_dernier[3]),
        .I1(score_dernier[1]),
        .I2(score_dernier[2]),
        .O(\rgb_out[23]_i_623_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair90" *) 
  LUT4 #(
    .INIT(16'h2000)) 
    \rgb_out[23]_i_625 
       (.I0(score_dernier[2]),
        .I1(score_dernier[3]),
        .I2(score_dernier[1]),
        .I3(score_dernier[0]),
        .O(\rgb_out[23]_i_625_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair60" *) 
  LUT4 #(
    .INIT(16'h9F79)) 
    \rgb_out[23]_i_627 
       (.I0(score_dernier[0]),
        .I1(score_dernier[2]),
        .I2(score_dernier[1]),
        .I3(score_dernier[3]),
        .O(\rgb_out[23]_i_627_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair77" *) 
  LUT4 #(
    .INIT(16'h1455)) 
    \rgb_out[23]_i_634 
       (.I0(record_personnel[0]),
        .I1(record_personnel[1]),
        .I2(record_personnel[3]),
        .I3(record_personnel[2]),
        .O(\REC_U/segments [2]));
  (* SOFT_HLUTNM = "soft_lutpair86" *) 
  LUT4 #(
    .INIT(16'hEFFB)) 
    \rgb_out[23]_i_636 
       (.I0(record_personnel[0]),
        .I1(record_personnel[1]),
        .I2(record_personnel[2]),
        .I3(record_personnel[3]),
        .O(\rgb_out[23]_i_636_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair77" *) 
  LUT4 #(
    .INIT(16'hC771)) 
    \rgb_out[23]_i_640 
       (.I0(record_personnel[0]),
        .I1(record_personnel[1]),
        .I2(record_personnel[2]),
        .I3(record_personnel[3]),
        .O(\REC_U/segments [1]));
  (* SOFT_HLUTNM = "soft_lutpair86" *) 
  LUT4 #(
    .INIT(16'h7F9F)) 
    \rgb_out[23]_i_641 
       (.I0(record_personnel[0]),
        .I1(record_personnel[1]),
        .I2(record_personnel[2]),
        .I3(record_personnel[3]),
        .O(\rgb_out[23]_i_641_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair101" *) 
  LUT3 #(
    .INIT(8'h7D)) 
    \rgb_out[23]_i_644 
       (.I0(record_personnel[2]),
        .I1(record_personnel[3]),
        .I2(record_personnel[1]),
        .O(\rgb_out[23]_i_644_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair84" *) 
  LUT4 #(
    .INIT(16'h00FD)) 
    \rgb_out[23]_i_645 
       (.I0(record_personnel[3]),
        .I1(record_personnel[2]),
        .I2(record_personnel[1]),
        .I3(record_personnel[0]),
        .O(\rgb_out[23]_i_645_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair70" *) 
  LUT4 #(
    .INIT(16'h4100)) 
    \rgb_out[23]_i_647 
       (.I0(record_personnel[2]),
        .I1(record_personnel[3]),
        .I2(record_personnel[1]),
        .I3(record_personnel[0]),
        .O(\rgb_out[23]_i_647_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair101" *) 
  LUT3 #(
    .INIT(8'h21)) 
    \rgb_out[23]_i_649 
       (.I0(record_personnel[3]),
        .I1(record_personnel[2]),
        .I2(record_personnel[1]),
        .O(\rgb_out[23]_i_649_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000000001)) 
    \rgb_out[23]_i_65 
       (.I0(\rgb_out[23]_i_42_n_0 ),
        .I1(\rgb_out[23]_i_219_n_0 ),
        .I2(pixel_y[11]),
        .I3(pixel_y[10]),
        .I4(pixel_x[11]),
        .I5(\rgb_out[23]_i_220_n_0 ),
        .O(\rgb_out[23]_i_65_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair84" *) 
  LUT4 #(
    .INIT(16'h2000)) 
    \rgb_out[23]_i_651 
       (.I0(record_personnel[2]),
        .I1(record_personnel[3]),
        .I2(record_personnel[1]),
        .I3(record_personnel[0]),
        .O(\rgb_out[23]_i_651_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair70" *) 
  LUT4 #(
    .INIT(16'hB76D)) 
    \rgb_out[23]_i_653 
       (.I0(record_personnel[0]),
        .I1(record_personnel[1]),
        .I2(record_personnel[2]),
        .I3(record_personnel[3]),
        .O(\rgb_out[23]_i_653_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000000015)) 
    \rgb_out[23]_i_66 
       (.I0(pixel_y[2]),
        .I1(pixel_y[1]),
        .I2(pixel_y[0]),
        .I3(pixel_y[5]),
        .I4(pixel_y[4]),
        .I5(pixel_y[3]),
        .O(\rgb_out[23]_i_66_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair98" *) 
  LUT3 #(
    .INIT(8'hFE)) 
    \rgb_out[23]_i_67 
       (.I0(pixel_y[8]),
        .I1(pixel_y[6]),
        .I2(pixel_y[7]),
        .O(\rgb_out[23]_i_67_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair111" *) 
  LUT3 #(
    .INIT(8'h7F)) 
    \rgb_out[23]_i_676 
       (.I0(pixel_x[8]),
        .I1(pixel_x[7]),
        .I2(pixel_x[6]),
        .O(\rgb_out[23]_i_676_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000000800)) 
    \rgb_out[23]_i_677 
       (.I0(pixel_x[7]),
        .I1(pixel_x[6]),
        .I2(pixel_x[11]),
        .I3(pixel_x[10]),
        .I4(pixel_x[9]),
        .I5(pixel_x[8]),
        .O(\rgb_out[23]_i_677_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair26" *) 
  LUT5 #(
    .INIT(32'hC080C000)) 
    \rgb_out[23]_i_678 
       (.I0(pixel_x[4]),
        .I1(pixel_x[7]),
        .I2(pixel_x[10]),
        .I3(pixel_x[6]),
        .I4(pixel_x[5]),
        .O(\rgb_out[23]_i_678_n_0 ));
  LUT6 #(
    .INIT(64'hFECCFECCFECCEECC)) 
    \rgb_out[23]_i_679 
       (.I0(\rgb_out[23]_i_224_n_0 ),
        .I1(pixel_x[11]),
        .I2(pixel_x[7]),
        .I3(pixel_x[10]),
        .I4(pixel_x[6]),
        .I5(pixel_x[5]),
        .O(\rgb_out[23]_i_679_n_0 ));
  LUT6 #(
    .INIT(64'h0000000400004444)) 
    \rgb_out[23]_i_68 
       (.I0(pixel_x[8]),
        .I1(\rgb_out[23]_i_221_n_0 ),
        .I2(pixel_x[1]),
        .I3(pixel_x[2]),
        .I4(pixel_x[6]),
        .I5(\rgb_out[23]_i_222_n_0 ),
        .O(\rgb_out[23]_i_68_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair5" *) 
  LUT5 #(
    .INIT(32'hA8888888)) 
    \rgb_out[23]_i_680 
       (.I0(pixel_x[7]),
        .I1(pixel_x[5]),
        .I2(pixel_x[3]),
        .I3(pixel_x[4]),
        .I4(pixel_x[2]),
        .O(\rgb_out[23]_i_680_n_0 ));
  LUT6 #(
    .INIT(64'h0444044404440000)) 
    \rgb_out[23]_i_681 
       (.I0(\rgb_out[23]_i_366_n_0 ),
        .I1(\rgb_out[23]_i_343_n_0 ),
        .I2(\rgb_out[23]_i_401_n_0 ),
        .I3(\rgb_out[23]_i_351_n_0 ),
        .I4(pixel_x[6]),
        .I5(\rgb_out[23]_i_568_n_0 ),
        .O(\rgb_out[23]_i_681_n_0 ));
  LUT6 #(
    .INIT(64'h0004000000000000)) 
    \rgb_out[23]_i_682 
       (.I0(\rgb_out[23]_i_224_n_0 ),
        .I1(pixel_x[10]),
        .I2(pixel_x[11]),
        .I3(pixel_x[4]),
        .I4(\rgb_out[11]_i_21_n_0 ),
        .I5(pixel_x[5]),
        .O(\rgb_out[23]_i_682_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair78" *) 
  LUT4 #(
    .INIT(16'h0001)) 
    \rgb_out[23]_i_683 
       (.I0(pixel_y[6]),
        .I1(pixel_y[7]),
        .I2(pixel_y[4]),
        .I3(pixel_y[5]),
        .O(\rgb_out[23]_i_683_n_0 ));
  LUT6 #(
    .INIT(64'h8000800080000000)) 
    \rgb_out[23]_i_684 
       (.I0(pixel_x[8]),
        .I1(pixel_x[9]),
        .I2(pixel_x[5]),
        .I3(pixel_x[4]),
        .I4(pixel_x[3]),
        .I5(pixel_x[2]),
        .O(\rgb_out[23]_i_684_n_0 ));
  LUT6 #(
    .INIT(64'hE0FFE0FFE0E0E0FF)) 
    \rgb_out[23]_i_685 
       (.I0(\rgb_out[23]_i_224_n_0 ),
        .I1(\rgb_out[23]_i_1206_n_0 ),
        .I2(\rgb_out[23]_i_375_n_0 ),
        .I3(\rgb_out[23]_i_555_n_0 ),
        .I4(\rgb_out[23]_i_219_n_0 ),
        .I5(\rgb_out[23]_i_1207_n_0 ),
        .O(\rgb_out[23]_i_685_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair4" *) 
  LUT5 #(
    .INIT(32'h00000001)) 
    \rgb_out[23]_i_686 
       (.I0(pixel_x[8]),
        .I1(pixel_x[7]),
        .I2(pixel_x[10]),
        .I3(pixel_x[11]),
        .I4(pixel_x[9]),
        .O(\rgb_out[23]_i_686_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair19" *) 
  LUT4 #(
    .INIT(16'h0111)) 
    \rgb_out[23]_i_687 
       (.I0(pixel_x[8]),
        .I1(pixel_x[7]),
        .I2(pixel_x[5]),
        .I3(pixel_x[6]),
        .O(\rgb_out[23]_i_687_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFFFF4)) 
    \rgb_out[23]_i_688 
       (.I0(\rgb_out[23]_i_334_n_0 ),
        .I1(pixel_x[4]),
        .I2(pixel_x[9]),
        .I3(pixel_x[5]),
        .I4(pixel_x[6]),
        .I5(pixel_x[7]),
        .O(\rgb_out[23]_i_688_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair119" *) 
  LUT2 #(
    .INIT(4'h7)) 
    \rgb_out[23]_i_689 
       (.I0(pixel_x[8]),
        .I1(pixel_x[10]),
        .O(\rgb_out[23]_i_689_n_0 ));
  LUT6 #(
    .INIT(64'hAAAAAAAAAAA2AAAA)) 
    \rgb_out[23]_i_69 
       (.I0(pixel_x[10]),
        .I1(\rgb_out[23]_i_223_n_0 ),
        .I2(\rgb_out[23]_i_224_n_0 ),
        .I3(pixel_x[7]),
        .I4(\rgb_out[23]_i_225_n_0 ),
        .I5(\rgb_out[23]_i_226_n_0 ),
        .O(\rgb_out[23]_i_69_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair59" *) 
  LUT4 #(
    .INIT(16'hECCC)) 
    \rgb_out[23]_i_690 
       (.I0(pixel_x[3]),
        .I1(pixel_x[4]),
        .I2(pixel_x[1]),
        .I3(pixel_x[2]),
        .O(\rgb_out[23]_i_690_n_0 ));
  LUT6 #(
    .INIT(64'hFEAAEEAAFEAAFEAA)) 
    \rgb_out[23]_i_691 
       (.I0(pixel_x[11]),
        .I1(pixel_x[9]),
        .I2(pixel_x[8]),
        .I3(pixel_x[10]),
        .I4(\rgb_out[20]_i_24_n_0 ),
        .I5(\rgb_out[20]_i_25_n_0 ),
        .O(\rgb_out[23]_i_691_n_0 ));
  LUT6 #(
    .INIT(64'h0040004000404040)) 
    \rgb_out[23]_i_692 
       (.I0(\rgb_out[23]_i_462_n_0 ),
        .I1(\rgb_out[23]_i_1208_n_0 ),
        .I2(\rgb_out[23]_i_425_n_0 ),
        .I3(pixel_x[4]),
        .I4(pixel_x[2]),
        .I5(pixel_x[3]),
        .O(\rgb_out[23]_i_692_n_0 ));
  LUT6 #(
    .INIT(64'h00F04444CCCCCCCC)) 
    \rgb_out[23]_i_693 
       (.I0(pixel_x[1]),
        .I1(\rgb_out[23]_i_1209_n_0 ),
        .I2(pixel_x[5]),
        .I3(\rgb_out[23]_i_689_n_0 ),
        .I4(pixel_x[2]),
        .I5(pixel_x[3]),
        .O(\rgb_out[23]_i_693_n_0 ));
  LUT6 #(
    .INIT(64'hEEEEEEEEEEEEEAEE)) 
    \rgb_out[23]_i_694 
       (.I0(pixel_x[11]),
        .I1(\rgb_out[23]_i_423_n_0 ),
        .I2(pixel_x[6]),
        .I3(\rgb_out[23]_i_233_n_0 ),
        .I4(pixel_x[7]),
        .I5(pixel_x[9]),
        .O(\rgb_out[23]_i_694_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000010000)) 
    \rgb_out[23]_i_695 
       (.I0(pixel_x[7]),
        .I1(pixel_x[11]),
        .I2(\rgb_out[23]_i_567_n_0 ),
        .I3(pixel_x[4]),
        .I4(pixel_x[3]),
        .I5(\rgb_out[11]_i_22_n_0 ),
        .O(\rgb_out[23]_i_695_n_0 ));
  LUT6 #(
    .INIT(64'h0100111133333333)) 
    \rgb_out[23]_i_696 
       (.I0(pixel_x[9]),
        .I1(pixel_x[11]),
        .I2(pixel_x[7]),
        .I3(\rgb_out[23]_i_367_n_0 ),
        .I4(pixel_x[8]),
        .I5(pixel_x[10]),
        .O(\rgb_out[23]_i_696_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFFFFD)) 
    \rgb_out[23]_i_697 
       (.I0(\rgb_out[23]_i_223_n_0 ),
        .I1(pixel_x[9]),
        .I2(pixel_x[3]),
        .I3(pixel_x[7]),
        .I4(pixel_x[4]),
        .I5(pixel_x[6]),
        .O(\rgb_out[23]_i_697_n_0 ));
  LUT6 #(
    .INIT(64'hC8C8C8C8C8C8C8C0)) 
    \rgb_out[23]_i_698 
       (.I0(pixel_x[8]),
        .I1(pixel_x[10]),
        .I2(pixel_x[9]),
        .I3(pixel_x[5]),
        .I4(pixel_x[6]),
        .I5(pixel_x[7]),
        .O(\rgb_out[23]_i_698_n_0 ));
  LUT6 #(
    .INIT(64'h0000000004000000)) 
    \rgb_out[23]_i_699 
       (.I0(pixel_x[11]),
        .I1(\rgb_out[23]_i_225_n_0 ),
        .I2(\rgb_out[23]_i_417_n_0 ),
        .I3(\rgb_out[23]_i_224_n_0 ),
        .I4(pixel_x[10]),
        .I5(\rgb_out[23]_i_425_n_0 ),
        .O(\rgb_out[23]_i_699_n_0 ));
  LUT6 #(
    .INIT(64'hD0FFD0FFD0FFD0D0)) 
    \rgb_out[23]_i_70 
       (.I0(\rgb_out[23]_i_182_n_0 ),
        .I1(\rgb_out[23]_i_227_n_0 ),
        .I2(\rgb_out[23]_i_228_n_0 ),
        .I3(\rgb_out[23]_i_229_n_0 ),
        .I4(\rgb_out[7]_i_15_n_0 ),
        .I5(\rgb_out[7]_i_50_n_0 ),
        .O(\rgb_out[23]_i_70_n_0 ));
  LUT6 #(
    .INIT(64'h0000000100000000)) 
    \rgb_out[23]_i_700 
       (.I0(pixel_x[9]),
        .I1(pixel_x[5]),
        .I2(\rgb_out[20]_i_24_n_0 ),
        .I3(\rgb_out[23]_i_462_n_0 ),
        .I4(\rgb_out[11]_i_22_n_0 ),
        .I5(\rgb_out[23]_i_392_n_0 ),
        .O(\rgb_out[23]_i_700_n_0 ));
  LUT6 #(
    .INIT(64'h0F55115500551155)) 
    \rgb_out[23]_i_701 
       (.I0(pixel_x[11]),
        .I1(pixel_x[9]),
        .I2(\rgb_out[23]_i_223_n_0 ),
        .I3(pixel_x[10]),
        .I4(pixel_x[8]),
        .I5(pixel_x[5]),
        .O(\rgb_out[23]_i_701_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair44" *) 
  LUT5 #(
    .INIT(32'h80000000)) 
    \rgb_out[23]_i_702 
       (.I0(pixel_x[3]),
        .I1(pixel_x[8]),
        .I2(pixel_x[10]),
        .I3(pixel_x[1]),
        .I4(pixel_x[2]),
        .O(\rgb_out[23]_i_702_n_0 ));
  LUT6 #(
    .INIT(64'h0000000001010111)) 
    \rgb_out[23]_i_703 
       (.I0(pixel_x[4]),
        .I1(\rgb_out[23]_i_346_n_0 ),
        .I2(pixel_x[8]),
        .I3(pixel_x[7]),
        .I4(pixel_x[6]),
        .I5(pixel_x[9]),
        .O(\rgb_out[23]_i_703_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000000010)) 
    \rgb_out[23]_i_704 
       (.I0(pixel_x[5]),
        .I1(pixel_x[9]),
        .I2(\rgb_out[11]_i_11_n_0 ),
        .I3(pixel_x[7]),
        .I4(pixel_x[8]),
        .I5(\rgb_out[23]_i_1210_n_0 ),
        .O(\rgb_out[23]_i_704_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair22" *) 
  LUT5 #(
    .INIT(32'h00000001)) 
    \rgb_out[23]_i_705 
       (.I0(pixel_x[7]),
        .I1(pixel_x[6]),
        .I2(pixel_x[5]),
        .I3(pixel_x[11]),
        .I4(pixel_x[9]),
        .O(\rgb_out[23]_i_705_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair28" *) 
  LUT5 #(
    .INIT(32'h7FFFFFFF)) 
    \rgb_out[23]_i_706 
       (.I0(pixel_x[10]),
        .I1(pixel_x[8]),
        .I2(pixel_x[3]),
        .I3(pixel_x[4]),
        .I4(pixel_x[2]),
        .O(\rgb_out[23]_i_706_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair132" *) 
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_707 
       (.I0(pixel_x[11]),
        .I1(pixel_x[7]),
        .O(\rgb_out[23]_i_707_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair7" *) 
  LUT5 #(
    .INIT(32'hFFFEFEFE)) 
    \rgb_out[23]_i_708 
       (.I0(pixel_x[6]),
        .I1(pixel_x[9]),
        .I2(pixel_x[5]),
        .I3(pixel_x[4]),
        .I4(pixel_x[3]),
        .O(\rgb_out[23]_i_708_n_0 ));
  LUT6 #(
    .INIT(64'h0000008000000000)) 
    \rgb_out[23]_i_709 
       (.I0(\rgb_out[23]_i_137_n_0 ),
        .I1(pixel_y[3]),
        .I2(pixel_y[4]),
        .I3(pixel_y[7]),
        .I4(\rgb_out[23]_i_267_n_0 ),
        .I5(\rgb_out[23]_i_135_n_0 ),
        .O(\rgb_out[23]_i_709_n_0 ));
  LUT6 #(
    .INIT(64'hAAAAFFFF8880FFFF)) 
    \rgb_out[23]_i_71 
       (.I0(\rgb_out[20]_i_23_n_0 ),
        .I1(pixel_x[6]),
        .I2(pixel_x[4]),
        .I3(pixel_x[5]),
        .I4(\rgb_out[11]_i_11_n_0 ),
        .I5(pixel_x[7]),
        .O(\rgb_out[23]_i_71_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair36" *) 
  LUT5 #(
    .INIT(32'h00000002)) 
    \rgb_out[23]_i_710 
       (.I0(pixel_y[5]),
        .I1(pixel_y[8]),
        .I2(pixel_y[6]),
        .I3(pixel_y[7]),
        .I4(\rgb_out[21]_i_6_n_0 ),
        .O(\rgb_out[23]_i_710_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000000001)) 
    \rgb_out[23]_i_711 
       (.I0(pixel_x[8]),
        .I1(pixel_x[7]),
        .I2(pixel_x[3]),
        .I3(pixel_x[4]),
        .I4(pixel_x[1]),
        .I5(pixel_x[2]),
        .O(\rgb_out[23]_i_711_n_0 ));
  LUT6 #(
    .INIT(64'h00000002AAAAAAAA)) 
    \rgb_out[23]_i_712 
       (.I0(\rgb_out[23]_i_686_n_0 ),
        .I1(pixel_x[2]),
        .I2(pixel_x[3]),
        .I3(pixel_x[4]),
        .I4(pixel_x[5]),
        .I5(pixel_x[6]),
        .O(\rgb_out[23]_i_712_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair91" *) 
  LUT3 #(
    .INIT(8'hF8)) 
    \rgb_out[23]_i_713 
       (.I0(pixel_x[9]),
        .I1(pixel_x[10]),
        .I2(pixel_x[11]),
        .O(\rgb_out[23]_i_713_n_0 ));
  LUT6 #(
    .INIT(64'hE0E0E0A0FFFFFFFF)) 
    \rgb_out[23]_i_72 
       (.I0(pixel_x[7]),
        .I1(pixel_x[6]),
        .I2(\rgb_out[20]_i_23_n_0 ),
        .I3(\rgb_out[23]_i_230_n_0 ),
        .I4(pixel_x[5]),
        .I5(\rgb_out[11]_i_11_n_0 ),
        .O(\rgb_out[23]_i_72_n_0 ));
  LUT5 #(
    .INIT(32'h4FFF4444)) 
    \rgb_out[23]_i_73 
       (.I0(\rgb_out[23]_i_229_n_0 ),
        .I1(\rgb_out[7]_i_47_n_0 ),
        .I2(\rgb_out[23]_i_231_n_0 ),
        .I3(\rgb_out[23]_i_150_n_0 ),
        .I4(\rgb_out[20]_i_10_n_0 ),
        .O(\rgb_out[23]_i_73_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair20" *) 
  LUT4 #(
    .INIT(16'hB76D)) 
    \rgb_out[23]_i_734 
       (.I0(score_courant[0]),
        .I1(score_courant[1]),
        .I2(score_courant[2]),
        .I3(score_courant[3]),
        .O(\rgb_out[23]_i_734_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair88" *) 
  LUT3 #(
    .INIT(8'h21)) 
    \rgb_out[23]_i_736 
       (.I0(score_courant[3]),
        .I1(score_courant[2]),
        .I2(score_courant[1]),
        .O(\rgb_out[23]_i_736_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair81" *) 
  LUT4 #(
    .INIT(16'h2000)) 
    \rgb_out[23]_i_738 
       (.I0(score_courant[2]),
        .I1(score_courant[3]),
        .I2(score_courant[1]),
        .I3(score_courant[0]),
        .O(\rgb_out[23]_i_738_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair65" *) 
  LUT4 #(
    .INIT(16'hFFE0)) 
    \rgb_out[23]_i_74 
       (.I0(\rgb_out[23]_i_232_n_0 ),
        .I1(\rgb_out[7]_i_16_n_0 ),
        .I2(\rgb_out[23]_i_76_n_0 ),
        .I3(\rgb_out[23]_i_147_n_0 ),
        .O(\rgb_out[23]_i_74_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair81" *) 
  LUT4 #(
    .INIT(16'hC771)) 
    \rgb_out[23]_i_742 
       (.I0(score_courant[0]),
        .I1(score_courant[1]),
        .I2(score_courant[2]),
        .I3(score_courant[3]),
        .O(\SC_U/segments [1]));
  (* SOFT_HLUTNM = "soft_lutpair64" *) 
  LUT4 #(
    .INIT(16'h7F9F)) 
    \rgb_out[23]_i_744 
       (.I0(score_courant[0]),
        .I1(score_courant[1]),
        .I2(score_courant[2]),
        .I3(score_courant[3]),
        .O(\rgb_out[23]_i_744_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair64" *) 
  LUT4 #(
    .INIT(16'h1455)) 
    \rgb_out[23]_i_748 
       (.I0(score_courant[0]),
        .I1(score_courant[1]),
        .I2(score_courant[3]),
        .I3(score_courant[2]),
        .O(\SC_U/segments [2]));
  (* SOFT_HLUTNM = "soft_lutpair88" *) 
  LUT4 #(
    .INIT(16'hEFFB)) 
    \rgb_out[23]_i_749 
       (.I0(score_courant[0]),
        .I1(score_courant[1]),
        .I2(score_courant[2]),
        .I3(score_courant[3]),
        .O(\rgb_out[23]_i_749_n_0 ));
  LUT6 #(
    .INIT(64'h0000000004000000)) 
    \rgb_out[23]_i_75 
       (.I0(\rgb_out[23]_i_233_n_0 ),
        .I1(\rgb_out[11]_i_21_n_0 ),
        .I2(\rgb_out[23]_i_234_n_0 ),
        .I3(pixel_x[3]),
        .I4(pixel_x[9]),
        .I5(\rgb_out[23]_i_235_n_0 ),
        .O(\rgb_out[23]_i_75_n_0 ));
  LUT6 #(
    .INIT(64'hFF01000100010001)) 
    \rgb_out[23]_i_76 
       (.I0(\rgb_out[23]_i_41_n_0 ),
        .I1(\rgb_out[23]_i_236_n_0 ),
        .I2(pixel_y[2]),
        .I3(\rgb_out[23]_i_135_n_0 ),
        .I4(\rgb_out[23]_i_237_n_0 ),
        .I5(\rgb_out[23]_i_238_n_0 ),
        .O(\rgb_out[23]_i_76_n_0 ));
  LUT6 #(
    .INIT(64'h0000101000001000)) 
    \rgb_out[23]_i_77 
       (.I0(\rgb_out[23]_i_138_n_0 ),
        .I1(\rgb_out[23]_i_239_n_0 ),
        .I2(\rgb_out[23]_i_135_n_0 ),
        .I3(pixel_y[3]),
        .I4(pixel_y[4]),
        .I5(\rgb_out[11]_i_31_n_0 ),
        .O(\rgb_out[23]_i_77_n_0 ));
  LUT6 #(
    .INIT(64'hFFFE000000000000)) 
    \rgb_out[23]_i_772 
       (.I0(pixel_x[5]),
        .I1(pixel_x[4]),
        .I2(pixel_x[6]),
        .I3(pixel_x[7]),
        .I4(pixel_x[10]),
        .I5(pixel_x[8]),
        .O(\rgb_out[23]_i_772_n_0 ));
  LUT6 #(
    .INIT(64'h1111111011101111)) 
    \rgb_out[23]_i_773 
       (.I0(\rgb_out[11]_i_32_n_0 ),
        .I1(\rgb_out[20]_i_24_n_0 ),
        .I2(\rgb_out[23]_i_1208_n_0 ),
        .I3(pixel_x[3]),
        .I4(pixel_x[2]),
        .I5(pixel_x[1]),
        .O(\rgb_out[23]_i_773_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFFFFE)) 
    \rgb_out[23]_i_774 
       (.I0(pixel_x[5]),
        .I1(pixel_x[4]),
        .I2(pixel_x[9]),
        .I3(pixel_x[6]),
        .I4(pixel_x[2]),
        .I5(pixel_x[3]),
        .O(\rgb_out[23]_i_774_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000FEFFFE)) 
    \rgb_out[23]_i_775 
       (.I0(pixel_x[4]),
        .I1(\rgb_out[23]_i_913_n_0 ),
        .I2(pixel_x[7]),
        .I3(pixel_x[3]),
        .I4(\rgb_out[11]_i_22_n_0 ),
        .I5(\rgb_out[23]_i_1208_n_0 ),
        .O(\rgb_out[23]_i_775_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000000002)) 
    \rgb_out[23]_i_776 
       (.I0(\rgb_out[23]_i_219_n_0 ),
        .I1(pixel_x[7]),
        .I2(pixel_x[8]),
        .I3(pixel_x[5]),
        .I4(pixel_x[4]),
        .I5(pixel_x[3]),
        .O(\rgb_out[23]_i_776_n_0 ));
  LUT6 #(
    .INIT(64'h88F888F8FFFF88F8)) 
    \rgb_out[23]_i_78 
       (.I0(\rgb_out[23]_i_240_n_0 ),
        .I1(\rgb_out[23]_i_241_n_0 ),
        .I2(\rgb_out[23]_i_242_n_0 ),
        .I3(\rgb_out[23]_i_243_n_0 ),
        .I4(\rgb_out[23]_i_244_n_0 ),
        .I5(\rgb_out[23]_i_150_n_0 ),
        .O(\rgb_out[23]_i_78_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_788 
       (.I0(local_x_1[8]),
        .I1(local_x_1[9]),
        .O(\rgb_out[23]_i_788_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_789 
       (.I0(local_x_1[6]),
        .I1(local_x_1[7]),
        .O(\rgb_out[23]_i_789_n_0 ));
  LUT6 #(
    .INIT(64'h0000080000000000)) 
    \rgb_out[23]_i_79 
       (.I0(\rgb_out[11]_i_22_n_0 ),
        .I1(pixel_x[3]),
        .I2(\rgb_out[23]_i_245_n_0 ),
        .I3(\rgb_out[20]_i_19_n_0 ),
        .I4(\rgb_out[23]_i_246_n_0 ),
        .I5(\rgb_out[7]_i_60_n_0 ),
        .O(\rgb_out[23]_i_79_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_790 
       (.I0(local_x_1[9]),
        .I1(local_x_1[8]),
        .O(\rgb_out[23]_i_790_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \rgb_out[23]_i_791 
       (.I0(local_x_1[7]),
        .I1(local_x_1[6]),
        .O(\rgb_out[23]_i_791_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair52" *) 
  LUT4 #(
    .INIT(16'h0020)) 
    \rgb_out[23]_i_8 
       (.I0(mode_ui[2]),
        .I1(mode_ui[0]),
        .I2(mode_ui[1]),
        .I3(\rgb_out[23]_i_19_n_0 ),
        .O(\rgb_out[23]_i_8_n_0 ));
  LUT6 #(
    .INIT(64'h000000EEF0F000EE)) 
    \rgb_out[23]_i_80 
       (.I0(\rgb_out[23]_i_247_n_0 ),
        .I1(\rgb_out[23]_i_248_n_0 ),
        .I2(\rgb_out[7]_i_57_n_0 ),
        .I3(\rgb_out[23]_i_249_n_0 ),
        .I4(\rgb_out[7]_i_60_n_0 ),
        .I5(\rgb_out[7]_i_59_n_0 ),
        .O(\rgb_out[23]_i_80_n_0 ));
  LUT5 #(
    .INIT(32'hE0FFE0E0)) 
    \rgb_out[23]_i_81 
       (.I0(\rgb_out[23]_i_77_n_0 ),
        .I1(\rgb_out[23]_i_250_n_0 ),
        .I2(\rgb_out[7]_i_11_n_0 ),
        .I3(\rgb_out[20]_i_9_n_0 ),
        .I4(\rgb_out[23]_i_251_n_0 ),
        .O(\rgb_out[23]_i_81_n_0 ));
  LUT5 #(
    .INIT(32'hFFE0E0E0)) 
    \rgb_out[23]_i_82 
       (.I0(\rgb_out[20]_i_12_n_0 ),
        .I1(\rgb_out[23]_i_142_n_0 ),
        .I2(\rgb_out[23]_i_252_n_0 ),
        .I3(\rgb_out[23]_i_253_n_0 ),
        .I4(\rgb_out[23]_i_254_n_0 ),
        .O(\rgb_out[23]_i_82_n_0 ));
  LUT5 #(
    .INIT(32'h4F4F4F44)) 
    \rgb_out[23]_i_83 
       (.I0(\rgb_out[23]_i_231_n_0 ),
        .I1(\rgb_out[23]_i_252_n_0 ),
        .I2(\rgb_out[23]_i_36_n_0 ),
        .I3(\rgb_out[23]_i_255_n_0 ),
        .I4(\rgb_out[7]_i_62_n_0 ),
        .O(\rgb_out[23]_i_83_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFD0D0D0D0D0)) 
    \rgb_out[23]_i_84 
       (.I0(\rgb_out[23]_i_256_n_0 ),
        .I1(\rgb_out[23]_i_257_n_0 ),
        .I2(\rgb_out[7]_i_56_n_0 ),
        .I3(\rgb_out[20]_i_13_n_0 ),
        .I4(\rgb_out[23]_i_244_n_0 ),
        .I5(\rgb_out[23]_i_258_n_0 ),
        .O(\rgb_out[23]_i_84_n_0 ));
  LUT6 #(
    .INIT(64'hF444F444FFFFF444)) 
    \rgb_out[23]_i_85 
       (.I0(\rgb_out[23]_i_259_n_0 ),
        .I1(\rgb_out[23]_i_260_n_0 ),
        .I2(\rgb_out[23]_i_261_n_0 ),
        .I3(\rgb_out[23]_i_262_n_0 ),
        .I4(\rgb_out[23]_i_263_n_0 ),
        .I5(\rgb_out[23]_i_150_n_0 ),
        .O(\rgb_out[23]_i_85_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_852 
       (.I0(pixel_x[0]),
        .I1(pixel_x[1]),
        .O(\rgb_out[23]_i_852_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_855 
       (.I0(pixel_x[3]),
        .I1(pixel_x[2]),
        .O(\rgb_out[23]_i_855_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_856 
       (.I0(pixel_x[1]),
        .I1(pixel_x[0]),
        .O(\rgb_out[23]_i_856_n_0 ));
  LUT6 #(
    .INIT(64'hC4F4C4F4FFFFC4F4)) 
    \rgb_out[23]_i_86 
       (.I0(\rgb_out[23]_i_181_n_0 ),
        .I1(\rgb_out[23]_i_264_n_0 ),
        .I2(\rgb_out[23]_i_227_n_0 ),
        .I3(\rgb_out[23]_i_265_n_0 ),
        .I4(\rgb_out[23]_i_232_n_0 ),
        .I5(\rgb_out[23]_i_256_n_0 ),
        .O(\rgb_out[23]_i_86_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000000002)) 
    \rgb_out[23]_i_87 
       (.I0(\rgb_out[23]_i_266_n_0 ),
        .I1(\rgb_out[20]_i_17_n_0 ),
        .I2(\rgb_out[23]_i_40_n_0 ),
        .I3(\rgb_out[21]_i_6_n_0 ),
        .I4(\rgb_out[23]_i_267_n_0 ),
        .I5(pixel_y[4]),
        .O(\rgb_out[23]_i_87_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_88 
       (.I0(\rgb_out[23]_i_268_n_0 ),
        .I1(\rgb_out[23]_i_261_n_0 ),
        .O(\rgb_out[23]_i_88_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[23]_i_886 
       (.I0(pixel_x[0]),
        .I1(pixel_x[1]),
        .O(\rgb_out[23]_i_886_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_889 
       (.I0(pixel_x[2]),
        .I1(pixel_x[3]),
        .O(\rgb_out[23]_i_889_n_0 ));
  LUT5 #(
    .INIT(32'hFFD0D0D0)) 
    \rgb_out[23]_i_89 
       (.I0(\rgb_out[23]_i_268_n_0 ),
        .I1(\rgb_out[23]_i_269_n_0 ),
        .I2(\rgb_out[23]_i_145_n_0 ),
        .I3(\rgb_out[23]_i_250_n_0 ),
        .I4(\rgb_out[7]_i_19_n_0 ),
        .O(\rgb_out[23]_i_89_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \rgb_out[23]_i_890 
       (.I0(pixel_x[1]),
        .I1(pixel_x[0]),
        .O(\rgb_out[23]_i_890_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000000054)) 
    \rgb_out[23]_i_9 
       (.I0(\rgb_out[23]_i_20_n_0 ),
        .I1(\rgb_out[23]_i_21_n_0 ),
        .I2(\rgb_out[23]_i_22_n_0 ),
        .I3(\rgb_out[23]_i_23_n_0 ),
        .I4(\rgb_out[23]_i_24_n_0 ),
        .I5(\rgb_out[23]_i_25_n_0 ),
        .O(\rgb_out[23]_i_9_n_0 ));
  LUT6 #(
    .INIT(64'h111F1111111F111F)) 
    \rgb_out[23]_i_90 
       (.I0(\rgb_out[23]_i_101_n_0 ),
        .I1(\rgb_out[23]_i_270_n_0 ),
        .I2(\rgb_out[23]_i_271_n_0 ),
        .I3(\rgb_out[23]_i_272_n_0 ),
        .I4(\rgb_out[23]_i_273_n_0 ),
        .I5(\rgb_out[23]_i_274_n_0 ),
        .O(\rgb_out[23]_i_90_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair7" *) 
  LUT5 #(
    .INIT(32'h00000001)) 
    \rgb_out[23]_i_909 
       (.I0(pixel_x[6]),
        .I1(pixel_x[3]),
        .I2(pixel_x[4]),
        .I3(pixel_x[9]),
        .I4(pixel_x[5]),
        .O(\rgb_out[23]_i_909_n_0 ));
  LUT6 #(
    .INIT(64'hF7F7F7F7F7F7F300)) 
    \rgb_out[23]_i_91 
       (.I0(\rgb_out[23]_i_275_n_0 ),
        .I1(\rgb_out[23]_i_276_n_0 ),
        .I2(\rgb_out[23]_i_277_n_0 ),
        .I3(\rgb_out[23]_i_278_n_0 ),
        .I4(\rgb_out[23]_i_279_n_0 ),
        .I5(\rgb_out[23]_i_280_n_0 ),
        .O(\rgb_out[23]_i_91_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair63" *) 
  LUT4 #(
    .INIT(16'h7FFF)) 
    \rgb_out[23]_i_910 
       (.I0(pixel_x[2]),
        .I1(pixel_x[3]),
        .I2(pixel_x[10]),
        .I3(pixel_x[7]),
        .O(\rgb_out[23]_i_910_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair18" *) 
  LUT5 #(
    .INIT(32'hF3F7F7F7)) 
    \rgb_out[23]_i_911 
       (.I0(pixel_x[9]),
        .I1(pixel_x[10]),
        .I2(pixel_x[11]),
        .I3(pixel_x[8]),
        .I4(pixel_x[7]),
        .O(\rgb_out[23]_i_911_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair12" *) 
  LUT5 #(
    .INIT(32'h00550057)) 
    \rgb_out[23]_i_912 
       (.I0(pixel_x[7]),
        .I1(pixel_x[5]),
        .I2(pixel_x[4]),
        .I3(pixel_x[9]),
        .I4(pixel_x[6]),
        .O(\rgb_out[23]_i_912_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair47" *) 
  LUT4 #(
    .INIT(16'hFFFE)) 
    \rgb_out[23]_i_913 
       (.I0(pixel_x[9]),
        .I1(pixel_x[11]),
        .I2(pixel_x[5]),
        .I3(pixel_x[6]),
        .O(\rgb_out[23]_i_913_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair50" *) 
  LUT5 #(
    .INIT(32'hE0000000)) 
    \rgb_out[23]_i_914 
       (.I0(pixel_x[5]),
        .I1(pixel_x[6]),
        .I2(pixel_x[10]),
        .I3(pixel_x[7]),
        .I4(pixel_x[8]),
        .O(\rgb_out[23]_i_914_n_0 ));
  LUT6 #(
    .INIT(64'hFFFF800000000000)) 
    \rgb_out[23]_i_915 
       (.I0(pixel_y[2]),
        .I1(pixel_y[3]),
        .I2(pixel_y[0]),
        .I3(pixel_y[1]),
        .I4(pixel_y[4]),
        .I5(pixel_y[5]),
        .O(\rgb_out[23]_i_915_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair23" *) 
  LUT5 #(
    .INIT(32'hEA7FFFFF)) 
    \rgb_out[23]_i_916 
       (.I0(pixel_y[2]),
        .I1(pixel_y[0]),
        .I2(pixel_y[1]),
        .I3(pixel_y[3]),
        .I4(pixel_y[4]),
        .O(\rgb_out[23]_i_916_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair24" *) 
  LUT5 #(
    .INIT(32'hFFFEFEFE)) 
    \rgb_out[23]_i_917 
       (.I0(pixel_y[7]),
        .I1(pixel_y[6]),
        .I2(pixel_y[8]),
        .I3(pixel_y[4]),
        .I4(pixel_y[5]),
        .O(\rgb_out[23]_i_917_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair115" *) 
  LUT3 #(
    .INIT(8'h07)) 
    \rgb_out[23]_i_918 
       (.I0(pixel_y[0]),
        .I1(pixel_y[1]),
        .I2(pixel_y[2]),
        .O(\rgb_out[23]_i_918_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair39" *) 
  LUT5 #(
    .INIT(32'h7FFFFFFF)) 
    \rgb_out[23]_i_919 
       (.I0(pixel_x[3]),
        .I1(pixel_x[2]),
        .I2(pixel_x[8]),
        .I3(pixel_x[10]),
        .I4(pixel_x[5]),
        .O(\rgb_out[23]_i_919_n_0 ));
  LUT6 #(
    .INIT(64'hAAAA88A8AAAAAAAA)) 
    \rgb_out[23]_i_92 
       (.I0(\rgb_out[23]_i_101_n_0 ),
        .I1(\rgb_out[23]_i_281_n_0 ),
        .I2(\rgb_out[23]_i_282_n_0 ),
        .I3(\rgb_out[23]_i_283_n_0 ),
        .I4(\rgb_out[23]_i_284_n_0 ),
        .I5(\rgb_out[23]_i_114_n_0 ),
        .O(\rgb_out[23]_i_92_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair124" *) 
  LUT2 #(
    .INIT(4'h7)) 
    \rgb_out[23]_i_920 
       (.I0(pixel_x[6]),
        .I1(pixel_x[10]),
        .O(\rgb_out[23]_i_920_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair126" *) 
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_921 
       (.I0(pixel_x[11]),
        .I1(pixel_x[9]),
        .O(\rgb_out[23]_i_921_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair50" *) 
  LUT4 #(
    .INIT(16'h7FFF)) 
    \rgb_out[23]_i_922 
       (.I0(pixel_x[8]),
        .I1(pixel_x[6]),
        .I2(pixel_x[10]),
        .I3(pixel_x[7]),
        .O(\rgb_out[23]_i_922_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair43" *) 
  LUT5 #(
    .INIT(32'h88888000)) 
    \rgb_out[23]_i_923 
       (.I0(pixel_y[4]),
        .I1(pixel_y[3]),
        .I2(pixel_y[0]),
        .I3(pixel_y[1]),
        .I4(pixel_y[2]),
        .O(\rgb_out[23]_i_923_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair106" *) 
  LUT3 #(
    .INIT(8'h80)) 
    \rgb_out[23]_i_924 
       (.I0(pixel_y[5]),
        .I1(pixel_y[0]),
        .I2(pixel_y[1]),
        .O(\rgb_out[23]_i_924_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair69" *) 
  LUT4 #(
    .INIT(16'hAAA8)) 
    \rgb_out[23]_i_925 
       (.I0(pixel_y[5]),
        .I1(pixel_y[2]),
        .I2(pixel_y[3]),
        .I3(pixel_y[4]),
        .O(\rgb_out[23]_i_925_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair27" *) 
  LUT3 #(
    .INIT(8'hFE)) 
    \rgb_out[23]_i_926 
       (.I0(pixel_x[8]),
        .I1(pixel_x[9]),
        .I2(pixel_x[11]),
        .O(\rgb_out[23]_i_926_n_0 ));
  LUT6 #(
    .INIT(64'h00000000BBBABABA)) 
    \rgb_out[23]_i_93 
       (.I0(\rgb_out[21]_i_6_n_0 ),
        .I1(\rgb_out[23]_i_40_n_0 ),
        .I2(\rgb_out[23]_i_267_n_0 ),
        .I3(pixel_y[4]),
        .I4(\rgb_out[23]_i_237_n_0 ),
        .I5(\rgb_out[23]_i_285_n_0 ),
        .O(\rgb_out[23]_i_93_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000000010)) 
    \rgb_out[23]_i_94 
       (.I0(\rgb_out[23]_i_111_n_0 ),
        .I1(\rgb_out[23]_i_286_n_0 ),
        .I2(\rgb_out[23]_i_287_n_0 ),
        .I3(\rgb_out[23]_i_288_n_0 ),
        .I4(\rgb_out[23]_i_289_n_0 ),
        .I5(\rgb_out[23]_i_290_n_0 ),
        .O(\rgb_out[23]_i_94_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFA8FCFCFCA8)) 
    \rgb_out[23]_i_95 
       (.I0(\rgb_out[23]_i_115_n_0 ),
        .I1(\rgb_out[23]_i_291_n_0 ),
        .I2(\rgb_out[23]_i_292_n_0 ),
        .I3(\rgb_out[23]_i_293_n_0 ),
        .I4(\rgb_out[23]_i_93_n_0 ),
        .I5(\rgb_out[23]_i_294_n_0 ),
        .O(\rgb_out[23]_i_95_n_0 ));
  LUT6 #(
    .INIT(64'h0000000888888808)) 
    \rgb_out[23]_i_96 
       (.I0(\rgb_out[23]_i_295_n_0 ),
        .I1(\rgb_out[23]_i_108_n_0 ),
        .I2(\rgb_out[23]_i_296_n_0 ),
        .I3(pixel_x[11]),
        .I4(\rgb_out[23]_i_297_n_0 ),
        .I5(\rgb_out[23]_i_298_n_0 ),
        .O(\rgb_out[23]_i_96_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair136" *) 
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[23]_i_97 
       (.I0(\rgb_out[23]_i_115_n_0 ),
        .I1(\rgb_out[23]_i_299_n_0 ),
        .O(\rgb_out[23]_i_97_n_0 ));
  LUT6 #(
    .INIT(64'h000000000000FB00)) 
    \rgb_out[23]_i_98 
       (.I0(\rgb_out[23]_i_300_n_0 ),
        .I1(pixel_x[2]),
        .I2(\rgb_out[23]_i_301_n_0 ),
        .I3(\rgb_out[23]_i_302_n_0 ),
        .I4(\rgb_out[23]_i_303_n_0 ),
        .I5(\rgb_out[23]_i_304_n_0 ),
        .O(\rgb_out[23]_i_98_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFF0C0A0000)) 
    \rgb_out[23]_i_99 
       (.I0(\rgb_out[23]_i_222_n_0 ),
        .I1(\rgb_out[23]_i_305_n_0 ),
        .I2(\rgb_out[11]_i_29_n_0 ),
        .I3(pixel_x[6]),
        .I4(\rgb_out[23]_i_219_n_0 ),
        .I5(\rgb_out[23]_i_294_n_0 ),
        .O(\rgb_out[23]_i_99_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair99" *) 
  LUT3 #(
    .INIT(8'hD5)) 
    \rgb_out[2]_i_2 
       (.I0(\rgb_out[16]_i_5_n_0 ),
        .I1(rgb_in[2]),
        .I2(is_pixel_mur),
        .O(\rgb_out[2]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h0000040004040404)) 
    \rgb_out[2]_i_3 
       (.I0(mode_ui[0]),
        .I1(mode_ui[2]),
        .I2(mode_ui[1]),
        .I3(rgb_in[2]),
        .I4(\rgb_out[23]_i_12_n_0 ),
        .I5(\rgb_out[23]_i_11_n_0 ),
        .O(\rgb_out[2]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h0000810081818181)) 
    \rgb_out[2]_i_4 
       (.I0(mode_ui[2]),
        .I1(mode_ui[0]),
        .I2(mode_ui[1]),
        .I3(rgb_in[2]),
        .I4(\rgb_out[11]_i_5_n_0 ),
        .I5(\rgb_out[23]_i_9_n_0 ),
        .O(\rgb_out[2]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hBABBBBBBBBBBABAB)) 
    \rgb_out[5]_i_2 
       (.I0(\rgb_out[21]_i_5_n_0 ),
        .I1(is_pixel_mur),
        .I2(mode_ui[1]),
        .I3(flash_on),
        .I4(mode_ui[0]),
        .I5(mode_ui[2]),
        .O(\rgb_out[5]_i_2_n_0 ));
  LUT5 #(
    .INIT(32'hFFFFBABB)) 
    \rgb_out[5]_i_3 
       (.I0(\rgb_out[21]_i_4_n_0 ),
        .I1(\rgb_out[17]_i_3_n_0 ),
        .I2(rgb_in[5]),
        .I3(\rgb_out[23]_i_10_n_0 ),
        .I4(\rgb_out[1]_i_3_n_0 ),
        .O(\rgb_out[5]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair99" *) 
  LUT3 #(
    .INIT(8'h8A)) 
    \rgb_out[6]_i_2 
       (.I0(\rgb_out[16]_i_5_n_0 ),
        .I1(rgb_in[6]),
        .I2(is_pixel_mur),
        .O(\rgb_out[6]_i_2_n_0 ));
  LUT5 #(
    .INIT(32'hBFBBAAAA)) 
    \rgb_out[6]_i_3 
       (.I0(\rgb_out[1]_i_3_n_0 ),
        .I1(\rgb_out[23]_i_11_n_0 ),
        .I2(\rgb_out[23]_i_12_n_0 ),
        .I3(rgb_in[6]),
        .I4(\rgb_out[23]_i_13_n_0 ),
        .O(\rgb_out[6]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h0000810081818181)) 
    \rgb_out[6]_i_4 
       (.I0(mode_ui[2]),
        .I1(mode_ui[0]),
        .I2(mode_ui[1]),
        .I3(rgb_in[6]),
        .I4(\rgb_out[11]_i_5_n_0 ),
        .I5(\rgb_out[23]_i_9_n_0 ),
        .O(\rgb_out[6]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFFEAA)) 
    \rgb_out[7]_i_10 
       (.I0(pixel_x[3]),
        .I1(pixel_x[0]),
        .I2(pixel_x[1]),
        .I3(pixel_x[2]),
        .I4(\rgb_out[7]_i_25_n_0 ),
        .I5(\rgb_out[7]_i_26_n_0 ),
        .O(\rgb_out[7]_i_10_n_0 ));
  LUT6 #(
    .INIT(64'hBABABABAFFFF1030)) 
    \rgb_out[7]_i_11 
       (.I0(\rgb_out[7]_i_27_n_0 ),
        .I1(\rgb_out[7]_i_25_n_0 ),
        .I2(\rgb_out[7]_i_26_n_0 ),
        .I3(\rgb_out[7]_i_28_n_0 ),
        .I4(\rgb_out[7]_i_29_n_0 ),
        .I5(\rgb_out[7]_i_30_n_0 ),
        .O(\rgb_out[7]_i_11_n_0 ));
  LUT6 #(
    .INIT(64'h0000000040000000)) 
    \rgb_out[7]_i_12 
       (.I0(\rgb_out[7]_i_31_n_0 ),
        .I1(\rgb_out[7]_i_32_n_0 ),
        .I2(pixel_y[3]),
        .I3(pixel_y[5]),
        .I4(pixel_y[4]),
        .I5(\rgb_out[23]_i_40_n_0 ),
        .O(\rgb_out[7]_i_12_n_0 ));
  LUT6 #(
    .INIT(64'h4040454440404044)) 
    \rgb_out[7]_i_13 
       (.I0(\rgb_out[21]_i_6_n_0 ),
        .I1(\rgb_out[7]_i_33_n_0 ),
        .I2(\rgb_out[23]_i_40_n_0 ),
        .I3(\rgb_out[7]_i_34_n_0 ),
        .I4(pixel_y[6]),
        .I5(\rgb_out[7]_i_35_n_0 ),
        .O(\rgb_out[7]_i_13_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000020200)) 
    \rgb_out[7]_i_14 
       (.I0(\rgb_out[7]_i_36_n_0 ),
        .I1(pixel_y[4]),
        .I2(pixel_y[5]),
        .I3(pixel_y[3]),
        .I4(pixel_y[2]),
        .I5(\rgb_out[7]_i_37_n_0 ),
        .O(\rgb_out[7]_i_14_n_0 ));
  LUT6 #(
    .INIT(64'h1313131310101000)) 
    \rgb_out[7]_i_15 
       (.I0(\rgb_out[7]_i_38_n_0 ),
        .I1(\rgb_out[7]_i_39_n_0 ),
        .I2(\rgb_out[20]_i_23_n_0 ),
        .I3(pixel_x[6]),
        .I4(pixel_x[7]),
        .I5(\rgb_out[7]_i_40_n_0 ),
        .O(\rgb_out[7]_i_15_n_0 ));
  LUT6 #(
    .INIT(64'hFFE2E2E2E2E2E2E2)) 
    \rgb_out[7]_i_16 
       (.I0(\rgb_out[7]_i_41_n_0 ),
        .I1(\rgb_out[7]_i_42_n_0 ),
        .I2(\rgb_out[7]_i_43_n_0 ),
        .I3(\rgb_out[7]_i_44_n_0 ),
        .I4(\rgb_out[7]_i_45_n_0 ),
        .I5(\rgb_out[7]_i_46_n_0 ),
        .O(\rgb_out[7]_i_16_n_0 ));
  LUT6 #(
    .INIT(64'h000000000000001F)) 
    \rgb_out[7]_i_17 
       (.I0(\rgb_out[23]_i_184_n_0 ),
        .I1(\rgb_out[23]_i_185_n_0 ),
        .I2(\rgb_out[7]_i_14_n_0 ),
        .I3(\rgb_out[23]_i_79_n_0 ),
        .I4(\rgb_out[23]_i_129_n_0 ),
        .I5(\rgb_out[7]_i_47_n_0 ),
        .O(\rgb_out[7]_i_17_n_0 ));
  LUT5 #(
    .INIT(32'hDDD0DDDD)) 
    \rgb_out[7]_i_18 
       (.I0(\rgb_out[7]_i_48_n_0 ),
        .I1(\rgb_out[7]_i_24_n_0 ),
        .I2(\rgb_out[7]_i_49_n_0 ),
        .I3(\rgb_out[7]_i_50_n_0 ),
        .I4(\rgb_out[23]_i_183_n_0 ),
        .O(\rgb_out[7]_i_18_n_0 ));
  LUT6 #(
    .INIT(64'hDFFFFFFFDFD8D8D8)) 
    \rgb_out[7]_i_19 
       (.I0(\rgb_out[7]_i_51_n_0 ),
        .I1(\rgb_out[7]_i_52_n_0 ),
        .I2(\rgb_out[7]_i_53_n_0 ),
        .I3(\rgb_out[7]_i_54_n_0 ),
        .I4(\rgb_out[20]_i_19_n_0 ),
        .I5(\rgb_out[7]_i_55_n_0 ),
        .O(\rgb_out[7]_i_19_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair51" *) 
  LUT3 #(
    .INIT(8'h8A)) 
    \rgb_out[7]_i_20 
       (.I0(\rgb_out[7]_i_56_n_0 ),
        .I1(\rgb_out[7]_i_13_n_0 ),
        .I2(\rgb_out[7]_i_48_n_0 ),
        .O(\rgb_out[7]_i_20_n_0 ));
  LUT6 #(
    .INIT(64'hFFF4F0F0C0C4C0C0)) 
    \rgb_out[7]_i_21 
       (.I0(\rgb_out[7]_i_57_n_0 ),
        .I1(\rgb_out[7]_i_58_n_0 ),
        .I2(\rgb_out[7]_i_47_n_0 ),
        .I3(\rgb_out[7]_i_59_n_0 ),
        .I4(\rgb_out[7]_i_60_n_0 ),
        .I5(\rgb_out[7]_i_61_n_0 ),
        .O(\rgb_out[7]_i_21_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair109" *) 
  LUT3 #(
    .INIT(8'h0E)) 
    \rgb_out[7]_i_22 
       (.I0(\rgb_out[7]_i_12_n_0 ),
        .I1(\rgb_out[7]_i_24_n_0 ),
        .I2(\rgb_out[23]_i_80_n_0 ),
        .O(\rgb_out[7]_i_22_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair51" *) 
  LUT4 #(
    .INIT(16'hA8AA)) 
    \rgb_out[7]_i_23 
       (.I0(\rgb_out[7]_i_62_n_0 ),
        .I1(\rgb_out[7]_i_12_n_0 ),
        .I2(\rgb_out[7]_i_13_n_0 ),
        .I3(\rgb_out[7]_i_48_n_0 ),
        .O(\rgb_out[7]_i_23_n_0 ));
  LUT6 #(
    .INIT(64'h2222222220002020)) 
    \rgb_out[7]_i_24 
       (.I0(\rgb_out[7]_i_32_n_0 ),
        .I1(\rgb_out[7]_i_63_n_0 ),
        .I2(\rgb_out[7]_i_64_n_0 ),
        .I3(\rgb_out[7]_i_65_n_0 ),
        .I4(\rgb_out[7]_i_66_n_0 ),
        .I5(\rgb_out[21]_i_6_n_0 ),
        .O(\rgb_out[7]_i_24_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair33" *) 
  LUT5 #(
    .INIT(32'hFFFFFF80)) 
    \rgb_out[7]_i_25 
       (.I0(pixel_x[9]),
        .I1(pixel_x[8]),
        .I2(pixel_x[7]),
        .I3(pixel_x[10]),
        .I4(pixel_x[11]),
        .O(\rgb_out[7]_i_25_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT5 #(
    .INIT(32'h7FFFFFFF)) 
    \rgb_out[7]_i_26 
       (.I0(pixel_x[9]),
        .I1(pixel_x[8]),
        .I2(pixel_x[5]),
        .I3(pixel_x[4]),
        .I4(pixel_x[6]),
        .O(\rgb_out[7]_i_26_n_0 ));
  LUT6 #(
    .INIT(64'h02AA0AAA02AA02AA)) 
    \rgb_out[7]_i_27 
       (.I0(\rgb_out[11]_i_11_n_0 ),
        .I1(\rgb_out[23]_i_333_n_0 ),
        .I2(pixel_x[7]),
        .I3(\rgb_out[20]_i_23_n_0 ),
        .I4(pixel_x[4]),
        .I5(\rgb_out[7]_i_67_n_0 ),
        .O(\rgb_out[7]_i_27_n_0 ));
  LUT6 #(
    .INIT(64'hF1FFFFFFFFFFFFFF)) 
    \rgb_out[7]_i_28 
       (.I0(\rgb_out[23]_i_466_n_0 ),
        .I1(pixel_x[2]),
        .I2(\rgb_out[23]_i_353_n_0 ),
        .I3(pixel_x[5]),
        .I4(pixel_x[9]),
        .I5(pixel_x[3]),
        .O(\rgb_out[7]_i_28_n_0 ));
  LUT6 #(
    .INIT(64'hE0E0E0A0E0A0E0A0)) 
    \rgb_out[7]_i_29 
       (.I0(pixel_x[7]),
        .I1(pixel_x[6]),
        .I2(\rgb_out[20]_i_23_n_0 ),
        .I3(pixel_x[5]),
        .I4(\rgb_out[23]_i_392_n_0 ),
        .I5(pixel_x[2]),
        .O(\rgb_out[7]_i_29_n_0 ));
  LUT6 #(
    .INIT(64'hE0E0E0C0FFFFFFFF)) 
    \rgb_out[7]_i_30 
       (.I0(\rgb_out[23]_i_333_n_0 ),
        .I1(pixel_x[7]),
        .I2(\rgb_out[20]_i_23_n_0 ),
        .I3(\rgb_out[11]_i_28_n_0 ),
        .I4(pixel_x[0]),
        .I5(\rgb_out[11]_i_11_n_0 ),
        .O(\rgb_out[7]_i_30_n_0 ));
  LUT6 #(
    .INIT(64'h0000000040404000)) 
    \rgb_out[7]_i_31 
       (.I0(\rgb_out[20]_i_27_n_0 ),
        .I1(pixel_y[2]),
        .I2(pixel_y[3]),
        .I3(pixel_y[1]),
        .I4(pixel_y[0]),
        .I5(\rgb_out[23]_i_40_n_0 ),
        .O(\rgb_out[7]_i_31_n_0 ));
  LUT6 #(
    .INIT(64'h0001010101010101)) 
    \rgb_out[7]_i_32 
       (.I0(pixel_y[9]),
        .I1(pixel_y[10]),
        .I2(pixel_y[11]),
        .I3(pixel_y[8]),
        .I4(pixel_y[7]),
        .I5(pixel_y[6]),
        .O(\rgb_out[7]_i_32_n_0 ));
  LUT6 #(
    .INIT(64'hFF00FFFFFF00FFA8)) 
    \rgb_out[7]_i_33 
       (.I0(pixel_y[5]),
        .I1(pixel_y[4]),
        .I2(\rgb_out[20]_i_17_n_0 ),
        .I3(\rgb_out[21]_i_6_n_0 ),
        .I4(\rgb_out[23]_i_40_n_0 ),
        .I5(pixel_y[6]),
        .O(\rgb_out[7]_i_33_n_0 ));
  LUT6 #(
    .INIT(64'h8888888088808880)) 
    \rgb_out[7]_i_34 
       (.I0(pixel_y[4]),
        .I1(pixel_y[5]),
        .I2(pixel_y[3]),
        .I3(pixel_y[2]),
        .I4(pixel_y[0]),
        .I5(pixel_y[1]),
        .O(\rgb_out[7]_i_34_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair31" *) 
  LUT5 #(
    .INIT(32'h7FFFFFFF)) 
    \rgb_out[7]_i_35 
       (.I0(pixel_y[3]),
        .I1(pixel_y[5]),
        .I2(pixel_y[4]),
        .I3(pixel_y[7]),
        .I4(pixel_y[8]),
        .O(\rgb_out[7]_i_35_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000000080)) 
    \rgb_out[7]_i_36 
       (.I0(pixel_y[6]),
        .I1(pixel_y[7]),
        .I2(pixel_y[8]),
        .I3(pixel_y[9]),
        .I4(pixel_y[10]),
        .I5(pixel_y[11]),
        .O(\rgb_out[7]_i_36_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair106" *) 
  LUT2 #(
    .INIT(4'h7)) 
    \rgb_out[7]_i_37 
       (.I0(pixel_y[1]),
        .I1(pixel_y[0]),
        .O(\rgb_out[7]_i_37_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT5 #(
    .INIT(32'hAAAAAAA8)) 
    \rgb_out[7]_i_38 
       (.I0(pixel_x[6]),
        .I1(pixel_x[5]),
        .I2(pixel_x[4]),
        .I3(pixel_x[3]),
        .I4(pixel_x[2]),
        .O(\rgb_out[7]_i_38_n_0 ));
  LUT6 #(
    .INIT(64'hC8FFC0FFC0FFC0FF)) 
    \rgb_out[7]_i_39 
       (.I0(pixel_x[6]),
        .I1(\rgb_out[20]_i_23_n_0 ),
        .I2(pixel_x[7]),
        .I3(\rgb_out[11]_i_11_n_0 ),
        .I4(pixel_x[0]),
        .I5(pixel_x[1]),
        .O(\rgb_out[7]_i_39_n_0 ));
  LUT4 #(
    .INIT(16'h55D5)) 
    \rgb_out[7]_i_4 
       (.I0(\rgb_out[7]_i_9_n_0 ),
        .I1(\rgb_out[23]_i_21_n_0 ),
        .I2(\rgb_out[7]_i_10_n_0 ),
        .I3(\rgb_out[7]_i_11_n_0 ),
        .O(\rgb_out[7]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h4000000000000000)) 
    \rgb_out[7]_i_40 
       (.I0(\rgb_out[23]_i_223_n_0 ),
        .I1(pixel_x[5]),
        .I2(pixel_x[8]),
        .I3(pixel_x[4]),
        .I4(pixel_x[9]),
        .I5(pixel_x[3]),
        .O(\rgb_out[7]_i_40_n_0 ));
  LUT6 #(
    .INIT(64'hA8A8A8A8A0A8A8A8)) 
    \rgb_out[7]_i_41 
       (.I0(\rgb_out[20]_i_23_n_0 ),
        .I1(pixel_x[6]),
        .I2(pixel_x[7]),
        .I3(\rgb_out[20]_i_25_n_0 ),
        .I4(\rgb_out[23]_i_334_n_0 ),
        .I5(\rgb_out[23]_i_466_n_0 ),
        .O(\rgb_out[7]_i_41_n_0 ));
  LUT6 #(
    .INIT(64'hAAAAFFFF8088FFFF)) 
    \rgb_out[7]_i_42 
       (.I0(\rgb_out[20]_i_23_n_0 ),
        .I1(pixel_x[6]),
        .I2(pixel_x[3]),
        .I3(\rgb_out[20]_i_25_n_0 ),
        .I4(\rgb_out[11]_i_11_n_0 ),
        .I5(pixel_x[7]),
        .O(\rgb_out[7]_i_42_n_0 ));
  LUT6 #(
    .INIT(64'hAAAAAAAA8AAAAAAA)) 
    \rgb_out[7]_i_43 
       (.I0(\rgb_out[7]_i_68_n_0 ),
        .I1(\rgb_out[23]_i_353_n_0 ),
        .I2(pixel_x[3]),
        .I3(pixel_x[9]),
        .I4(pixel_x[2]),
        .I5(\rgb_out[23]_i_370_n_0 ),
        .O(\rgb_out[7]_i_43_n_0 ));
  LUT6 #(
    .INIT(64'hAAAAAAAAAABBAABF)) 
    \rgb_out[7]_i_44 
       (.I0(\rgb_out[7]_i_69_n_0 ),
        .I1(pixel_x[4]),
        .I2(pixel_x[3]),
        .I3(pixel_x[7]),
        .I4(\rgb_out[11]_i_22_n_0 ),
        .I5(\rgb_out[23]_i_333_n_0 ),
        .O(\rgb_out[7]_i_44_n_0 ));
  LUT6 #(
    .INIT(64'hFF00FF00FE000000)) 
    \rgb_out[7]_i_45 
       (.I0(pixel_x[5]),
        .I1(pixel_x[4]),
        .I2(\rgb_out[23]_i_346_n_0 ),
        .I3(\rgb_out[20]_i_23_n_0 ),
        .I4(pixel_x[6]),
        .I5(pixel_x[7]),
        .O(\rgb_out[7]_i_45_n_0 ));
  LUT6 #(
    .INIT(64'hAAAAAAAAAAAAAAA8)) 
    \rgb_out[7]_i_46 
       (.I0(\rgb_out[11]_i_11_n_0 ),
        .I1(pixel_x[7]),
        .I2(pixel_x[4]),
        .I3(pixel_x[5]),
        .I4(pixel_x[0]),
        .I5(pixel_x[1]),
        .O(\rgb_out[7]_i_46_n_0 ));
  LUT6 #(
    .INIT(64'h0000000040400040)) 
    \rgb_out[7]_i_47 
       (.I0(\rgb_out[23]_i_249_n_0 ),
        .I1(pixel_x[9]),
        .I2(\rgb_out[11]_i_21_n_0 ),
        .I3(\rgb_out[7]_i_70_n_0 ),
        .I4(\rgb_out[23]_i_235_n_0 ),
        .I5(\rgb_out[7]_i_60_n_0 ),
        .O(\rgb_out[7]_i_47_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000F20DFF)) 
    \rgb_out[7]_i_48 
       (.I0(pixel_y[6]),
        .I1(\rgb_out[23]_i_40_n_0 ),
        .I2(\rgb_out[21]_i_6_n_0 ),
        .I3(\rgb_out[7]_i_71_n_0 ),
        .I4(\rgb_out[7]_i_31_n_0 ),
        .I5(\rgb_out[7]_i_58_n_0 ),
        .O(\rgb_out[7]_i_48_n_0 ));
  LUT6 #(
    .INIT(64'h0888088808888888)) 
    \rgb_out[7]_i_49 
       (.I0(\rgb_out[7]_i_72_n_0 ),
        .I1(\rgb_out[7]_i_73_n_0 ),
        .I2(\rgb_out[20]_i_23_n_0 ),
        .I3(\rgb_out[23]_i_222_n_0 ),
        .I4(\rgb_out[11]_i_22_n_0 ),
        .I5(pixel_x[0]),
        .O(\rgb_out[7]_i_49_n_0 ));
  LUT6 #(
    .INIT(64'hFEFEEEEEFEF00000)) 
    \rgb_out[7]_i_5 
       (.I0(\rgb_out[7]_i_9_n_0 ),
        .I1(\rgb_out[7]_i_12_n_0 ),
        .I2(\rgb_out[7]_i_13_n_0 ),
        .I3(\rgb_out[7]_i_14_n_0 ),
        .I4(\rgb_out[7]_i_15_n_0 ),
        .I5(\rgb_out[7]_i_16_n_0 ),
        .O(\rgb_out[7]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'h8088888888888888)) 
    \rgb_out[7]_i_50 
       (.I0(\rgb_out[7]_i_74_n_0 ),
        .I1(\rgb_out[7]_i_75_n_0 ),
        .I2(\rgb_out[23]_i_223_n_0 ),
        .I3(\rgb_out[7]_i_76_n_0 ),
        .I4(\rgb_out[20]_i_23_n_0 ),
        .I5(pixel_x[0]),
        .O(\rgb_out[7]_i_50_n_0 ));
  LUT6 #(
    .INIT(64'h00570057FFFF0057)) 
    \rgb_out[7]_i_51 
       (.I0(pixel_x[3]),
        .I1(\rgb_out[11]_i_22_n_0 ),
        .I2(pixel_x[0]),
        .I3(\rgb_out[7]_i_77_n_0 ),
        .I4(\rgb_out[20]_i_19_n_0 ),
        .I5(\rgb_out[23]_i_245_n_0 ),
        .O(\rgb_out[7]_i_51_n_0 ));
  LUT6 #(
    .INIT(64'hFF00FFFF4000FFFF)) 
    \rgb_out[7]_i_52 
       (.I0(\rgb_out[23]_i_307_n_0 ),
        .I1(\rgb_out[11]_i_21_n_0 ),
        .I2(pixel_x[5]),
        .I3(pixel_x[9]),
        .I4(\rgb_out[11]_i_11_n_0 ),
        .I5(pixel_x[8]),
        .O(\rgb_out[7]_i_52_n_0 ));
  LUT6 #(
    .INIT(64'h222A22AA22AA22AA)) 
    \rgb_out[7]_i_53 
       (.I0(\rgb_out[20]_i_19_n_0 ),
        .I1(\rgb_out[23]_i_245_n_0 ),
        .I2(pixel_x[3]),
        .I3(pixel_x[4]),
        .I4(pixel_x[1]),
        .I5(pixel_x[2]),
        .O(\rgb_out[7]_i_53_n_0 ));
  LUT6 #(
    .INIT(64'hF7FFFFFFF7F7F7F7)) 
    \rgb_out[7]_i_54 
       (.I0(pixel_x[9]),
        .I1(\rgb_out[11]_i_21_n_0 ),
        .I2(\rgb_out[23]_i_233_n_0 ),
        .I3(pixel_x[0]),
        .I4(pixel_x[1]),
        .I5(\rgb_out[23]_i_334_n_0 ),
        .O(\rgb_out[7]_i_54_n_0 ));
  LUT6 #(
    .INIT(64'h2AAAAAAAAAAAAAAA)) 
    \rgb_out[7]_i_55 
       (.I0(\rgb_out[20]_i_19_n_0 ),
        .I1(pixel_x[9]),
        .I2(pixel_x[5]),
        .I3(\rgb_out[11]_i_21_n_0 ),
        .I4(pixel_x[3]),
        .I5(pixel_x[4]),
        .O(\rgb_out[7]_i_55_n_0 ));
  LUT6 #(
    .INIT(64'h0003000000020002)) 
    \rgb_out[7]_i_56 
       (.I0(pixel_x[2]),
        .I1(\rgb_out[7]_i_78_n_0 ),
        .I2(pixel_x[4]),
        .I3(\rgb_out[23]_i_235_n_0 ),
        .I4(\rgb_out[7]_i_79_n_0 ),
        .I5(pixel_x[3]),
        .O(\rgb_out[7]_i_56_n_0 ));
  LUT6 #(
    .INIT(64'hF3333333F3B33333)) 
    \rgb_out[7]_i_57 
       (.I0(pixel_x[4]),
        .I1(\rgb_out[20]_i_19_n_0 ),
        .I2(pixel_x[9]),
        .I3(pixel_x[5]),
        .I4(\rgb_out[11]_i_21_n_0 ),
        .I5(\rgb_out[7]_i_80_n_0 ),
        .O(\rgb_out[7]_i_57_n_0 ));
  LUT6 #(
    .INIT(64'h004400CC00CC00C0)) 
    \rgb_out[7]_i_58 
       (.I0(pixel_y[0]),
        .I1(\rgb_out[7]_i_36_n_0 ),
        .I2(\rgb_out[21]_i_6_n_0 ),
        .I3(\rgb_out[7]_i_81_n_0 ),
        .I4(pixel_y[2]),
        .I5(pixel_y[1]),
        .O(\rgb_out[7]_i_58_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000000057)) 
    \rgb_out[7]_i_59 
       (.I0(pixel_x[2]),
        .I1(pixel_x[1]),
        .I2(pixel_x[0]),
        .I3(pixel_x[3]),
        .I4(\rgb_out[23]_i_235_n_0 ),
        .I5(pixel_x[5]),
        .O(\rgb_out[7]_i_59_n_0 ));
  LUT5 #(
    .INIT(32'hFFFFF0FE)) 
    \rgb_out[7]_i_6 
       (.I0(\rgb_out[7]_i_14_n_0 ),
        .I1(\rgb_out[7]_i_13_n_0 ),
        .I2(\rgb_out[23]_i_52_n_0 ),
        .I3(\rgb_out[7]_i_17_n_0 ),
        .I4(\rgb_out[7]_i_18_n_0 ),
        .O(\rgb_out[7]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'hC0800000FFFFFFFF)) 
    \rgb_out[7]_i_60 
       (.I0(pixel_x[4]),
        .I1(pixel_x[7]),
        .I2(pixel_x[6]),
        .I3(pixel_x[5]),
        .I4(pixel_x[9]),
        .I5(\rgb_out[20]_i_19_n_0 ),
        .O(\rgb_out[7]_i_60_n_0 ));
  LUT6 #(
    .INIT(64'h00F000F000F04444)) 
    \rgb_out[7]_i_61 
       (.I0(\rgb_out[7]_i_82_n_0 ),
        .I1(\rgb_out[7]_i_83_n_0 ),
        .I2(\rgb_out[23]_i_137_n_0 ),
        .I3(\rgb_out[23]_i_41_n_0 ),
        .I4(\rgb_out[21]_i_6_n_0 ),
        .I5(\rgb_out[7]_i_84_n_0 ),
        .O(\rgb_out[7]_i_61_n_0 ));
  LUT6 #(
    .INIT(64'h000000000000AA2A)) 
    \rgb_out[7]_i_62 
       (.I0(\rgb_out[7]_i_28_n_0 ),
        .I1(pixel_x[6]),
        .I2(pixel_x[4]),
        .I3(\rgb_out[7]_i_85_n_0 ),
        .I4(\rgb_out[7]_i_25_n_0 ),
        .I5(\rgb_out[7]_i_27_n_0 ),
        .O(\rgb_out[7]_i_62_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair43" *) 
  LUT4 #(
    .INIT(16'hEAAA)) 
    \rgb_out[7]_i_63 
       (.I0(pixel_y[4]),
        .I1(pixel_y[2]),
        .I2(pixel_y[3]),
        .I3(pixel_y[1]),
        .O(\rgb_out[7]_i_63_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair36" *) 
  LUT4 #(
    .INIT(16'hE000)) 
    \rgb_out[7]_i_64 
       (.I0(pixel_y[5]),
        .I1(pixel_y[6]),
        .I2(pixel_y[7]),
        .I3(pixel_y[8]),
        .O(\rgb_out[7]_i_64_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair125" *) 
  LUT3 #(
    .INIT(8'hEA)) 
    \rgb_out[7]_i_65 
       (.I0(pixel_y[6]),
        .I1(pixel_y[4]),
        .I2(pixel_y[5]),
        .O(\rgb_out[7]_i_65_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair25" *) 
  LUT4 #(
    .INIT(16'h5557)) 
    \rgb_out[7]_i_66 
       (.I0(pixel_y[3]),
        .I1(pixel_y[2]),
        .I2(pixel_y[1]),
        .I3(pixel_y[0]),
        .O(\rgb_out[7]_i_66_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair112" *) 
  LUT3 #(
    .INIT(8'h07)) 
    \rgb_out[7]_i_67 
       (.I0(pixel_x[2]),
        .I1(pixel_x[1]),
        .I2(pixel_x[3]),
        .O(\rgb_out[7]_i_67_n_0 ));
  LUT6 #(
    .INIT(64'h0000000101010101)) 
    \rgb_out[7]_i_68 
       (.I0(pixel_x[7]),
        .I1(pixel_x[11]),
        .I2(pixel_x[10]),
        .I3(pixel_x[5]),
        .I4(pixel_x[4]),
        .I5(pixel_x[6]),
        .O(\rgb_out[7]_i_68_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair71" *) 
  LUT4 #(
    .INIT(16'h1FFF)) 
    \rgb_out[7]_i_69 
       (.I0(pixel_x[7]),
        .I1(pixel_x[6]),
        .I2(pixel_x[8]),
        .I3(pixel_x[9]),
        .O(\rgb_out[7]_i_69_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFFFF8)) 
    \rgb_out[7]_i_7 
       (.I0(\rgb_out[7]_i_12_n_0 ),
        .I1(\rgb_out[7]_i_19_n_0 ),
        .I2(\rgb_out[7]_i_20_n_0 ),
        .I3(\rgb_out[7]_i_21_n_0 ),
        .I4(\rgb_out[7]_i_22_n_0 ),
        .I5(\rgb_out[7]_i_23_n_0 ),
        .O(\rgb_out[7]_i_7_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair13" *) 
  LUT5 #(
    .INIT(32'h00000111)) 
    \rgb_out[7]_i_70 
       (.I0(pixel_x[4]),
        .I1(pixel_x[5]),
        .I2(pixel_x[2]),
        .I3(pixel_x[1]),
        .I4(pixel_x[3]),
        .O(\rgb_out[7]_i_70_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000000001)) 
    \rgb_out[7]_i_71 
       (.I0(pixel_y[1]),
        .I1(pixel_y[2]),
        .I2(pixel_y[3]),
        .I3(pixel_y[4]),
        .I4(pixel_y[5]),
        .I5(\rgb_out[21]_i_6_n_0 ),
        .O(\rgb_out[7]_i_71_n_0 ));
  LUT6 #(
    .INIT(64'hFEAAAAAAAAAAAAAA)) 
    \rgb_out[7]_i_72 
       (.I0(\rgb_out[23]_i_394_n_0 ),
        .I1(pixel_x[2]),
        .I2(pixel_x[3]),
        .I3(pixel_x[4]),
        .I4(pixel_x[5]),
        .I5(\rgb_out[20]_i_23_n_0 ),
        .O(\rgb_out[7]_i_72_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000001FFF)) 
    \rgb_out[7]_i_73 
       (.I0(pixel_x[7]),
        .I1(pixel_x[6]),
        .I2(pixel_x[9]),
        .I3(pixel_x[8]),
        .I4(pixel_x[11]),
        .I5(pixel_x[10]),
        .O(\rgb_out[7]_i_73_n_0 ));
  LUT6 #(
    .INIT(64'h0100000000000000)) 
    \rgb_out[7]_i_74 
       (.I0(\rgb_out[23]_i_392_n_0 ),
        .I1(pixel_x[5]),
        .I2(pixel_x[7]),
        .I3(pixel_x[6]),
        .I4(\rgb_out[20]_i_23_n_0 ),
        .I5(\rgb_out[11]_i_11_n_0 ),
        .O(\rgb_out[7]_i_74_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFD0FF)) 
    \rgb_out[7]_i_75 
       (.I0(\rgb_out[23]_i_334_n_0 ),
        .I1(pixel_x[1]),
        .I2(pixel_x[4]),
        .I3(\rgb_out[11]_i_11_n_0 ),
        .I4(pixel_x[5]),
        .I5(pixel_x[7]),
        .O(\rgb_out[7]_i_75_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair130" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \rgb_out[7]_i_76 
       (.I0(pixel_x[6]),
        .I1(pixel_x[4]),
        .O(\rgb_out[7]_i_76_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair57" *) 
  LUT4 #(
    .INIT(16'hFFFE)) 
    \rgb_out[7]_i_77 
       (.I0(pixel_x[4]),
        .I1(pixel_x[11]),
        .I2(pixel_x[10]),
        .I3(pixel_x[8]),
        .O(\rgb_out[7]_i_77_n_0 ));
  LUT6 #(
    .INIT(64'h0C4C4C4C4C4C4C4C)) 
    \rgb_out[7]_i_78 
       (.I0(pixel_x[8]),
        .I1(\rgb_out[11]_i_11_n_0 ),
        .I2(pixel_x[9]),
        .I3(pixel_x[5]),
        .I4(pixel_x[6]),
        .I5(pixel_x[7]),
        .O(\rgb_out[7]_i_78_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair9" *) 
  LUT3 #(
    .INIT(8'h01)) 
    \rgb_out[7]_i_79 
       (.I0(pixel_x[0]),
        .I1(pixel_x[2]),
        .I2(pixel_x[1]),
        .O(\rgb_out[7]_i_79_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair103" *) 
  LUT3 #(
    .INIT(8'h08)) 
    \rgb_out[7]_i_8 
       (.I0(mode_ui[1]),
        .I1(mode_ui[0]),
        .I2(mode_ui[2]),
        .O(\rgb_out[7]_i_8_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair112" *) 
  LUT3 #(
    .INIT(8'h57)) 
    \rgb_out[7]_i_80 
       (.I0(pixel_x[3]),
        .I1(pixel_x[2]),
        .I2(pixel_x[1]),
        .O(\rgb_out[7]_i_80_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair31" *) 
  LUT3 #(
    .INIT(8'hFE)) 
    \rgb_out[7]_i_81 
       (.I0(pixel_y[3]),
        .I1(pixel_y[4]),
        .I2(pixel_y[5]),
        .O(\rgb_out[7]_i_81_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair58" *) 
  LUT4 #(
    .INIT(16'h777F)) 
    \rgb_out[7]_i_82 
       (.I0(pixel_y[7]),
        .I1(pixel_y[8]),
        .I2(pixel_y[0]),
        .I3(pixel_y[1]),
        .O(\rgb_out[7]_i_82_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair69" *) 
  LUT4 #(
    .INIT(16'h8000)) 
    \rgb_out[7]_i_83 
       (.I0(pixel_y[3]),
        .I1(pixel_y[2]),
        .I2(pixel_y[4]),
        .I3(pixel_y[5]),
        .O(\rgb_out[7]_i_83_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair14" *) 
  LUT3 #(
    .INIT(8'h80)) 
    \rgb_out[7]_i_84 
       (.I0(pixel_y[6]),
        .I1(pixel_y[7]),
        .I2(pixel_y[8]),
        .O(\rgb_out[7]_i_84_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair118" *) 
  LUT3 #(
    .INIT(8'h7F)) 
    \rgb_out[7]_i_85 
       (.I0(pixel_x[5]),
        .I1(pixel_x[8]),
        .I2(pixel_x[9]),
        .O(\rgb_out[7]_i_85_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair109" *) 
  LUT2 #(
    .INIT(4'hE)) 
    \rgb_out[7]_i_9 
       (.I0(\rgb_out[7]_i_24_n_0 ),
        .I1(\rgb_out[7]_i_14_n_0 ),
        .O(\rgb_out[7]_i_9_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair97" *) 
  LUT3 #(
    .INIT(8'h8A)) 
    \rgb_out[8]_i_2 
       (.I0(\rgb_out[15]_i_5_n_0 ),
        .I1(rgb_in[8]),
        .I2(is_pixel_mur),
        .O(\rgb_out[8]_i_2_n_0 ));
  LUT5 #(
    .INIT(32'hBFBBAAAA)) 
    \rgb_out[8]_i_3 
       (.I0(\rgb_out[1]_i_3_n_0 ),
        .I1(\rgb_out[23]_i_11_n_0 ),
        .I2(\rgb_out[23]_i_12_n_0 ),
        .I3(rgb_in[8]),
        .I4(\rgb_out[23]_i_13_n_0 ),
        .O(\rgb_out[8]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h0000810081818181)) 
    \rgb_out[8]_i_4 
       (.I0(mode_ui[2]),
        .I1(mode_ui[0]),
        .I2(mode_ui[1]),
        .I3(rgb_in[8]),
        .I4(\rgb_out[11]_i_5_n_0 ),
        .I5(\rgb_out[23]_i_9_n_0 ),
        .O(\rgb_out[8]_i_4_n_0 ));
  FDRE \rgb_out_reg[0] 
       (.C(pixel_clk),
        .CE(1'b1),
        .D(TM_U_n_24),
        .Q(rgb_out[0]),
        .R(\rgb_out[23]_i_1_n_0 ));
  FDRE \rgb_out_reg[10] 
       (.C(pixel_clk),
        .CE(1'b1),
        .D(TM_U_n_14),
        .Q(rgb_out[10]),
        .R(\rgb_out[23]_i_1_n_0 ));
  FDRE \rgb_out_reg[11] 
       (.C(pixel_clk),
        .CE(1'b1),
        .D(TM_U_n_13),
        .Q(rgb_out[11]),
        .R(\rgb_out[23]_i_1_n_0 ));
  FDRE \rgb_out_reg[12] 
       (.C(pixel_clk),
        .CE(1'b1),
        .D(TM_U_n_12),
        .Q(rgb_out[12]),
        .R(\rgb_out[23]_i_1_n_0 ));
  FDRE \rgb_out_reg[13] 
       (.C(pixel_clk),
        .CE(1'b1),
        .D(TM_U_n_11),
        .Q(rgb_out[13]),
        .R(\rgb_out[23]_i_1_n_0 ));
  FDRE \rgb_out_reg[14] 
       (.C(pixel_clk),
        .CE(1'b1),
        .D(TM_U_n_10),
        .Q(rgb_out[14]),
        .R(\rgb_out[23]_i_1_n_0 ));
  FDRE \rgb_out_reg[15] 
       (.C(pixel_clk),
        .CE(1'b1),
        .D(TM_U_n_9),
        .Q(rgb_out[15]),
        .R(\rgb_out[23]_i_1_n_0 ));
  FDRE \rgb_out_reg[16] 
       (.C(pixel_clk),
        .CE(1'b1),
        .D(TM_U_n_8),
        .Q(rgb_out[16]),
        .R(\rgb_out[23]_i_1_n_0 ));
  FDRE \rgb_out_reg[17] 
       (.C(pixel_clk),
        .CE(1'b1),
        .D(TM_U_n_7),
        .Q(rgb_out[17]),
        .R(\rgb_out[23]_i_1_n_0 ));
  FDRE \rgb_out_reg[18] 
       (.C(pixel_clk),
        .CE(1'b1),
        .D(TM_U_n_6),
        .Q(rgb_out[18]),
        .R(\rgb_out[23]_i_1_n_0 ));
  FDRE \rgb_out_reg[19] 
       (.C(pixel_clk),
        .CE(1'b1),
        .D(TM_U_n_5),
        .Q(rgb_out[19]),
        .R(\rgb_out[23]_i_1_n_0 ));
  FDRE \rgb_out_reg[1] 
       (.C(pixel_clk),
        .CE(1'b1),
        .D(TM_U_n_23),
        .Q(rgb_out[1]),
        .R(\rgb_out[23]_i_1_n_0 ));
  FDRE \rgb_out_reg[20] 
       (.C(pixel_clk),
        .CE(1'b1),
        .D(TM_U_n_4),
        .Q(rgb_out[20]),
        .R(\rgb_out[23]_i_1_n_0 ));
  FDRE \rgb_out_reg[21] 
       (.C(pixel_clk),
        .CE(1'b1),
        .D(TM_U_n_3),
        .Q(rgb_out[21]),
        .R(\rgb_out[23]_i_1_n_0 ));
  FDRE \rgb_out_reg[22] 
       (.C(pixel_clk),
        .CE(1'b1),
        .D(TM_U_n_2),
        .Q(rgb_out[22]),
        .R(\rgb_out[23]_i_1_n_0 ));
  FDRE \rgb_out_reg[23] 
       (.C(pixel_clk),
        .CE(1'b1),
        .D(TM_U_n_1),
        .Q(rgb_out[23]),
        .R(\rgb_out[23]_i_1_n_0 ));
  CARRY4 \rgb_out_reg[23]_i_1253 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_1253_n_0 ,\rgb_out_reg[23]_i_1253_n_1 ,\rgb_out_reg[23]_i_1253_n_2 ,\rgb_out_reg[23]_i_1253_n_3 }),
        .CYINIT(1'b1),
        .DI({\rgb_out[23]_i_1928_n_0 ,\rgb_out[23]_i_1929_n_0 ,local_x_0[3],\rgb_out[23]_i_1930_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_1253_O_UNCONNECTED [3:0]),
        .S({\rgb_out[23]_i_1931_n_0 ,\rgb_out[23]_i_1932_n_0 ,\rgb_out[23]_i_1933_n_0 ,\rgb_out[23]_i_1934_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_1300 
       (.CI(\rgb_out_reg[23]_i_1998_n_0 ),
        .CO({\rgb_out_reg[0]_0 ,\NLW_rgb_out_reg[23]_i_1300_CO_UNCONNECTED [2],\rgb_out_reg[23]_i_1300_n_2 ,\rgb_out_reg[23]_i_1300_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,pixel_y[11:9]}),
        .O({\NLW_rgb_out_reg[23]_i_1300_O_UNCONNECTED [3],local_y[10:8]}),
        .S({1'b1,\rgb_out[23]_i_1999_n_0 ,\rgb_out[23]_i_2000_n_0 ,\rgb_out[23]_i_2001_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_1308 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_1308_n_0 ,\rgb_out_reg[23]_i_1308_n_1 ,\rgb_out_reg[23]_i_1308_n_2 ,\rgb_out_reg[23]_i_1308_n_3 }),
        .CYINIT(1'b1),
        .DI({\rgb_out[23]_i_2009_n_0 ,\rgb_out[23]_i_2010_n_0 ,local_x[3],\rgb_out[23]_i_2012_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_1308_O_UNCONNECTED [3:0]),
        .S({\rgb_out[23]_i_2013_n_0 ,\rgb_out[23]_i_2014_n_0 ,\rgb_out[23]_i_2015_n_0 ,\rgb_out[23]_i_2016_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_1317 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_1317_n_0 ,\rgb_out_reg[23]_i_1317_n_1 ,\rgb_out_reg[23]_i_1317_n_2 ,\rgb_out_reg[23]_i_1317_n_3 }),
        .CYINIT(1'b1),
        .DI({\rgb_out[23]_i_2024_n_0 ,\rgb_out[23]_i_2025_n_0 ,local_y[2],\rgb_out[23]_i_2026_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_1317_O_UNCONNECTED [3:0]),
        .S({\rgb_out[23]_i_2027_n_0 ,\rgb_out[23]_i_2028_n_0 ,\rgb_out[23]_i_2029_n_0 ,\rgb_out[23]_i_2030_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_1322 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_1322_n_0 ,\rgb_out_reg[23]_i_1322_n_1 ,\rgb_out_reg[23]_i_1322_n_2 ,\rgb_out_reg[23]_i_1322_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,\rgb_out[23]_i_2031_n_0 ,\rgb_out[23]_i_2032_n_0 ,\rgb_out[23]_i_2033_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_1322_O_UNCONNECTED [3:0]),
        .S({\rgb_out[23]_i_2034_n_0 ,\rgb_out[23]_i_2035_n_0 ,\rgb_out[23]_i_2036_n_0 ,\rgb_out[23]_i_2037_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_1331 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_1331_n_0 ,\rgb_out_reg[23]_i_1331_n_1 ,\rgb_out_reg[23]_i_1331_n_2 ,\rgb_out_reg[23]_i_1331_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,\rgb_out[23]_i_2044_n_0 ,\rgb_out[23]_i_2045_n_0 ,\rgb_out[23]_i_2046_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_1331_O_UNCONNECTED [3:0]),
        .S({\rgb_out[23]_i_2047_n_0 ,\rgb_out[23]_i_2048_n_0 ,\rgb_out[23]_i_2049_n_0 ,\rgb_out[23]_i_2050_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_1998 
       (.CI(\rgb_out_reg[23]_i_2003_n_0 ),
        .CO({\rgb_out_reg[23]_i_1998_n_0 ,\rgb_out_reg[23]_i_1998_n_1 ,\rgb_out_reg[23]_i_1998_n_2 ,\rgb_out_reg[23]_i_1998_n_3 }),
        .CYINIT(1'b0),
        .DI(pixel_y[8:5]),
        .O(local_y[7:4]),
        .S({\rgb_out[23]_i_2125_n_0 ,\rgb_out[23]_i_2126_n_0 ,\rgb_out[23]_i_2127_n_0 ,\rgb_out[23]_i_2128_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_2003 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_2003_n_0 ,\rgb_out_reg[23]_i_2003_n_1 ,\rgb_out_reg[23]_i_2003_n_2 ,\rgb_out_reg[23]_i_2003_n_3 }),
        .CYINIT(1'b0),
        .DI({pixel_y[4],1'b0,pixel_y[2],1'b0}),
        .O(local_y[3:0]),
        .S({\rgb_out[23]_i_2129_n_0 ,pixel_y[3],\rgb_out[23]_i_2130_n_0 ,pixel_y[1]}));
  CARRY4 \rgb_out_reg[23]_i_472 
       (.CI(\rgb_out_reg[23]_i_787_n_0 ),
        .CO({\NLW_rgb_out_reg[23]_i_472_CO_UNCONNECTED [3],\TM_D/pixel_on9 ,\rgb_out_reg[23]_i_472_n_2 ,\rgb_out_reg[23]_i_472_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\rgb_out[23]_i_788_n_0 ,\rgb_out[23]_i_789_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_472_O_UNCONNECTED [3:0]),
        .S({1'b0,\pixel_x[3]_3 ,\rgb_out[23]_i_790_n_0 ,\rgb_out[23]_i_791_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_733 
       (.CI(\rgb_out_reg[23]_i_1253_n_0 ),
        .CO({\NLW_rgb_out_reg[23]_i_733_CO_UNCONNECTED [3],\SC_U/pixel_on9 ,\rgb_out_reg[23]_i_733_n_2 ,\rgb_out_reg[23]_i_733_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\rgb_out[23]_i_1254_n_0 ,\rgb_out[23]_i_1255_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_733_O_UNCONNECTED [3:0]),
        .S({1'b0,\pixel_x[1]_8 ,\rgb_out[23]_i_1256_n_0 ,\rgb_out[23]_i_1257_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_752 
       (.CI(\rgb_out_reg[23]_i_1308_n_0 ),
        .CO({\NLW_rgb_out_reg[23]_i_752_CO_UNCONNECTED [3],\SC_D/pixel_on9 ,\rgb_out_reg[23]_i_752_n_2 ,\rgb_out_reg[23]_i_752_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\rgb_out[23]_i_1309_n_0 ,\rgb_out[23]_i_1310_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_752_O_UNCONNECTED [3:0]),
        .S({1'b0,\pixel_x[1]_3 ,\rgb_out[23]_i_1311_n_0 ,\rgb_out[23]_i_1312_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_754 
       (.CI(\rgb_out_reg[23]_i_1317_n_0 ),
        .CO({\NLW_rgb_out_reg[23]_i_754_CO_UNCONNECTED [3],\SC_D/pixel_on83_in ,\rgb_out_reg[23]_i_754_n_2 ,\rgb_out_reg[23]_i_754_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\rgb_out[23]_i_1318_n_0 ,\rgb_out[23]_i_1319_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_754_O_UNCONNECTED [3:0]),
        .S({1'b0,\rgb_out_reg[0]_0 ,\rgb_out[23]_i_1320_n_0 ,\rgb_out[23]_i_1321_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_755 
       (.CI(\rgb_out_reg[23]_i_1322_n_0 ),
        .CO({\NLW_rgb_out_reg[23]_i_755_CO_UNCONNECTED [3],\SC_D/pixel_on7 ,\rgb_out_reg[23]_i_755_n_2 ,\rgb_out_reg[23]_i_755_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,\rgb_out[23]_i_1323_n_0 ,1'b0,1'b0}),
        .O(\NLW_rgb_out_reg[23]_i_755_O_UNCONNECTED [3:0]),
        .S({1'b0,\rgb_out_reg[0]_0 ,\rgb_out[23]_i_1324_n_0 ,\rgb_out[23]_i_1325_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_757 
       (.CI(\rgb_out_reg[23]_i_1331_n_0 ),
        .CO({\NLW_rgb_out_reg[23]_i_757_CO_UNCONNECTED [3],\SC_D/pixel_on66_in ,\rgb_out_reg[23]_i_757_n_2 ,\rgb_out_reg[23]_i_757_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,\rgb_out[23]_i_1332_n_0 ,1'b0,1'b0}),
        .O(\NLW_rgb_out_reg[23]_i_757_O_UNCONNECTED [3:0]),
        .S({1'b0,\rgb_out_reg[0]_0 ,\rgb_out[23]_i_1333_n_0 ,\rgb_out[23]_i_1334_n_0 }));
  CARRY4 \rgb_out_reg[23]_i_787 
       (.CI(1'b0),
        .CO({\rgb_out_reg[23]_i_787_n_0 ,\rgb_out_reg[23]_i_787_n_1 ,\rgb_out_reg[23]_i_787_n_2 ,\rgb_out_reg[23]_i_787_n_3 }),
        .CYINIT(1'b1),
        .DI({\rgb_out[23]_i_1382_n_0 ,\rgb_out[23]_i_1383_n_0 ,local_x_1[1],\rgb_out[23]_i_1384_n_0 }),
        .O(\NLW_rgb_out_reg[23]_i_787_O_UNCONNECTED [3:0]),
        .S({\rgb_out[23]_i_1385_n_0 ,\rgb_out[23]_i_1386_n_0 ,\rgb_out[23]_i_1387_n_0 ,\rgb_out[23]_i_1388_n_0 }));
  FDRE \rgb_out_reg[2] 
       (.C(pixel_clk),
        .CE(1'b1),
        .D(TM_U_n_22),
        .Q(rgb_out[2]),
        .R(\rgb_out[23]_i_1_n_0 ));
  FDRE \rgb_out_reg[3] 
       (.C(pixel_clk),
        .CE(1'b1),
        .D(TM_U_n_21),
        .Q(rgb_out[3]),
        .R(\rgb_out[23]_i_1_n_0 ));
  FDRE \rgb_out_reg[4] 
       (.C(pixel_clk),
        .CE(1'b1),
        .D(TM_U_n_20),
        .Q(rgb_out[4]),
        .R(\rgb_out[23]_i_1_n_0 ));
  FDRE \rgb_out_reg[5] 
       (.C(pixel_clk),
        .CE(1'b1),
        .D(TM_U_n_19),
        .Q(rgb_out[5]),
        .R(\rgb_out[23]_i_1_n_0 ));
  FDRE \rgb_out_reg[6] 
       (.C(pixel_clk),
        .CE(1'b1),
        .D(TM_U_n_18),
        .Q(rgb_out[6]),
        .R(\rgb_out[23]_i_1_n_0 ));
  FDRE \rgb_out_reg[7] 
       (.C(pixel_clk),
        .CE(1'b1),
        .D(TM_U_n_17),
        .Q(rgb_out[7]),
        .R(\rgb_out[23]_i_1_n_0 ));
  FDRE \rgb_out_reg[8] 
       (.C(pixel_clk),
        .CE(1'b1),
        .D(TM_U_n_16),
        .Q(rgb_out[8]),
        .R(\rgb_out[23]_i_1_n_0 ));
  FDRE \rgb_out_reg[9] 
       (.C(pixel_clk),
        .CE(1'b1),
        .D(TM_U_n_15),
        .Q(rgb_out[9]),
        .R(\rgb_out[23]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair128" *) 
  LUT2 #(
    .INIT(4'h2)) 
    vsync_out_i_1
       (.I0(vsync_in),
        .I1(reset),
        .O(vsync_out_i_1_n_0));
  FDRE vsync_out_reg
       (.C(pixel_clk),
        .CE(1'b1),
        .D(vsync_out_i_1_n_0),
        .Q(vsync_out),
        .R(1'b0));
endmodule
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

endmodule
`endif
