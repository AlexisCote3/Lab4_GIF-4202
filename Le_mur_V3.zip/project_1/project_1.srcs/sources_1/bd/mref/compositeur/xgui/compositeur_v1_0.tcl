# Definitional proc to organize widgets for parameters.
proc init_gui { IPINST } {
  ipgui::add_param $IPINST -name "Component_Name"
  #Adding Page
  set Page_0 [ipgui::add_page $IPINST -name "Page 0"]
  ipgui::add_param $IPINST -name "DEBUG_JOUEUR" -parent ${Page_0}
  ipgui::add_param $IPINST -name "SCREEN_HEIGHT" -parent ${Page_0}
  ipgui::add_param $IPINST -name "SCREEN_WIDTH" -parent ${Page_0}
  ipgui::add_param $IPINST -name "WALL_ONE_IS_OPENING" -parent ${Page_0}


}

proc update_PARAM_VALUE.DEBUG_JOUEUR { PARAM_VALUE.DEBUG_JOUEUR } {
	# Procedure called to update DEBUG_JOUEUR when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.DEBUG_JOUEUR { PARAM_VALUE.DEBUG_JOUEUR } {
	# Procedure called to validate DEBUG_JOUEUR
	return true
}

proc update_PARAM_VALUE.SCREEN_HEIGHT { PARAM_VALUE.SCREEN_HEIGHT } {
	# Procedure called to update SCREEN_HEIGHT when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.SCREEN_HEIGHT { PARAM_VALUE.SCREEN_HEIGHT } {
	# Procedure called to validate SCREEN_HEIGHT
	return true
}

proc update_PARAM_VALUE.SCREEN_WIDTH { PARAM_VALUE.SCREEN_WIDTH } {
	# Procedure called to update SCREEN_WIDTH when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.SCREEN_WIDTH { PARAM_VALUE.SCREEN_WIDTH } {
	# Procedure called to validate SCREEN_WIDTH
	return true
}

proc update_PARAM_VALUE.WALL_ONE_IS_OPENING { PARAM_VALUE.WALL_ONE_IS_OPENING } {
	# Procedure called to update WALL_ONE_IS_OPENING when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.WALL_ONE_IS_OPENING { PARAM_VALUE.WALL_ONE_IS_OPENING } {
	# Procedure called to validate WALL_ONE_IS_OPENING
	return true
}


proc update_MODELPARAM_VALUE.SCREEN_WIDTH { MODELPARAM_VALUE.SCREEN_WIDTH PARAM_VALUE.SCREEN_WIDTH } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.SCREEN_WIDTH}] ${MODELPARAM_VALUE.SCREEN_WIDTH}
}

proc update_MODELPARAM_VALUE.SCREEN_HEIGHT { MODELPARAM_VALUE.SCREEN_HEIGHT PARAM_VALUE.SCREEN_HEIGHT } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.SCREEN_HEIGHT}] ${MODELPARAM_VALUE.SCREEN_HEIGHT}
}

proc update_MODELPARAM_VALUE.WALL_ONE_IS_OPENING { MODELPARAM_VALUE.WALL_ONE_IS_OPENING PARAM_VALUE.WALL_ONE_IS_OPENING } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.WALL_ONE_IS_OPENING}] ${MODELPARAM_VALUE.WALL_ONE_IS_OPENING}
}

proc update_MODELPARAM_VALUE.DEBUG_JOUEUR { MODELPARAM_VALUE.DEBUG_JOUEUR PARAM_VALUE.DEBUG_JOUEUR } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.DEBUG_JOUEUR}] ${MODELPARAM_VALUE.DEBUG_JOUEUR}
}

