-- Copyright 1986-2018 Xilinx, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2018.2.1 (win64) Build 2288692 Thu Jul 26 18:24:02 MDT 2018
-- Date        : Mon Nov 23 17:05:48 2026
-- Host        : pcetu-136 running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode synth_stub
--               c:/Users/keham9/Downloads/ZYBO_HDMI_MGA_2018_2/ZYBO_HDMI_MGA_2018_2/project_1/project_1.srcs/sources_1/bd/HDMI_bd/ip/HDMI_bd_FSM_0_3/HDMI_bd_FSM_0_3_stub.vhdl
-- Design      : HDMI_bd_FSM_0_3
-- Purpose     : Stub declaration of top-level module interface
-- Device      : xc7z020clg400-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity HDMI_bd_FSM_0_3 is
  Port ( 
    clk : in STD_LOGIC;
    reset : in STD_LOGIC;
    run : in STD_LOGIC;
    pause : in STD_LOGIC;
    quit : in STD_LOGIC;
    difficulty : in STD_LOGIC_VECTOR ( 1 downto 0 );
    q_pass : in STD_LOGIC;
    new_round : out STD_LOGIC;
    diff_out : out STD_LOGIC_VECTOR ( 1 downto 0 );
    mode_ui : out STD_LOGIC_VECTOR ( 2 downto 0 );
    sec : out STD_LOGIC_VECTOR ( 3 downto 0 );
    decompte_ui : out STD_LOGIC_VECTOR ( 3 downto 0 );
    flash_on : out STD_LOGIC;
    score_courant : out STD_LOGIC_VECTOR ( 3 downto 0 );
    score_dernier : out STD_LOGIC_VECTOR ( 3 downto 0 );
    record_perso : out STD_LOGIC_VECTOR ( 3 downto 0 )
  );

end HDMI_bd_FSM_0_3;

architecture stub of HDMI_bd_FSM_0_3 is
attribute syn_black_box : boolean;
attribute black_box_pad_pin : string;
attribute syn_black_box of stub : architecture is true;
attribute black_box_pad_pin of stub : architecture is "clk,reset,run,pause,quit,difficulty[1:0],q_pass,new_round,diff_out[1:0],mode_ui[2:0],sec[3:0],decompte_ui[3:0],flash_on,score_courant[3:0],score_dernier[3:0],record_perso[3:0]";
attribute x_core_info : string;
attribute x_core_info of stub : architecture is "FSM,Vivado 2018.2.1";
begin
end;
