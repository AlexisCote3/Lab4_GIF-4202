// Copyright 1986-2018 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2018.2.1 (win64) Build 2288692 Thu Jul 26 18:24:02 MDT 2018
// Date        : Mon Nov 23 17:05:48 2026
// Host        : pcetu-136 running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode synth_stub
//               c:/Users/keham9/Downloads/ZYBO_HDMI_MGA_2018_2/ZYBO_HDMI_MGA_2018_2/project_1/project_1.srcs/sources_1/bd/HDMI_bd/ip/HDMI_bd_FSM_0_3/HDMI_bd_FSM_0_3_stub.v
// Design      : HDMI_bd_FSM_0_3
// Purpose     : Stub declaration of top-level module interface
// Device      : xc7z020clg400-1
// --------------------------------------------------------------------------------

// This empty module with port declaration file causes synthesis tools to infer a black box for IP.
// The synthesis directives are for Synopsys Synplify support to prevent IO buffer insertion.
// Please paste the declaration into a Verilog source file or add the file as an additional source.
(* x_core_info = "FSM,Vivado 2018.2.1" *)
module HDMI_bd_FSM_0_3(clk, reset, run, pause, quit, difficulty, q_pass, 
  new_round, diff_out, mode_ui, sec, decompte_ui, flash_on, score_courant, score_dernier, 
  record_perso)
/* synthesis syn_black_box black_box_pad_pin="clk,reset,run,pause,quit,difficulty[1:0],q_pass,new_round,diff_out[1:0],mode_ui[2:0],sec[3:0],decompte_ui[3:0],flash_on,score_courant[3:0],score_dernier[3:0],record_perso[3:0]" */;
  input clk;
  input reset;
  input run;
  input pause;
  input quit;
  input [1:0]difficulty;
  input q_pass;
  output new_round;
  output [1:0]diff_out;
  output [2:0]mode_ui;
  output [3:0]sec;
  output [3:0]decompte_ui;
  output flash_on;
  output [3:0]score_courant;
  output [3:0]score_dernier;
  output [3:0]record_perso;
endmodule
