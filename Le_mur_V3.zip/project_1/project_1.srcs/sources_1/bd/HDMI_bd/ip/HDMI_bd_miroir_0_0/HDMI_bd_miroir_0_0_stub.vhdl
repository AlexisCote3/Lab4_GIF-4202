-- Copyright 1986-2018 Xilinx, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2018.2.1 (win64) Build 2288692 Thu Jul 26 18:24:02 MDT 2018
-- Date        : Mon Nov 23 18:44:58 2026
-- Host        : pcetu-136 running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode synth_stub
--               c:/Users/keham9/Downloads/ZYBO_HDMI_MGA_2018_2/ZYBO_HDMI_MGA_2018_2/project_1/project_1.srcs/sources_1/bd/HDMI_bd/ip/HDMI_bd_miroir_0_0/HDMI_bd_miroir_0_0_stub.vhdl
-- Design      : HDMI_bd_miroir_0_0
-- Purpose     : Stub declaration of top-level module interface
-- Device      : xc7z020clg400-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity HDMI_bd_miroir_0_0 is
  Port ( 
    PixelClk : in STD_LOGIC;
    VSync_in : in STD_LOGIC;
    VDE_in : in STD_LOGIC;
    HSync_in : in STD_LOGIC;
    VSync_out : out STD_LOGIC;
    VDE_out : out STD_LOGIC;
    HSync_out : out STD_LOGIC;
    address : out STD_LOGIC_VECTOR ( 10 downto 0 );
    wea : out STD_LOGIC_VECTOR ( 0 to 0 )
  );

end HDMI_bd_miroir_0_0;

architecture stub of HDMI_bd_miroir_0_0 is
attribute syn_black_box : boolean;
attribute black_box_pad_pin : string;
attribute syn_black_box of stub : architecture is true;
attribute black_box_pad_pin of stub : architecture is "PixelClk,VSync_in,VDE_in,HSync_in,VSync_out,VDE_out,HSync_out,address[10:0],wea[0:0]";
attribute x_core_info : string;
attribute x_core_info of stub : architecture is "miroir,Vivado 2018.2.1";
begin
end;
