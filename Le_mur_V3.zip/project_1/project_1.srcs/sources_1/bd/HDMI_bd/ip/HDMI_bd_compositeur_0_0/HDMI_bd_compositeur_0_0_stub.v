// Copyright 1986-2018 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2018.2.1 (win64) Build 2288692 Thu Jul 26 18:24:02 MDT 2018
// Date        : Mon Nov 23 17:53:06 2026
// Host        : pcetu-136 running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode synth_stub
//               c:/Users/keham9/Downloads/ZYBO_HDMI_MGA_2018_2/ZYBO_HDMI_MGA_2018_2/project_1/project_1.srcs/sources_1/bd/HDMI_bd/ip/HDMI_bd_compositeur_0_0/HDMI_bd_compositeur_0_0_stub.v
// Design      : HDMI_bd_compositeur_0_0
// Purpose     : Stub declaration of top-level module interface
// Device      : xc7z020clg400-1
// --------------------------------------------------------------------------------

// This empty module with port declaration file causes synthesis tools to infer a black box for IP.
// The synthesis directives are for Synopsys Synplify support to prevent IO buffer insertion.
// Please paste the declaration into a Verilog source file or add the file as an additional source.
(* x_core_info = "compositeur,Vivado 2018.2.1" *)
module HDMI_bd_compositeur_0_0(pixel_clk, reset, rgb_in, de_in, hsync_in, 
  vsync_in, pixel_x, pixel_y, is_pixel_mur, is_pixel_joueur, mode_ui, decompte_ui, flash_on, 
  score_courant, temps_restant, score_dernier, record_personnel, rgb_out, de_out, hsync_out, 
  vsync_out)
/* synthesis syn_black_box black_box_pad_pin="pixel_clk,reset,rgb_in[23:0],de_in,hsync_in,vsync_in,pixel_x[11:0],pixel_y[11:0],is_pixel_mur,is_pixel_joueur,mode_ui[2:0],decompte_ui[3:0],flash_on,score_courant[3:0],temps_restant[3:0],score_dernier[3:0],record_personnel[3:0],rgb_out[23:0],de_out,hsync_out,vsync_out" */;
  input pixel_clk;
  input reset;
  input [23:0]rgb_in;
  input de_in;
  input hsync_in;
  input vsync_in;
  input [11:0]pixel_x;
  input [11:0]pixel_y;
  input is_pixel_mur;
  input is_pixel_joueur;
  input [2:0]mode_ui;
  input [3:0]decompte_ui;
  input flash_on;
  input [3:0]score_courant;
  input [3:0]temps_restant;
  input [3:0]score_dernier;
  input [3:0]record_personnel;
  output [23:0]rgb_out;
  output de_out;
  output hsync_out;
  output vsync_out;
endmodule
