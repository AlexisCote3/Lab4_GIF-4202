-- (c) Copyright 1995-2026 Xilinx, Inc. All rights reserved.
-- 
-- This file contains confidential and proprietary information
-- of Xilinx, Inc. and is protected under U.S. and
-- international copyright and other intellectual property
-- laws.
-- 
-- DISCLAIMER
-- This disclaimer is not a license and does not grant any
-- rights to the materials distributed herewith. Except as
-- otherwise provided in a valid license issued to you by
-- Xilinx, and to the maximum extent permitted by applicable
-- law: (1) THESE MATERIALS ARE MADE AVAILABLE "AS IS" AND
-- WITH ALL FAULTS, AND XILINX HEREBY DISCLAIMS ALL WARRANTIES
-- AND CONDITIONS, EXPRESS, IMPLIED, OR STATUTORY, INCLUDING
-- BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, NON-
-- INFRINGEMENT, OR FITNESS FOR ANY PARTICULAR PURPOSE; and
-- (2) Xilinx shall not be liable (whether in contract or tort,
-- including negligence, or under any other theory of
-- liability) for any loss or damage of any kind or nature
-- related to, arising under or in connection with these
-- materials, including for any direct, or any indirect,
-- special, incidental, or consequential loss or damage
-- (including loss of data, profits, goodwill, or any type of
-- loss or damage suffered as a result of any action brought
-- by a third party) even if such damage or loss was
-- reasonably foreseeable or Xilinx had been advised of the
-- possibility of the same.
-- 
-- CRITICAL APPLICATIONS
-- Xilinx products are not designed or intended to be fail-
-- safe, or for use in any application requiring fail-safe
-- performance, such as life-support or safety devices or
-- systems, Class III medical devices, nuclear facilities,
-- applications related to the deployment of airbags, or any
-- other applications that could lead to death, personal
-- injury, or severe property or environmental damage
-- (individually and collectively, "Critical
-- Applications"). Customer assumes the sole risk and
-- liability of any use of Xilinx products in Critical
-- Applications, subject only to applicable laws and
-- regulations governing limitations on product liability.
-- 
-- THIS COPYRIGHT NOTICE AND DISCLAIMER MUST BE RETAINED AS
-- PART OF THIS FILE AT ALL TIMES.
-- 
-- DO NOT MODIFY THIS FILE.

-- IP VLNV: xilinx.com:module_ref:compositeur:1.0
-- IP Revision: 1

LIBRARY ieee;
USE ieee.std_logic_1164.ALL;
USE ieee.numeric_std.ALL;

ENTITY HDMI_bd_compositeur_0_0 IS
  PORT (
    pixel_clk : IN STD_LOGIC;
    reset : IN STD_LOGIC;
    rgb_in : IN STD_LOGIC_VECTOR(23 DOWNTO 0);
    de_in : IN STD_LOGIC;
    hsync_in : IN STD_LOGIC;
    vsync_in : IN STD_LOGIC;
    pixel_x : IN STD_LOGIC_VECTOR(11 DOWNTO 0);
    pixel_y : IN STD_LOGIC_VECTOR(11 DOWNTO 0);
    is_pixel_mur : IN STD_LOGIC;
    is_pixel_joueur : IN STD_LOGIC;
    mode_ui : IN STD_LOGIC_VECTOR(2 DOWNTO 0);
    decompte_ui : IN STD_LOGIC_VECTOR(3 DOWNTO 0);
    flash_on : IN STD_LOGIC;
    score_courant : IN STD_LOGIC_VECTOR(3 DOWNTO 0);
    temps_restant : IN STD_LOGIC_VECTOR(3 DOWNTO 0);
    score_dernier : IN STD_LOGIC_VECTOR(3 DOWNTO 0);
    record_personnel : IN STD_LOGIC_VECTOR(3 DOWNTO 0);
    rgb_out : OUT STD_LOGIC_VECTOR(23 DOWNTO 0);
    de_out : OUT STD_LOGIC;
    hsync_out : OUT STD_LOGIC;
    vsync_out : OUT STD_LOGIC
  );
END HDMI_bd_compositeur_0_0;

ARCHITECTURE HDMI_bd_compositeur_0_0_arch OF HDMI_bd_compositeur_0_0 IS
  ATTRIBUTE DowngradeIPIdentifiedWarnings : STRING;
  ATTRIBUTE DowngradeIPIdentifiedWarnings OF HDMI_bd_compositeur_0_0_arch: ARCHITECTURE IS "yes";
  COMPONENT compositeur IS
    GENERIC (
      SCREEN_WIDTH : INTEGER;
      SCREEN_HEIGHT : INTEGER;
      WALL_ONE_IS_OPENING : BOOLEAN;
      DEBUG_JOUEUR : BOOLEAN
    );
    PORT (
      pixel_clk : IN STD_LOGIC;
      reset : IN STD_LOGIC;
      rgb_in : IN STD_LOGIC_VECTOR(23 DOWNTO 0);
      de_in : IN STD_LOGIC;
      hsync_in : IN STD_LOGIC;
      vsync_in : IN STD_LOGIC;
      pixel_x : IN STD_LOGIC_VECTOR(11 DOWNTO 0);
      pixel_y : IN STD_LOGIC_VECTOR(11 DOWNTO 0);
      is_pixel_mur : IN STD_LOGIC;
      is_pixel_joueur : IN STD_LOGIC;
      mode_ui : IN STD_LOGIC_VECTOR(2 DOWNTO 0);
      decompte_ui : IN STD_LOGIC_VECTOR(3 DOWNTO 0);
      flash_on : IN STD_LOGIC;
      score_courant : IN STD_LOGIC_VECTOR(3 DOWNTO 0);
      temps_restant : IN STD_LOGIC_VECTOR(3 DOWNTO 0);
      score_dernier : IN STD_LOGIC_VECTOR(3 DOWNTO 0);
      record_personnel : IN STD_LOGIC_VECTOR(3 DOWNTO 0);
      rgb_out : OUT STD_LOGIC_VECTOR(23 DOWNTO 0);
      de_out : OUT STD_LOGIC;
      hsync_out : OUT STD_LOGIC;
      vsync_out : OUT STD_LOGIC
    );
  END COMPONENT compositeur;
  ATTRIBUTE X_CORE_INFO : STRING;
  ATTRIBUTE X_CORE_INFO OF HDMI_bd_compositeur_0_0_arch: ARCHITECTURE IS "compositeur,Vivado 2018.2.1";
  ATTRIBUTE CHECK_LICENSE_TYPE : STRING;
  ATTRIBUTE CHECK_LICENSE_TYPE OF HDMI_bd_compositeur_0_0_arch : ARCHITECTURE IS "HDMI_bd_compositeur_0_0,compositeur,{}";
  ATTRIBUTE CORE_GENERATION_INFO : STRING;
  ATTRIBUTE CORE_GENERATION_INFO OF HDMI_bd_compositeur_0_0_arch: ARCHITECTURE IS "HDMI_bd_compositeur_0_0,compositeur,{x_ipProduct=Vivado 2018.2.1,x_ipVendor=xilinx.com,x_ipLibrary=module_ref,x_ipName=compositeur,x_ipVersion=1.0,x_ipCoreRevision=1,x_ipLanguage=VHDL,x_ipSimLanguage=MIXED,SCREEN_WIDTH=1600,SCREEN_HEIGHT=900,WALL_ONE_IS_OPENING=true,DEBUG_JOUEUR=false}";
  ATTRIBUTE IP_DEFINITION_SOURCE : STRING;
  ATTRIBUTE IP_DEFINITION_SOURCE OF HDMI_bd_compositeur_0_0_arch: ARCHITECTURE IS "module_ref";
  ATTRIBUTE X_INTERFACE_INFO : STRING;
  ATTRIBUTE X_INTERFACE_PARAMETER : STRING;
  ATTRIBUTE X_INTERFACE_PARAMETER OF reset: SIGNAL IS "XIL_INTERFACENAME reset, POLARITY ACTIVE_HIGH";
  ATTRIBUTE X_INTERFACE_INFO OF reset: SIGNAL IS "xilinx.com:signal:reset:1.0 reset RST";
  ATTRIBUTE X_INTERFACE_PARAMETER OF pixel_clk: SIGNAL IS "XIL_INTERFACENAME pixel_clk, ASSOCIATED_RESET reset, FREQ_HZ 100000000, PHASE 0.000, CLK_DOMAIN HDMI_bd_dvi2rgb_0_0_PixelClk";
  ATTRIBUTE X_INTERFACE_INFO OF pixel_clk: SIGNAL IS "xilinx.com:signal:clock:1.0 pixel_clk CLK";
BEGIN
  U0 : compositeur
    GENERIC MAP (
      SCREEN_WIDTH => 1600,
      SCREEN_HEIGHT => 900,
      WALL_ONE_IS_OPENING => true,
      DEBUG_JOUEUR => false
    )
    PORT MAP (
      pixel_clk => pixel_clk,
      reset => reset,
      rgb_in => rgb_in,
      de_in => de_in,
      hsync_in => hsync_in,
      vsync_in => vsync_in,
      pixel_x => pixel_x,
      pixel_y => pixel_y,
      is_pixel_mur => is_pixel_mur,
      is_pixel_joueur => is_pixel_joueur,
      mode_ui => mode_ui,
      decompte_ui => decompte_ui,
      flash_on => flash_on,
      score_courant => score_courant,
      temps_restant => temps_restant,
      score_dernier => score_dernier,
      record_personnel => record_personnel,
      rgb_out => rgb_out,
      de_out => de_out,
      hsync_out => hsync_out,
      vsync_out => vsync_out
    );
END HDMI_bd_compositeur_0_0_arch;
