-- Copyright 1986-2018 Xilinx, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2018.2.1 (win64) Build 2288692 Thu Jul 26 18:24:02 MDT 2018
-- Date        : Mon Nov 23 17:53:06 2026
-- Host        : pcetu-136 running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode funcsim
--               c:/Users/keham9/Downloads/ZYBO_HDMI_MGA_2018_2/ZYBO_HDMI_MGA_2018_2/project_1/project_1.srcs/sources_1/bd/HDMI_bd/ip/HDMI_bd_compositeur_0_0/HDMI_bd_compositeur_0_0_sim_netlist.vhdl
-- Design      : HDMI_bd_compositeur_0_0
-- Purpose     : This VHDL netlist is a functional simulation representation of the design and should not be modified or
--               synthesized. This netlist cannot be used for SDF annotated simulation.
-- Device      : xc7z020clg400-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity \HDMI_bd_compositeur_0_0_chiffre_7seg__parameterized2\ is
  port (
    CO : out STD_LOGIC_VECTOR ( 0 to 0 );
    D : out STD_LOGIC_VECTOR ( 23 downto 0 );
    \rgb_out_reg[20]\ : out STD_LOGIC_VECTOR ( 0 to 0 );
    \rgb_out_reg[20]_0\ : out STD_LOGIC_VECTOR ( 0 to 0 );
    \rgb_out_reg[20]_1\ : out STD_LOGIC_VECTOR ( 0 to 0 );
    \rgb_out_reg[20]_2\ : out STD_LOGIC_VECTOR ( 0 to 0 );
    \rgb_out_reg[20]_3\ : out STD_LOGIC_VECTOR ( 0 to 0 );
    \rgb_out_reg[20]_4\ : out STD_LOGIC_VECTOR ( 0 to 0 );
    \rgb_out_reg[20]_5\ : out STD_LOGIC_VECTOR ( 0 to 0 );
    \rgb_out_reg[20]_6\ : out STD_LOGIC_VECTOR ( 0 to 0 );
    \rgb_out_reg[20]_7\ : out STD_LOGIC_VECTOR ( 0 to 0 );
    pixel_x : in STD_LOGIC_VECTOR ( 11 downto 0 );
    pixel_y : in STD_LOGIC_VECTOR ( 11 downto 0 );
    pixel_x_5_sp_1 : in STD_LOGIC;
    rgb_in : in STD_LOGIC_VECTOR ( 11 downto 0 );
    pixel_x_2_sp_1 : in STD_LOGIC;
    \pixel_x[2]_0\ : in STD_LOGIC;
    pixel_x_1_sp_1 : in STD_LOGIC;
    is_pixel_mur : in STD_LOGIC;
    pixel_y_4_sp_1 : in STD_LOGIC;
    \pixel_y[4]_0\ : in STD_LOGIC;
    pixel_y_9_sp_1 : in STD_LOGIC;
    \pixel_x[2]_1\ : in STD_LOGIC;
    mode_ui_1_sp_1 : in STD_LOGIC;
    \pixel_y[4]_1\ : in STD_LOGIC;
    \pixel_x[2]_2\ : in STD_LOGIC;
    mode_ui_2_sp_1 : in STD_LOGIC;
    pixel_y_6_sp_1 : in STD_LOGIC;
    pixel_x_3_sp_1 : in STD_LOGIC;
    \pixel_x[2]_3\ : in STD_LOGIC;
    pixel_y_7_sp_1 : in STD_LOGIC;
    \pixel_y[4]_2\ : in STD_LOGIC;
    \pixel_y[4]_3\ : in STD_LOGIC;
    mode_ui_0_sp_1 : in STD_LOGIC;
    \pixel_y[9]_0\ : in STD_LOGIC;
    \pixel_x[2]_4\ : in STD_LOGIC;
    \pixel_x[3]_0\ : in STD_LOGIC;
    \pixel_y[4]_4\ : in STD_LOGIC;
    \pixel_x[2]_5\ : in STD_LOGIC;
    \pixel_x[2]_6\ : in STD_LOGIC;
    \pixel_x[3]_1\ : in STD_LOGIC;
    \pixel_x[2]_7\ : in STD_LOGIC;
    \pixel_y[4]_5\ : in STD_LOGIC;
    \pixel_x[2]_8\ : in STD_LOGIC;
    \pixel_x[3]_2\ : in STD_LOGIC;
    \pixel_y[4]_6\ : in STD_LOGIC;
    \pixel_x[2]_9\ : in STD_LOGIC;
    \pixel_x[3]_3\ : in STD_LOGIC;
    \pixel_y[4]_7\ : in STD_LOGIC;
    \pixel_x[2]_10\ : in STD_LOGIC;
    \pixel_x[3]_4\ : in STD_LOGIC;
    \pixel_y[4]_8\ : in STD_LOGIC;
    \pixel_x[2]_11\ : in STD_LOGIC;
    \pixel_x[3]_5\ : in STD_LOGIC;
    \pixel_y[4]_9\ : in STD_LOGIC;
    \pixel_x[2]_12\ : in STD_LOGIC;
    \pixel_x[3]_6\ : in STD_LOGIC;
    \pixel_y[4]_10\ : in STD_LOGIC;
    \pixel_x[2]_13\ : in STD_LOGIC;
    \pixel_x[3]_7\ : in STD_LOGIC;
    \pixel_y[4]_11\ : in STD_LOGIC;
    \pixel_x[2]_14\ : in STD_LOGIC;
    \pixel_x[3]_8\ : in STD_LOGIC;
    \pixel_y[4]_12\ : in STD_LOGIC;
    \pixel_x[2]_15\ : in STD_LOGIC;
    \pixel_x[3]_9\ : in STD_LOGIC;
    \pixel_y[4]_13\ : in STD_LOGIC;
    \pixel_x[2]_16\ : in STD_LOGIC;
    \pixel_x[3]_10\ : in STD_LOGIC;
    \pixel_y[4]_14\ : in STD_LOGIC;
    \pixel_x[2]_17\ : in STD_LOGIC;
    \pixel_x[3]_11\ : in STD_LOGIC;
    \pixel_x[2]_18\ : in STD_LOGIC;
    mode_ui : in STD_LOGIC_VECTOR ( 2 downto 0 );
    \pixel_x[1]_0\ : in STD_LOGIC;
    \mode_ui[0]_0\ : in STD_LOGIC;
    \pixel_x[2]_19\ : in STD_LOGIC;
    \pixel_x[2]_20\ : in STD_LOGIC;
    \pixel_y[9]_1\ : in STD_LOGIC;
    \pixel_x[2]_21\ : in STD_LOGIC;
    \pixel_x[2]_22\ : in STD_LOGIC;
    \pixel_x[2]_23\ : in STD_LOGIC;
    \pixel_x[2]_24\ : in STD_LOGIC;
    \pixel_x[2]_25\ : in STD_LOGIC;
    \pixel_x[3]_12\ : in STD_LOGIC;
    \mode_ui[2]_0\ : in STD_LOGIC;
    \mode_ui[2]_1\ : in STD_LOGIC;
    num_tm_d : in STD_LOGIC;
    \pixel_x[5]_0\ : in STD_LOGIC;
    pixel_x_8_sp_1 : in STD_LOGIC;
    decompte_ui_1_sp_1 : in STD_LOGIC;
    pixel_y_2_sp_1 : in STD_LOGIC;
    \temps_restant[2]\ : in STD_LOGIC;
    decompte_ui : in STD_LOGIC_VECTOR ( 3 downto 0 );
    \pixel_y[2]_0\ : in STD_LOGIC;
    pixel_y_5_sp_1 : in STD_LOGIC;
    \pixel_y[2]_1\ : in STD_LOGIC;
    \pixel_x[5]_1\ : in STD_LOGIC;
    \pixel_x[5]_2\ : in STD_LOGIC;
    \pixel_y[5]_0\ : in STD_LOGIC;
    \pixel_y[2]_2\ : in STD_LOGIC;
    \pixel_y[5]_1\ : in STD_LOGIC;
    \pixel_y[2]_3\ : in STD_LOGIC;
    \pixel_y[2]_4\ : in STD_LOGIC;
    DI : in STD_LOGIC_VECTOR ( 0 to 0 );
    S : in STD_LOGIC_VECTOR ( 1 downto 0 );
    \pixel_x[1]_1\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \pixel_x[3]_13\ : in STD_LOGIC_VECTOR ( 1 downto 0 );
    \pixel_x[2]_26\ : in STD_LOGIC_VECTOR ( 1 downto 0 );
    \pixel_x[3]_14\ : in STD_LOGIC_VECTOR ( 1 downto 0 );
    \pixel_x[5]_3\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    pixel_x_4_sp_1 : in STD_LOGIC
  );
  attribute ORIG_REF_NAME : string;
  attribute ORIG_REF_NAME of \HDMI_bd_compositeur_0_0_chiffre_7seg__parameterized2\ : entity is "chiffre_7seg";
end \HDMI_bd_compositeur_0_0_chiffre_7seg__parameterized2\;

architecture STRUCTURE of \HDMI_bd_compositeur_0_0_chiffre_7seg__parameterized2\ is
  signal \^co\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal decompte_ui_1_sn_1 : STD_LOGIC;
  signal local_x_2 : STD_LOGIC_VECTOR ( 12 downto 4 );
  signal \local_x_carry__0_i_1_n_0\ : STD_LOGIC;
  signal \local_x_carry__0_i_2_n_0\ : STD_LOGIC;
  signal \local_x_carry__0_n_0\ : STD_LOGIC;
  signal \local_x_carry__0_n_1\ : STD_LOGIC;
  signal \local_x_carry__0_n_2\ : STD_LOGIC;
  signal \local_x_carry__0_n_3\ : STD_LOGIC;
  signal local_x_carry_i_1_n_0 : STD_LOGIC;
  signal local_x_carry_i_2_n_0 : STD_LOGIC;
  signal local_x_carry_n_0 : STD_LOGIC;
  signal local_x_carry_n_1 : STD_LOGIC;
  signal local_x_carry_n_2 : STD_LOGIC;
  signal local_x_carry_n_3 : STD_LOGIC;
  signal local_y_3 : STD_LOGIC_VECTOR ( 12 downto 1 );
  signal \local_y_carry__0_i_1_n_0\ : STD_LOGIC;
  signal \local_y_carry__0_i_2_n_0\ : STD_LOGIC;
  signal \local_y_carry__0_i_3_n_0\ : STD_LOGIC;
  signal \local_y_carry__0_i_4_n_0\ : STD_LOGIC;
  signal \local_y_carry__0_n_0\ : STD_LOGIC;
  signal \local_y_carry__0_n_1\ : STD_LOGIC;
  signal \local_y_carry__0_n_2\ : STD_LOGIC;
  signal \local_y_carry__0_n_3\ : STD_LOGIC;
  signal \local_y_carry__1_i_1_n_0\ : STD_LOGIC;
  signal \local_y_carry__1_i_2_n_0\ : STD_LOGIC;
  signal \local_y_carry__1_i_3_n_0\ : STD_LOGIC;
  signal \local_y_carry__1_n_0\ : STD_LOGIC;
  signal \local_y_carry__1_n_2\ : STD_LOGIC;
  signal \local_y_carry__1_n_3\ : STD_LOGIC;
  signal local_y_carry_i_1_n_0 : STD_LOGIC;
  signal local_y_carry_i_2_n_0 : STD_LOGIC;
  signal local_y_carry_n_0 : STD_LOGIC;
  signal local_y_carry_n_1 : STD_LOGIC;
  signal local_y_carry_n_2 : STD_LOGIC;
  signal local_y_carry_n_3 : STD_LOGIC;
  signal mode_ui_0_sn_1 : STD_LOGIC;
  signal mode_ui_1_sn_1 : STD_LOGIC;
  signal mode_ui_2_sn_1 : STD_LOGIC;
  signal pixel_on2 : STD_LOGIC;
  signal pixel_on3 : STD_LOGIC;
  signal \pixel_on3_carry__0_i_1_n_0\ : STD_LOGIC;
  signal \pixel_on3_carry__0_i_2_n_0\ : STD_LOGIC;
  signal \pixel_on3_carry__0_i_3_n_0\ : STD_LOGIC;
  signal \pixel_on3_carry__0_i_4_n_0\ : STD_LOGIC;
  signal \pixel_on3_carry__0_n_2\ : STD_LOGIC;
  signal \pixel_on3_carry__0_n_3\ : STD_LOGIC;
  signal pixel_on3_carry_i_1_n_0 : STD_LOGIC;
  signal pixel_on3_carry_i_2_n_0 : STD_LOGIC;
  signal pixel_on3_carry_i_3_n_0 : STD_LOGIC;
  signal pixel_on3_carry_i_4_n_0 : STD_LOGIC;
  signal pixel_on3_carry_i_5_n_0 : STD_LOGIC;
  signal pixel_on3_carry_i_6_n_0 : STD_LOGIC;
  signal pixel_on3_carry_i_7_n_0 : STD_LOGIC;
  signal pixel_on3_carry_i_8_n_0 : STD_LOGIC;
  signal pixel_on3_carry_n_0 : STD_LOGIC;
  signal pixel_on3_carry_n_1 : STD_LOGIC;
  signal pixel_on3_carry_n_2 : STD_LOGIC;
  signal pixel_on3_carry_n_3 : STD_LOGIC;
  signal pixel_on4 : STD_LOGIC;
  signal pixel_on40_in : STD_LOGIC;
  signal \pixel_on4__6_carry__0_i_2_n_0\ : STD_LOGIC;
  signal \pixel_on4__6_carry__0_n_3\ : STD_LOGIC;
  signal \pixel_on4__6_carry_i_1_n_0\ : STD_LOGIC;
  signal \pixel_on4__6_carry_i_2_n_0\ : STD_LOGIC;
  signal \pixel_on4__6_carry_i_3_n_0\ : STD_LOGIC;
  signal \pixel_on4__6_carry_i_4_n_0\ : STD_LOGIC;
  signal \pixel_on4__6_carry_i_5_n_0\ : STD_LOGIC;
  signal \pixel_on4__6_carry_i_6_n_0\ : STD_LOGIC;
  signal \pixel_on4__6_carry_n_0\ : STD_LOGIC;
  signal \pixel_on4__6_carry_n_1\ : STD_LOGIC;
  signal \pixel_on4__6_carry_n_2\ : STD_LOGIC;
  signal \pixel_on4__6_carry_n_3\ : STD_LOGIC;
  signal \pixel_on4_carry__0_i_1_n_0\ : STD_LOGIC;
  signal \pixel_on4_carry__0_i_2_n_0\ : STD_LOGIC;
  signal \pixel_on4_carry__0_i_3_n_0\ : STD_LOGIC;
  signal \pixel_on4_carry__0_i_4_n_0\ : STD_LOGIC;
  signal \pixel_on4_carry__0_n_2\ : STD_LOGIC;
  signal \pixel_on4_carry__0_n_3\ : STD_LOGIC;
  signal pixel_on4_carry_i_1_n_0 : STD_LOGIC;
  signal pixel_on4_carry_i_2_n_0 : STD_LOGIC;
  signal pixel_on4_carry_i_3_n_0 : STD_LOGIC;
  signal pixel_on4_carry_i_4_n_0 : STD_LOGIC;
  signal pixel_on4_carry_i_5_n_0 : STD_LOGIC;
  signal pixel_on4_carry_i_6_n_0 : STD_LOGIC;
  signal pixel_on4_carry_i_7_n_0 : STD_LOGIC;
  signal pixel_on4_carry_i_8_n_0 : STD_LOGIC;
  signal pixel_on4_carry_n_0 : STD_LOGIC;
  signal pixel_on4_carry_n_1 : STD_LOGIC;
  signal pixel_on4_carry_n_2 : STD_LOGIC;
  signal pixel_on4_carry_n_3 : STD_LOGIC;
  signal pixel_on8 : STD_LOGIC;
  signal \pixel_on8_carry__0_i_1_n_0\ : STD_LOGIC;
  signal \pixel_on8_carry__0_i_3_n_0\ : STD_LOGIC;
  signal \pixel_on8_carry__0_i_4_n_0\ : STD_LOGIC;
  signal \pixel_on8_carry__0_n_2\ : STD_LOGIC;
  signal \pixel_on8_carry__0_n_3\ : STD_LOGIC;
  signal pixel_on8_carry_i_1_n_0 : STD_LOGIC;
  signal pixel_on8_carry_i_2_n_0 : STD_LOGIC;
  signal pixel_on8_carry_i_3_n_0 : STD_LOGIC;
  signal pixel_on8_carry_i_4_n_0 : STD_LOGIC;
  signal pixel_on8_carry_i_5_n_0 : STD_LOGIC;
  signal pixel_on8_carry_i_6_n_0 : STD_LOGIC;
  signal pixel_on8_carry_i_7_n_0 : STD_LOGIC;
  signal pixel_on8_carry_n_0 : STD_LOGIC;
  signal pixel_on8_carry_n_1 : STD_LOGIC;
  signal pixel_on8_carry_n_2 : STD_LOGIC;
  signal pixel_on8_carry_n_3 : STD_LOGIC;
  signal pixel_on9 : STD_LOGIC;
  signal pixel_on99_in : STD_LOGIC;
  signal pixel_x_1_sn_1 : STD_LOGIC;
  signal pixel_x_2_sn_1 : STD_LOGIC;
  signal pixel_x_3_sn_1 : STD_LOGIC;
  signal pixel_x_4_sn_1 : STD_LOGIC;
  signal pixel_x_5_sn_1 : STD_LOGIC;
  signal pixel_x_8_sn_1 : STD_LOGIC;
  signal pixel_y_2_sn_1 : STD_LOGIC;
  signal pixel_y_4_sn_1 : STD_LOGIC;
  signal pixel_y_5_sn_1 : STD_LOGIC;
  signal pixel_y_6_sn_1 : STD_LOGIC;
  signal pixel_y_7_sn_1 : STD_LOGIC;
  signal pixel_y_9_sn_1 : STD_LOGIC;
  signal \rgb_out[0]_i_2_n_0\ : STD_LOGIC;
  signal \rgb_out[10]_i_4_n_0\ : STD_LOGIC;
  signal \rgb_out[11]_i_2_n_0\ : STD_LOGIC;
  signal \rgb_out[13]_i_2_n_0\ : STD_LOGIC;
  signal \rgb_out[20]_i_4_n_0\ : STD_LOGIC;
  signal \rgb_out[21]_i_3_n_0\ : STD_LOGIC;
  signal \rgb_out[22]_i_4_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1454_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1455_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1456_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1457_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1458_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1459_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1460_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1461_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1462_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1463_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1464_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1465_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1466_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1469_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1470_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1473_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1474_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1475_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1476_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1477_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1478_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1479_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1480_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1481_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1482_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1483_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1484_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1485_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1486_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1487_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1488_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1489_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1490_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1491_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1492_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1493_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1494_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1495_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1496_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_17_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_18_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_216_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_494_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_496_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_497_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_498_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_499_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_503_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_504_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_505_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_506_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_508_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_509_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_510_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_513_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_514_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_515_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_516_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_56_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_57_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_59_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_62_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_63_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_64_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_7_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_845_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_846_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_847_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_848_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_849_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_850_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_851_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_853_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_854_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_858_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_859_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_860_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_861_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_863_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_864_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_865_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_866_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_867_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_868_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_869_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_870_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_871_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_872_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_873_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_874_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_875_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_876_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_877_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_878_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_879_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_882_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_883_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_884_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_885_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_887_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_888_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_892_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_893_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_894_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_895_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_897_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_898_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_899_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_900_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_902_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_903_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_904_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_906_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_907_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_908_n_0\ : STD_LOGIC;
  signal \rgb_out[3]_i_2_n_0\ : STD_LOGIC;
  signal \rgb_out[4]_i_2_n_0\ : STD_LOGIC;
  signal \rgb_out[7]_i_2_n_0\ : STD_LOGIC;
  signal \rgb_out[7]_i_3_n_0\ : STD_LOGIC;
  signal \rgb_out[9]_i_2_n_0\ : STD_LOGIC;
  signal \^rgb_out_reg[20]\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal \^rgb_out_reg[20]_0\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal \^rgb_out_reg[20]_1\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal \^rgb_out_reg[20]_2\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal \^rgb_out_reg[20]_3\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal \^rgb_out_reg[20]_4\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal \rgb_out_reg[23]_i_193_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_194_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_194_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_197_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_197_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_198_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_198_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_201_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_201_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_492_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_492_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_492_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_492_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_495_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_495_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_495_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_495_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_500_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_500_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_501_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_501_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_502_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_502_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_502_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_502_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_507_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_507_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_507_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_507_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_511_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_511_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_512_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_512_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_512_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_512_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_517_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_517_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_518_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_518_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_519_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_519_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_520_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_520_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_857_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_857_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_857_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_857_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_862_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_862_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_862_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_862_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_880_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_880_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_880_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_880_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_891_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_891_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_891_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_891_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_896_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_896_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_896_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_896_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_901_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_901_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_901_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_901_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_905_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_905_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_905_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_905_n_3\ : STD_LOGIC;
  signal \NLW_local_y_carry__1_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 2 to 2 );
  signal \NLW_local_y_carry__1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal NLW_pixel_on3_carry_O_UNCONNECTED : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_pixel_on3_carry__0_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_pixel_on3_carry__0_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_pixel_on4__6_carry_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_pixel_on4__6_carry__0_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_pixel_on4__6_carry__0_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal NLW_pixel_on4_carry_O_UNCONNECTED : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_pixel_on4_carry__0_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_pixel_on4_carry__0_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal NLW_pixel_on8_carry_O_UNCONNECTED : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_pixel_on8_carry__0_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_pixel_on8_carry__0_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_pixel_on8_carry__0_i_2_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_pixel_on8_carry__0_i_2_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_193_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_rgb_out_reg[23]_i_193_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_194_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_rgb_out_reg[23]_i_194_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_197_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_rgb_out_reg[23]_i_197_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_198_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_rgb_out_reg[23]_i_198_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_201_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_rgb_out_reg[23]_i_201_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_492_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_495_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_500_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_rgb_out_reg[23]_i_500_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_501_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_rgb_out_reg[23]_i_501_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_502_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_507_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_511_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_rgb_out_reg[23]_i_511_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_512_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_517_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_rgb_out_reg[23]_i_517_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_518_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_rgb_out_reg[23]_i_518_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_519_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_rgb_out_reg[23]_i_519_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_520_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_rgb_out_reg[23]_i_520_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_857_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_862_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_880_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_891_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_896_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_901_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_905_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
begin
  CO(0) <= \^co\(0);
  decompte_ui_1_sn_1 <= decompte_ui_1_sp_1;
  mode_ui_0_sn_1 <= mode_ui_0_sp_1;
  mode_ui_1_sn_1 <= mode_ui_1_sp_1;
  mode_ui_2_sn_1 <= mode_ui_2_sp_1;
  pixel_x_1_sn_1 <= pixel_x_1_sp_1;
  pixel_x_2_sn_1 <= pixel_x_2_sp_1;
  pixel_x_3_sn_1 <= pixel_x_3_sp_1;
  pixel_x_4_sn_1 <= pixel_x_4_sp_1;
  pixel_x_5_sn_1 <= pixel_x_5_sp_1;
  pixel_x_8_sn_1 <= pixel_x_8_sp_1;
  pixel_y_2_sn_1 <= pixel_y_2_sp_1;
  pixel_y_4_sn_1 <= pixel_y_4_sp_1;
  pixel_y_5_sn_1 <= pixel_y_5_sp_1;
  pixel_y_6_sn_1 <= pixel_y_6_sp_1;
  pixel_y_7_sn_1 <= pixel_y_7_sp_1;
  pixel_y_9_sn_1 <= pixel_y_9_sp_1;
  \rgb_out_reg[20]\(0) <= \^rgb_out_reg[20]\(0);
  \rgb_out_reg[20]_0\(0) <= \^rgb_out_reg[20]_0\(0);
  \rgb_out_reg[20]_1\(0) <= \^rgb_out_reg[20]_1\(0);
  \rgb_out_reg[20]_2\(0) <= \^rgb_out_reg[20]_2\(0);
  \rgb_out_reg[20]_3\(0) <= \^rgb_out_reg[20]_3\(0);
  \rgb_out_reg[20]_4\(0) <= \^rgb_out_reg[20]_4\(0);
local_x_carry: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => local_x_carry_n_0,
      CO(2) => local_x_carry_n_1,
      CO(1) => local_x_carry_n_2,
      CO(0) => local_x_carry_n_3,
      CYINIT => '0',
      DI(3) => '0',
      DI(2 downto 1) => pixel_x(6 downto 5),
      DI(0) => '0',
      O(3 downto 0) => local_x_2(7 downto 4),
      S(3) => pixel_x(7),
      S(2) => local_x_carry_i_1_n_0,
      S(1) => local_x_carry_i_2_n_0,
      S(0) => pixel_x(4)
    );
\local_x_carry__0\: unisim.vcomponents.CARRY4
     port map (
      CI => local_x_carry_n_0,
      CO(3) => \local_x_carry__0_n_0\,
      CO(2) => \local_x_carry__0_n_1\,
      CO(1) => \local_x_carry__0_n_2\,
      CO(0) => \local_x_carry__0_n_3\,
      CYINIT => '0',
      DI(3) => pixel_x(11),
      DI(2) => '0',
      DI(1) => pixel_x(9),
      DI(0) => '0',
      O(3 downto 0) => local_x_2(11 downto 8),
      S(3) => \local_x_carry__0_i_1_n_0\,
      S(2) => pixel_x(10),
      S(1) => \local_x_carry__0_i_2_n_0\,
      S(0) => pixel_x(8)
    );
\local_x_carry__0_i_1\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_x(11),
      O => \local_x_carry__0_i_1_n_0\
    );
\local_x_carry__0_i_2\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_x(9),
      O => \local_x_carry__0_i_2_n_0\
    );
local_x_carry_i_1: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_x(6),
      O => local_x_carry_i_1_n_0
    );
local_x_carry_i_2: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_x(5),
      O => local_x_carry_i_2_n_0
    );
local_y_carry: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => local_y_carry_n_0,
      CO(2) => local_y_carry_n_1,
      CO(1) => local_y_carry_n_2,
      CO(0) => local_y_carry_n_3,
      CYINIT => '0',
      DI(3) => pixel_y(4),
      DI(2) => '0',
      DI(1) => pixel_y(2),
      DI(0) => '0',
      O(3 downto 0) => local_y_3(4 downto 1),
      S(3) => local_y_carry_i_1_n_0,
      S(2) => pixel_y(3),
      S(1) => local_y_carry_i_2_n_0,
      S(0) => pixel_y(1)
    );
\local_y_carry__0\: unisim.vcomponents.CARRY4
     port map (
      CI => local_y_carry_n_0,
      CO(3) => \local_y_carry__0_n_0\,
      CO(2) => \local_y_carry__0_n_1\,
      CO(1) => \local_y_carry__0_n_2\,
      CO(0) => \local_y_carry__0_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => pixel_y(8 downto 5),
      O(3 downto 0) => local_y_3(8 downto 5),
      S(3) => \local_y_carry__0_i_1_n_0\,
      S(2) => \local_y_carry__0_i_2_n_0\,
      S(1) => \local_y_carry__0_i_3_n_0\,
      S(0) => \local_y_carry__0_i_4_n_0\
    );
\local_y_carry__0_i_1\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_y(8),
      O => \local_y_carry__0_i_1_n_0\
    );
\local_y_carry__0_i_2\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_y(7),
      O => \local_y_carry__0_i_2_n_0\
    );
\local_y_carry__0_i_3\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_y(6),
      O => \local_y_carry__0_i_3_n_0\
    );
\local_y_carry__0_i_4\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_y(5),
      O => \local_y_carry__0_i_4_n_0\
    );
\local_y_carry__1\: unisim.vcomponents.CARRY4
     port map (
      CI => \local_y_carry__0_n_0\,
      CO(3) => \local_y_carry__1_n_0\,
      CO(2) => \NLW_local_y_carry__1_CO_UNCONNECTED\(2),
      CO(1) => \local_y_carry__1_n_2\,
      CO(0) => \local_y_carry__1_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2 downto 0) => pixel_y(11 downto 9),
      O(3) => \NLW_local_y_carry__1_O_UNCONNECTED\(3),
      O(2 downto 0) => local_y_3(11 downto 9),
      S(3) => '1',
      S(2) => \local_y_carry__1_i_1_n_0\,
      S(1) => \local_y_carry__1_i_2_n_0\,
      S(0) => \local_y_carry__1_i_3_n_0\
    );
\local_y_carry__1_i_1\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_y(11),
      O => \local_y_carry__1_i_1_n_0\
    );
\local_y_carry__1_i_2\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_y(10),
      O => \local_y_carry__1_i_2_n_0\
    );
\local_y_carry__1_i_3\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_y(9),
      O => \local_y_carry__1_i_3_n_0\
    );
local_y_carry_i_1: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_y(4),
      O => local_y_carry_i_1_n_0
    );
local_y_carry_i_2: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_y(2),
      O => local_y_carry_i_2_n_0
    );
pixel_on3_carry: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => pixel_on3_carry_n_0,
      CO(2) => pixel_on3_carry_n_1,
      CO(1) => pixel_on3_carry_n_2,
      CO(0) => pixel_on3_carry_n_3,
      CYINIT => '1',
      DI(3) => pixel_on3_carry_i_1_n_0,
      DI(2) => pixel_on3_carry_i_2_n_0,
      DI(1) => pixel_on3_carry_i_3_n_0,
      DI(0) => pixel_on3_carry_i_4_n_0,
      O(3 downto 0) => NLW_pixel_on3_carry_O_UNCONNECTED(3 downto 0),
      S(3) => pixel_on3_carry_i_5_n_0,
      S(2) => pixel_on3_carry_i_6_n_0,
      S(1) => pixel_on3_carry_i_7_n_0,
      S(0) => pixel_on3_carry_i_8_n_0
    );
\pixel_on3_carry__0\: unisim.vcomponents.CARRY4
     port map (
      CI => pixel_on3_carry_n_0,
      CO(3) => \NLW_pixel_on3_carry__0_CO_UNCONNECTED\(3),
      CO(2) => pixel_on3,
      CO(1) => \pixel_on3_carry__0_n_2\,
      CO(0) => \pixel_on3_carry__0_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \pixel_on3_carry__0_i_1_n_0\,
      DI(0) => \pixel_on3_carry__0_i_2_n_0\,
      O(3 downto 0) => \NLW_pixel_on3_carry__0_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \local_y_carry__1_n_0\,
      S(1) => \pixel_on3_carry__0_i_3_n_0\,
      S(0) => \pixel_on3_carry__0_i_4_n_0\
    );
\pixel_on3_carry__0_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => local_y_3(10),
      I1 => local_y_3(11),
      O => \pixel_on3_carry__0_i_1_n_0\
    );
\pixel_on3_carry__0_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => local_y_3(8),
      I1 => local_y_3(9),
      O => \pixel_on3_carry__0_i_2_n_0\
    );
\pixel_on3_carry__0_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => local_y_3(11),
      I1 => local_y_3(10),
      O => \pixel_on3_carry__0_i_3_n_0\
    );
\pixel_on3_carry__0_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => local_y_3(9),
      I1 => local_y_3(8),
      O => \pixel_on3_carry__0_i_4_n_0\
    );
pixel_on3_carry_i_1: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => local_y_3(6),
      I1 => local_y_3(7),
      O => pixel_on3_carry_i_1_n_0
    );
pixel_on3_carry_i_2: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => local_y_3(4),
      I1 => local_y_3(5),
      O => pixel_on3_carry_i_2_n_0
    );
pixel_on3_carry_i_3: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => local_y_3(2),
      I1 => local_y_3(3),
      O => pixel_on3_carry_i_3_n_0
    );
pixel_on3_carry_i_4: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => pixel_y(0),
      I1 => local_y_3(1),
      O => pixel_on3_carry_i_4_n_0
    );
pixel_on3_carry_i_5: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => local_y_3(7),
      I1 => local_y_3(6),
      O => pixel_on3_carry_i_5_n_0
    );
pixel_on3_carry_i_6: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => local_y_3(5),
      I1 => local_y_3(4),
      O => pixel_on3_carry_i_6_n_0
    );
pixel_on3_carry_i_7: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => local_y_3(3),
      I1 => local_y_3(2),
      O => pixel_on3_carry_i_7_n_0
    );
pixel_on3_carry_i_8: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => local_y_3(1),
      I1 => pixel_y(0),
      O => pixel_on3_carry_i_8_n_0
    );
\pixel_on4__6_carry\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \pixel_on4__6_carry_n_0\,
      CO(2) => \pixel_on4__6_carry_n_1\,
      CO(1) => \pixel_on4__6_carry_n_2\,
      CO(0) => \pixel_on4__6_carry_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \pixel_on4__6_carry_i_1_n_0\,
      DI(0) => \pixel_on4__6_carry_i_2_n_0\,
      O(3 downto 0) => \NLW_pixel_on4__6_carry_O_UNCONNECTED\(3 downto 0),
      S(3) => \pixel_on4__6_carry_i_3_n_0\,
      S(2) => \pixel_on4__6_carry_i_4_n_0\,
      S(1) => \pixel_on4__6_carry_i_5_n_0\,
      S(0) => \pixel_on4__6_carry_i_6_n_0\
    );
\pixel_on4__6_carry__0\: unisim.vcomponents.CARRY4
     port map (
      CI => \pixel_on4__6_carry_n_0\,
      CO(3 downto 2) => \NLW_pixel_on4__6_carry__0_CO_UNCONNECTED\(3 downto 2),
      CO(1) => pixel_on4,
      CO(0) => \pixel_on4__6_carry__0_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => local_x_2(12),
      DI(0) => '0',
      O(3 downto 0) => \NLW_pixel_on4__6_carry__0_O_UNCONNECTED\(3 downto 0),
      S(3 downto 2) => B"00",
      S(1) => \^co\(0),
      S(0) => \pixel_on4__6_carry__0_i_2_n_0\
    );
\pixel_on4__6_carry__0_i_1\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \^co\(0),
      O => local_x_2(12)
    );
\pixel_on4__6_carry__0_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => local_x_2(11),
      I1 => local_x_2(10),
      O => \pixel_on4__6_carry__0_i_2_n_0\
    );
\pixel_on4__6_carry_i_1\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => local_x_2(5),
      O => \pixel_on4__6_carry_i_1_n_0\
    );
\pixel_on4__6_carry_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_x(3),
      I1 => pixel_x(2),
      O => \pixel_on4__6_carry_i_2_n_0\
    );
\pixel_on4__6_carry_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => local_x_2(9),
      I1 => local_x_2(8),
      O => \pixel_on4__6_carry_i_3_n_0\
    );
\pixel_on4__6_carry_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => local_x_2(7),
      I1 => local_x_2(6),
      O => \pixel_on4__6_carry_i_4_n_0\
    );
\pixel_on4__6_carry_i_5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => local_x_2(5),
      I1 => local_x_2(4),
      O => \pixel_on4__6_carry_i_5_n_0\
    );
\pixel_on4__6_carry_i_6\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => pixel_x(2),
      I1 => pixel_x(3),
      O => \pixel_on4__6_carry_i_6_n_0\
    );
pixel_on4_carry: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => pixel_on4_carry_n_0,
      CO(2) => pixel_on4_carry_n_1,
      CO(1) => pixel_on4_carry_n_2,
      CO(0) => pixel_on4_carry_n_3,
      CYINIT => '1',
      DI(3) => pixel_on4_carry_i_1_n_0,
      DI(2) => pixel_on4_carry_i_2_n_0,
      DI(1) => pixel_on4_carry_i_3_n_0,
      DI(0) => pixel_on4_carry_i_4_n_0,
      O(3 downto 0) => NLW_pixel_on4_carry_O_UNCONNECTED(3 downto 0),
      S(3) => pixel_on4_carry_i_5_n_0,
      S(2) => pixel_on4_carry_i_6_n_0,
      S(1) => pixel_on4_carry_i_7_n_0,
      S(0) => pixel_on4_carry_i_8_n_0
    );
\pixel_on4_carry__0\: unisim.vcomponents.CARRY4
     port map (
      CI => pixel_on4_carry_n_0,
      CO(3) => \NLW_pixel_on4_carry__0_CO_UNCONNECTED\(3),
      CO(2) => pixel_on40_in,
      CO(1) => \pixel_on4_carry__0_n_2\,
      CO(0) => \pixel_on4_carry__0_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \pixel_on4_carry__0_i_1_n_0\,
      DI(0) => \pixel_on4_carry__0_i_2_n_0\,
      O(3 downto 0) => \NLW_pixel_on4_carry__0_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \^co\(0),
      S(1) => \pixel_on4_carry__0_i_3_n_0\,
      S(0) => \pixel_on4_carry__0_i_4_n_0\
    );
\pixel_on4_carry__0_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => local_x_2(10),
      I1 => local_x_2(11),
      O => \pixel_on4_carry__0_i_1_n_0\
    );
\pixel_on4_carry__0_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => local_x_2(8),
      I1 => local_x_2(9),
      O => \pixel_on4_carry__0_i_2_n_0\
    );
\pixel_on4_carry__0_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => local_x_2(11),
      I1 => local_x_2(10),
      O => \pixel_on4_carry__0_i_3_n_0\
    );
\pixel_on4_carry__0_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => local_x_2(9),
      I1 => local_x_2(8),
      O => \pixel_on4_carry__0_i_4_n_0\
    );
pixel_on4_carry_i_1: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => local_x_2(6),
      I1 => local_x_2(7),
      O => pixel_on4_carry_i_1_n_0
    );
pixel_on4_carry_i_2: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => local_x_2(4),
      I1 => local_x_2(5),
      O => pixel_on4_carry_i_2_n_0
    );
pixel_on4_carry_i_3: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => pixel_x(2),
      I1 => pixel_x(3),
      O => pixel_on4_carry_i_3_n_0
    );
pixel_on4_carry_i_4: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => pixel_x(1),
      I1 => pixel_x(0),
      O => pixel_on4_carry_i_4_n_0
    );
pixel_on4_carry_i_5: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => local_x_2(7),
      I1 => local_x_2(6),
      O => pixel_on4_carry_i_5_n_0
    );
pixel_on4_carry_i_6: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => local_x_2(5),
      I1 => local_x_2(4),
      O => pixel_on4_carry_i_6_n_0
    );
pixel_on4_carry_i_7: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_x(3),
      I1 => pixel_x(2),
      O => pixel_on4_carry_i_7_n_0
    );
pixel_on4_carry_i_8: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_x(0),
      I1 => pixel_x(1),
      O => pixel_on4_carry_i_8_n_0
    );
pixel_on8_carry: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => pixel_on8_carry_n_0,
      CO(2) => pixel_on8_carry_n_1,
      CO(1) => pixel_on8_carry_n_2,
      CO(0) => pixel_on8_carry_n_3,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => pixel_on8_carry_i_1_n_0,
      DI(1) => pixel_on8_carry_i_2_n_0,
      DI(0) => pixel_on8_carry_i_3_n_0,
      O(3 downto 0) => NLW_pixel_on8_carry_O_UNCONNECTED(3 downto 0),
      S(3) => pixel_on8_carry_i_4_n_0,
      S(2) => pixel_on8_carry_i_5_n_0,
      S(1) => pixel_on8_carry_i_6_n_0,
      S(0) => pixel_on8_carry_i_7_n_0
    );
\pixel_on8_carry__0\: unisim.vcomponents.CARRY4
     port map (
      CI => pixel_on8_carry_n_0,
      CO(3) => \NLW_pixel_on8_carry__0_CO_UNCONNECTED\(3),
      CO(2) => pixel_on8,
      CO(1) => \pixel_on8_carry__0_n_2\,
      CO(0) => \pixel_on8_carry__0_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \pixel_on8_carry__0_i_1_n_0\,
      DI(1 downto 0) => B"00",
      O(3 downto 0) => \NLW_pixel_on8_carry__0_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \^co\(0),
      S(1) => \pixel_on8_carry__0_i_3_n_0\,
      S(0) => \pixel_on8_carry__0_i_4_n_0\
    );
\pixel_on8_carry__0_i_1\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \^co\(0),
      O => \pixel_on8_carry__0_i_1_n_0\
    );
\pixel_on8_carry__0_i_2\: unisim.vcomponents.CARRY4
     port map (
      CI => \local_x_carry__0_n_0\,
      CO(3 downto 1) => \NLW_pixel_on8_carry__0_i_2_CO_UNCONNECTED\(3 downto 1),
      CO(0) => \^co\(0),
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => \NLW_pixel_on8_carry__0_i_2_O_UNCONNECTED\(3 downto 0),
      S(3 downto 0) => B"0001"
    );
\pixel_on8_carry__0_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => local_x_2(11),
      I1 => local_x_2(10),
      O => \pixel_on8_carry__0_i_3_n_0\
    );
\pixel_on8_carry__0_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => local_x_2(9),
      I1 => local_x_2(8),
      O => \pixel_on8_carry__0_i_4_n_0\
    );
pixel_on8_carry_i_1: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => local_x_2(5),
      I1 => local_x_2(4),
      O => pixel_on8_carry_i_1_n_0
    );
pixel_on8_carry_i_2: unisim.vcomponents.LUT2
    generic map(
      INIT => X"7"
    )
        port map (
      I0 => pixel_x(2),
      I1 => pixel_x(3),
      O => pixel_on8_carry_i_2_n_0
    );
pixel_on8_carry_i_3: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_x(1),
      O => pixel_on8_carry_i_3_n_0
    );
pixel_on8_carry_i_4: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => local_x_2(7),
      I1 => local_x_2(6),
      O => pixel_on8_carry_i_4_n_0
    );
pixel_on8_carry_i_5: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => local_x_2(4),
      I1 => local_x_2(5),
      O => pixel_on8_carry_i_5_n_0
    );
pixel_on8_carry_i_6: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => pixel_x(3),
      I1 => pixel_x(2),
      O => pixel_on8_carry_i_6_n_0
    );
pixel_on8_carry_i_7: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => pixel_x(1),
      I1 => pixel_x(0),
      O => pixel_on8_carry_i_7_n_0
    );
\rgb_out[0]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFF44F4"
    )
        port map (
      I0 => \rgb_out[0]_i_2_n_0\,
      I1 => pixel_x_5_sn_1,
      I2 => rgb_in(0),
      I3 => pixel_x_2_sn_1,
      I4 => \pixel_x[2]_0\,
      O => D(0)
    );
\rgb_out[0]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000888AAAAAAAA"
    )
        port map (
      I0 => \rgb_out[7]_i_3_n_0\,
      I1 => pixel_x_1_sn_1,
      I2 => is_pixel_mur,
      I3 => rgb_in(0),
      I4 => pixel_y_4_sn_1,
      I5 => \rgb_out[23]_i_18_n_0\,
      O => \rgb_out[0]_i_2_n_0\
    );
\rgb_out[10]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFF4F4F4"
    )
        port map (
      I0 => pixel_x_2_sn_1,
      I1 => rgb_in(6),
      I2 => \pixel_x[2]_0\,
      I3 => \rgb_out[10]_i_4_n_0\,
      I4 => pixel_x_5_sn_1,
      O => D(10)
    );
\rgb_out[10]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"75770000FFFFFFFF"
    )
        port map (
      I0 => pixel_x_1_sn_1,
      I1 => \pixel_y[4]_1\,
      I2 => rgb_in(6),
      I3 => is_pixel_mur,
      I4 => \rgb_out[23]_i_18_n_0\,
      I5 => \rgb_out[7]_i_3_n_0\,
      O => \rgb_out[10]_i_4_n_0\
    );
\rgb_out[11]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"F1F1F1F1FFF1F1F1"
    )
        port map (
      I0 => \rgb_out[11]_i_2_n_0\,
      I1 => pixel_y_9_sn_1,
      I2 => \pixel_x[2]_2\,
      I3 => rgb_in(7),
      I4 => mode_ui_2_sn_1,
      I5 => pixel_y_6_sn_1,
      O => D(11)
    );
\rgb_out[11]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000800AAAAAAAA"
    )
        port map (
      I0 => \rgb_out[7]_i_3_n_0\,
      I1 => pixel_x_1_sn_1,
      I2 => \pixel_y[4]_0\,
      I3 => is_pixel_mur,
      I4 => rgb_in(7),
      I5 => \rgb_out[23]_i_18_n_0\,
      O => \rgb_out[11]_i_2_n_0\
    );
\rgb_out[12]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFFFD0"
    )
        port map (
      I0 => \rgb_out[20]_i_4_n_0\,
      I1 => \pixel_y[4]_7\,
      I2 => mode_ui_0_sn_1,
      I3 => \pixel_x[2]_1\,
      I4 => \pixel_x[2]_10\,
      I5 => \pixel_x[3]_4\,
      O => D(12)
    );
\rgb_out[13]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFF1FFF1F1"
    )
        port map (
      I0 => \rgb_out[13]_i_2_n_0\,
      I1 => pixel_y_9_sn_1,
      I2 => pixel_x_3_sn_1,
      I3 => \pixel_x[2]_3\,
      I4 => pixel_y_7_sn_1,
      I5 => \pixel_x[2]_1\,
      O => D(13)
    );
\rgb_out[13]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"08880000AAAAAAAA"
    )
        port map (
      I0 => \rgb_out[7]_i_3_n_0\,
      I1 => pixel_x_1_sn_1,
      I2 => is_pixel_mur,
      I3 => rgb_in(8),
      I4 => \pixel_y[4]_2\,
      I5 => \rgb_out[23]_i_18_n_0\,
      O => \rgb_out[13]_i_2_n_0\
    );
\rgb_out[14]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFFFD0"
    )
        port map (
      I0 => \rgb_out[20]_i_4_n_0\,
      I1 => \pixel_y[4]_8\,
      I2 => mode_ui_0_sn_1,
      I3 => \pixel_x[2]_1\,
      I4 => \pixel_x[2]_11\,
      I5 => \pixel_x[3]_5\,
      O => D(14)
    );
\rgb_out[15]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFFF0D"
    )
        port map (
      I0 => \rgb_out[20]_i_4_n_0\,
      I1 => \pixel_y[4]_9\,
      I2 => pixel_y_9_sn_1,
      I3 => \pixel_x[2]_5\,
      I4 => \pixel_x[2]_12\,
      I5 => \pixel_x[3]_6\,
      O => D(15)
    );
\rgb_out[16]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFFF0D"
    )
        port map (
      I0 => \rgb_out[20]_i_4_n_0\,
      I1 => \pixel_y[4]_10\,
      I2 => pixel_y_9_sn_1,
      I3 => \pixel_x[2]_5\,
      I4 => \pixel_x[2]_13\,
      I5 => \pixel_x[3]_7\,
      O => D(16)
    );
\rgb_out[17]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFFFD0"
    )
        port map (
      I0 => \rgb_out[20]_i_4_n_0\,
      I1 => \pixel_y[4]_11\,
      I2 => mode_ui_0_sn_1,
      I3 => \pixel_x[2]_1\,
      I4 => \pixel_x[2]_14\,
      I5 => \pixel_x[3]_8\,
      O => D(17)
    );
\rgb_out[18]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFFF0D"
    )
        port map (
      I0 => \rgb_out[20]_i_4_n_0\,
      I1 => \pixel_y[4]_12\,
      I2 => pixel_y_9_sn_1,
      I3 => \pixel_x[2]_5\,
      I4 => \pixel_x[2]_15\,
      I5 => \pixel_x[3]_9\,
      O => D(18)
    );
\rgb_out[19]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFFF0D"
    )
        port map (
      I0 => \rgb_out[20]_i_4_n_0\,
      I1 => \pixel_y[4]_13\,
      I2 => pixel_y_9_sn_1,
      I3 => \pixel_x[2]_5\,
      I4 => \pixel_x[2]_16\,
      I5 => \pixel_x[3]_10\,
      O => D(19)
    );
\rgb_out[1]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFFFD0"
    )
        port map (
      I0 => \rgb_out[20]_i_4_n_0\,
      I1 => \pixel_y[4]_3\,
      I2 => mode_ui_0_sn_1,
      I3 => \pixel_y[9]_0\,
      I4 => \pixel_x[2]_4\,
      I5 => \pixel_x[3]_0\,
      O => D(1)
    );
\rgb_out[20]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFFF45"
    )
        port map (
      I0 => pixel_y_9_sn_1,
      I1 => \pixel_y[4]_14\,
      I2 => \rgb_out[20]_i_4_n_0\,
      I3 => \pixel_x[2]_17\,
      I4 => \pixel_x[2]_5\,
      I5 => \pixel_x[3]_11\,
      O => D(20)
    );
\rgb_out[20]_i_4\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0400"
    )
        port map (
      I0 => \rgb_out[23]_i_17_n_0\,
      I1 => \rgb_out[23]_i_18_n_0\,
      I2 => pixel_x_4_sn_1,
      I3 => pixel_x_1_sn_1,
      O => \rgb_out[20]_i_4_n_0\
    );
\rgb_out[21]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"BFEEAAAABFEEBFEE"
    )
        port map (
      I0 => \pixel_x[2]_18\,
      I1 => mode_ui(0),
      I2 => mode_ui(2),
      I3 => mode_ui(1),
      I4 => \rgb_out[21]_i_3_n_0\,
      I5 => \pixel_x[1]_0\,
      O => D(21)
    );
\rgb_out[21]_i_3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"BFBBBFBF"
    )
        port map (
      I0 => \rgb_out[23]_i_17_n_0\,
      I1 => \rgb_out[23]_i_18_n_0\,
      I2 => \pixel_y[4]_0\,
      I3 => rgb_in(9),
      I4 => is_pixel_mur,
      O => \rgb_out[21]_i_3_n_0\
    );
\rgb_out[22]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFEFCFCFFFEFFFE"
    )
        port map (
      I0 => \mode_ui[0]_0\,
      I1 => \pixel_x[2]_19\,
      I2 => \pixel_x[2]_20\,
      I3 => \pixel_y[9]_1\,
      I4 => \rgb_out[22]_i_4_n_0\,
      I5 => \pixel_x[1]_0\,
      O => D(22)
    );
\rgb_out[22]_i_4\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"BFBBBFBF"
    )
        port map (
      I0 => \rgb_out[23]_i_17_n_0\,
      I1 => \rgb_out[23]_i_18_n_0\,
      I2 => \pixel_y[4]_1\,
      I3 => rgb_in(10),
      I4 => is_pixel_mur,
      O => \rgb_out[22]_i_4_n_0\
    );
\rgb_out[23]_i_1454\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => local_y_3(6),
      I1 => local_y_3(7),
      O => \rgb_out[23]_i_1454_n_0\
    );
\rgb_out[23]_i_1455\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => local_y_3(1),
      I1 => pixel_y(0),
      O => \rgb_out[23]_i_1455_n_0\
    );
\rgb_out[23]_i_1456\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => local_y_3(7),
      I1 => local_y_3(6),
      O => \rgb_out[23]_i_1456_n_0\
    );
\rgb_out[23]_i_1457\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => local_y_3(4),
      I1 => local_y_3(5),
      O => \rgb_out[23]_i_1457_n_0\
    );
\rgb_out[23]_i_1458\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => local_y_3(3),
      I1 => local_y_3(2),
      O => \rgb_out[23]_i_1458_n_0\
    );
\rgb_out[23]_i_1459\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => local_y_3(1),
      I1 => pixel_y(0),
      O => \rgb_out[23]_i_1459_n_0\
    );
\rgb_out[23]_i_1460\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"7"
    )
        port map (
      I0 => local_y_3(4),
      I1 => local_y_3(5),
      O => \rgb_out[23]_i_1460_n_0\
    );
\rgb_out[23]_i_1461\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => local_y_3(3),
      I1 => local_y_3(2),
      O => \rgb_out[23]_i_1461_n_0\
    );
\rgb_out[23]_i_1462\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => local_y_3(1),
      O => \rgb_out[23]_i_1462_n_0\
    );
\rgb_out[23]_i_1463\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => local_y_3(7),
      I1 => local_y_3(6),
      O => \rgb_out[23]_i_1463_n_0\
    );
\rgb_out[23]_i_1464\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => local_y_3(5),
      I1 => local_y_3(4),
      O => \rgb_out[23]_i_1464_n_0\
    );
\rgb_out[23]_i_1465\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => local_y_3(2),
      I1 => local_y_3(3),
      O => \rgb_out[23]_i_1465_n_0\
    );
\rgb_out[23]_i_1466\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => local_y_3(1),
      I1 => pixel_y(0),
      O => \rgb_out[23]_i_1466_n_0\
    );
\rgb_out[23]_i_1469\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => local_x_2(7),
      I1 => local_x_2(6),
      O => \rgb_out[23]_i_1469_n_0\
    );
\rgb_out[23]_i_1470\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => local_x_2(5),
      I1 => local_x_2(4),
      O => \rgb_out[23]_i_1470_n_0\
    );
\rgb_out[23]_i_1473\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => local_y_3(6),
      I1 => local_y_3(7),
      O => \rgb_out[23]_i_1473_n_0\
    );
\rgb_out[23]_i_1474\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => local_y_3(1),
      I1 => pixel_y(0),
      O => \rgb_out[23]_i_1474_n_0\
    );
\rgb_out[23]_i_1475\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => local_y_3(7),
      I1 => local_y_3(6),
      O => \rgb_out[23]_i_1475_n_0\
    );
\rgb_out[23]_i_1476\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => local_y_3(5),
      I1 => local_y_3(4),
      O => \rgb_out[23]_i_1476_n_0\
    );
\rgb_out[23]_i_1477\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => local_y_3(2),
      I1 => local_y_3(3),
      O => \rgb_out[23]_i_1477_n_0\
    );
\rgb_out[23]_i_1478\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => local_y_3(1),
      I1 => pixel_y(0),
      O => \rgb_out[23]_i_1478_n_0\
    );
\rgb_out[23]_i_1479\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => local_y_3(6),
      I1 => local_y_3(7),
      O => \rgb_out[23]_i_1479_n_0\
    );
\rgb_out[23]_i_1480\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => local_y_3(3),
      I1 => local_y_3(2),
      O => \rgb_out[23]_i_1480_n_0\
    );
\rgb_out[23]_i_1481\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => local_y_3(7),
      I1 => local_y_3(6),
      O => \rgb_out[23]_i_1481_n_0\
    );
\rgb_out[23]_i_1482\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => local_y_3(4),
      I1 => local_y_3(5),
      O => \rgb_out[23]_i_1482_n_0\
    );
\rgb_out[23]_i_1483\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => local_y_3(3),
      I1 => local_y_3(2),
      O => \rgb_out[23]_i_1483_n_0\
    );
\rgb_out[23]_i_1484\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => local_y_3(1),
      I1 => pixel_y(0),
      O => \rgb_out[23]_i_1484_n_0\
    );
\rgb_out[23]_i_1485\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => local_y_3(5),
      O => \rgb_out[23]_i_1485_n_0\
    );
\rgb_out[23]_i_1486\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => local_y_3(1),
      I1 => pixel_y(0),
      O => \rgb_out[23]_i_1486_n_0\
    );
\rgb_out[23]_i_1487\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => local_y_3(7),
      I1 => local_y_3(6),
      O => \rgb_out[23]_i_1487_n_0\
    );
\rgb_out[23]_i_1488\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => local_y_3(5),
      I1 => local_y_3(4),
      O => \rgb_out[23]_i_1488_n_0\
    );
\rgb_out[23]_i_1489\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => local_y_3(3),
      I1 => local_y_3(2),
      O => \rgb_out[23]_i_1489_n_0\
    );
\rgb_out[23]_i_1490\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => pixel_y(0),
      I1 => local_y_3(1),
      O => \rgb_out[23]_i_1490_n_0\
    );
\rgb_out[23]_i_1491\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => local_y_3(3),
      I1 => local_y_3(2),
      O => \rgb_out[23]_i_1491_n_0\
    );
\rgb_out[23]_i_1492\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => local_y_3(1),
      O => \rgb_out[23]_i_1492_n_0\
    );
\rgb_out[23]_i_1493\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => local_y_3(7),
      I1 => local_y_3(6),
      O => \rgb_out[23]_i_1493_n_0\
    );
\rgb_out[23]_i_1494\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => local_y_3(5),
      I1 => local_y_3(4),
      O => \rgb_out[23]_i_1494_n_0\
    );
\rgb_out[23]_i_1495\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => local_y_3(2),
      I1 => local_y_3(3),
      O => \rgb_out[23]_i_1495_n_0\
    );
\rgb_out[23]_i_1496\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => local_y_3(1),
      I1 => pixel_y(0),
      O => \rgb_out[23]_i_1496_n_0\
    );
\rgb_out[23]_i_17\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8A8A8A8A8A8A8A88"
    )
        port map (
      I0 => \mode_ui[2]_1\,
      I1 => num_tm_d,
      I2 => \rgb_out[23]_i_56_n_0\,
      I3 => \rgb_out[23]_i_57_n_0\,
      I4 => \pixel_x[5]_0\,
      I5 => \rgb_out[23]_i_59_n_0\,
      O => \rgb_out[23]_i_17_n_0\
    );
\rgb_out[23]_i_18\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFEAEAEAEE"
    )
        port map (
      I0 => pixel_x_8_sn_1,
      I1 => decompte_ui_1_sn_1,
      I2 => \rgb_out[23]_i_62_n_0\,
      I3 => \rgb_out[23]_i_63_n_0\,
      I4 => \rgb_out[23]_i_64_n_0\,
      I5 => \mode_ui[2]_1\,
      O => \rgb_out[23]_i_18_n_0\
    );
\rgb_out[23]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFCFFFEFEFCFE"
    )
        port map (
      I0 => \mode_ui[0]_0\,
      I1 => \pixel_x[2]_21\,
      I2 => \pixel_x[2]_22\,
      I3 => \pixel_x[1]_0\,
      I4 => \rgb_out[23]_i_7_n_0\,
      I5 => \pixel_y[9]_1\,
      O => D(23)
    );
\rgb_out[23]_i_216\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0007FFFFFFFFFFFF"
    )
        port map (
      I0 => \^rgb_out_reg[20]_1\(0),
      I1 => \^rgb_out_reg[20]_2\(0),
      I2 => \^rgb_out_reg[20]_3\(0),
      I3 => \^rgb_out_reg[20]_4\(0),
      I4 => pixel_on8,
      I5 => pixel_on9,
      O => \rgb_out[23]_i_216_n_0\
    );
\rgb_out[23]_i_493\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \local_y_carry__1_n_0\,
      O => local_y_3(12)
    );
\rgb_out[23]_i_494\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => local_y_3(11),
      I1 => local_y_3(10),
      O => \rgb_out[23]_i_494_n_0\
    );
\rgb_out[23]_i_496\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => local_x_2(10),
      I1 => local_x_2(11),
      O => \rgb_out[23]_i_496_n_0\
    );
\rgb_out[23]_i_497\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => local_x_2(8),
      I1 => local_x_2(9),
      O => \rgb_out[23]_i_497_n_0\
    );
\rgb_out[23]_i_498\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => local_x_2(11),
      I1 => local_x_2(10),
      O => \rgb_out[23]_i_498_n_0\
    );
\rgb_out[23]_i_499\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => local_x_2(9),
      I1 => local_x_2(8),
      O => \rgb_out[23]_i_499_n_0\
    );
\rgb_out[23]_i_503\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => local_y_3(10),
      I1 => local_y_3(11),
      O => \rgb_out[23]_i_503_n_0\
    );
\rgb_out[23]_i_504\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => local_y_3(8),
      I1 => local_y_3(9),
      O => \rgb_out[23]_i_504_n_0\
    );
\rgb_out[23]_i_505\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => local_y_3(11),
      I1 => local_y_3(10),
      O => \rgb_out[23]_i_505_n_0\
    );
\rgb_out[23]_i_506\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => local_y_3(9),
      I1 => local_y_3(8),
      O => \rgb_out[23]_i_506_n_0\
    );
\rgb_out[23]_i_508\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \local_y_carry__1_n_0\,
      O => \rgb_out[23]_i_508_n_0\
    );
\rgb_out[23]_i_509\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => local_y_3(11),
      I1 => local_y_3(10),
      O => \rgb_out[23]_i_509_n_0\
    );
\rgb_out[23]_i_510\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => local_y_3(9),
      I1 => local_y_3(8),
      O => \rgb_out[23]_i_510_n_0\
    );
\rgb_out[23]_i_513\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => local_x_2(10),
      I1 => local_x_2(11),
      O => \rgb_out[23]_i_513_n_0\
    );
\rgb_out[23]_i_514\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => local_x_2(8),
      I1 => local_x_2(9),
      O => \rgb_out[23]_i_514_n_0\
    );
\rgb_out[23]_i_515\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => local_x_2(11),
      I1 => local_x_2(10),
      O => \rgb_out[23]_i_515_n_0\
    );
\rgb_out[23]_i_516\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => local_x_2(9),
      I1 => local_x_2(8),
      O => \rgb_out[23]_i_516_n_0\
    );
\rgb_out[23]_i_56\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"7FFF"
    )
        port map (
      I0 => pixel_on2,
      I1 => pixel_on3,
      I2 => pixel_on40_in,
      I3 => pixel_on4,
      O => \rgb_out[23]_i_56_n_0\
    );
\rgb_out[23]_i_57\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"8A888888"
    )
        port map (
      I0 => pixel_on99_in,
      I1 => pixel_y_2_sn_1,
      I2 => \temps_restant[2]\,
      I3 => \^rgb_out_reg[20]\(0),
      I4 => \^rgb_out_reg[20]_0\(0),
      O => \rgb_out[23]_i_57_n_0\
    );
\rgb_out[23]_i_59\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"88808888"
    )
        port map (
      I0 => pixel_on8,
      I1 => pixel_on9,
      I2 => \pixel_y[5]_1\,
      I3 => \pixel_y[2]_3\,
      I4 => \pixel_y[2]_4\,
      O => \rgb_out[23]_i_59_n_0\
    );
\rgb_out[23]_i_62\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FEAA"
    )
        port map (
      I0 => \rgb_out[23]_i_56_n_0\,
      I1 => decompte_ui(2),
      I2 => decompte_ui(1),
      I3 => decompte_ui(3),
      O => \rgb_out[23]_i_62_n_0\
    );
\rgb_out[23]_i_63\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"A8A8A8A8A888A8A8"
    )
        port map (
      I0 => pixel_on99_in,
      I1 => \pixel_y[5]_0\,
      I2 => \pixel_y[2]_2\,
      I3 => decompte_ui(2),
      I4 => decompte_ui(1),
      I5 => decompte_ui(0),
      O => \rgb_out[23]_i_63_n_0\
    );
\rgb_out[23]_i_64\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFF0010"
    )
        port map (
      I0 => \pixel_y[2]_0\,
      I1 => pixel_y_5_sn_1,
      I2 => \pixel_y[2]_1\,
      I3 => \rgb_out[23]_i_216_n_0\,
      I4 => \pixel_x[5]_1\,
      I5 => \pixel_x[5]_2\,
      O => \rgb_out[23]_i_64_n_0\
    );
\rgb_out[23]_i_7\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"BFBBBFBF"
    )
        port map (
      I0 => \rgb_out[23]_i_17_n_0\,
      I1 => \rgb_out[23]_i_18_n_0\,
      I2 => \pixel_y[4]_1\,
      I3 => rgb_in(11),
      I4 => is_pixel_mur,
      O => \rgb_out[23]_i_7_n_0\
    );
\rgb_out[23]_i_845\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"7"
    )
        port map (
      I0 => local_y_3(4),
      I1 => local_y_3(5),
      O => \rgb_out[23]_i_845_n_0\
    );
\rgb_out[23]_i_846\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"7"
    )
        port map (
      I0 => local_y_3(2),
      I1 => local_y_3(3),
      O => \rgb_out[23]_i_846_n_0\
    );
\rgb_out[23]_i_847\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => local_y_3(9),
      I1 => local_y_3(8),
      O => \rgb_out[23]_i_847_n_0\
    );
\rgb_out[23]_i_848\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => local_y_3(7),
      I1 => local_y_3(6),
      O => \rgb_out[23]_i_848_n_0\
    );
\rgb_out[23]_i_849\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => local_y_3(5),
      I1 => local_y_3(4),
      O => \rgb_out[23]_i_849_n_0\
    );
\rgb_out[23]_i_850\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => local_y_3(3),
      I1 => local_y_3(2),
      O => \rgb_out[23]_i_850_n_0\
    );
\rgb_out[23]_i_851\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => local_x_2(6),
      I1 => local_x_2(7),
      O => \rgb_out[23]_i_851_n_0\
    );
\rgb_out[23]_i_853\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => local_x_2(7),
      I1 => local_x_2(6),
      O => \rgb_out[23]_i_853_n_0\
    );
\rgb_out[23]_i_854\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => local_x_2(4),
      I1 => local_x_2(5),
      O => \rgb_out[23]_i_854_n_0\
    );
\rgb_out[23]_i_858\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => local_y_3(10),
      I1 => local_y_3(11),
      O => \rgb_out[23]_i_858_n_0\
    );
\rgb_out[23]_i_859\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => local_y_3(8),
      I1 => local_y_3(9),
      O => \rgb_out[23]_i_859_n_0\
    );
\rgb_out[23]_i_860\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => local_y_3(11),
      I1 => local_y_3(10),
      O => \rgb_out[23]_i_860_n_0\
    );
\rgb_out[23]_i_861\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => local_y_3(9),
      I1 => local_y_3(8),
      O => \rgb_out[23]_i_861_n_0\
    );
\rgb_out[23]_i_863\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \local_y_carry__1_n_0\,
      O => \rgb_out[23]_i_863_n_0\
    );
\rgb_out[23]_i_864\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => local_y_3(11),
      I1 => local_y_3(10),
      O => \rgb_out[23]_i_864_n_0\
    );
\rgb_out[23]_i_865\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => local_y_3(9),
      I1 => local_y_3(8),
      O => \rgb_out[23]_i_865_n_0\
    );
\rgb_out[23]_i_866\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => local_y_3(6),
      I1 => local_y_3(7),
      O => \rgb_out[23]_i_866_n_0\
    );
\rgb_out[23]_i_867\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => local_y_3(4),
      I1 => local_y_3(5),
      O => \rgb_out[23]_i_867_n_0\
    );
\rgb_out[23]_i_868\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => local_y_3(1),
      I1 => pixel_y(0),
      O => \rgb_out[23]_i_868_n_0\
    );
\rgb_out[23]_i_869\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => local_y_3(7),
      I1 => local_y_3(6),
      O => \rgb_out[23]_i_869_n_0\
    );
\rgb_out[23]_i_870\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => local_y_3(5),
      I1 => local_y_3(4),
      O => \rgb_out[23]_i_870_n_0\
    );
\rgb_out[23]_i_871\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => local_y_3(2),
      I1 => local_y_3(3),
      O => \rgb_out[23]_i_871_n_0\
    );
\rgb_out[23]_i_872\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => local_y_3(1),
      I1 => pixel_y(0),
      O => \rgb_out[23]_i_872_n_0\
    );
\rgb_out[23]_i_873\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => local_y_3(5),
      I1 => local_y_3(4),
      O => \rgb_out[23]_i_873_n_0\
    );
\rgb_out[23]_i_874\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"7"
    )
        port map (
      I0 => local_y_3(2),
      I1 => local_y_3(3),
      O => \rgb_out[23]_i_874_n_0\
    );
\rgb_out[23]_i_875\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => local_y_3(1),
      O => \rgb_out[23]_i_875_n_0\
    );
\rgb_out[23]_i_876\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => local_y_3(7),
      I1 => local_y_3(6),
      O => \rgb_out[23]_i_876_n_0\
    );
\rgb_out[23]_i_877\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => local_y_3(4),
      I1 => local_y_3(5),
      O => \rgb_out[23]_i_877_n_0\
    );
\rgb_out[23]_i_878\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => local_y_3(3),
      I1 => local_y_3(2),
      O => \rgb_out[23]_i_878_n_0\
    );
\rgb_out[23]_i_879\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => local_y_3(1),
      I1 => pixel_y(0),
      O => \rgb_out[23]_i_879_n_0\
    );
\rgb_out[23]_i_882\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => local_x_2(11),
      I1 => local_x_2(10),
      O => \rgb_out[23]_i_882_n_0\
    );
\rgb_out[23]_i_883\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => local_x_2(9),
      I1 => local_x_2(8),
      O => \rgb_out[23]_i_883_n_0\
    );
\rgb_out[23]_i_884\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => local_x_2(6),
      I1 => local_x_2(7),
      O => \rgb_out[23]_i_884_n_0\
    );
\rgb_out[23]_i_885\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => local_x_2(4),
      I1 => local_x_2(5),
      O => \rgb_out[23]_i_885_n_0\
    );
\rgb_out[23]_i_887\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => local_x_2(7),
      I1 => local_x_2(6),
      O => \rgb_out[23]_i_887_n_0\
    );
\rgb_out[23]_i_888\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => local_x_2(5),
      I1 => local_x_2(4),
      O => \rgb_out[23]_i_888_n_0\
    );
\rgb_out[23]_i_892\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => local_y_3(10),
      I1 => local_y_3(11),
      O => \rgb_out[23]_i_892_n_0\
    );
\rgb_out[23]_i_893\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => local_y_3(8),
      I1 => local_y_3(9),
      O => \rgb_out[23]_i_893_n_0\
    );
\rgb_out[23]_i_894\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => local_y_3(11),
      I1 => local_y_3(10),
      O => \rgb_out[23]_i_894_n_0\
    );
\rgb_out[23]_i_895\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => local_y_3(9),
      I1 => local_y_3(8),
      O => \rgb_out[23]_i_895_n_0\
    );
\rgb_out[23]_i_897\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => local_y_3(10),
      I1 => local_y_3(11),
      O => \rgb_out[23]_i_897_n_0\
    );
\rgb_out[23]_i_898\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => local_y_3(8),
      I1 => local_y_3(9),
      O => \rgb_out[23]_i_898_n_0\
    );
\rgb_out[23]_i_899\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => local_y_3(11),
      I1 => local_y_3(10),
      O => \rgb_out[23]_i_899_n_0\
    );
\rgb_out[23]_i_900\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => local_y_3(9),
      I1 => local_y_3(8),
      O => \rgb_out[23]_i_900_n_0\
    );
\rgb_out[23]_i_902\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \local_y_carry__1_n_0\,
      O => \rgb_out[23]_i_902_n_0\
    );
\rgb_out[23]_i_903\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => local_y_3(11),
      I1 => local_y_3(10),
      O => \rgb_out[23]_i_903_n_0\
    );
\rgb_out[23]_i_904\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => local_y_3(9),
      I1 => local_y_3(8),
      O => \rgb_out[23]_i_904_n_0\
    );
\rgb_out[23]_i_906\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \local_y_carry__1_n_0\,
      O => \rgb_out[23]_i_906_n_0\
    );
\rgb_out[23]_i_907\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => local_y_3(11),
      I1 => local_y_3(10),
      O => \rgb_out[23]_i_907_n_0\
    );
\rgb_out[23]_i_908\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => local_y_3(9),
      I1 => local_y_3(8),
      O => \rgb_out[23]_i_908_n_0\
    );
\rgb_out[2]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFFF0D"
    )
        port map (
      I0 => \rgb_out[20]_i_4_n_0\,
      I1 => \pixel_y[4]_4\,
      I2 => pixel_y_9_sn_1,
      I3 => \pixel_x[2]_5\,
      I4 => \pixel_x[2]_6\,
      I5 => \pixel_x[3]_1\,
      O => D(2)
    );
\rgb_out[3]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFF44F4"
    )
        port map (
      I0 => pixel_x_2_sn_1,
      I1 => rgb_in(1),
      I2 => pixel_x_5_sn_1,
      I3 => \rgb_out[3]_i_2_n_0\,
      I4 => \pixel_x[2]_0\,
      O => D(3)
    );
\rgb_out[3]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000800AAAAAAAA"
    )
        port map (
      I0 => \rgb_out[7]_i_3_n_0\,
      I1 => pixel_x_1_sn_1,
      I2 => \pixel_y[4]_0\,
      I3 => is_pixel_mur,
      I4 => rgb_in(1),
      I5 => \rgb_out[23]_i_18_n_0\,
      O => \rgb_out[3]_i_2_n_0\
    );
\rgb_out[4]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFF44F4"
    )
        port map (
      I0 => \rgb_out[4]_i_2_n_0\,
      I1 => pixel_x_5_sn_1,
      I2 => rgb_in(2),
      I3 => pixel_x_2_sn_1,
      I4 => \pixel_x[2]_0\,
      O => D(4)
    );
\rgb_out[4]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000888AAAAAAAA"
    )
        port map (
      I0 => \rgb_out[7]_i_3_n_0\,
      I1 => pixel_x_1_sn_1,
      I2 => is_pixel_mur,
      I3 => rgb_in(2),
      I4 => \pixel_y[4]_0\,
      I5 => \rgb_out[23]_i_18_n_0\,
      O => \rgb_out[4]_i_2_n_0\
    );
\rgb_out[5]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFD50000"
    )
        port map (
      I0 => \rgb_out[20]_i_4_n_0\,
      I1 => is_pixel_mur,
      I2 => rgb_in(3),
      I3 => \pixel_y[4]_1\,
      I4 => mode_ui_0_sn_1,
      I5 => \pixel_x[2]_7\,
      O => D(5)
    );
\rgb_out[6]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFFFD0"
    )
        port map (
      I0 => \rgb_out[20]_i_4_n_0\,
      I1 => \pixel_y[4]_5\,
      I2 => mode_ui_0_sn_1,
      I3 => \pixel_x[2]_1\,
      I4 => \pixel_x[2]_8\,
      I5 => \pixel_x[3]_2\,
      O => D(6)
    );
\rgb_out[7]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFF4F444F4F"
    )
        port map (
      I0 => pixel_x_2_sn_1,
      I1 => rgb_in(4),
      I2 => pixel_y_9_sn_1,
      I3 => \rgb_out[7]_i_2_n_0\,
      I4 => \rgb_out[7]_i_3_n_0\,
      I5 => \pixel_x[2]_1\,
      O => D(7)
    );
\rgb_out[7]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000A808AAAAAAAA"
    )
        port map (
      I0 => \rgb_out[23]_i_18_n_0\,
      I1 => mode_ui_1_sn_1,
      I2 => is_pixel_mur,
      I3 => rgb_in(4),
      I4 => \pixel_y[4]_0\,
      I5 => pixel_x_1_sn_1,
      O => \rgb_out[7]_i_2_n_0\
    );
\rgb_out[7]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000000000002FFFF"
    )
        port map (
      I0 => \pixel_x[2]_23\,
      I1 => \pixel_x[2]_24\,
      I2 => \pixel_x[2]_25\,
      I3 => \pixel_x[3]_12\,
      I4 => \mode_ui[2]_0\,
      I5 => \rgb_out[23]_i_17_n_0\,
      O => \rgb_out[7]_i_3_n_0\
    );
\rgb_out[8]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFFFD0"
    )
        port map (
      I0 => \rgb_out[20]_i_4_n_0\,
      I1 => \pixel_y[4]_6\,
      I2 => mode_ui_0_sn_1,
      I3 => \pixel_x[2]_1\,
      I4 => \pixel_x[2]_9\,
      I5 => \pixel_x[3]_3\,
      O => D(8)
    );
\rgb_out[9]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFF44F4"
    )
        port map (
      I0 => \rgb_out[9]_i_2_n_0\,
      I1 => pixel_x_5_sn_1,
      I2 => rgb_in(5),
      I3 => pixel_x_2_sn_1,
      I4 => \pixel_x[2]_0\,
      O => D(9)
    );
\rgb_out[9]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"80888080AAAAAAAA"
    )
        port map (
      I0 => \rgb_out[7]_i_3_n_0\,
      I1 => pixel_x_1_sn_1,
      I2 => \pixel_y[4]_1\,
      I3 => rgb_in(5),
      I4 => is_pixel_mur,
      I5 => \rgb_out[23]_i_18_n_0\,
      O => \rgb_out[9]_i_2_n_0\
    );
\rgb_out_reg[23]_i_193\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_492_n_0\,
      CO(3 downto 2) => \NLW_rgb_out_reg[23]_i_193_CO_UNCONNECTED\(3 downto 2),
      CO(1) => pixel_on2,
      CO(0) => \rgb_out_reg[23]_i_193_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => local_y_3(12),
      DI(0) => '0',
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_193_O_UNCONNECTED\(3 downto 0),
      S(3 downto 2) => B"00",
      S(1) => \local_y_carry__1_n_0\,
      S(0) => \rgb_out[23]_i_494_n_0\
    );
\rgb_out_reg[23]_i_194\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_495_n_0\,
      CO(3) => \NLW_rgb_out_reg[23]_i_194_CO_UNCONNECTED\(3),
      CO(2) => pixel_on99_in,
      CO(1) => \rgb_out_reg[23]_i_194_n_2\,
      CO(0) => \rgb_out_reg[23]_i_194_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \rgb_out[23]_i_496_n_0\,
      DI(0) => \rgb_out[23]_i_497_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_194_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \^co\(0),
      S(1) => \rgb_out[23]_i_498_n_0\,
      S(0) => \rgb_out[23]_i_499_n_0\
    );
\rgb_out_reg[23]_i_197\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_502_n_0\,
      CO(3) => \NLW_rgb_out_reg[23]_i_197_CO_UNCONNECTED\(3),
      CO(2) => \^rgb_out_reg[20]\(0),
      CO(1) => \rgb_out_reg[23]_i_197_n_2\,
      CO(0) => \rgb_out_reg[23]_i_197_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \rgb_out[23]_i_503_n_0\,
      DI(0) => \rgb_out[23]_i_504_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_197_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \local_y_carry__1_n_0\,
      S(1) => \rgb_out[23]_i_505_n_0\,
      S(0) => \rgb_out[23]_i_506_n_0\
    );
\rgb_out_reg[23]_i_198\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_507_n_0\,
      CO(3) => \NLW_rgb_out_reg[23]_i_198_CO_UNCONNECTED\(3),
      CO(2) => \^rgb_out_reg[20]_0\(0),
      CO(1) => \rgb_out_reg[23]_i_198_n_2\,
      CO(0) => \rgb_out_reg[23]_i_198_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \rgb_out[23]_i_508_n_0\,
      DI(1 downto 0) => B"00",
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_198_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \local_y_carry__1_n_0\,
      S(1) => \rgb_out[23]_i_509_n_0\,
      S(0) => \rgb_out[23]_i_510_n_0\
    );
\rgb_out_reg[23]_i_201\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_512_n_0\,
      CO(3) => \NLW_rgb_out_reg[23]_i_201_CO_UNCONNECTED\(3),
      CO(2) => pixel_on9,
      CO(1) => \rgb_out_reg[23]_i_201_n_2\,
      CO(0) => \rgb_out_reg[23]_i_201_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \rgb_out[23]_i_513_n_0\,
      DI(0) => \rgb_out[23]_i_514_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_201_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \^co\(0),
      S(1) => \rgb_out[23]_i_515_n_0\,
      S(0) => \rgb_out[23]_i_516_n_0\
    );
\rgb_out_reg[23]_i_492\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_492_n_0\,
      CO(2) => \rgb_out_reg[23]_i_492_n_1\,
      CO(1) => \rgb_out_reg[23]_i_492_n_2\,
      CO(0) => \rgb_out_reg[23]_i_492_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \rgb_out[23]_i_845_n_0\,
      DI(0) => \rgb_out[23]_i_846_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_492_O_UNCONNECTED\(3 downto 0),
      S(3) => \rgb_out[23]_i_847_n_0\,
      S(2) => \rgb_out[23]_i_848_n_0\,
      S(1) => \rgb_out[23]_i_849_n_0\,
      S(0) => \rgb_out[23]_i_850_n_0\
    );
\rgb_out_reg[23]_i_495\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_495_n_0\,
      CO(2) => \rgb_out_reg[23]_i_495_n_1\,
      CO(1) => \rgb_out_reg[23]_i_495_n_2\,
      CO(0) => \rgb_out_reg[23]_i_495_n_3\,
      CYINIT => '1',
      DI(3) => \rgb_out[23]_i_851_n_0\,
      DI(2) => local_x_2(5),
      DI(1) => '0',
      DI(0) => DI(0),
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_495_O_UNCONNECTED\(3 downto 0),
      S(3) => \rgb_out[23]_i_853_n_0\,
      S(2) => \rgb_out[23]_i_854_n_0\,
      S(1 downto 0) => S(1 downto 0)
    );
\rgb_out_reg[23]_i_500\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_857_n_0\,
      CO(3) => \NLW_rgb_out_reg[23]_i_500_CO_UNCONNECTED\(3),
      CO(2) => \rgb_out_reg[20]_6\(0),
      CO(1) => \rgb_out_reg[23]_i_500_n_2\,
      CO(0) => \rgb_out_reg[23]_i_500_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \rgb_out[23]_i_858_n_0\,
      DI(0) => \rgb_out[23]_i_859_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_500_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \local_y_carry__1_n_0\,
      S(1) => \rgb_out[23]_i_860_n_0\,
      S(0) => \rgb_out[23]_i_861_n_0\
    );
\rgb_out_reg[23]_i_501\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_862_n_0\,
      CO(3) => \NLW_rgb_out_reg[23]_i_501_CO_UNCONNECTED\(3),
      CO(2) => \rgb_out_reg[20]_5\(0),
      CO(1) => \rgb_out_reg[23]_i_501_n_2\,
      CO(0) => \rgb_out_reg[23]_i_501_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \rgb_out[23]_i_863_n_0\,
      DI(1 downto 0) => B"00",
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_501_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \local_y_carry__1_n_0\,
      S(1) => \rgb_out[23]_i_864_n_0\,
      S(0) => \rgb_out[23]_i_865_n_0\
    );
\rgb_out_reg[23]_i_502\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_502_n_0\,
      CO(2) => \rgb_out_reg[23]_i_502_n_1\,
      CO(1) => \rgb_out_reg[23]_i_502_n_2\,
      CO(0) => \rgb_out_reg[23]_i_502_n_3\,
      CYINIT => '1',
      DI(3) => \rgb_out[23]_i_866_n_0\,
      DI(2) => \rgb_out[23]_i_867_n_0\,
      DI(1) => local_y_3(3),
      DI(0) => \rgb_out[23]_i_868_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_502_O_UNCONNECTED\(3 downto 0),
      S(3) => \rgb_out[23]_i_869_n_0\,
      S(2) => \rgb_out[23]_i_870_n_0\,
      S(1) => \rgb_out[23]_i_871_n_0\,
      S(0) => \rgb_out[23]_i_872_n_0\
    );
\rgb_out_reg[23]_i_507\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_507_n_0\,
      CO(2) => \rgb_out_reg[23]_i_507_n_1\,
      CO(1) => \rgb_out_reg[23]_i_507_n_2\,
      CO(0) => \rgb_out_reg[23]_i_507_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \rgb_out[23]_i_873_n_0\,
      DI(1) => \rgb_out[23]_i_874_n_0\,
      DI(0) => \rgb_out[23]_i_875_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_507_O_UNCONNECTED\(3 downto 0),
      S(3) => \rgb_out[23]_i_876_n_0\,
      S(2) => \rgb_out[23]_i_877_n_0\,
      S(1) => \rgb_out[23]_i_878_n_0\,
      S(0) => \rgb_out[23]_i_879_n_0\
    );
\rgb_out_reg[23]_i_511\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_880_n_0\,
      CO(3) => \NLW_rgb_out_reg[23]_i_511_CO_UNCONNECTED\(3),
      CO(2) => \rgb_out_reg[20]_7\(0),
      CO(1) => \rgb_out_reg[23]_i_511_n_2\,
      CO(0) => \rgb_out_reg[23]_i_511_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \pixel_x[5]_3\(0),
      DI(1 downto 0) => B"00",
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_511_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \^co\(0),
      S(1) => \rgb_out[23]_i_882_n_0\,
      S(0) => \rgb_out[23]_i_883_n_0\
    );
\rgb_out_reg[23]_i_512\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_512_n_0\,
      CO(2) => \rgb_out_reg[23]_i_512_n_1\,
      CO(1) => \rgb_out_reg[23]_i_512_n_2\,
      CO(0) => \rgb_out_reg[23]_i_512_n_3\,
      CYINIT => '1',
      DI(3) => \rgb_out[23]_i_884_n_0\,
      DI(2) => \rgb_out[23]_i_885_n_0\,
      DI(1) => pixel_x(3),
      DI(0) => \pixel_x[1]_1\(0),
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_512_O_UNCONNECTED\(3 downto 0),
      S(3) => \rgb_out[23]_i_887_n_0\,
      S(2) => \rgb_out[23]_i_888_n_0\,
      S(1 downto 0) => \pixel_x[3]_13\(1 downto 0)
    );
\rgb_out_reg[23]_i_517\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_891_n_0\,
      CO(3) => \NLW_rgb_out_reg[23]_i_517_CO_UNCONNECTED\(3),
      CO(2) => \^rgb_out_reg[20]_3\(0),
      CO(1) => \rgb_out_reg[23]_i_517_n_2\,
      CO(0) => \rgb_out_reg[23]_i_517_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \rgb_out[23]_i_892_n_0\,
      DI(0) => \rgb_out[23]_i_893_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_517_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \local_y_carry__1_n_0\,
      S(1) => \rgb_out[23]_i_894_n_0\,
      S(0) => \rgb_out[23]_i_895_n_0\
    );
\rgb_out_reg[23]_i_518\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_896_n_0\,
      CO(3) => \NLW_rgb_out_reg[23]_i_518_CO_UNCONNECTED\(3),
      CO(2) => \^rgb_out_reg[20]_2\(0),
      CO(1) => \rgb_out_reg[23]_i_518_n_2\,
      CO(0) => \rgb_out_reg[23]_i_518_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \rgb_out[23]_i_897_n_0\,
      DI(0) => \rgb_out[23]_i_898_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_518_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \local_y_carry__1_n_0\,
      S(1) => \rgb_out[23]_i_899_n_0\,
      S(0) => \rgb_out[23]_i_900_n_0\
    );
\rgb_out_reg[23]_i_519\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_901_n_0\,
      CO(3) => \NLW_rgb_out_reg[23]_i_519_CO_UNCONNECTED\(3),
      CO(2) => \^rgb_out_reg[20]_1\(0),
      CO(1) => \rgb_out_reg[23]_i_519_n_2\,
      CO(0) => \rgb_out_reg[23]_i_519_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \rgb_out[23]_i_902_n_0\,
      DI(1 downto 0) => B"00",
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_519_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \local_y_carry__1_n_0\,
      S(1) => \rgb_out[23]_i_903_n_0\,
      S(0) => \rgb_out[23]_i_904_n_0\
    );
\rgb_out_reg[23]_i_520\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_905_n_0\,
      CO(3) => \NLW_rgb_out_reg[23]_i_520_CO_UNCONNECTED\(3),
      CO(2) => \^rgb_out_reg[20]_4\(0),
      CO(1) => \rgb_out_reg[23]_i_520_n_2\,
      CO(0) => \rgb_out_reg[23]_i_520_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \rgb_out[23]_i_906_n_0\,
      DI(1 downto 0) => B"00",
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_520_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \local_y_carry__1_n_0\,
      S(1) => \rgb_out[23]_i_907_n_0\,
      S(0) => \rgb_out[23]_i_908_n_0\
    );
\rgb_out_reg[23]_i_857\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_857_n_0\,
      CO(2) => \rgb_out_reg[23]_i_857_n_1\,
      CO(1) => \rgb_out_reg[23]_i_857_n_2\,
      CO(0) => \rgb_out_reg[23]_i_857_n_3\,
      CYINIT => '1',
      DI(3) => \rgb_out[23]_i_1454_n_0\,
      DI(2) => local_y_3(5),
      DI(1) => '0',
      DI(0) => \rgb_out[23]_i_1455_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_857_O_UNCONNECTED\(3 downto 0),
      S(3) => \rgb_out[23]_i_1456_n_0\,
      S(2) => \rgb_out[23]_i_1457_n_0\,
      S(1) => \rgb_out[23]_i_1458_n_0\,
      S(0) => \rgb_out[23]_i_1459_n_0\
    );
\rgb_out_reg[23]_i_862\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_862_n_0\,
      CO(2) => \rgb_out_reg[23]_i_862_n_1\,
      CO(1) => \rgb_out_reg[23]_i_862_n_2\,
      CO(0) => \rgb_out_reg[23]_i_862_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \rgb_out[23]_i_1460_n_0\,
      DI(1) => \rgb_out[23]_i_1461_n_0\,
      DI(0) => \rgb_out[23]_i_1462_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_862_O_UNCONNECTED\(3 downto 0),
      S(3) => \rgb_out[23]_i_1463_n_0\,
      S(2) => \rgb_out[23]_i_1464_n_0\,
      S(1) => \rgb_out[23]_i_1465_n_0\,
      S(0) => \rgb_out[23]_i_1466_n_0\
    );
\rgb_out_reg[23]_i_880\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_880_n_0\,
      CO(2) => \rgb_out_reg[23]_i_880_n_1\,
      CO(1) => \rgb_out_reg[23]_i_880_n_2\,
      CO(0) => \rgb_out_reg[23]_i_880_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1 downto 0) => \pixel_x[2]_26\(1 downto 0),
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_880_O_UNCONNECTED\(3 downto 0),
      S(3) => \rgb_out[23]_i_1469_n_0\,
      S(2) => \rgb_out[23]_i_1470_n_0\,
      S(1 downto 0) => \pixel_x[3]_14\(1 downto 0)
    );
\rgb_out_reg[23]_i_891\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_891_n_0\,
      CO(2) => \rgb_out_reg[23]_i_891_n_1\,
      CO(1) => \rgb_out_reg[23]_i_891_n_2\,
      CO(0) => \rgb_out_reg[23]_i_891_n_3\,
      CYINIT => '1',
      DI(3) => \rgb_out[23]_i_1473_n_0\,
      DI(2) => '0',
      DI(1) => local_y_3(3),
      DI(0) => \rgb_out[23]_i_1474_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_891_O_UNCONNECTED\(3 downto 0),
      S(3) => \rgb_out[23]_i_1475_n_0\,
      S(2) => \rgb_out[23]_i_1476_n_0\,
      S(1) => \rgb_out[23]_i_1477_n_0\,
      S(0) => \rgb_out[23]_i_1478_n_0\
    );
\rgb_out_reg[23]_i_896\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_896_n_0\,
      CO(2) => \rgb_out_reg[23]_i_896_n_1\,
      CO(1) => \rgb_out_reg[23]_i_896_n_2\,
      CO(0) => \rgb_out_reg[23]_i_896_n_3\,
      CYINIT => '1',
      DI(3) => \rgb_out[23]_i_1479_n_0\,
      DI(2) => local_y_3(5),
      DI(1) => \rgb_out[23]_i_1480_n_0\,
      DI(0) => '0',
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_896_O_UNCONNECTED\(3 downto 0),
      S(3) => \rgb_out[23]_i_1481_n_0\,
      S(2) => \rgb_out[23]_i_1482_n_0\,
      S(1) => \rgb_out[23]_i_1483_n_0\,
      S(0) => \rgb_out[23]_i_1484_n_0\
    );
\rgb_out_reg[23]_i_901\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_901_n_0\,
      CO(2) => \rgb_out_reg[23]_i_901_n_1\,
      CO(1) => \rgb_out_reg[23]_i_901_n_2\,
      CO(0) => \rgb_out_reg[23]_i_901_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \rgb_out[23]_i_1485_n_0\,
      DI(1) => '0',
      DI(0) => \rgb_out[23]_i_1486_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_901_O_UNCONNECTED\(3 downto 0),
      S(3) => \rgb_out[23]_i_1487_n_0\,
      S(2) => \rgb_out[23]_i_1488_n_0\,
      S(1) => \rgb_out[23]_i_1489_n_0\,
      S(0) => \rgb_out[23]_i_1490_n_0\
    );
\rgb_out_reg[23]_i_905\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_905_n_0\,
      CO(2) => \rgb_out_reg[23]_i_905_n_1\,
      CO(1) => \rgb_out_reg[23]_i_905_n_2\,
      CO(0) => \rgb_out_reg[23]_i_905_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \rgb_out[23]_i_1491_n_0\,
      DI(0) => \rgb_out[23]_i_1492_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_905_O_UNCONNECTED\(3 downto 0),
      S(3) => \rgb_out[23]_i_1493_n_0\,
      S(2) => \rgb_out[23]_i_1494_n_0\,
      S(1) => \rgb_out[23]_i_1495_n_0\,
      S(0) => \rgb_out[23]_i_1496_n_0\
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity HDMI_bd_compositeur_0_0_compositeur is
  port (
    CO : out STD_LOGIC_VECTOR ( 0 to 0 );
    de_out : out STD_LOGIC;
    hsync_out : out STD_LOGIC;
    vsync_out : out STD_LOGIC;
    local_y : out STD_LOGIC_VECTOR ( 10 downto 0 );
    \rgb_out_reg[0]_0\ : out STD_LOGIC_VECTOR ( 0 to 0 );
    rgb_out : out STD_LOGIC_VECTOR ( 23 downto 0 );
    pixel_x : in STD_LOGIC_VECTOR ( 11 downto 0 );
    pixel_y : in STD_LOGIC_VECTOR ( 11 downto 0 );
    pixel_clk : in STD_LOGIC;
    \pixel_x[1]\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \pixel_x[5]\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \pixel_y[2]\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \pixel_x[1]_0\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \pixel_y[2]_0\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \pixel_x[1]_1\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \pixel_y[2]_1\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \pixel_y[5]\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \pixel_x[1]_2\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \pixel_y[2]_2\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    local_x : in STD_LOGIC_VECTOR ( 11 downto 0 );
    \pixel_x[1]_3\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \pixel_y[2]_3\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    score_courant : in STD_LOGIC_VECTOR ( 3 downto 0 );
    \pixel_y[5]_0\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \pixel_x[1]_4\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \pixel_y[2]_4\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \pixel_y[2]_5\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \pixel_x[6]\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \pixel_x[1]_5\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \pixel_y[2]_6\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \pixel_y[5]_1\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \pixel_y[2]_7\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \pixel_y[2]_8\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \pixel_x[1]_6\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \pixel_y[2]_9\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \pixel_x[1]_7\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \pixel_y[2]_10\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    local_x_0 : in STD_LOGIC_VECTOR ( 11 downto 0 );
    \pixel_x[1]_8\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \pixel_x[7]\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \pixel_x[3]\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \pixel_y[2]_11\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \pixel_x[3]_0\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \pixel_y[2]_12\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \pixel_x[3]_1\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \pixel_y[2]_13\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \pixel_y[5]_2\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \pixel_x[3]_2\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \pixel_y[5]_3\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \pixel_y[2]_14\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \pixel_y[2]_15\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \pixel_y[2]_16\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    local_x_1 : in STD_LOGIC_VECTOR ( 9 downto 0 );
    \pixel_x[3]_3\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \pixel_x[2]\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \pixel_x[2]_0\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \pixel_y[1]\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \pixel_x[2]_1\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \pixel_y[1]_0\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \pixel_x[2]_2\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \pixel_y[1]_1\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \pixel_y[5]_4\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \pixel_x[7]_0\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \pixel_x[2]_3\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \pixel_y[5]_5\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \pixel_y[1]_2\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \pixel_y[1]_3\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \pixel_y[1]_4\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \pixel_x[5]_0\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \pixel_x[2]_4\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \pixel_y[1]_5\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \pixel_y[5]_6\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    score_dernier : in STD_LOGIC_VECTOR ( 3 downto 0 );
    \pixel_y[1]_6\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \pixel_y[1]_7\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \pixel_x[2]_5\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \pixel_x[2]_6\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \pixel_y[1]_8\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \pixel_y[5]_7\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \pixel_y[1]_9\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \pixel_y[1]_10\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \pixel_x[2]_7\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \pixel_y[1]_11\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \pixel_x[2]_8\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \pixel_y[1]_12\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \pixel_x[2]_9\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \pixel_x[2]_10\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \pixel_y[1]_13\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \pixel_x[2]_11\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \pixel_y[1]_14\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \pixel_x[2]_12\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \pixel_y[1]_15\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \pixel_y[5]_8\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \pixel_x[5]_1\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \pixel_x[2]_13\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \pixel_y[5]_9\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \pixel_y[1]_16\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \pixel_y[1]_17\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \pixel_y[1]_18\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \pixel_x[6]_0\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \pixel_x[2]_14\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \pixel_y[1]_19\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \pixel_y[5]_10\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    record_personnel : in STD_LOGIC_VECTOR ( 3 downto 0 );
    \pixel_y[1]_20\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \pixel_y[1]_21\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \pixel_x[2]_15\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \pixel_x[2]_16\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \pixel_y[1]_22\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \pixel_y[5]_11\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \pixel_y[1]_23\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \pixel_y[1]_24\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \pixel_x[2]_17\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \pixel_y[1]_25\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \pixel_x[2]_18\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \pixel_y[1]_26\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    rgb_in : in STD_LOGIC_VECTOR ( 23 downto 0 );
    is_pixel_mur : in STD_LOGIC;
    mode_ui : in STD_LOGIC_VECTOR ( 2 downto 0 );
    temps_restant : in STD_LOGIC_VECTOR ( 3 downto 0 );
    flash_on : in STD_LOGIC;
    decompte_ui : in STD_LOGIC_VECTOR ( 3 downto 0 );
    DI : in STD_LOGIC_VECTOR ( 1 downto 0 );
    S : in STD_LOGIC_VECTOR ( 1 downto 0 );
    \pixel_x[5]_2\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    hsync_in : in STD_LOGIC;
    reset : in STD_LOGIC;
    vsync_in : in STD_LOGIC;
    de_in : in STD_LOGIC
  );
  attribute ORIG_REF_NAME : string;
  attribute ORIG_REF_NAME of HDMI_bd_compositeur_0_0_compositeur : entity is "compositeur";
end HDMI_bd_compositeur_0_0_compositeur;

architecture STRUCTURE of HDMI_bd_compositeur_0_0_compositeur is
  signal \LAST_U/segments\ : STD_LOGIC_VECTOR ( 2 downto 1 );
  signal \REC_U/segments\ : STD_LOGIC_VECTOR ( 2 downto 1 );
  signal \SC_D/pixel_on66_in\ : STD_LOGIC;
  signal \SC_D/pixel_on7\ : STD_LOGIC;
  signal \SC_D/pixel_on83_in\ : STD_LOGIC;
  signal \SC_D/pixel_on9\ : STD_LOGIC;
  signal \SC_U/pixel_on0\ : STD_LOGIC;
  signal \SC_U/pixel_on9\ : STD_LOGIC;
  signal \SC_U/segments\ : STD_LOGIC_VECTOR ( 2 downto 1 );
  signal \TM_D/pixel_on9\ : STD_LOGIC;
  signal TM_U_n_1 : STD_LOGIC;
  signal TM_U_n_10 : STD_LOGIC;
  signal TM_U_n_11 : STD_LOGIC;
  signal TM_U_n_12 : STD_LOGIC;
  signal TM_U_n_13 : STD_LOGIC;
  signal TM_U_n_14 : STD_LOGIC;
  signal TM_U_n_15 : STD_LOGIC;
  signal TM_U_n_16 : STD_LOGIC;
  signal TM_U_n_17 : STD_LOGIC;
  signal TM_U_n_18 : STD_LOGIC;
  signal TM_U_n_19 : STD_LOGIC;
  signal TM_U_n_2 : STD_LOGIC;
  signal TM_U_n_20 : STD_LOGIC;
  signal TM_U_n_21 : STD_LOGIC;
  signal TM_U_n_22 : STD_LOGIC;
  signal TM_U_n_23 : STD_LOGIC;
  signal TM_U_n_24 : STD_LOGIC;
  signal TM_U_n_3 : STD_LOGIC;
  signal TM_U_n_4 : STD_LOGIC;
  signal TM_U_n_5 : STD_LOGIC;
  signal TM_U_n_6 : STD_LOGIC;
  signal TM_U_n_7 : STD_LOGIC;
  signal TM_U_n_8 : STD_LOGIC;
  signal TM_U_n_9 : STD_LOGIC;
  signal de_out_i_1_n_0 : STD_LOGIC;
  signal dernier_diz : STD_LOGIC;
  signal hsync_out_i_1_n_0 : STD_LOGIC;
  signal \^local_y\ : STD_LOGIC_VECTOR ( 10 downto 0 );
  signal num_last_d : STD_LOGIC;
  signal num_last_u : STD_LOGIC;
  signal num_rec_d : STD_LOGIC;
  signal num_rec_u : STD_LOGIC;
  signal num_sc_d : STD_LOGIC;
  signal num_tm_d : STD_LOGIC;
  signal pixel_on22_in : STD_LOGIC;
  signal pixel_on31_in : STD_LOGIC;
  signal pixel_on5 : STD_LOGIC;
  signal pixel_on6 : STD_LOGIC;
  signal pixel_on66_in : STD_LOGIC;
  signal pixel_on7 : STD_LOGIC;
  signal pixel_on712_in : STD_LOGIC;
  signal pixel_on75_in : STD_LOGIC;
  signal pixel_on83_in : STD_LOGIC;
  signal record_diz : STD_LOGIC;
  signal \rgb_out[0]_i_3_n_0\ : STD_LOGIC;
  signal \rgb_out[10]_i_2_n_0\ : STD_LOGIC;
  signal \rgb_out[10]_i_3_n_0\ : STD_LOGIC;
  signal \rgb_out[10]_i_5_n_0\ : STD_LOGIC;
  signal \rgb_out[11]_i_10_n_0\ : STD_LOGIC;
  signal \rgb_out[11]_i_11_n_0\ : STD_LOGIC;
  signal \rgb_out[11]_i_12_n_0\ : STD_LOGIC;
  signal \rgb_out[11]_i_13_n_0\ : STD_LOGIC;
  signal \rgb_out[11]_i_14_n_0\ : STD_LOGIC;
  signal \rgb_out[11]_i_15_n_0\ : STD_LOGIC;
  signal \rgb_out[11]_i_16_n_0\ : STD_LOGIC;
  signal \rgb_out[11]_i_17_n_0\ : STD_LOGIC;
  signal \rgb_out[11]_i_18_n_0\ : STD_LOGIC;
  signal \rgb_out[11]_i_19_n_0\ : STD_LOGIC;
  signal \rgb_out[11]_i_20_n_0\ : STD_LOGIC;
  signal \rgb_out[11]_i_21_n_0\ : STD_LOGIC;
  signal \rgb_out[11]_i_22_n_0\ : STD_LOGIC;
  signal \rgb_out[11]_i_23_n_0\ : STD_LOGIC;
  signal \rgb_out[11]_i_24_n_0\ : STD_LOGIC;
  signal \rgb_out[11]_i_25_n_0\ : STD_LOGIC;
  signal \rgb_out[11]_i_26_n_0\ : STD_LOGIC;
  signal \rgb_out[11]_i_27_n_0\ : STD_LOGIC;
  signal \rgb_out[11]_i_28_n_0\ : STD_LOGIC;
  signal \rgb_out[11]_i_29_n_0\ : STD_LOGIC;
  signal \rgb_out[11]_i_30_n_0\ : STD_LOGIC;
  signal \rgb_out[11]_i_31_n_0\ : STD_LOGIC;
  signal \rgb_out[11]_i_32_n_0\ : STD_LOGIC;
  signal \rgb_out[11]_i_33_n_0\ : STD_LOGIC;
  signal \rgb_out[11]_i_34_n_0\ : STD_LOGIC;
  signal \rgb_out[11]_i_35_n_0\ : STD_LOGIC;
  signal \rgb_out[11]_i_3_n_0\ : STD_LOGIC;
  signal \rgb_out[11]_i_4_n_0\ : STD_LOGIC;
  signal \rgb_out[11]_i_5_n_0\ : STD_LOGIC;
  signal \rgb_out[11]_i_6_n_0\ : STD_LOGIC;
  signal \rgb_out[11]_i_7_n_0\ : STD_LOGIC;
  signal \rgb_out[11]_i_8_n_0\ : STD_LOGIC;
  signal \rgb_out[11]_i_9_n_0\ : STD_LOGIC;
  signal \rgb_out[12]_i_2_n_0\ : STD_LOGIC;
  signal \rgb_out[12]_i_3_n_0\ : STD_LOGIC;
  signal \rgb_out[12]_i_4_n_0\ : STD_LOGIC;
  signal \rgb_out[13]_i_3_n_0\ : STD_LOGIC;
  signal \rgb_out[13]_i_4_n_0\ : STD_LOGIC;
  signal \rgb_out[13]_i_5_n_0\ : STD_LOGIC;
  signal \rgb_out[14]_i_2_n_0\ : STD_LOGIC;
  signal \rgb_out[14]_i_3_n_0\ : STD_LOGIC;
  signal \rgb_out[14]_i_4_n_0\ : STD_LOGIC;
  signal \rgb_out[14]_i_5_n_0\ : STD_LOGIC;
  signal \rgb_out[15]_i_2_n_0\ : STD_LOGIC;
  signal \rgb_out[15]_i_3_n_0\ : STD_LOGIC;
  signal \rgb_out[15]_i_4_n_0\ : STD_LOGIC;
  signal \rgb_out[15]_i_5_n_0\ : STD_LOGIC;
  signal \rgb_out[16]_i_2_n_0\ : STD_LOGIC;
  signal \rgb_out[16]_i_3_n_0\ : STD_LOGIC;
  signal \rgb_out[16]_i_4_n_0\ : STD_LOGIC;
  signal \rgb_out[16]_i_5_n_0\ : STD_LOGIC;
  signal \rgb_out[17]_i_2_n_0\ : STD_LOGIC;
  signal \rgb_out[17]_i_3_n_0\ : STD_LOGIC;
  signal \rgb_out[17]_i_4_n_0\ : STD_LOGIC;
  signal \rgb_out[17]_i_5_n_0\ : STD_LOGIC;
  signal \rgb_out[17]_i_6_n_0\ : STD_LOGIC;
  signal \rgb_out[17]_i_7_n_0\ : STD_LOGIC;
  signal \rgb_out[18]_i_2_n_0\ : STD_LOGIC;
  signal \rgb_out[18]_i_3_n_0\ : STD_LOGIC;
  signal \rgb_out[18]_i_4_n_0\ : STD_LOGIC;
  signal \rgb_out[19]_i_2_n_0\ : STD_LOGIC;
  signal \rgb_out[19]_i_3_n_0\ : STD_LOGIC;
  signal \rgb_out[19]_i_4_n_0\ : STD_LOGIC;
  signal \rgb_out[1]_i_2_n_0\ : STD_LOGIC;
  signal \rgb_out[1]_i_3_n_0\ : STD_LOGIC;
  signal \rgb_out[1]_i_4_n_0\ : STD_LOGIC;
  signal \rgb_out[1]_i_5_n_0\ : STD_LOGIC;
  signal \rgb_out[20]_i_10_n_0\ : STD_LOGIC;
  signal \rgb_out[20]_i_11_n_0\ : STD_LOGIC;
  signal \rgb_out[20]_i_12_n_0\ : STD_LOGIC;
  signal \rgb_out[20]_i_13_n_0\ : STD_LOGIC;
  signal \rgb_out[20]_i_14_n_0\ : STD_LOGIC;
  signal \rgb_out[20]_i_15_n_0\ : STD_LOGIC;
  signal \rgb_out[20]_i_16_n_0\ : STD_LOGIC;
  signal \rgb_out[20]_i_17_n_0\ : STD_LOGIC;
  signal \rgb_out[20]_i_18_n_0\ : STD_LOGIC;
  signal \rgb_out[20]_i_19_n_0\ : STD_LOGIC;
  signal \rgb_out[20]_i_20_n_0\ : STD_LOGIC;
  signal \rgb_out[20]_i_21_n_0\ : STD_LOGIC;
  signal \rgb_out[20]_i_22_n_0\ : STD_LOGIC;
  signal \rgb_out[20]_i_23_n_0\ : STD_LOGIC;
  signal \rgb_out[20]_i_24_n_0\ : STD_LOGIC;
  signal \rgb_out[20]_i_25_n_0\ : STD_LOGIC;
  signal \rgb_out[20]_i_26_n_0\ : STD_LOGIC;
  signal \rgb_out[20]_i_27_n_0\ : STD_LOGIC;
  signal \rgb_out[20]_i_28_n_0\ : STD_LOGIC;
  signal \rgb_out[20]_i_29_n_0\ : STD_LOGIC;
  signal \rgb_out[20]_i_2_n_0\ : STD_LOGIC;
  signal \rgb_out[20]_i_30_n_0\ : STD_LOGIC;
  signal \rgb_out[20]_i_31_n_0\ : STD_LOGIC;
  signal \rgb_out[20]_i_3_n_0\ : STD_LOGIC;
  signal \rgb_out[20]_i_5_n_0\ : STD_LOGIC;
  signal \rgb_out[20]_i_6_n_0\ : STD_LOGIC;
  signal \rgb_out[20]_i_7_n_0\ : STD_LOGIC;
  signal \rgb_out[20]_i_8_n_0\ : STD_LOGIC;
  signal \rgb_out[20]_i_9_n_0\ : STD_LOGIC;
  signal \rgb_out[21]_i_2_n_0\ : STD_LOGIC;
  signal \rgb_out[21]_i_4_n_0\ : STD_LOGIC;
  signal \rgb_out[21]_i_5_n_0\ : STD_LOGIC;
  signal \rgb_out[21]_i_6_n_0\ : STD_LOGIC;
  signal \rgb_out[21]_i_7_n_0\ : STD_LOGIC;
  signal \rgb_out[22]_i_2_n_0\ : STD_LOGIC;
  signal \rgb_out[22]_i_3_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_100_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_101_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_102_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_103_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_108_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_109_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_10_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_110_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_111_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_112_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_113_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_114_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_115_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_116_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_117_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_118_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_119_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_11_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1206_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1207_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1208_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1209_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_120_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1210_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_121_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_122_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_123_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_124_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1254_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1255_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1256_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1257_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_125_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_126_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_127_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_128_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_129_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_12_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1309_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_130_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1310_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1311_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1312_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1318_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1319_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_131_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1320_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1321_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1323_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1324_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1325_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_132_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1332_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1333_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1334_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_133_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_134_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_135_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_136_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_137_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1382_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1383_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1384_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1385_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1386_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1387_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1388_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_138_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_139_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_13_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_140_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_141_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_142_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_143_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_144_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_145_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_146_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_147_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_148_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_149_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_14_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_150_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_151_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_152_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_153_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_154_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_155_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_156_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_157_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_158_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_159_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_15_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_160_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_161_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_162_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_163_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_164_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_165_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_168_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_169_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_16_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_170_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_171_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_172_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_173_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_174_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_175_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_176_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_177_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_178_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_179_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_180_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_181_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_182_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_183_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_184_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_185_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_186_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_187_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_188_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_190_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1928_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1929_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_192_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1930_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1931_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1932_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1933_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1934_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_195_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_196_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1999_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_199_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_19_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2000_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2001_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2009_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_200_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2010_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2012_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2013_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2014_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2015_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2016_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2024_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2025_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2026_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2027_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2028_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2029_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_202_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2030_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2031_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2032_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2033_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2034_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2035_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2036_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2037_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_203_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2044_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2045_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2046_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2047_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2048_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2049_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_204_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2050_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_205_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_206_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_207_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_208_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_209_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_20_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_210_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_211_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2125_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2126_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2127_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2128_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2129_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_212_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2130_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_213_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_214_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_215_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_217_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_218_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_219_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_21_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_220_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_221_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_222_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_223_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_224_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_225_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_226_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_227_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_228_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_229_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_22_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_230_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_231_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_232_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_233_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_234_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_235_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_236_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_237_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_238_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_239_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_23_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_240_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_241_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_242_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_243_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_244_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_245_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_246_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_247_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_248_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_249_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_24_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_250_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_251_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_252_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_253_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_254_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_255_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_256_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_257_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_258_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_259_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_25_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_260_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_261_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_262_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_263_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_264_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_265_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_266_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_267_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_268_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_269_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_26_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_270_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_271_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_272_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_273_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_274_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_275_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_276_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_277_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_278_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_279_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_27_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_280_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_281_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_282_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_283_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_284_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_285_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_286_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_287_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_288_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_289_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_28_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_290_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_291_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_292_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_293_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_294_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_295_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_296_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_297_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_298_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_299_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_29_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_300_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_301_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_302_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_303_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_304_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_305_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_306_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_307_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_308_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_309_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_30_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_310_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_314_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_315_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_316_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_317_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_318_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_319_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_31_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_320_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_321_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_322_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_323_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_324_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_325_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_326_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_327_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_328_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_32_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_332_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_333_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_334_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_335_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_336_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_337_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_338_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_339_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_33_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_340_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_341_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_342_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_343_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_344_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_345_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_346_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_347_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_348_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_349_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_34_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_350_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_351_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_352_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_353_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_354_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_355_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_356_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_357_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_358_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_359_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_35_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_360_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_361_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_362_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_363_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_364_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_365_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_366_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_367_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_368_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_369_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_36_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_370_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_371_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_372_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_373_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_374_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_375_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_376_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_377_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_378_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_379_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_37_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_380_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_381_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_382_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_383_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_384_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_385_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_386_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_387_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_388_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_389_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_38_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_390_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_391_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_392_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_393_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_394_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_395_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_396_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_397_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_398_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_399_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_39_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_3_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_400_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_401_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_402_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_403_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_404_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_405_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_406_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_407_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_408_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_409_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_40_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_410_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_411_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_412_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_413_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_414_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_415_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_416_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_417_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_418_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_419_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_41_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_420_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_421_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_422_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_423_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_424_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_425_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_426_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_427_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_428_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_429_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_42_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_430_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_431_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_432_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_433_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_434_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_435_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_436_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_437_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_43_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_442_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_443_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_444_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_445_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_446_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_447_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_448_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_449_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_44_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_453_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_454_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_455_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_456_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_457_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_458_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_459_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_45_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_460_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_461_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_462_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_463_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_464_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_465_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_466_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_467_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_468_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_469_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_46_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_47_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_48_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_49_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_4_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_50_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_51_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_521_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_522_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_523_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_524_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_525_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_526_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_527_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_528_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_529_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_52_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_530_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_531_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_532_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_533_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_534_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_535_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_536_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_537_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_538_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_539_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_53_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_540_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_541_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_542_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_543_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_544_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_545_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_546_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_547_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_548_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_549_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_54_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_550_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_551_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_552_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_553_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_554_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_555_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_556_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_557_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_558_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_559_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_560_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_561_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_562_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_563_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_564_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_565_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_566_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_567_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_568_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_569_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_570_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_571_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_572_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_573_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_574_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_575_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_576_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_577_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_578_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_579_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_58_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_5_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_60_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_610_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_615_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_618_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_619_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_61_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_621_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_623_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_625_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_627_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_636_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_641_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_644_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_645_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_647_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_649_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_651_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_653_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_65_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_66_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_676_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_677_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_678_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_679_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_67_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_680_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_681_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_682_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_683_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_684_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_685_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_686_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_687_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_688_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_689_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_68_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_690_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_691_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_692_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_693_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_694_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_695_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_696_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_697_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_698_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_699_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_69_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_6_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_700_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_701_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_702_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_703_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_704_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_705_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_706_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_707_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_708_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_709_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_70_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_710_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_711_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_712_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_713_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_71_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_72_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_734_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_736_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_738_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_73_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_744_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_749_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_74_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_75_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_76_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_772_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_773_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_774_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_775_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_776_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_77_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_788_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_789_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_78_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_790_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_791_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_79_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_80_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_81_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_82_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_83_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_84_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_852_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_855_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_856_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_85_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_86_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_87_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_886_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_889_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_88_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_890_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_89_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_8_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_909_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_90_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_910_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_911_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_912_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_913_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_914_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_915_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_916_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_917_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_918_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_919_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_91_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_920_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_921_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_922_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_923_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_924_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_925_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_926_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_92_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_93_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_94_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_95_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_96_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_97_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_98_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_99_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_9_n_0\ : STD_LOGIC;
  signal \rgb_out[2]_i_2_n_0\ : STD_LOGIC;
  signal \rgb_out[2]_i_3_n_0\ : STD_LOGIC;
  signal \rgb_out[2]_i_4_n_0\ : STD_LOGIC;
  signal \rgb_out[5]_i_2_n_0\ : STD_LOGIC;
  signal \rgb_out[5]_i_3_n_0\ : STD_LOGIC;
  signal \rgb_out[6]_i_2_n_0\ : STD_LOGIC;
  signal \rgb_out[6]_i_3_n_0\ : STD_LOGIC;
  signal \rgb_out[6]_i_4_n_0\ : STD_LOGIC;
  signal \rgb_out[7]_i_10_n_0\ : STD_LOGIC;
  signal \rgb_out[7]_i_11_n_0\ : STD_LOGIC;
  signal \rgb_out[7]_i_12_n_0\ : STD_LOGIC;
  signal \rgb_out[7]_i_13_n_0\ : STD_LOGIC;
  signal \rgb_out[7]_i_14_n_0\ : STD_LOGIC;
  signal \rgb_out[7]_i_15_n_0\ : STD_LOGIC;
  signal \rgb_out[7]_i_16_n_0\ : STD_LOGIC;
  signal \rgb_out[7]_i_17_n_0\ : STD_LOGIC;
  signal \rgb_out[7]_i_18_n_0\ : STD_LOGIC;
  signal \rgb_out[7]_i_19_n_0\ : STD_LOGIC;
  signal \rgb_out[7]_i_20_n_0\ : STD_LOGIC;
  signal \rgb_out[7]_i_21_n_0\ : STD_LOGIC;
  signal \rgb_out[7]_i_22_n_0\ : STD_LOGIC;
  signal \rgb_out[7]_i_23_n_0\ : STD_LOGIC;
  signal \rgb_out[7]_i_24_n_0\ : STD_LOGIC;
  signal \rgb_out[7]_i_25_n_0\ : STD_LOGIC;
  signal \rgb_out[7]_i_26_n_0\ : STD_LOGIC;
  signal \rgb_out[7]_i_27_n_0\ : STD_LOGIC;
  signal \rgb_out[7]_i_28_n_0\ : STD_LOGIC;
  signal \rgb_out[7]_i_29_n_0\ : STD_LOGIC;
  signal \rgb_out[7]_i_30_n_0\ : STD_LOGIC;
  signal \rgb_out[7]_i_31_n_0\ : STD_LOGIC;
  signal \rgb_out[7]_i_32_n_0\ : STD_LOGIC;
  signal \rgb_out[7]_i_33_n_0\ : STD_LOGIC;
  signal \rgb_out[7]_i_34_n_0\ : STD_LOGIC;
  signal \rgb_out[7]_i_35_n_0\ : STD_LOGIC;
  signal \rgb_out[7]_i_36_n_0\ : STD_LOGIC;
  signal \rgb_out[7]_i_37_n_0\ : STD_LOGIC;
  signal \rgb_out[7]_i_38_n_0\ : STD_LOGIC;
  signal \rgb_out[7]_i_39_n_0\ : STD_LOGIC;
  signal \rgb_out[7]_i_40_n_0\ : STD_LOGIC;
  signal \rgb_out[7]_i_41_n_0\ : STD_LOGIC;
  signal \rgb_out[7]_i_42_n_0\ : STD_LOGIC;
  signal \rgb_out[7]_i_43_n_0\ : STD_LOGIC;
  signal \rgb_out[7]_i_44_n_0\ : STD_LOGIC;
  signal \rgb_out[7]_i_45_n_0\ : STD_LOGIC;
  signal \rgb_out[7]_i_46_n_0\ : STD_LOGIC;
  signal \rgb_out[7]_i_47_n_0\ : STD_LOGIC;
  signal \rgb_out[7]_i_48_n_0\ : STD_LOGIC;
  signal \rgb_out[7]_i_49_n_0\ : STD_LOGIC;
  signal \rgb_out[7]_i_4_n_0\ : STD_LOGIC;
  signal \rgb_out[7]_i_50_n_0\ : STD_LOGIC;
  signal \rgb_out[7]_i_51_n_0\ : STD_LOGIC;
  signal \rgb_out[7]_i_52_n_0\ : STD_LOGIC;
  signal \rgb_out[7]_i_53_n_0\ : STD_LOGIC;
  signal \rgb_out[7]_i_54_n_0\ : STD_LOGIC;
  signal \rgb_out[7]_i_55_n_0\ : STD_LOGIC;
  signal \rgb_out[7]_i_56_n_0\ : STD_LOGIC;
  signal \rgb_out[7]_i_57_n_0\ : STD_LOGIC;
  signal \rgb_out[7]_i_58_n_0\ : STD_LOGIC;
  signal \rgb_out[7]_i_59_n_0\ : STD_LOGIC;
  signal \rgb_out[7]_i_5_n_0\ : STD_LOGIC;
  signal \rgb_out[7]_i_60_n_0\ : STD_LOGIC;
  signal \rgb_out[7]_i_61_n_0\ : STD_LOGIC;
  signal \rgb_out[7]_i_62_n_0\ : STD_LOGIC;
  signal \rgb_out[7]_i_63_n_0\ : STD_LOGIC;
  signal \rgb_out[7]_i_64_n_0\ : STD_LOGIC;
  signal \rgb_out[7]_i_65_n_0\ : STD_LOGIC;
  signal \rgb_out[7]_i_66_n_0\ : STD_LOGIC;
  signal \rgb_out[7]_i_67_n_0\ : STD_LOGIC;
  signal \rgb_out[7]_i_68_n_0\ : STD_LOGIC;
  signal \rgb_out[7]_i_69_n_0\ : STD_LOGIC;
  signal \rgb_out[7]_i_6_n_0\ : STD_LOGIC;
  signal \rgb_out[7]_i_70_n_0\ : STD_LOGIC;
  signal \rgb_out[7]_i_71_n_0\ : STD_LOGIC;
  signal \rgb_out[7]_i_72_n_0\ : STD_LOGIC;
  signal \rgb_out[7]_i_73_n_0\ : STD_LOGIC;
  signal \rgb_out[7]_i_74_n_0\ : STD_LOGIC;
  signal \rgb_out[7]_i_75_n_0\ : STD_LOGIC;
  signal \rgb_out[7]_i_76_n_0\ : STD_LOGIC;
  signal \rgb_out[7]_i_77_n_0\ : STD_LOGIC;
  signal \rgb_out[7]_i_78_n_0\ : STD_LOGIC;
  signal \rgb_out[7]_i_79_n_0\ : STD_LOGIC;
  signal \rgb_out[7]_i_7_n_0\ : STD_LOGIC;
  signal \rgb_out[7]_i_80_n_0\ : STD_LOGIC;
  signal \rgb_out[7]_i_81_n_0\ : STD_LOGIC;
  signal \rgb_out[7]_i_82_n_0\ : STD_LOGIC;
  signal \rgb_out[7]_i_83_n_0\ : STD_LOGIC;
  signal \rgb_out[7]_i_84_n_0\ : STD_LOGIC;
  signal \rgb_out[7]_i_85_n_0\ : STD_LOGIC;
  signal \rgb_out[7]_i_8_n_0\ : STD_LOGIC;
  signal \rgb_out[7]_i_9_n_0\ : STD_LOGIC;
  signal \rgb_out[8]_i_2_n_0\ : STD_LOGIC;
  signal \rgb_out[8]_i_3_n_0\ : STD_LOGIC;
  signal \rgb_out[8]_i_4_n_0\ : STD_LOGIC;
  signal \^rgb_out_reg[0]_0\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal \rgb_out_reg[23]_i_1253_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1253_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1253_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1253_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1300_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1300_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1308_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1308_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1308_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1308_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1317_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1317_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1317_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1317_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1322_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1322_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1322_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1322_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1331_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1331_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1331_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1331_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1998_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1998_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1998_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1998_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_2003_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_2003_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_2003_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_2003_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_472_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_472_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_733_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_733_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_752_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_752_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_754_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_754_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_755_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_755_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_757_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_757_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_787_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_787_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_787_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_787_n_3\ : STD_LOGIC;
  signal score_diz : STD_LOGIC;
  signal vsync_out_i_1_n_0 : STD_LOGIC;
  signal \NLW_rgb_out_reg[23]_i_1253_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_1300_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 2 to 2 );
  signal \NLW_rgb_out_reg[23]_i_1300_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_rgb_out_reg[23]_i_1308_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_1317_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_1322_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_1331_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_472_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_rgb_out_reg[23]_i_472_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_733_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_rgb_out_reg[23]_i_733_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_752_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_rgb_out_reg[23]_i_752_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_754_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_rgb_out_reg[23]_i_754_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_755_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_rgb_out_reg[23]_i_755_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_757_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_rgb_out_reg[23]_i_757_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_787_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  attribute SOFT_HLUTNM : string;
  attribute SOFT_HLUTNM of hsync_out_i_1 : label is "soft_lutpair128";
  attribute SOFT_HLUTNM of \rgb_out[10]_i_5\ : label is "soft_lutpair3";
  attribute SOFT_HLUTNM of \rgb_out[11]_i_20\ : label is "soft_lutpair17";
  attribute SOFT_HLUTNM of \rgb_out[11]_i_21\ : label is "soft_lutpair127";
  attribute SOFT_HLUTNM of \rgb_out[11]_i_22\ : label is "soft_lutpair134";
  attribute SOFT_HLUTNM of \rgb_out[11]_i_23\ : label is "soft_lutpair46";
  attribute SOFT_HLUTNM of \rgb_out[11]_i_24\ : label is "soft_lutpair73";
  attribute SOFT_HLUTNM of \rgb_out[11]_i_26\ : label is "soft_lutpair104";
  attribute SOFT_HLUTNM of \rgb_out[11]_i_28\ : label is "soft_lutpair74";
  attribute SOFT_HLUTNM of \rgb_out[11]_i_29\ : label is "soft_lutpair117";
  attribute SOFT_HLUTNM of \rgb_out[11]_i_31\ : label is "soft_lutpair115";
  attribute SOFT_HLUTNM of \rgb_out[11]_i_32\ : label is "soft_lutpair80";
  attribute SOFT_HLUTNM of \rgb_out[11]_i_33\ : label is "soft_lutpair44";
  attribute SOFT_HLUTNM of \rgb_out[11]_i_34\ : label is "soft_lutpair137";
  attribute SOFT_HLUTNM of \rgb_out[11]_i_35\ : label is "soft_lutpair98";
  attribute SOFT_HLUTNM of \rgb_out[11]_i_4\ : label is "soft_lutpair2";
  attribute SOFT_HLUTNM of \rgb_out[11]_i_7\ : label is "soft_lutpair14";
  attribute SOFT_HLUTNM of \rgb_out[12]_i_2\ : label is "soft_lutpair105";
  attribute SOFT_HLUTNM of \rgb_out[13]_i_4\ : label is "soft_lutpair79";
  attribute SOFT_HLUTNM of \rgb_out[14]_i_5\ : label is "soft_lutpair94";
  attribute SOFT_HLUTNM of \rgb_out[15]_i_2\ : label is "soft_lutpair97";
  attribute SOFT_HLUTNM of \rgb_out[16]_i_2\ : label is "soft_lutpair107";
  attribute SOFT_HLUTNM of \rgb_out[17]_i_3\ : label is "soft_lutpair116";
  attribute SOFT_HLUTNM of \rgb_out[17]_i_4\ : label is "soft_lutpair79";
  attribute SOFT_HLUTNM of \rgb_out[17]_i_7\ : label is "soft_lutpair116";
  attribute SOFT_HLUTNM of \rgb_out[18]_i_2\ : label is "soft_lutpair105";
  attribute SOFT_HLUTNM of \rgb_out[19]_i_2\ : label is "soft_lutpair102";
  attribute SOFT_HLUTNM of \rgb_out[1]_i_2\ : label is "soft_lutpair107";
  attribute SOFT_HLUTNM of \rgb_out[1]_i_3\ : label is "soft_lutpair52";
  attribute SOFT_HLUTNM of \rgb_out[20]_i_16\ : label is "soft_lutpair125";
  attribute SOFT_HLUTNM of \rgb_out[20]_i_17\ : label is "soft_lutpair87";
  attribute SOFT_HLUTNM of \rgb_out[20]_i_19\ : label is "soft_lutpair35";
  attribute SOFT_HLUTNM of \rgb_out[20]_i_2\ : label is "soft_lutpair93";
  attribute SOFT_HLUTNM of \rgb_out[20]_i_20\ : label is "soft_lutpair37";
  attribute SOFT_HLUTNM of \rgb_out[20]_i_24\ : label is "soft_lutpair120";
  attribute SOFT_HLUTNM of \rgb_out[20]_i_25\ : label is "soft_lutpair135";
  attribute SOFT_HLUTNM of \rgb_out[20]_i_27\ : label is "soft_lutpair137";
  attribute SOFT_HLUTNM of \rgb_out[20]_i_28\ : label is "soft_lutpair34";
  attribute SOFT_HLUTNM of \rgb_out[20]_i_29\ : label is "soft_lutpair73";
  attribute SOFT_HLUTNM of \rgb_out[20]_i_3\ : label is "soft_lutpair102";
  attribute SOFT_HLUTNM of \rgb_out[20]_i_30\ : label is "soft_lutpair121";
  attribute SOFT_HLUTNM of \rgb_out[20]_i_31\ : label is "soft_lutpair67";
  attribute SOFT_HLUTNM of \rgb_out[20]_i_6\ : label is "soft_lutpair3";
  attribute SOFT_HLUTNM of \rgb_out[20]_i_9\ : label is "soft_lutpair16";
  attribute SOFT_HLUTNM of \rgb_out[21]_i_4\ : label is "soft_lutpair2";
  attribute SOFT_HLUTNM of \rgb_out[21]_i_6\ : label is "soft_lutpair104";
  attribute SOFT_HLUTNM of \rgb_out[21]_i_7\ : label is "soft_lutpair87";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_101\ : label is "soft_lutpair136";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_118\ : label is "soft_lutpair18";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_1207\ : label is "soft_lutpair6";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_1208\ : label is "soft_lutpair48";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_1209\ : label is "soft_lutpair21";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_1210\ : label is "soft_lutpair54";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_128\ : label is "soft_lutpair8";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_13\ : label is "soft_lutpair93";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_134\ : label is "soft_lutpair24";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_135\ : label is "soft_lutpair53";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_136\ : label is "soft_lutpair68";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_137\ : label is "soft_lutpair121";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_138\ : label is "soft_lutpair113";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_139\ : label is "soft_lutpair108";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_145\ : label is "soft_lutpair66";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_172\ : label is "soft_lutpair29";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_175\ : label is "soft_lutpair96";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_176\ : label is "soft_lutpair100";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_179\ : label is "soft_lutpair29";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_190\ : label is "soft_lutpair45";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_196\ : label is "soft_lutpair41";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_199\ : label is "soft_lutpair92";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_202\ : label is "soft_lutpair41";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_204\ : label is "soft_lutpair45";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_212\ : label is "soft_lutpair92";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_213\ : label is "soft_lutpair42";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_215\ : label is "soft_lutpair82";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_219\ : label is "soft_lutpair123";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_22\ : label is "soft_lutpair65";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_221\ : label is "soft_lutpair123";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_222\ : label is "soft_lutpair80";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_223\ : label is "soft_lutpair96";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_224\ : label is "soft_lutpair118";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_225\ : label is "soft_lutpair133";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_226\ : label is "soft_lutpair131";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_228\ : label is "soft_lutpair46";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_230\ : label is "soft_lutpair28";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_233\ : label is "soft_lutpair135";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_234\ : label is "soft_lutpair8";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_235\ : label is "soft_lutpair119";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_236\ : label is "soft_lutpair113";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_237\ : label is "soft_lutpair68";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_238\ : label is "soft_lutpair78";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_239\ : label is "soft_lutpair95";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_241\ : label is "soft_lutpair129";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_244\ : label is "soft_lutpair16";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_245\ : label is "soft_lutpair22";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_246\ : label is "soft_lutpair59";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_247\ : label is "soft_lutpair120";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_263\ : label is "soft_lutpair129";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_265\ : label is "soft_lutpair108";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_266\ : label is "soft_lutpair95";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_282\ : label is "soft_lutpair0";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_3\ : label is "soft_lutpair103";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_300\ : label is "soft_lutpair100";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_305\ : label is "soft_lutpair67";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_307\ : label is "soft_lutpair114";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_330\ : label is "soft_lutpair110";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_333\ : label is "soft_lutpair130";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_334\ : label is "soft_lutpair114";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_335\ : label is "soft_lutpair11";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_337\ : label is "soft_lutpair35";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_338\ : label is "soft_lutpair1";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_339\ : label is "soft_lutpair10";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_344\ : label is "soft_lutpair72";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_345\ : label is "soft_lutpair11";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_346\ : label is "soft_lutpair39";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_347\ : label is "soft_lutpair122";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_348\ : label is "soft_lutpair26";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_349\ : label is "soft_lutpair76";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_350\ : label is "soft_lutpair49";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_351\ : label is "soft_lutpair122";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_352\ : label is "soft_lutpair57";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_353\ : label is "soft_lutpair131";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_362\ : label is "soft_lutpair47";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_363\ : label is "soft_lutpair132";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_366\ : label is "soft_lutpair71";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_367\ : label is "soft_lutpair17";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_368\ : label is "soft_lutpair25";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_369\ : label is "soft_lutpair53";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_372\ : label is "soft_lutpair12";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_373\ : label is "soft_lutpair9";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_375\ : label is "soft_lutpair56";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_377\ : label is "soft_lutpair15";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_380\ : label is "soft_lutpair32";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_381\ : label is "soft_lutpair38";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_382\ : label is "soft_lutpair74";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_383\ : label is "soft_lutpair37";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_384\ : label is "soft_lutpair32";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_385\ : label is "soft_lutpair30";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_389\ : label is "soft_lutpair127";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_39\ : label is "soft_lutpair76";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_392\ : label is "soft_lutpair133";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_393\ : label is "soft_lutpair111";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_40\ : label is "soft_lutpair58";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_401\ : label is "soft_lutpair55";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_408\ : label is "soft_lutpair89";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_416\ : label is "soft_lutpair15";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_423\ : label is "soft_lutpair124";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_424\ : label is "soft_lutpair54";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_425\ : label is "soft_lutpair48";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_434\ : label is "soft_lutpair21";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_437\ : label is "soft_lutpair40";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_44\ : label is "soft_lutpair66";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_442\ : label is "soft_lutpair62";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_444\ : label is "soft_lutpair20";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_445\ : label is "soft_lutpair62";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_455\ : label is "soft_lutpair89";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_462\ : label is "soft_lutpair72";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_466\ : label is "soft_lutpair134";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_469\ : label is "soft_lutpair38";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_522\ : label is "soft_lutpair4";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_537\ : label is "soft_lutpair55";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_539\ : label is "soft_lutpair42";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_54\ : label is "soft_lutpair94";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_540\ : label is "soft_lutpair34";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_543\ : label is "soft_lutpair56";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_544\ : label is "soft_lutpair117";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_546\ : label is "soft_lutpair19";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_552\ : label is "soft_lutpair49";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_553\ : label is "soft_lutpair63";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_555\ : label is "soft_lutpair13";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_556\ : label is "soft_lutpair6";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_557\ : label is "soft_lutpair33";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_561\ : label is "soft_lutpair75";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_562\ : label is "soft_lutpair75";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_563\ : label is "soft_lutpair23";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_564\ : label is "soft_lutpair91";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_565\ : label is "soft_lutpair85";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_566\ : label is "soft_lutpair40";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_567\ : label is "soft_lutpair126";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_568\ : label is "soft_lutpair27";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_570\ : label is "soft_lutpair10";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_572\ : label is "soft_lutpair30";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_575\ : label is "soft_lutpair5";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_578\ : label is "soft_lutpair85";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_608\ : label is "soft_lutpair61";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_61\ : label is "soft_lutpair82";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_610\ : label is "soft_lutpair83";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_614\ : label is "soft_lutpair83";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_615\ : label is "soft_lutpair61";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_618\ : label is "soft_lutpair110";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_619\ : label is "soft_lutpair60";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_621\ : label is "soft_lutpair90";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_625\ : label is "soft_lutpair90";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_627\ : label is "soft_lutpair60";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_634\ : label is "soft_lutpair77";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_636\ : label is "soft_lutpair86";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_640\ : label is "soft_lutpair77";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_641\ : label is "soft_lutpair86";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_644\ : label is "soft_lutpair101";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_645\ : label is "soft_lutpair84";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_647\ : label is "soft_lutpair70";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_649\ : label is "soft_lutpair101";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_651\ : label is "soft_lutpair84";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_653\ : label is "soft_lutpair70";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_67\ : label is "soft_lutpair98";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_676\ : label is "soft_lutpair111";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_678\ : label is "soft_lutpair26";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_680\ : label is "soft_lutpair5";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_683\ : label is "soft_lutpair78";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_686\ : label is "soft_lutpair4";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_687\ : label is "soft_lutpair19";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_689\ : label is "soft_lutpair119";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_690\ : label is "soft_lutpair59";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_702\ : label is "soft_lutpair44";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_705\ : label is "soft_lutpair22";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_706\ : label is "soft_lutpair28";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_707\ : label is "soft_lutpair132";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_708\ : label is "soft_lutpair7";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_710\ : label is "soft_lutpair36";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_713\ : label is "soft_lutpair91";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_734\ : label is "soft_lutpair20";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_736\ : label is "soft_lutpair88";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_738\ : label is "soft_lutpair81";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_74\ : label is "soft_lutpair65";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_742\ : label is "soft_lutpair81";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_744\ : label is "soft_lutpair64";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_748\ : label is "soft_lutpair64";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_749\ : label is "soft_lutpair88";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_8\ : label is "soft_lutpair52";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_909\ : label is "soft_lutpair7";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_910\ : label is "soft_lutpair63";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_911\ : label is "soft_lutpair18";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_912\ : label is "soft_lutpair12";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_913\ : label is "soft_lutpair47";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_914\ : label is "soft_lutpair50";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_916\ : label is "soft_lutpair23";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_917\ : label is "soft_lutpair24";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_918\ : label is "soft_lutpair115";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_919\ : label is "soft_lutpair39";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_920\ : label is "soft_lutpair124";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_921\ : label is "soft_lutpair126";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_922\ : label is "soft_lutpair50";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_923\ : label is "soft_lutpair43";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_924\ : label is "soft_lutpair106";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_925\ : label is "soft_lutpair69";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_926\ : label is "soft_lutpair27";
  attribute SOFT_HLUTNM of \rgb_out[23]_i_97\ : label is "soft_lutpair136";
  attribute SOFT_HLUTNM of \rgb_out[2]_i_2\ : label is "soft_lutpair99";
  attribute SOFT_HLUTNM of \rgb_out[6]_i_2\ : label is "soft_lutpair99";
  attribute SOFT_HLUTNM of \rgb_out[7]_i_20\ : label is "soft_lutpair51";
  attribute SOFT_HLUTNM of \rgb_out[7]_i_22\ : label is "soft_lutpair109";
  attribute SOFT_HLUTNM of \rgb_out[7]_i_23\ : label is "soft_lutpair51";
  attribute SOFT_HLUTNM of \rgb_out[7]_i_25\ : label is "soft_lutpair33";
  attribute SOFT_HLUTNM of \rgb_out[7]_i_26\ : label is "soft_lutpair1";
  attribute SOFT_HLUTNM of \rgb_out[7]_i_35\ : label is "soft_lutpair31";
  attribute SOFT_HLUTNM of \rgb_out[7]_i_37\ : label is "soft_lutpair106";
  attribute SOFT_HLUTNM of \rgb_out[7]_i_38\ : label is "soft_lutpair0";
  attribute SOFT_HLUTNM of \rgb_out[7]_i_63\ : label is "soft_lutpair43";
  attribute SOFT_HLUTNM of \rgb_out[7]_i_64\ : label is "soft_lutpair36";
  attribute SOFT_HLUTNM of \rgb_out[7]_i_65\ : label is "soft_lutpair125";
  attribute SOFT_HLUTNM of \rgb_out[7]_i_66\ : label is "soft_lutpair25";
  attribute SOFT_HLUTNM of \rgb_out[7]_i_67\ : label is "soft_lutpair112";
  attribute SOFT_HLUTNM of \rgb_out[7]_i_69\ : label is "soft_lutpair71";
  attribute SOFT_HLUTNM of \rgb_out[7]_i_70\ : label is "soft_lutpair13";
  attribute SOFT_HLUTNM of \rgb_out[7]_i_76\ : label is "soft_lutpair130";
  attribute SOFT_HLUTNM of \rgb_out[7]_i_77\ : label is "soft_lutpair57";
  attribute SOFT_HLUTNM of \rgb_out[7]_i_79\ : label is "soft_lutpair9";
  attribute SOFT_HLUTNM of \rgb_out[7]_i_8\ : label is "soft_lutpair103";
  attribute SOFT_HLUTNM of \rgb_out[7]_i_80\ : label is "soft_lutpair112";
  attribute SOFT_HLUTNM of \rgb_out[7]_i_81\ : label is "soft_lutpair31";
  attribute SOFT_HLUTNM of \rgb_out[7]_i_82\ : label is "soft_lutpair58";
  attribute SOFT_HLUTNM of \rgb_out[7]_i_83\ : label is "soft_lutpair69";
  attribute SOFT_HLUTNM of \rgb_out[7]_i_84\ : label is "soft_lutpair14";
  attribute SOFT_HLUTNM of \rgb_out[7]_i_85\ : label is "soft_lutpair118";
  attribute SOFT_HLUTNM of \rgb_out[7]_i_9\ : label is "soft_lutpair109";
  attribute SOFT_HLUTNM of \rgb_out[8]_i_2\ : label is "soft_lutpair97";
  attribute SOFT_HLUTNM of vsync_out_i_1 : label is "soft_lutpair128";
begin
  local_y(10 downto 0) <= \^local_y\(10 downto 0);
  \rgb_out_reg[0]_0\(0) <= \^rgb_out_reg[0]_0\(0);
TM_U: entity work.\HDMI_bd_compositeur_0_0_chiffre_7seg__parameterized2\
     port map (
      CO(0) => CO(0),
      D(23) => TM_U_n_1,
      D(22) => TM_U_n_2,
      D(21) => TM_U_n_3,
      D(20) => TM_U_n_4,
      D(19) => TM_U_n_5,
      D(18) => TM_U_n_6,
      D(17) => TM_U_n_7,
      D(16) => TM_U_n_8,
      D(15) => TM_U_n_9,
      D(14) => TM_U_n_10,
      D(13) => TM_U_n_11,
      D(12) => TM_U_n_12,
      D(11) => TM_U_n_13,
      D(10) => TM_U_n_14,
      D(9) => TM_U_n_15,
      D(8) => TM_U_n_16,
      D(7) => TM_U_n_17,
      D(6) => TM_U_n_18,
      D(5) => TM_U_n_19,
      D(4) => TM_U_n_20,
      D(3) => TM_U_n_21,
      D(2) => TM_U_n_22,
      D(1) => TM_U_n_23,
      D(0) => TM_U_n_24,
      DI(0) => \rgb_out[23]_i_852_n_0\,
      S(1) => \rgb_out[23]_i_855_n_0\,
      S(0) => \rgb_out[23]_i_856_n_0\,
      decompte_ui(3 downto 0) => decompte_ui(3 downto 0),
      decompte_ui_1_sp_1 => \rgb_out[23]_i_61_n_0\,
      is_pixel_mur => is_pixel_mur,
      mode_ui(2 downto 0) => mode_ui(2 downto 0),
      \mode_ui[0]_0\ => \rgb_out[23]_i_3_n_0\,
      \mode_ui[2]_0\ => \rgb_out[7]_i_8_n_0\,
      \mode_ui[2]_1\ => \rgb_out[23]_i_54_n_0\,
      mode_ui_0_sp_1 => \rgb_out[17]_i_3_n_0\,
      mode_ui_1_sp_1 => \rgb_out[14]_i_5_n_0\,
      mode_ui_2_sp_1 => \rgb_out[11]_i_4_n_0\,
      num_tm_d => num_tm_d,
      pixel_x(11 downto 0) => pixel_x(11 downto 0),
      \pixel_x[1]_0\ => \rgb_out[23]_i_6_n_0\,
      \pixel_x[1]_1\(0) => \rgb_out[23]_i_886_n_0\,
      \pixel_x[2]_0\ => \rgb_out[10]_i_3_n_0\,
      \pixel_x[2]_1\ => \rgb_out[17]_i_4_n_0\,
      \pixel_x[2]_10\ => \rgb_out[12]_i_3_n_0\,
      \pixel_x[2]_11\ => \rgb_out[14]_i_3_n_0\,
      \pixel_x[2]_12\ => \rgb_out[15]_i_3_n_0\,
      \pixel_x[2]_13\ => \rgb_out[16]_i_3_n_0\,
      \pixel_x[2]_14\ => \rgb_out[17]_i_5_n_0\,
      \pixel_x[2]_15\ => \rgb_out[18]_i_3_n_0\,
      \pixel_x[2]_16\ => \rgb_out[19]_i_3_n_0\,
      \pixel_x[2]_17\ => \rgb_out[20]_i_5_n_0\,
      \pixel_x[2]_18\ => \rgb_out[21]_i_2_n_0\,
      \pixel_x[2]_19\ => \rgb_out[22]_i_2_n_0\,
      \pixel_x[2]_2\ => \rgb_out[11]_i_3_n_0\,
      \pixel_x[2]_20\ => \rgb_out[22]_i_3_n_0\,
      \pixel_x[2]_21\ => \rgb_out[23]_i_4_n_0\,
      \pixel_x[2]_22\ => \rgb_out[23]_i_5_n_0\,
      \pixel_x[2]_23\ => \rgb_out[7]_i_4_n_0\,
      \pixel_x[2]_24\ => \rgb_out[7]_i_5_n_0\,
      \pixel_x[2]_25\ => \rgb_out[7]_i_6_n_0\,
      \pixel_x[2]_26\(1 downto 0) => DI(1 downto 0),
      \pixel_x[2]_3\ => \rgb_out[13]_i_4_n_0\,
      \pixel_x[2]_4\ => \rgb_out[1]_i_4_n_0\,
      \pixel_x[2]_5\ => \rgb_out[20]_i_6_n_0\,
      \pixel_x[2]_6\ => \rgb_out[2]_i_3_n_0\,
      \pixel_x[2]_7\ => \rgb_out[5]_i_3_n_0\,
      \pixel_x[2]_8\ => \rgb_out[6]_i_3_n_0\,
      \pixel_x[2]_9\ => \rgb_out[8]_i_3_n_0\,
      \pixel_x[3]_0\ => \rgb_out[1]_i_5_n_0\,
      \pixel_x[3]_1\ => \rgb_out[2]_i_4_n_0\,
      \pixel_x[3]_10\ => \rgb_out[19]_i_4_n_0\,
      \pixel_x[3]_11\ => \rgb_out[20]_i_7_n_0\,
      \pixel_x[3]_12\ => \rgb_out[7]_i_7_n_0\,
      \pixel_x[3]_13\(1) => \rgb_out[23]_i_889_n_0\,
      \pixel_x[3]_13\(0) => \rgb_out[23]_i_890_n_0\,
      \pixel_x[3]_14\(1 downto 0) => S(1 downto 0),
      \pixel_x[3]_2\ => \rgb_out[6]_i_4_n_0\,
      \pixel_x[3]_3\ => \rgb_out[8]_i_4_n_0\,
      \pixel_x[3]_4\ => \rgb_out[12]_i_4_n_0\,
      \pixel_x[3]_5\ => \rgb_out[14]_i_4_n_0\,
      \pixel_x[3]_6\ => \rgb_out[15]_i_4_n_0\,
      \pixel_x[3]_7\ => \rgb_out[16]_i_4_n_0\,
      \pixel_x[3]_8\ => \rgb_out[17]_i_6_n_0\,
      \pixel_x[3]_9\ => \rgb_out[18]_i_4_n_0\,
      \pixel_x[5]_0\ => \rgb_out[23]_i_58_n_0\,
      \pixel_x[5]_1\ => \rgb_out[23]_i_217_n_0\,
      \pixel_x[5]_2\ => \rgb_out[23]_i_218_n_0\,
      \pixel_x[5]_3\(0) => \pixel_x[5]_2\(0),
      pixel_x_1_sp_1 => \rgb_out[23]_i_15_n_0\,
      pixel_x_2_sp_1 => \rgb_out[10]_i_2_n_0\,
      pixel_x_3_sp_1 => \rgb_out[13]_i_3_n_0\,
      pixel_x_4_sp_1 => \rgb_out[23]_i_16_n_0\,
      pixel_x_5_sp_1 => \rgb_out[10]_i_5_n_0\,
      pixel_x_8_sp_1 => \rgb_out[23]_i_60_n_0\,
      pixel_y(11 downto 0) => pixel_y(11 downto 0),
      \pixel_y[2]_0\ => \rgb_out[23]_i_213_n_0\,
      \pixel_y[2]_1\ => \rgb_out[23]_i_215_n_0\,
      \pixel_y[2]_2\ => \rgb_out[23]_i_212_n_0\,
      \pixel_y[2]_3\ => \rgb_out[23]_i_203_n_0\,
      \pixel_y[2]_4\ => \rgb_out[23]_i_204_n_0\,
      \pixel_y[4]_0\ => \rgb_out[21]_i_5_n_0\,
      \pixel_y[4]_1\ => \rgb_out[5]_i_2_n_0\,
      \pixel_y[4]_10\ => \rgb_out[16]_i_2_n_0\,
      \pixel_y[4]_11\ => \rgb_out[17]_i_2_n_0\,
      \pixel_y[4]_12\ => \rgb_out[18]_i_2_n_0\,
      \pixel_y[4]_13\ => \rgb_out[19]_i_2_n_0\,
      \pixel_y[4]_14\ => \rgb_out[20]_i_3_n_0\,
      \pixel_y[4]_2\ => \rgb_out[15]_i_5_n_0\,
      \pixel_y[4]_3\ => \rgb_out[1]_i_2_n_0\,
      \pixel_y[4]_4\ => \rgb_out[2]_i_2_n_0\,
      \pixel_y[4]_5\ => \rgb_out[6]_i_2_n_0\,
      \pixel_y[4]_6\ => \rgb_out[8]_i_2_n_0\,
      \pixel_y[4]_7\ => \rgb_out[12]_i_2_n_0\,
      \pixel_y[4]_8\ => \rgb_out[14]_i_2_n_0\,
      \pixel_y[4]_9\ => \rgb_out[15]_i_2_n_0\,
      \pixel_y[5]_0\ => \rgb_out[23]_i_211_n_0\,
      \pixel_y[5]_1\ => \rgb_out[23]_i_202_n_0\,
      \pixel_y[9]_0\ => \rgb_out[1]_i_3_n_0\,
      \pixel_y[9]_1\ => \rgb_out[23]_i_8_n_0\,
      pixel_y_2_sp_1 => \rgb_out[23]_i_195_n_0\,
      pixel_y_4_sp_1 => \rgb_out[0]_i_3_n_0\,
      pixel_y_5_sp_1 => \rgb_out[23]_i_214_n_0\,
      pixel_y_6_sp_1 => \rgb_out[11]_i_5_n_0\,
      pixel_y_7_sp_1 => \rgb_out[13]_i_5_n_0\,
      pixel_y_9_sp_1 => \rgb_out[20]_i_2_n_0\,
      rgb_in(11 downto 9) => rgb_in(23 downto 21),
      rgb_in(8) => rgb_in(13),
      rgb_in(7 downto 5) => rgb_in(11 downto 9),
      rgb_in(4) => rgb_in(7),
      rgb_in(3 downto 1) => rgb_in(5 downto 3),
      rgb_in(0) => rgb_in(0),
      \rgb_out_reg[20]\(0) => pixel_on83_in,
      \rgb_out_reg[20]_0\(0) => pixel_on7,
      \rgb_out_reg[20]_1\(0) => pixel_on22_in,
      \rgb_out_reg[20]_2\(0) => pixel_on31_in,
      \rgb_out_reg[20]_3\(0) => pixel_on5,
      \rgb_out_reg[20]_4\(0) => pixel_on712_in,
      \rgb_out_reg[20]_5\(0) => pixel_on66_in,
      \rgb_out_reg[20]_6\(0) => pixel_on75_in,
      \rgb_out_reg[20]_7\(0) => pixel_on6,
      \temps_restant[2]\ => \rgb_out[23]_i_196_n_0\
    );
de_out_i_1: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => de_in,
      I1 => reset,
      O => de_out_i_1_n_0
    );
de_out_reg: unisim.vcomponents.FDRE
     port map (
      C => pixel_clk,
      CE => '1',
      D => de_out_i_1_n_0,
      Q => de_out,
      R => '0'
    );
hsync_out_i_1: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => hsync_in,
      I1 => reset,
      O => hsync_out_i_1_n_0
    );
hsync_out_reg: unisim.vcomponents.FDRE
     port map (
      C => pixel_clk,
      CE => '1',
      D => hsync_out_i_1_n_0,
      Q => hsync_out,
      R => '0'
    );
\rgb_out[0]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAAAAAABAAAAAEE"
    )
        port map (
      I0 => \rgb_out[21]_i_5_n_0\,
      I1 => mode_ui(1),
      I2 => flash_on,
      I3 => mode_ui(0),
      I4 => mode_ui(2),
      I5 => is_pixel_mur,
      O => \rgb_out[0]_i_3_n_0\
    );
\rgb_out[10]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"BFFEBFFEBFCEBFFE"
    )
        port map (
      I0 => \rgb_out[11]_i_5_n_0\,
      I1 => mode_ui(0),
      I2 => mode_ui(2),
      I3 => mode_ui(1),
      I4 => \rgb_out[23]_i_11_n_0\,
      I5 => \rgb_out[23]_i_12_n_0\,
      O => \rgb_out[10]_i_2_n_0\
    );
\rgb_out[10]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFF008500850085"
    )
        port map (
      I0 => mode_ui(1),
      I1 => mode_ui(2),
      I2 => mode_ui(0),
      I3 => \rgb_out[23]_i_10_n_0\,
      I4 => \rgb_out[1]_i_3_n_0\,
      I5 => \rgb_out[20]_i_8_n_0\,
      O => \rgb_out[10]_i_3_n_0\
    );
\rgb_out[10]_i_5\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"3F8C"
    )
        port map (
      I0 => \rgb_out[20]_i_8_n_0\,
      I1 => mode_ui(1),
      I2 => mode_ui(2),
      I3 => mode_ui(0),
      O => \rgb_out[10]_i_5_n_0\
    );
\rgb_out[11]_i_10\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"2222222222222220"
    )
        port map (
      I0 => \rgb_out[11]_i_18_n_0\,
      I1 => \rgb_out[11]_i_19_n_0\,
      I2 => pixel_x(11),
      I3 => pixel_x(9),
      I4 => pixel_x(8),
      I5 => \rgb_out[11]_i_20_n_0\,
      O => \rgb_out[11]_i_10_n_0\
    );
\rgb_out[11]_i_11\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_x(11),
      I1 => pixel_x(10),
      O => \rgb_out[11]_i_11_n_0\
    );
\rgb_out[11]_i_12\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0002000300000003"
    )
        port map (
      I0 => \rgb_out[23]_i_225_n_0\,
      I1 => pixel_x(6),
      I2 => pixel_x(7),
      I3 => pixel_x(8),
      I4 => pixel_x(5),
      I5 => \rgb_out[23]_i_223_n_0\,
      O => \rgb_out[11]_i_12_n_0\
    );
\rgb_out[11]_i_13\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"EAAAAAAAAAAAAAAA"
    )
        port map (
      I0 => \rgb_out[23]_i_224_n_0\,
      I1 => pixel_x(5),
      I2 => \rgb_out[11]_i_21_n_0\,
      I3 => pixel_x(4),
      I4 => pixel_x(3),
      I5 => \rgb_out[11]_i_22_n_0\,
      O => \rgb_out[11]_i_13_n_0\
    );
\rgb_out[11]_i_14\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFF00D0FFD0"
    )
        port map (
      I0 => \rgb_out[11]_i_23_n_0\,
      I1 => \rgb_out[11]_i_24_n_0\,
      I2 => \rgb_out[23]_i_40_n_0\,
      I3 => pixel_y(9),
      I4 => \rgb_out[11]_i_25_n_0\,
      I5 => \rgb_out[11]_i_26_n_0\,
      O => \rgb_out[11]_i_14_n_0\
    );
\rgb_out[11]_i_15\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00007FFFFFFFFFFF"
    )
        port map (
      I0 => pixel_x(4),
      I1 => pixel_x(3),
      I2 => pixel_x(2),
      I3 => pixel_x(1),
      I4 => pixel_x(5),
      I5 => pixel_x(7),
      O => \rgb_out[11]_i_15_n_0\
    );
\rgb_out[11]_i_16\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFAAAAEAAA"
    )
        port map (
      I0 => \rgb_out[11]_i_27_n_0\,
      I1 => \rgb_out[11]_i_28_n_0\,
      I2 => pixel_x(9),
      I3 => pixel_x(5),
      I4 => \rgb_out[11]_i_29_n_0\,
      I5 => \rgb_out[11]_i_30_n_0\,
      O => \rgb_out[11]_i_16_n_0\
    );
\rgb_out[11]_i_17\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"5544544454445444"
    )
        port map (
      I0 => \rgb_out[23]_i_40_n_0\,
      I1 => pixel_y(6),
      I2 => pixel_y(4),
      I3 => pixel_y(5),
      I4 => pixel_y(3),
      I5 => \rgb_out[11]_i_31_n_0\,
      O => \rgb_out[11]_i_17_n_0\
    );
\rgb_out[11]_i_18\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"030733FFFFFFFFFF"
    )
        port map (
      I0 => pixel_x(6),
      I1 => \rgb_out[11]_i_32_n_0\,
      I2 => pixel_x(7),
      I3 => pixel_x(9),
      I4 => pixel_x(8),
      I5 => pixel_x(10),
      O => \rgb_out[11]_i_18_n_0\
    );
\rgb_out[11]_i_19\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"DDCCDDCFDDCCDDCC"
    )
        port map (
      I0 => \rgb_out[11]_i_33_n_0\,
      I1 => pixel_x(11),
      I2 => pixel_x(5),
      I3 => pixel_x(6),
      I4 => \rgb_out[11]_i_22_n_0\,
      I5 => \rgb_out[23]_i_335_n_0\,
      O => \rgb_out[11]_i_19_n_0\
    );
\rgb_out[11]_i_20\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFFFFF8"
    )
        port map (
      I0 => pixel_x(4),
      I1 => pixel_x(3),
      I2 => pixel_x(6),
      I3 => pixel_x(7),
      I4 => pixel_x(5),
      O => \rgb_out[11]_i_20_n_0\
    );
\rgb_out[11]_i_21\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => pixel_x(6),
      I1 => pixel_x(7),
      O => \rgb_out[11]_i_21_n_0\
    );
\rgb_out[11]_i_22\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => pixel_x(1),
      I1 => pixel_x(2),
      O => \rgb_out[11]_i_22_n_0\
    );
\rgb_out[11]_i_23\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"EAAA"
    )
        port map (
      I0 => pixel_y(3),
      I1 => pixel_y(1),
      I2 => pixel_y(0),
      I3 => pixel_y(2),
      O => \rgb_out[11]_i_23_n_0\
    );
\rgb_out[11]_i_24\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"7FFF"
    )
        port map (
      I0 => pixel_y(4),
      I1 => pixel_y(5),
      I2 => pixel_y(6),
      I3 => pixel_y(8),
      O => \rgb_out[11]_i_24_n_0\
    );
\rgb_out[11]_i_25\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000FF2FFF"
    )
        port map (
      I0 => \rgb_out[7]_i_37_n_0\,
      I1 => pixel_y(2),
      I2 => pixel_y(3),
      I3 => pixel_y(5),
      I4 => pixel_y(4),
      I5 => \rgb_out[23]_i_67_n_0\,
      O => \rgb_out[11]_i_25_n_0\
    );
\rgb_out[11]_i_26\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => pixel_y(11),
      I1 => pixel_y(10),
      O => \rgb_out[11]_i_26_n_0\
    );
\rgb_out[11]_i_27\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFBFBFBFBFBFBFBF"
    )
        port map (
      I0 => \rgb_out[21]_i_6_n_0\,
      I1 => pixel_x(9),
      I2 => \rgb_out[11]_i_11_n_0\,
      I3 => pixel_x(8),
      I4 => pixel_x(7),
      I5 => pixel_x(6),
      O => \rgb_out[11]_i_27_n_0\
    );
\rgb_out[11]_i_28\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFFE"
    )
        port map (
      I0 => pixel_x(2),
      I1 => pixel_x(1),
      I2 => pixel_x(4),
      I3 => pixel_x(3),
      O => \rgb_out[11]_i_28_n_0\
    );
\rgb_out[11]_i_29\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"7"
    )
        port map (
      I0 => pixel_x(7),
      I1 => pixel_x(8),
      O => \rgb_out[11]_i_29_n_0\
    );
\rgb_out[11]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0F00004F0000000F"
    )
        port map (
      I0 => \rgb_out[23]_i_12_n_0\,
      I1 => rgb_in(11),
      I2 => \rgb_out[23]_i_10_n_0\,
      I3 => mode_ui(1),
      I4 => mode_ui(0),
      I5 => mode_ui(2),
      O => \rgb_out[11]_i_3_n_0\
    );
\rgb_out[11]_i_30\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFF00F400440044"
    )
        port map (
      I0 => \rgb_out[11]_i_31_n_0\,
      I1 => \rgb_out[23]_i_540_n_0\,
      I2 => \rgb_out[11]_i_34_n_0\,
      I3 => pixel_y(5),
      I4 => \rgb_out[11]_i_35_n_0\,
      I5 => \rgb_out[23]_i_40_n_0\,
      O => \rgb_out[11]_i_30_n_0\
    );
\rgb_out[11]_i_31\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"FE"
    )
        port map (
      I0 => pixel_y(0),
      I1 => pixel_y(1),
      I2 => pixel_y(2),
      O => \rgb_out[11]_i_31_n_0\
    );
\rgb_out[11]_i_32\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFFE"
    )
        port map (
      I0 => pixel_x(5),
      I1 => pixel_x(9),
      I2 => pixel_x(4),
      I3 => pixel_x(3),
      O => \rgb_out[11]_i_32_n_0\
    );
\rgb_out[11]_i_33\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"7FFF"
    )
        port map (
      I0 => pixel_x(2),
      I1 => pixel_x(1),
      I2 => pixel_x(10),
      I3 => pixel_x(8),
      O => \rgb_out[11]_i_33_n_0\
    );
\rgb_out[11]_i_34\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"7"
    )
        port map (
      I0 => pixel_y(4),
      I1 => pixel_y(3),
      O => \rgb_out[11]_i_34_n_0\
    );
\rgb_out[11]_i_35\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"7"
    )
        port map (
      I0 => pixel_y(8),
      I1 => pixel_y(6),
      O => \rgb_out[11]_i_35_n_0\
    );
\rgb_out[11]_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"81"
    )
        port map (
      I0 => mode_ui(1),
      I1 => mode_ui(0),
      I2 => mode_ui(2),
      O => \rgb_out[11]_i_4_n_0\
    );
\rgb_out[11]_i_5\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFFAEEE"
    )
        port map (
      I0 => \rgb_out[11]_i_6_n_0\,
      I1 => \rgb_out[11]_i_7_n_0\,
      I2 => pixel_y(8),
      I3 => \rgb_out[11]_i_8_n_0\,
      I4 => \rgb_out[11]_i_9_n_0\,
      O => \rgb_out[11]_i_5_n_0\
    );
\rgb_out[11]_i_6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000EE2E2222"
    )
        port map (
      I0 => \rgb_out[11]_i_10_n_0\,
      I1 => \rgb_out[11]_i_11_n_0\,
      I2 => pixel_x(9),
      I3 => \rgb_out[11]_i_12_n_0\,
      I4 => \rgb_out[11]_i_13_n_0\,
      I5 => \rgb_out[11]_i_14_n_0\,
      O => \rgb_out[11]_i_6_n_0\
    );
\rgb_out[11]_i_7\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00000515"
    )
        port map (
      I0 => \rgb_out[21]_i_6_n_0\,
      I1 => pixel_y(7),
      I2 => pixel_y(8),
      I3 => pixel_y(6),
      I4 => \rgb_out[23]_i_38_n_0\,
      O => \rgb_out[11]_i_7_n_0\
    );
\rgb_out[11]_i_8\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAAAAAAAAAA8000"
    )
        port map (
      I0 => pixel_y(5),
      I1 => pixel_y(2),
      I2 => pixel_y(0),
      I3 => pixel_y(1),
      I4 => pixel_y(4),
      I5 => pixel_y(3),
      O => \rgb_out[11]_i_8_n_0\
    );
\rgb_out[11]_i_9\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000000000000FDDD"
    )
        port map (
      I0 => \rgb_out[11]_i_15_n_0\,
      I1 => pixel_x(8),
      I2 => pixel_x(7),
      I3 => pixel_x(6),
      I4 => \rgb_out[11]_i_16_n_0\,
      I5 => \rgb_out[11]_i_17_n_0\,
      O => \rgb_out[11]_i_9_n_0\
    );
\rgb_out[12]_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"0D"
    )
        port map (
      I0 => is_pixel_mur,
      I1 => rgb_in(12),
      I2 => \rgb_out[5]_i_2_n_0\,
      O => \rgb_out[12]_i_2_n_0\
    );
\rgb_out[12]_i_3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"BFBBAAAA"
    )
        port map (
      I0 => \rgb_out[1]_i_3_n_0\,
      I1 => \rgb_out[23]_i_11_n_0\,
      I2 => \rgb_out[23]_i_12_n_0\,
      I3 => rgb_in(12),
      I4 => \rgb_out[23]_i_13_n_0\,
      O => \rgb_out[12]_i_3_n_0\
    );
\rgb_out[12]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000810081818181"
    )
        port map (
      I0 => mode_ui(2),
      I1 => mode_ui(0),
      I2 => mode_ui(1),
      I3 => rgb_in(12),
      I4 => \rgb_out[11]_i_5_n_0\,
      I5 => \rgb_out[23]_i_9_n_0\,
      O => \rgb_out[12]_i_4_n_0\
    );
\rgb_out[13]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"A8000000000000A8"
    )
        port map (
      I0 => \rgb_out[23]_i_9_n_0\,
      I1 => rgb_in(13),
      I2 => \rgb_out[11]_i_5_n_0\,
      I3 => mode_ui(1),
      I4 => mode_ui(0),
      I5 => mode_ui(2),
      O => \rgb_out[13]_i_3_n_0\
    );
\rgb_out[13]_i_4\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FBFF"
    )
        port map (
      I0 => mode_ui(0),
      I1 => mode_ui(2),
      I2 => mode_ui(1),
      I3 => \rgb_out[23]_i_11_n_0\,
      O => \rgb_out[13]_i_4_n_0\
    );
\rgb_out[13]_i_5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => rgb_in(13),
      I1 => \rgb_out[23]_i_12_n_0\,
      O => \rgb_out[13]_i_5_n_0\
    );
\rgb_out[14]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000BBBB8B88"
    )
        port map (
      I0 => rgb_in(14),
      I1 => is_pixel_mur,
      I2 => mode_ui(2),
      I3 => mode_ui(0),
      I4 => \rgb_out[14]_i_5_n_0\,
      I5 => \rgb_out[21]_i_5_n_0\,
      O => \rgb_out[14]_i_2_n_0\
    );
\rgb_out[14]_i_3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"BFBBAAAA"
    )
        port map (
      I0 => \rgb_out[1]_i_3_n_0\,
      I1 => \rgb_out[23]_i_11_n_0\,
      I2 => \rgb_out[23]_i_12_n_0\,
      I3 => rgb_in(14),
      I4 => \rgb_out[23]_i_13_n_0\,
      O => \rgb_out[14]_i_3_n_0\
    );
\rgb_out[14]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000810081818181"
    )
        port map (
      I0 => mode_ui(2),
      I1 => mode_ui(0),
      I2 => mode_ui(1),
      I3 => rgb_in(14),
      I4 => \rgb_out[11]_i_5_n_0\,
      I5 => \rgb_out[23]_i_9_n_0\,
      O => \rgb_out[14]_i_4_n_0\
    );
\rgb_out[14]_i_5\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"F27F"
    )
        port map (
      I0 => mode_ui(0),
      I1 => flash_on,
      I2 => mode_ui(2),
      I3 => mode_ui(1),
      O => \rgb_out[14]_i_5_n_0\
    );
\rgb_out[15]_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"8A"
    )
        port map (
      I0 => \rgb_out[15]_i_5_n_0\,
      I1 => rgb_in(15),
      I2 => is_pixel_mur,
      O => \rgb_out[15]_i_2_n_0\
    );
\rgb_out[15]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000040004040404"
    )
        port map (
      I0 => mode_ui(0),
      I1 => mode_ui(2),
      I2 => mode_ui(1),
      I3 => rgb_in(15),
      I4 => \rgb_out[23]_i_12_n_0\,
      I5 => \rgb_out[23]_i_11_n_0\,
      O => \rgb_out[15]_i_3_n_0\
    );
\rgb_out[15]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000810081818181"
    )
        port map (
      I0 => mode_ui(2),
      I1 => mode_ui(0),
      I2 => mode_ui(1),
      I3 => rgb_in(15),
      I4 => \rgb_out[11]_i_5_n_0\,
      I5 => \rgb_out[23]_i_9_n_0\,
      O => \rgb_out[15]_i_4_n_0\
    );
\rgb_out[15]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"5555555510000000"
    )
        port map (
      I0 => \rgb_out[21]_i_5_n_0\,
      I1 => mode_ui(2),
      I2 => mode_ui(0),
      I3 => mode_ui(1),
      I4 => flash_on,
      I5 => is_pixel_mur,
      O => \rgb_out[15]_i_5_n_0\
    );
\rgb_out[16]_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"8A"
    )
        port map (
      I0 => \rgb_out[16]_i_5_n_0\,
      I1 => rgb_in(16),
      I2 => is_pixel_mur,
      O => \rgb_out[16]_i_2_n_0\
    );
\rgb_out[16]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000040004040404"
    )
        port map (
      I0 => mode_ui(0),
      I1 => mode_ui(2),
      I2 => mode_ui(1),
      I3 => rgb_in(16),
      I4 => \rgb_out[23]_i_12_n_0\,
      I5 => \rgb_out[23]_i_11_n_0\,
      O => \rgb_out[16]_i_3_n_0\
    );
\rgb_out[16]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000810081818181"
    )
        port map (
      I0 => mode_ui(2),
      I1 => mode_ui(0),
      I2 => mode_ui(1),
      I3 => rgb_in(16),
      I4 => \rgb_out[11]_i_5_n_0\,
      I5 => \rgb_out[23]_i_9_n_0\,
      O => \rgb_out[16]_i_4_n_0\
    );
\rgb_out[16]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"4444554554444444"
    )
        port map (
      I0 => \rgb_out[21]_i_5_n_0\,
      I1 => is_pixel_mur,
      I2 => mode_ui(0),
      I3 => flash_on,
      I4 => mode_ui(2),
      I5 => mode_ui(1),
      O => \rgb_out[16]_i_5_n_0\
    );
\rgb_out[17]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000DDDD8DDD"
    )
        port map (
      I0 => is_pixel_mur,
      I1 => rgb_in(17),
      I2 => flash_on,
      I3 => mode_ui(1),
      I4 => \rgb_out[17]_i_7_n_0\,
      I5 => \rgb_out[21]_i_5_n_0\,
      O => \rgb_out[17]_i_2_n_0\
    );
\rgb_out[17]_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"7A"
    )
        port map (
      I0 => mode_ui(1),
      I1 => mode_ui(2),
      I2 => mode_ui(0),
      O => \rgb_out[17]_i_3_n_0\
    );
\rgb_out[17]_i_4\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"4011"
    )
        port map (
      I0 => \rgb_out[23]_i_10_n_0\,
      I1 => mode_ui(0),
      I2 => mode_ui(2),
      I3 => mode_ui(1),
      O => \rgb_out[17]_i_4_n_0\
    );
\rgb_out[17]_i_5\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"BFBBAAAA"
    )
        port map (
      I0 => \rgb_out[1]_i_3_n_0\,
      I1 => \rgb_out[23]_i_11_n_0\,
      I2 => \rgb_out[23]_i_12_n_0\,
      I3 => rgb_in(17),
      I4 => \rgb_out[23]_i_13_n_0\,
      O => \rgb_out[17]_i_5_n_0\
    );
\rgb_out[17]_i_6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000810081818181"
    )
        port map (
      I0 => mode_ui(2),
      I1 => mode_ui(0),
      I2 => mode_ui(1),
      I3 => rgb_in(17),
      I4 => \rgb_out[11]_i_5_n_0\,
      I5 => \rgb_out[23]_i_9_n_0\,
      O => \rgb_out[17]_i_6_n_0\
    );
\rgb_out[17]_i_7\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"B"
    )
        port map (
      I0 => mode_ui(2),
      I1 => mode_ui(0),
      O => \rgb_out[17]_i_7_n_0\
    );
\rgb_out[18]_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"EA"
    )
        port map (
      I0 => \rgb_out[5]_i_2_n_0\,
      I1 => rgb_in(18),
      I2 => is_pixel_mur,
      O => \rgb_out[18]_i_2_n_0\
    );
\rgb_out[18]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000040004040404"
    )
        port map (
      I0 => mode_ui(0),
      I1 => mode_ui(2),
      I2 => mode_ui(1),
      I3 => rgb_in(18),
      I4 => \rgb_out[23]_i_12_n_0\,
      I5 => \rgb_out[23]_i_11_n_0\,
      O => \rgb_out[18]_i_3_n_0\
    );
\rgb_out[18]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000810081818181"
    )
        port map (
      I0 => mode_ui(2),
      I1 => mode_ui(0),
      I2 => mode_ui(1),
      I3 => rgb_in(18),
      I4 => \rgb_out[11]_i_5_n_0\,
      I5 => \rgb_out[23]_i_9_n_0\,
      O => \rgb_out[18]_i_4_n_0\
    );
\rgb_out[19]_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"08"
    )
        port map (
      I0 => rgb_in(19),
      I1 => is_pixel_mur,
      I2 => \rgb_out[21]_i_5_n_0\,
      O => \rgb_out[19]_i_2_n_0\
    );
\rgb_out[19]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000040004040404"
    )
        port map (
      I0 => mode_ui(0),
      I1 => mode_ui(2),
      I2 => mode_ui(1),
      I3 => rgb_in(19),
      I4 => \rgb_out[23]_i_12_n_0\,
      I5 => \rgb_out[23]_i_11_n_0\,
      O => \rgb_out[19]_i_3_n_0\
    );
\rgb_out[19]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000810081818181"
    )
        port map (
      I0 => mode_ui(2),
      I1 => mode_ui(0),
      I2 => mode_ui(1),
      I3 => rgb_in(19),
      I4 => \rgb_out[11]_i_5_n_0\,
      I5 => \rgb_out[23]_i_9_n_0\,
      O => \rgb_out[19]_i_4_n_0\
    );
\rgb_out[1]_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"0D"
    )
        port map (
      I0 => is_pixel_mur,
      I1 => rgb_in(1),
      I2 => \rgb_out[21]_i_5_n_0\,
      O => \rgb_out[1]_i_2_n_0\
    );
\rgb_out[1]_i_3\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"2000"
    )
        port map (
      I0 => mode_ui(2),
      I1 => mode_ui(0),
      I2 => mode_ui(1),
      I3 => \rgb_out[23]_i_19_n_0\,
      O => \rgb_out[1]_i_3_n_0\
    );
\rgb_out[1]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"1FFF1F1F11111111"
    )
        port map (
      I0 => \rgb_out[17]_i_3_n_0\,
      I1 => \rgb_out[23]_i_10_n_0\,
      I2 => \rgb_out[23]_i_11_n_0\,
      I3 => \rgb_out[23]_i_12_n_0\,
      I4 => rgb_in(1),
      I5 => \rgb_out[23]_i_13_n_0\,
      O => \rgb_out[1]_i_4_n_0\
    );
\rgb_out[1]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000810081818181"
    )
        port map (
      I0 => mode_ui(2),
      I1 => mode_ui(0),
      I2 => mode_ui(1),
      I3 => rgb_in(1),
      I4 => \rgb_out[11]_i_5_n_0\,
      I5 => \rgb_out[23]_i_9_n_0\,
      O => \rgb_out[1]_i_5_n_0\
    );
\rgb_out[20]_i_10\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000A0A03000"
    )
        port map (
      I0 => \rgb_out[20]_i_15_n_0\,
      I1 => \rgb_out[20]_i_16_n_0\,
      I2 => pixel_y(8),
      I3 => \rgb_out[20]_i_17_n_0\,
      I4 => pixel_y(7),
      I5 => \rgb_out[21]_i_6_n_0\,
      O => \rgb_out[20]_i_10_n_0\
    );
\rgb_out[20]_i_11\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AF23AFAFAFA0AFAF"
    )
        port map (
      I0 => \rgb_out[20]_i_18_n_0\,
      I1 => pixel_x(2),
      I2 => \rgb_out[23]_i_71_n_0\,
      I3 => \rgb_out[20]_i_19_n_0\,
      I4 => \rgb_out[20]_i_20_n_0\,
      I5 => \rgb_out[20]_i_21_n_0\,
      O => \rgb_out[20]_i_11_n_0\
    );
\rgb_out[20]_i_12\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFF08880808"
    )
        port map (
      I0 => \rgb_out[20]_i_22_n_0\,
      I1 => \rgb_out[11]_i_11_n_0\,
      I2 => \rgb_out[20]_i_23_n_0\,
      I3 => \rgb_out[20]_i_24_n_0\,
      I4 => \rgb_out[20]_i_25_n_0\,
      I5 => \rgb_out[20]_i_26_n_0\,
      O => \rgb_out[20]_i_12_n_0\
    );
\rgb_out[20]_i_13\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000080000000000"
    )
        port map (
      I0 => \rgb_out[23]_i_266_n_0\,
      I1 => pixel_y(6),
      I2 => \rgb_out[20]_i_27_n_0\,
      I3 => pixel_y(8),
      I4 => \rgb_out[20]_i_17_n_0\,
      I5 => \rgb_out[23]_i_540_n_0\,
      O => \rgb_out[20]_i_13_n_0\
    );
\rgb_out[20]_i_14\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0013001300130010"
    )
        port map (
      I0 => \rgb_out[23]_i_266_n_0\,
      I1 => \rgb_out[20]_i_28_n_0\,
      I2 => \rgb_out[23]_i_239_n_0\,
      I3 => \rgb_out[20]_i_29_n_0\,
      I4 => \rgb_out[23]_i_41_n_0\,
      I5 => \rgb_out[20]_i_30_n_0\,
      O => \rgb_out[20]_i_14_n_0\
    );
\rgb_out[20]_i_15\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000000001"
    )
        port map (
      I0 => pixel_y(5),
      I1 => pixel_y(6),
      I2 => pixel_y(4),
      I3 => pixel_y(3),
      I4 => pixel_y(2),
      I5 => pixel_y(1),
      O => \rgb_out[20]_i_15_n_0\
    );
\rgb_out[20]_i_16\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"7F"
    )
        port map (
      I0 => pixel_y(4),
      I1 => pixel_y(5),
      I2 => pixel_y(6),
      O => \rgb_out[20]_i_16_n_0\
    );
\rgb_out[20]_i_17\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"80"
    )
        port map (
      I0 => pixel_y(1),
      I1 => pixel_y(3),
      I2 => pixel_y(2),
      O => \rgb_out[20]_i_17_n_0\
    );
\rgb_out[20]_i_18\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FC00EC00FFFFFFFF"
    )
        port map (
      I0 => \rgb_out[20]_i_31_n_0\,
      I1 => pixel_x(7),
      I2 => pixel_x(6),
      I3 => \rgb_out[20]_i_23_n_0\,
      I4 => pixel_x(5),
      I5 => \rgb_out[11]_i_11_n_0\,
      O => \rgb_out[20]_i_18_n_0\
    );
\rgb_out[20]_i_19\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0111"
    )
        port map (
      I0 => pixel_x(10),
      I1 => pixel_x(11),
      I2 => pixel_x(8),
      I3 => pixel_x(9),
      O => \rgb_out[20]_i_19_n_0\
    );
\rgb_out[20]_i_2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"00C5"
    )
        port map (
      I0 => mode_ui(0),
      I1 => mode_ui(2),
      I2 => mode_ui(1),
      I3 => \rgb_out[23]_i_8_n_0\,
      O => \rgb_out[20]_i_2_n_0\
    );
\rgb_out[20]_i_20\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFFE"
    )
        port map (
      I0 => pixel_x(7),
      I1 => pixel_x(6),
      I2 => pixel_x(10),
      I3 => pixel_x(11),
      O => \rgb_out[20]_i_20_n_0\
    );
\rgb_out[20]_i_21\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000000001"
    )
        port map (
      I0 => pixel_x(7),
      I1 => pixel_x(11),
      I2 => pixel_x(10),
      I3 => pixel_x(5),
      I4 => pixel_x(4),
      I5 => pixel_x(3),
      O => \rgb_out[20]_i_21_n_0\
    );
\rgb_out[20]_i_22\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"F0F0F0F0F0F0F0E0"
    )
        port map (
      I0 => pixel_x(4),
      I1 => \rgb_out[23]_i_346_n_0\,
      I2 => \rgb_out[20]_i_23_n_0\,
      I3 => pixel_x(5),
      I4 => pixel_x(7),
      I5 => pixel_x(6),
      O => \rgb_out[20]_i_22_n_0\
    );
\rgb_out[20]_i_23\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => pixel_x(9),
      I1 => pixel_x(8),
      O => \rgb_out[20]_i_23_n_0\
    );
\rgb_out[20]_i_24\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => pixel_x(6),
      I1 => pixel_x(7),
      O => \rgb_out[20]_i_24_n_0\
    );
\rgb_out[20]_i_25\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_x(5),
      I1 => pixel_x(4),
      O => \rgb_out[20]_i_25_n_0\
    );
\rgb_out[20]_i_26\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8000000000000000"
    )
        port map (
      I0 => pixel_x(9),
      I1 => pixel_x(5),
      I2 => \rgb_out[11]_i_21_n_0\,
      I3 => \rgb_out[23]_i_392_n_0\,
      I4 => pixel_x(2),
      I5 => \rgb_out[20]_i_19_n_0\,
      O => \rgb_out[20]_i_26_n_0\
    );
\rgb_out[20]_i_27\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"7"
    )
        port map (
      I0 => pixel_y(5),
      I1 => pixel_y(4),
      O => \rgb_out[20]_i_27_n_0\
    );
\rgb_out[20]_i_28\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FEFFFFFF"
    )
        port map (
      I0 => pixel_y(11),
      I1 => pixel_y(10),
      I2 => pixel_y(9),
      I3 => pixel_y(7),
      I4 => pixel_y(8),
      O => \rgb_out[20]_i_28_n_0\
    );
\rgb_out[20]_i_29\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"FE"
    )
        port map (
      I0 => pixel_y(4),
      I1 => pixel_y(5),
      I2 => pixel_y(6),
      O => \rgb_out[20]_i_29_n_0\
    );
\rgb_out[20]_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"EA"
    )
        port map (
      I0 => \rgb_out[21]_i_5_n_0\,
      I1 => rgb_in(20),
      I2 => is_pixel_mur,
      O => \rgb_out[20]_i_3_n_0\
    );
\rgb_out[20]_i_30\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"FE"
    )
        port map (
      I0 => pixel_y(6),
      I1 => pixel_y(1),
      I2 => pixel_y(2),
      O => \rgb_out[20]_i_30_n_0\
    );
\rgb_out[20]_i_31\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"A8"
    )
        port map (
      I0 => pixel_x(4),
      I1 => pixel_x(2),
      I2 => pixel_x(3),
      O => \rgb_out[20]_i_31_n_0\
    );
\rgb_out[20]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000040004040404"
    )
        port map (
      I0 => mode_ui(0),
      I1 => mode_ui(2),
      I2 => mode_ui(1),
      I3 => rgb_in(20),
      I4 => \rgb_out[23]_i_12_n_0\,
      I5 => \rgb_out[23]_i_11_n_0\,
      O => \rgb_out[20]_i_5_n_0\
    );
\rgb_out[20]_i_6\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"0040C073"
    )
        port map (
      I0 => \rgb_out[20]_i_8_n_0\,
      I1 => mode_ui(1),
      I2 => mode_ui(2),
      I3 => mode_ui(0),
      I4 => \rgb_out[23]_i_10_n_0\,
      O => \rgb_out[20]_i_6_n_0\
    );
\rgb_out[20]_i_7\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000810081818181"
    )
        port map (
      I0 => mode_ui(2),
      I1 => mode_ui(0),
      I2 => mode_ui(1),
      I3 => rgb_in(20),
      I4 => \rgb_out[11]_i_5_n_0\,
      I5 => \rgb_out[23]_i_9_n_0\,
      O => \rgb_out[20]_i_7_n_0\
    );
\rgb_out[20]_i_8\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000044445545"
    )
        port map (
      I0 => \rgb_out[23]_i_45_n_0\,
      I1 => \rgb_out[20]_i_9_n_0\,
      I2 => \rgb_out[20]_i_10_n_0\,
      I3 => \rgb_out[20]_i_11_n_0\,
      I4 => \rgb_out[20]_i_12_n_0\,
      I5 => \rgb_out[23]_i_43_n_0\,
      O => \rgb_out[20]_i_8_n_0\
    );
\rgb_out[20]_i_9\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00000001"
    )
        port map (
      I0 => \rgb_out[23]_i_87_n_0\,
      I1 => \rgb_out[23]_i_151_n_0\,
      I2 => \rgb_out[20]_i_10_n_0\,
      I3 => \rgb_out[20]_i_13_n_0\,
      I4 => \rgb_out[20]_i_14_n_0\,
      O => \rgb_out[20]_i_9_n_0\
    );
\rgb_out[21]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"EFEEEFEF"
    )
        port map (
      I0 => \rgb_out[21]_i_4_n_0\,
      I1 => \rgb_out[1]_i_3_n_0\,
      I2 => \rgb_out[17]_i_3_n_0\,
      I3 => rgb_in(21),
      I4 => \rgb_out[23]_i_10_n_0\,
      O => \rgb_out[21]_i_2_n_0\
    );
\rgb_out[21]_i_4\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"C00A000C"
    )
        port map (
      I0 => \rgb_out[23]_i_12_n_0\,
      I1 => \rgb_out[11]_i_5_n_0\,
      I2 => mode_ui(1),
      I3 => mode_ui(0),
      I4 => mode_ui(2),
      O => \rgb_out[21]_i_4_n_0\
    );
\rgb_out[21]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000101010101"
    )
        port map (
      I0 => pixel_y(8),
      I1 => pixel_y(7),
      I2 => \rgb_out[21]_i_6_n_0\,
      I3 => pixel_y(5),
      I4 => \rgb_out[21]_i_7_n_0\,
      I5 => pixel_y(6),
      O => \rgb_out[21]_i_5_n_0\
    );
\rgb_out[21]_i_6\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"FE"
    )
        port map (
      I0 => pixel_y(9),
      I1 => pixel_y(10),
      I2 => pixel_y(11),
      O => \rgb_out[21]_i_6_n_0\
    );
\rgb_out[21]_i_7\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"E000"
    )
        port map (
      I0 => pixel_y(1),
      I1 => pixel_y(2),
      I2 => pixel_y(3),
      I3 => pixel_y(4),
      O => \rgb_out[21]_i_7_n_0\
    );
\rgb_out[22]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"20AAAAAA"
    )
        port map (
      I0 => \rgb_out[11]_i_4_n_0\,
      I1 => \rgb_out[11]_i_5_n_0\,
      I2 => rgb_in(22),
      I3 => \rgb_out[23]_i_9_n_0\,
      I4 => \rgb_out[23]_i_10_n_0\,
      O => \rgb_out[22]_i_2_n_0\
    );
\rgb_out[22]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"BFBFFFBFAAAAAAAA"
    )
        port map (
      I0 => \rgb_out[23]_i_14_n_0\,
      I1 => \rgb_out[23]_i_10_n_0\,
      I2 => \rgb_out[23]_i_11_n_0\,
      I3 => rgb_in(22),
      I4 => \rgb_out[23]_i_12_n_0\,
      I5 => \rgb_out[23]_i_13_n_0\,
      O => \rgb_out[22]_i_3_n_0\
    );
\rgb_out[23]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"B"
    )
        port map (
      I0 => reset,
      I1 => de_in,
      O => \rgb_out[23]_i_1_n_0\
    );
\rgb_out[23]_i_10\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000000002"
    )
        port map (
      I0 => \rgb_out[23]_i_26_n_0\,
      I1 => \rgb_out[23]_i_27_n_0\,
      I2 => \rgb_out[23]_i_28_n_0\,
      I3 => \rgb_out[23]_i_29_n_0\,
      I4 => \rgb_out[23]_i_30_n_0\,
      I5 => \rgb_out[23]_i_31_n_0\,
      O => \rgb_out[23]_i_10_n_0\
    );
\rgb_out[23]_i_100\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"888888880C080808"
    )
        port map (
      I0 => \rgb_out[23]_i_306_n_0\,
      I1 => \rgb_out[23]_i_219_n_0\,
      I2 => pixel_x(6),
      I3 => \rgb_out[23]_i_307_n_0\,
      I4 => pixel_x(5),
      I5 => \rgb_out[11]_i_29_n_0\,
      O => \rgb_out[23]_i_100_n_0\
    );
\rgb_out[23]_i_101\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \rgb_out[23]_i_280_n_0\,
      I1 => \rgb_out[23]_i_299_n_0\,
      O => \rgb_out[23]_i_101_n_0\
    );
\rgb_out[23]_i_102\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"88808A8A"
    )
        port map (
      I0 => \rgb_out[23]_i_93_n_0\,
      I1 => \rgb_out[23]_i_298_n_0\,
      I2 => \rgb_out[23]_i_297_n_0\,
      I3 => pixel_x(11),
      I4 => \rgb_out[23]_i_308_n_0\,
      O => \rgb_out[23]_i_102_n_0\
    );
\rgb_out[23]_i_103\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \rgb_out[23]_i_278_n_0\,
      I1 => \rgb_out[23]_i_275_n_0\,
      O => \rgb_out[23]_i_103_n_0\
    );
\rgb_out[23]_i_104\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000EAEEEAEA"
    )
        port map (
      I0 => \rgb_out[23]_i_309_n_0\,
      I1 => \rgb_out[23]_i_310_n_0\,
      I2 => \pixel_x[2]_9\(0),
      I3 => record_diz,
      I4 => \pixel_x[2]_10\(0),
      I5 => \rgb_out[23]_i_314_n_0\,
      O => num_rec_d
    );
\rgb_out[23]_i_105\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAAAAAAAAAAAAA8"
    )
        port map (
      I0 => \rgb_out[23]_i_315_n_0\,
      I1 => \rgb_out[23]_i_316_n_0\,
      I2 => \rgb_out[23]_i_317_n_0\,
      I3 => \rgb_out[23]_i_318_n_0\,
      I4 => \rgb_out[23]_i_319_n_0\,
      I5 => \rgb_out[23]_i_320_n_0\,
      O => num_last_u
    );
\rgb_out[23]_i_106\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAAAAAAAAAAAAA8"
    )
        port map (
      I0 => \rgb_out[23]_i_321_n_0\,
      I1 => \rgb_out[23]_i_322_n_0\,
      I2 => \rgb_out[23]_i_323_n_0\,
      I3 => \rgb_out[23]_i_324_n_0\,
      I4 => \rgb_out[23]_i_325_n_0\,
      I5 => \rgb_out[23]_i_326_n_0\,
      O => num_rec_u
    );
\rgb_out[23]_i_107\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000EAEEEAEA"
    )
        port map (
      I0 => \rgb_out[23]_i_327_n_0\,
      I1 => \rgb_out[23]_i_328_n_0\,
      I2 => \pixel_x[2]\(0),
      I3 => dernier_diz,
      I4 => \pixel_x[2]_0\(0),
      I5 => \rgb_out[23]_i_332_n_0\,
      O => num_last_d
    );
\rgb_out[23]_i_108\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"08FFFFFF08FF0000"
    )
        port map (
      I0 => \rgb_out[23]_i_333_n_0\,
      I1 => pixel_x(4),
      I2 => \rgb_out[23]_i_334_n_0\,
      I3 => \rgb_out[23]_i_335_n_0\,
      I4 => \rgb_out[23]_i_297_n_0\,
      I5 => \rgb_out[23]_i_308_n_0\,
      O => \rgb_out[23]_i_108_n_0\
    );
\rgb_out[23]_i_109\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFAAAABAAA"
    )
        port map (
      I0 => \rgb_out[23]_i_336_n_0\,
      I1 => \rgb_out[23]_i_337_n_0\,
      I2 => \rgb_out[23]_i_338_n_0\,
      I3 => \rgb_out[23]_i_339_n_0\,
      I4 => \rgb_out[23]_i_340_n_0\,
      I5 => \rgb_out[23]_i_341_n_0\,
      O => \rgb_out[23]_i_109_n_0\
    );
\rgb_out[23]_i_11\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000010111010"
    )
        port map (
      I0 => \rgb_out[23]_i_32_n_0\,
      I1 => \rgb_out[23]_i_33_n_0\,
      I2 => \rgb_out[23]_i_34_n_0\,
      I3 => \rgb_out[23]_i_35_n_0\,
      I4 => \rgb_out[23]_i_36_n_0\,
      I5 => \rgb_out[23]_i_37_n_0\,
      O => \rgb_out[23]_i_11_n_0\
    );
\rgb_out[23]_i_110\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"EEEEEEEFEEEEEEEE"
    )
        port map (
      I0 => \rgb_out[23]_i_342_n_0\,
      I1 => \rgb_out[23]_i_343_n_0\,
      I2 => pixel_x(11),
      I3 => pixel_x(9),
      I4 => pixel_x(8),
      I5 => \rgb_out[20]_i_25_n_0\,
      O => \rgb_out[23]_i_110_n_0\
    );
\rgb_out[23]_i_111\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000020200020"
    )
        port map (
      I0 => \rgb_out[23]_i_300_n_0\,
      I1 => \rgb_out[23]_i_344_n_0\,
      I2 => \rgb_out[23]_i_345_n_0\,
      I3 => \rgb_out[23]_i_346_n_0\,
      I4 => \rgb_out[23]_i_347_n_0\,
      I5 => \rgb_out[23]_i_348_n_0\,
      O => \rgb_out[23]_i_111_n_0\
    );
\rgb_out[23]_i_112\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000000010"
    )
        port map (
      I0 => \rgb_out[21]_i_6_n_0\,
      I1 => \rgb_out[23]_i_40_n_0\,
      I2 => pixel_y(4),
      I3 => \rgb_out[23]_i_237_n_0\,
      I4 => \rgb_out[23]_i_267_n_0\,
      I5 => \rgb_out[23]_i_349_n_0\,
      O => \rgb_out[23]_i_112_n_0\
    );
\rgb_out[23]_i_113\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000F20000"
    )
        port map (
      I0 => \rgb_out[23]_i_293_n_0\,
      I1 => \rgb_out[23]_i_287_n_0\,
      I2 => \rgb_out[23]_i_280_n_0\,
      I3 => \rgb_out[23]_i_350_n_0\,
      I4 => \rgb_out[23]_i_351_n_0\,
      I5 => \rgb_out[23]_i_352_n_0\,
      O => \rgb_out[23]_i_113_n_0\
    );
\rgb_out[23]_i_114\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFEFFFAAAAAAAA"
    )
        port map (
      I0 => \rgb_out[23]_i_337_n_0\,
      I1 => pixel_x(4),
      I2 => \rgb_out[23]_i_334_n_0\,
      I3 => pixel_x(5),
      I4 => \rgb_out[23]_i_353_n_0\,
      I5 => \rgb_out[23]_i_354_n_0\,
      O => \rgb_out[23]_i_114_n_0\
    );
\rgb_out[23]_i_115\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000002000000000"
    )
        port map (
      I0 => \rgb_out[23]_i_349_n_0\,
      I1 => \rgb_out[23]_i_267_n_0\,
      I2 => \rgb_out[11]_i_23_n_0\,
      I3 => \rgb_out[21]_i_6_n_0\,
      I4 => \rgb_out[23]_i_40_n_0\,
      I5 => pixel_y(4),
      O => \rgb_out[23]_i_115_n_0\
    );
\rgb_out[23]_i_116\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFFFFE"
    )
        port map (
      I0 => \rgb_out[23]_i_355_n_0\,
      I1 => \rgb_out[23]_i_356_n_0\,
      I2 => \rgb_out[23]_i_357_n_0\,
      I3 => \rgb_out[23]_i_290_n_0\,
      I4 => \rgb_out[23]_i_289_n_0\,
      I5 => \rgb_out[23]_i_109_n_0\,
      O => \rgb_out[23]_i_116_n_0\
    );
\rgb_out[23]_i_117\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFF3704F7F4"
    )
        port map (
      I0 => pixel_x(11),
      I1 => \rgb_out[23]_i_358_n_0\,
      I2 => \rgb_out[23]_i_359_n_0\,
      I3 => \rgb_out[23]_i_343_n_0\,
      I4 => \rgb_out[23]_i_360_n_0\,
      I5 => \rgb_out[23]_i_361_n_0\,
      O => \rgb_out[23]_i_117_n_0\
    );
\rgb_out[23]_i_118\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00550155"
    )
        port map (
      I0 => pixel_x(11),
      I1 => pixel_x(9),
      I2 => pixel_x(8),
      I3 => pixel_x(10),
      I4 => pixel_x(7),
      O => \rgb_out[23]_i_118_n_0\
    );
\rgb_out[23]_i_119\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00C000C000E0FFEE"
    )
        port map (
      I0 => \rgb_out[11]_i_21_n_0\,
      I1 => \rgb_out[23]_i_362_n_0\,
      I2 => \rgb_out[23]_i_363_n_0\,
      I3 => \rgb_out[23]_i_364_n_0\,
      I4 => \rgb_out[23]_i_365_n_0\,
      I5 => \rgb_out[23]_i_366_n_0\,
      O => \rgb_out[23]_i_119_n_0\
    );
\rgb_out[23]_i_12\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"BBBBBBBBAAAAABAA"
    )
        port map (
      I0 => \rgb_out[11]_i_6_n_0\,
      I1 => \rgb_out[23]_i_38_n_0\,
      I2 => \rgb_out[23]_i_39_n_0\,
      I3 => \rgb_out[23]_i_40_n_0\,
      I4 => \rgb_out[23]_i_41_n_0\,
      I5 => \rgb_out[23]_i_42_n_0\,
      O => \rgb_out[23]_i_12_n_0\
    );
\rgb_out[23]_i_120\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"80FFFFFF80FF80FF"
    )
        port map (
      I0 => \rgb_out[23]_i_351_n_0\,
      I1 => pixel_x(5),
      I2 => \rgb_out[23]_i_230_n_0\,
      I3 => \rgb_out[23]_i_343_n_0\,
      I4 => \rgb_out[23]_i_224_n_0\,
      I5 => \rgb_out[23]_i_367_n_0\,
      O => \rgb_out[23]_i_120_n_0\
    );
\rgb_out[23]_i_1206\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFEFFFEFFFE"
    )
        port map (
      I0 => pixel_x(11),
      I1 => pixel_x(10),
      I2 => pixel_x(6),
      I3 => pixel_x(7),
      I4 => pixel_x(4),
      I5 => pixel_x(5),
      O => \rgb_out[23]_i_1206_n_0\
    );
\rgb_out[23]_i_1207\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"EAAA"
    )
        port map (
      I0 => pixel_x(6),
      I1 => pixel_x(5),
      I2 => pixel_x(4),
      I3 => pixel_x(3),
      O => \rgb_out[23]_i_1207_n_0\
    );
\rgb_out[23]_i_1208\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFFFFFE"
    )
        port map (
      I0 => pixel_x(7),
      I1 => pixel_x(9),
      I2 => pixel_x(6),
      I3 => pixel_x(5),
      I4 => pixel_x(4),
      O => \rgb_out[23]_i_1208_n_0\
    );
\rgb_out[23]_i_1209\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00000001"
    )
        port map (
      I0 => pixel_x(4),
      I1 => pixel_x(9),
      I2 => pixel_x(6),
      I3 => pixel_x(11),
      I4 => pixel_x(7),
      O => \rgb_out[23]_i_1209_n_0\
    );
\rgb_out[23]_i_121\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFF0001FFFF"
    )
        port map (
      I0 => pixel_y(2),
      I1 => pixel_y(6),
      I2 => pixel_y(7),
      I3 => \rgb_out[23]_i_41_n_0\,
      I4 => \rgb_out[23]_i_368_n_0\,
      I5 => \rgb_out[23]_i_369_n_0\,
      O => \rgb_out[23]_i_121_n_0\
    );
\rgb_out[23]_i_1210\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"AAA8"
    )
        port map (
      I0 => pixel_x(4),
      I1 => pixel_x(1),
      I2 => pixel_x(3),
      I3 => pixel_x(2),
      O => \rgb_out[23]_i_1210_n_0\
    );
\rgb_out[23]_i_122\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"1DDD00001DDD1DDD"
    )
        port map (
      I0 => \rgb_out[23]_i_370_n_0\,
      I1 => pixel_x(8),
      I2 => \rgb_out[11]_i_22_n_0\,
      I3 => pixel_x(9),
      I4 => \rgb_out[20]_i_26_n_0\,
      I5 => \rgb_out[23]_i_371_n_0\,
      O => \rgb_out[23]_i_122_n_0\
    );
\rgb_out[23]_i_123\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000AAA8A8A8"
    )
        port map (
      I0 => \rgb_out[7]_i_55_n_0\,
      I1 => pixel_x(2),
      I2 => pixel_x(3),
      I3 => pixel_x(1),
      I4 => pixel_x(0),
      I5 => \rgb_out[23]_i_372_n_0\,
      O => \rgb_out[23]_i_123_n_0\
    );
\rgb_out[23]_i_124\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFF1FFFFFFFFF"
    )
        port map (
      I0 => \rgb_out[11]_i_28_n_0\,
      I1 => pixel_x(5),
      I2 => \rgb_out[23]_i_373_n_0\,
      I3 => \rgb_out[20]_i_20_n_0\,
      I4 => \rgb_out[23]_i_300_n_0\,
      I5 => \rgb_out[20]_i_23_n_0\,
      O => \rgb_out[23]_i_124_n_0\
    );
\rgb_out[23]_i_125\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"1000FFFF10001000"
    )
        port map (
      I0 => \rgb_out[23]_i_374_n_0\,
      I1 => \rgb_out[23]_i_375_n_0\,
      I2 => \rgb_out[20]_i_23_n_0\,
      I3 => \rgb_out[23]_i_253_n_0\,
      I4 => \rgb_out[23]_i_36_n_0\,
      I5 => \rgb_out[23]_i_184_n_0\,
      O => \rgb_out[23]_i_125_n_0\
    );
\rgb_out[23]_i_1254\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => local_x_0(10),
      I1 => local_x_0(11),
      O => \rgb_out[23]_i_1254_n_0\
    );
\rgb_out[23]_i_1255\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => local_x_0(8),
      I1 => local_x_0(9),
      O => \rgb_out[23]_i_1255_n_0\
    );
\rgb_out[23]_i_1256\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => local_x_0(11),
      I1 => local_x_0(10),
      O => \rgb_out[23]_i_1256_n_0\
    );
\rgb_out[23]_i_1257\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => local_x_0(9),
      I1 => local_x_0(8),
      O => \rgb_out[23]_i_1257_n_0\
    );
\rgb_out[23]_i_126\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0808080008080808"
    )
        port map (
      I0 => \rgb_out[23]_i_376_n_0\,
      I1 => \rgb_out[23]_i_76_n_0\,
      I2 => \rgb_out[7]_i_40_n_0\,
      I3 => pixel_x(0),
      I4 => pixel_x(7),
      I5 => \rgb_out[23]_i_377_n_0\,
      O => \rgb_out[23]_i_126_n_0\
    );
\rgb_out[23]_i_127\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"AE"
    )
        port map (
      I0 => \rgb_out[23]_i_378_n_0\,
      I1 => \rgb_out[7]_i_41_n_0\,
      I2 => \rgb_out[7]_i_42_n_0\,
      O => \rgb_out[23]_i_127_n_0\
    );
\rgb_out[23]_i_128\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00AA0080"
    )
        port map (
      I0 => \rgb_out[23]_i_379_n_0\,
      I1 => pixel_x(1),
      I2 => pixel_x(0),
      I3 => \rgb_out[23]_i_380_n_0\,
      I4 => pixel_x(2),
      O => \rgb_out[23]_i_128_n_0\
    );
\rgb_out[23]_i_129\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000004000000"
    )
        port map (
      I0 => \rgb_out[20]_i_24_n_0\,
      I1 => \rgb_out[11]_i_11_n_0\,
      I2 => pixel_x(4),
      I3 => pixel_x(5),
      I4 => \rgb_out[20]_i_23_n_0\,
      I5 => \rgb_out[23]_i_381_n_0\,
      O => \rgb_out[23]_i_129_n_0\
    );
\rgb_out[23]_i_13\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"04"
    )
        port map (
      I0 => mode_ui(1),
      I1 => mode_ui(2),
      I2 => mode_ui(0),
      O => \rgb_out[23]_i_13_n_0\
    );
\rgb_out[23]_i_130\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000070000000"
    )
        port map (
      I0 => \rgb_out[23]_i_334_n_0\,
      I1 => \rgb_out[23]_i_370_n_0\,
      I2 => pixel_x(4),
      I3 => \rgb_out[23]_i_382_n_0\,
      I4 => \rgb_out[23]_i_383_n_0\,
      I5 => \rgb_out[20]_i_19_n_0\,
      O => \rgb_out[23]_i_130_n_0\
    );
\rgb_out[23]_i_1309\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => local_x(10),
      I1 => local_x(11),
      O => \rgb_out[23]_i_1309_n_0\
    );
\rgb_out[23]_i_131\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000A8A800A8"
    )
        port map (
      I0 => \rgb_out[23]_i_384_n_0\,
      I1 => \rgb_out[20]_i_19_n_0\,
      I2 => \rgb_out[23]_i_383_n_0\,
      I3 => \rgb_out[23]_i_382_n_0\,
      I4 => \rgb_out[23]_i_385_n_0\,
      I5 => \rgb_out[23]_i_386_n_0\,
      O => \rgb_out[23]_i_131_n_0\
    );
\rgb_out[23]_i_1310\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => local_x(8),
      I1 => local_x(9),
      O => \rgb_out[23]_i_1310_n_0\
    );
\rgb_out[23]_i_1311\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => local_x(11),
      I1 => local_x(10),
      O => \rgb_out[23]_i_1311_n_0\
    );
\rgb_out[23]_i_1312\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => local_x(9),
      I1 => local_x(8),
      O => \rgb_out[23]_i_1312_n_0\
    );
\rgb_out[23]_i_1318\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \^local_y\(9),
      I1 => \^local_y\(10),
      O => \rgb_out[23]_i_1318_n_0\
    );
\rgb_out[23]_i_1319\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \^local_y\(7),
      I1 => \^local_y\(8),
      O => \rgb_out[23]_i_1319_n_0\
    );
\rgb_out[23]_i_132\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAA2AAA20000AAA2"
    )
        port map (
      I0 => \rgb_out[23]_i_387_n_0\,
      I1 => \rgb_out[23]_i_370_n_0\,
      I2 => \rgb_out[23]_i_388_n_0\,
      I3 => \rgb_out[23]_i_389_n_0\,
      I4 => \rgb_out[23]_i_390_n_0\,
      I5 => \rgb_out[23]_i_379_n_0\,
      O => \rgb_out[23]_i_132_n_0\
    );
\rgb_out[23]_i_1320\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \^local_y\(10),
      I1 => \^local_y\(9),
      O => \rgb_out[23]_i_1320_n_0\
    );
\rgb_out[23]_i_1321\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \^local_y\(8),
      I1 => \^local_y\(7),
      O => \rgb_out[23]_i_1321_n_0\
    );
\rgb_out[23]_i_1323\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \^rgb_out_reg[0]_0\(0),
      O => \rgb_out[23]_i_1323_n_0\
    );
\rgb_out[23]_i_1324\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \^local_y\(10),
      I1 => \^local_y\(9),
      O => \rgb_out[23]_i_1324_n_0\
    );
\rgb_out[23]_i_1325\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \^local_y\(8),
      I1 => \^local_y\(7),
      O => \rgb_out[23]_i_1325_n_0\
    );
\rgb_out[23]_i_133\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000000111"
    )
        port map (
      I0 => \rgb_out[23]_i_267_n_0\,
      I1 => pixel_y(7),
      I2 => pixel_y(1),
      I3 => pixel_y(0),
      I4 => pixel_y(2),
      I5 => pixel_y(3),
      O => \rgb_out[23]_i_133_n_0\
    );
\rgb_out[23]_i_1332\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \^rgb_out_reg[0]_0\(0),
      O => \rgb_out[23]_i_1332_n_0\
    );
\rgb_out[23]_i_1333\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \^local_y\(10),
      I1 => \^local_y\(9),
      O => \rgb_out[23]_i_1333_n_0\
    );
\rgb_out[23]_i_1334\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \^local_y\(8),
      I1 => \^local_y\(7),
      O => \rgb_out[23]_i_1334_n_0\
    );
\rgb_out[23]_i_134\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"AAAAAAA8"
    )
        port map (
      I0 => pixel_y(8),
      I1 => pixel_y(5),
      I2 => pixel_y(4),
      I3 => pixel_y(7),
      I4 => pixel_y(6),
      O => \rgb_out[23]_i_134_n_0\
    );
\rgb_out[23]_i_135\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0001"
    )
        port map (
      I0 => pixel_y(10),
      I1 => pixel_y(11),
      I2 => pixel_y(8),
      I3 => pixel_y(9),
      O => \rgb_out[23]_i_135_n_0\
    );
\rgb_out[23]_i_136\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FEAA"
    )
        port map (
      I0 => pixel_y(3),
      I1 => pixel_y(1),
      I2 => pixel_y(0),
      I3 => pixel_y(2),
      O => \rgb_out[23]_i_136_n_0\
    );
\rgb_out[23]_i_137\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_y(2),
      I1 => pixel_y(1),
      O => \rgb_out[23]_i_137_n_0\
    );
\rgb_out[23]_i_138\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"7F"
    )
        port map (
      I0 => pixel_y(6),
      I1 => pixel_y(7),
      I2 => pixel_y(5),
      O => \rgb_out[23]_i_138_n_0\
    );
\rgb_out[23]_i_1382\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => local_x_1(4),
      I1 => local_x_1(5),
      O => \rgb_out[23]_i_1382_n_0\
    );
\rgb_out[23]_i_1383\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => local_x_1(2),
      I1 => local_x_1(3),
      O => \rgb_out[23]_i_1383_n_0\
    );
\rgb_out[23]_i_1384\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => pixel_x(0),
      I1 => pixel_x(1),
      O => \rgb_out[23]_i_1384_n_0\
    );
\rgb_out[23]_i_1385\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => local_x_1(5),
      I1 => local_x_1(4),
      O => \rgb_out[23]_i_1385_n_0\
    );
\rgb_out[23]_i_1386\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => local_x_1(3),
      I1 => local_x_1(2),
      O => \rgb_out[23]_i_1386_n_0\
    );
\rgb_out[23]_i_1387\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => local_x_1(0),
      I1 => local_x_1(1),
      O => \rgb_out[23]_i_1387_n_0\
    );
\rgb_out[23]_i_1388\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => pixel_x(1),
      I1 => pixel_x(0),
      O => \rgb_out[23]_i_1388_n_0\
    );
\rgb_out[23]_i_139\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"FE"
    )
        port map (
      I0 => \rgb_out[23]_i_391_n_0\,
      I1 => \rgb_out[23]_i_253_n_0\,
      I2 => \rgb_out[23]_i_76_n_0\,
      O => \rgb_out[23]_i_139_n_0\
    );
\rgb_out[23]_i_14\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"2020202020002020"
    )
        port map (
      I0 => mode_ui(2),
      I1 => mode_ui(0),
      I2 => mode_ui(1),
      I3 => \rgb_out[23]_i_43_n_0\,
      I4 => \rgb_out[23]_i_44_n_0\,
      I5 => \rgb_out[23]_i_45_n_0\,
      O => \rgb_out[23]_i_14_n_0\
    );
\rgb_out[23]_i_140\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8000808080008000"
    )
        port map (
      I0 => \rgb_out[20]_i_23_n_0\,
      I1 => pixel_x(6),
      I2 => pixel_x(7),
      I3 => pixel_x(5),
      I4 => \rgb_out[23]_i_223_n_0\,
      I5 => \rgb_out[23]_i_392_n_0\,
      O => \rgb_out[23]_i_140_n_0\
    );
\rgb_out[23]_i_141\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"7F3FFF3FFF3FFF3F"
    )
        port map (
      I0 => \rgb_out[11]_i_28_n_0\,
      I1 => pixel_x(9),
      I2 => \rgb_out[11]_i_11_n_0\,
      I3 => \rgb_out[23]_i_393_n_0\,
      I4 => pixel_x(5),
      I5 => pixel_x(6),
      O => \rgb_out[23]_i_141_n_0\
    );
\rgb_out[23]_i_142\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"01000F0000000000"
    )
        port map (
      I0 => pixel_x(5),
      I1 => \rgb_out[23]_i_230_n_0\,
      I2 => \rgb_out[20]_i_24_n_0\,
      I3 => \rgb_out[11]_i_11_n_0\,
      I4 => \rgb_out[23]_i_300_n_0\,
      I5 => \rgb_out[20]_i_23_n_0\,
      O => \rgb_out[23]_i_142_n_0\
    );
\rgb_out[23]_i_143\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00020000"
    )
        port map (
      I0 => \rgb_out[11]_i_11_n_0\,
      I1 => \rgb_out[20]_i_24_n_0\,
      I2 => pixel_x(3),
      I3 => \rgb_out[23]_i_233_n_0\,
      I4 => \rgb_out[20]_i_23_n_0\,
      O => \rgb_out[23]_i_143_n_0\
    );
\rgb_out[23]_i_144\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"1000000000000000"
    )
        port map (
      I0 => pixel_x(2),
      I1 => \rgb_out[23]_i_394_n_0\,
      I2 => pixel_x(5),
      I3 => pixel_x(4),
      I4 => pixel_x(3),
      I5 => \rgb_out[20]_i_23_n_0\,
      O => \rgb_out[23]_i_144_n_0\
    );
\rgb_out[23]_i_145\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \rgb_out[20]_i_10_n_0\,
      I1 => \rgb_out[23]_i_252_n_0\,
      O => \rgb_out[23]_i_145_n_0\
    );
\rgb_out[23]_i_146\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"AAAAA8AA"
    )
        port map (
      I0 => \rgb_out[23]_i_87_n_0\,
      I1 => \rgb_out[23]_i_269_n_0\,
      I2 => \rgb_out[23]_i_395_n_0\,
      I3 => \rgb_out[23]_i_231_n_0\,
      I4 => \rgb_out[23]_i_261_n_0\,
      O => \rgb_out[23]_i_146_n_0\
    );
\rgb_out[23]_i_147\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAAAAAA2AAA2A0A"
    )
        port map (
      I0 => \rgb_out[23]_i_252_n_0\,
      I1 => \rgb_out[20]_i_18_n_0\,
      I2 => \rgb_out[23]_i_396_n_0\,
      I3 => \rgb_out[23]_i_71_n_0\,
      I4 => \rgb_out[7]_i_42_n_0\,
      I5 => \rgb_out[23]_i_397_n_0\,
      O => \rgb_out[23]_i_147_n_0\
    );
\rgb_out[23]_i_148\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"F7F7F7F7F7F3F700"
    )
        port map (
      I0 => \rgb_out[23]_i_150_n_0\,
      I1 => \rgb_out[23]_i_396_n_0\,
      I2 => \rgb_out[23]_i_261_n_0\,
      I3 => \rgb_out[20]_i_14_n_0\,
      I4 => \rgb_out[23]_i_151_n_0\,
      I5 => \rgb_out[20]_i_13_n_0\,
      O => \rgb_out[23]_i_148_n_0\
    );
\rgb_out[23]_i_149\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFF88888"
    )
        port map (
      I0 => \rgb_out[23]_i_398_n_0\,
      I1 => \rgb_out[23]_i_241_n_0\,
      I2 => \rgb_out[23]_i_399_n_0\,
      I3 => \rgb_out[23]_i_240_n_0\,
      I4 => \rgb_out[23]_i_262_n_0\,
      O => \rgb_out[23]_i_149_n_0\
    );
\rgb_out[23]_i_15\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000000002"
    )
        port map (
      I0 => \rgb_out[23]_i_46_n_0\,
      I1 => \rgb_out[23]_i_47_n_0\,
      I2 => \rgb_out[23]_i_48_n_0\,
      I3 => \rgb_out[23]_i_49_n_0\,
      I4 => \rgb_out[23]_i_50_n_0\,
      I5 => \rgb_out[23]_i_51_n_0\,
      O => \rgb_out[23]_i_15_n_0\
    );
\rgb_out[23]_i_150\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"5555555555554555"
    )
        port map (
      I0 => \rgb_out[23]_i_400_n_0\,
      I1 => \rgb_out[20]_i_20_n_0\,
      I2 => \rgb_out[23]_i_401_n_0\,
      I3 => \rgb_out[23]_i_380_n_0\,
      I4 => pixel_x(5),
      I5 => \rgb_out[20]_i_19_n_0\,
      O => \rgb_out[23]_i_150_n_0\
    );
\rgb_out[23]_i_151\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0004000000000400"
    )
        port map (
      I0 => \rgb_out[21]_i_6_n_0\,
      I1 => \rgb_out[23]_i_40_n_0\,
      I2 => \rgb_out[11]_i_24_n_0\,
      I3 => pixel_y(3),
      I4 => pixel_y(1),
      I5 => pixel_y(2),
      O => \rgb_out[23]_i_151_n_0\
    );
\rgb_out[23]_i_152\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000000002"
    )
        port map (
      I0 => \rgb_out[23]_i_402_n_0\,
      I1 => \rgb_out[23]_i_403_n_0\,
      I2 => \rgb_out[23]_i_404_n_0\,
      I3 => \rgb_out[23]_i_405_n_0\,
      I4 => \rgb_out[23]_i_406_n_0\,
      I5 => \rgb_out[23]_i_407_n_0\,
      O => \rgb_out[23]_i_152_n_0\
    );
\rgb_out[23]_i_153\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8888800000000000"
    )
        port map (
      I0 => \rgb_out[23]_i_408_n_0\,
      I1 => \rgb_out[23]_i_135_n_0\,
      I2 => pixel_y(1),
      I3 => pixel_y(2),
      I4 => pixel_y(3),
      I5 => pixel_y(4),
      O => \rgb_out[23]_i_153_n_0\
    );
\rgb_out[23]_i_154\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFF00000200"
    )
        port map (
      I0 => \rgb_out[23]_i_137_n_0\,
      I1 => pixel_y(3),
      I2 => pixel_y(4),
      I3 => pixel_y(5),
      I4 => \rgb_out[23]_i_409_n_0\,
      I5 => \rgb_out[23]_i_179_n_0\,
      O => \rgb_out[23]_i_154_n_0\
    );
\rgb_out[23]_i_155\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000000000000FFAB"
    )
        port map (
      I0 => \rgb_out[23]_i_159_n_0\,
      I1 => \rgb_out[23]_i_156_n_0\,
      I2 => \rgb_out[23]_i_179_n_0\,
      I3 => \rgb_out[23]_i_410_n_0\,
      I4 => \rgb_out[23]_i_411_n_0\,
      I5 => \rgb_out[23]_i_412_n_0\,
      O => \rgb_out[23]_i_155_n_0\
    );
\rgb_out[23]_i_156\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0800000000000000"
    )
        port map (
      I0 => pixel_y(1),
      I1 => \rgb_out[23]_i_408_n_0\,
      I2 => pixel_y(2),
      I3 => pixel_y(3),
      I4 => pixel_y(4),
      I5 => \rgb_out[23]_i_135_n_0\,
      O => \rgb_out[23]_i_156_n_0\
    );
\rgb_out[23]_i_157\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000007000707"
    )
        port map (
      I0 => \rgb_out[23]_i_156_n_0\,
      I1 => \rgb_out[23]_i_407_n_0\,
      I2 => \rgb_out[23]_i_413_n_0\,
      I3 => \rgb_out[23]_i_414_n_0\,
      I4 => \rgb_out[23]_i_415_n_0\,
      I5 => \rgb_out[23]_i_416_n_0\,
      O => \rgb_out[23]_i_157_n_0\
    );
\rgb_out[23]_i_158\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFF10F010F010F0"
    )
        port map (
      I0 => \rgb_out[23]_i_417_n_0\,
      I1 => \rgb_out[23]_i_418_n_0\,
      I2 => \rgb_out[23]_i_419_n_0\,
      I3 => \rgb_out[23]_i_420_n_0\,
      I4 => \rgb_out[23]_i_416_n_0\,
      I5 => \rgb_out[23]_i_421_n_0\,
      O => \rgb_out[23]_i_158_n_0\
    );
\rgb_out[23]_i_159\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0001000F0F0F0F0F"
    )
        port map (
      I0 => \rgb_out[23]_i_226_n_0\,
      I1 => pixel_x(7),
      I2 => pixel_x(11),
      I3 => pixel_x(9),
      I4 => pixel_x(8),
      I5 => pixel_x(10),
      O => \rgb_out[23]_i_159_n_0\
    );
\rgb_out[23]_i_16\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAAAAA8AAAAAAAA"
    )
        port map (
      I0 => \rgb_out[7]_i_8_n_0\,
      I1 => \rgb_out[7]_i_7_n_0\,
      I2 => \rgb_out[23]_i_52_n_0\,
      I3 => \rgb_out[23]_i_53_n_0\,
      I4 => \rgb_out[7]_i_5_n_0\,
      I5 => \rgb_out[7]_i_4_n_0\,
      O => \rgb_out[23]_i_16_n_0\
    );
\rgb_out[23]_i_160\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000FFFF2A22"
    )
        port map (
      I0 => \rgb_out[23]_i_422_n_0\,
      I1 => \rgb_out[23]_i_423_n_0\,
      I2 => \rgb_out[23]_i_424_n_0\,
      I3 => \rgb_out[23]_i_425_n_0\,
      I4 => \rgb_out[23]_i_426_n_0\,
      I5 => \rgb_out[23]_i_427_n_0\,
      O => \rgb_out[23]_i_160_n_0\
    );
\rgb_out[23]_i_161\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"80AA8080AAAAAAAA"
    )
        port map (
      I0 => \rgb_out[23]_i_428_n_0\,
      I1 => \rgb_out[23]_i_173_n_0\,
      I2 => \rgb_out[23]_i_424_n_0\,
      I3 => \rgb_out[23]_i_429_n_0\,
      I4 => \rgb_out[23]_i_430_n_0\,
      I5 => \rgb_out[23]_i_431_n_0\,
      O => \rgb_out[23]_i_161_n_0\
    );
\rgb_out[23]_i_162\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"FE"
    )
        port map (
      I0 => \rgb_out[23]_i_179_n_0\,
      I1 => \rgb_out[23]_i_432_n_0\,
      I2 => \rgb_out[23]_i_156_n_0\,
      O => \rgb_out[23]_i_162_n_0\
    );
\rgb_out[23]_i_163\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"BFBFBFBB80808088"
    )
        port map (
      I0 => \rgb_out[23]_i_433_n_0\,
      I1 => \rgb_out[23]_i_352_n_0\,
      I2 => \rgb_out[23]_i_434_n_0\,
      I3 => \rgb_out[23]_i_334_n_0\,
      I4 => \rgb_out[23]_i_233_n_0\,
      I5 => \rgb_out[23]_i_435_n_0\,
      O => \rgb_out[23]_i_163_n_0\
    );
\rgb_out[23]_i_164\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8000000000000000"
    )
        port map (
      I0 => pixel_x(2),
      I1 => pixel_x(1),
      I2 => pixel_x(3),
      I3 => pixel_x(6),
      I4 => \rgb_out[23]_i_436_n_0\,
      I5 => \rgb_out[23]_i_437_n_0\,
      O => \rgb_out[23]_i_164_n_0\
    );
\rgb_out[23]_i_165\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"8000"
    )
        port map (
      I0 => \pixel_x[1]_6\(0),
      I1 => \pixel_y[2]_9\(0),
      I2 => \pixel_x[1]_7\(0),
      I3 => \pixel_y[2]_10\(0),
      O => \rgb_out[23]_i_165_n_0\
    );
\rgb_out[23]_i_166\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFEFEE"
    )
        port map (
      I0 => \rgb_out[23]_i_442_n_0\,
      I1 => \rgb_out[23]_i_443_n_0\,
      I2 => \rgb_out[23]_i_444_n_0\,
      I3 => \rgb_out[23]_i_445_n_0\,
      I4 => \rgb_out[23]_i_446_n_0\,
      I5 => \rgb_out[23]_i_447_n_0\,
      O => \SC_U/pixel_on0\
    );
\rgb_out[23]_i_167\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000EAEEEAEA"
    )
        port map (
      I0 => \rgb_out[23]_i_448_n_0\,
      I1 => \rgb_out[23]_i_449_n_0\,
      I2 => \pixel_x[1]\(0),
      I3 => score_diz,
      I4 => \pixel_x[5]\(0),
      I5 => \rgb_out[23]_i_453_n_0\,
      O => num_sc_d
    );
\rgb_out[23]_i_168\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"2000000000000000"
    )
        port map (
      I0 => \rgb_out[23]_i_454_n_0\,
      I1 => \rgb_out[23]_i_455_n_0\,
      I2 => pixel_y(1),
      I3 => pixel_y(2),
      I4 => pixel_y(3),
      I5 => pixel_y(4),
      O => \rgb_out[23]_i_168_n_0\
    );
\rgb_out[23]_i_169\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"8A"
    )
        port map (
      I0 => \rgb_out[23]_i_456_n_0\,
      I1 => \rgb_out[23]_i_457_n_0\,
      I2 => \rgb_out[23]_i_431_n_0\,
      O => \rgb_out[23]_i_169_n_0\
    );
\rgb_out[23]_i_170\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"ABABAB00ABABABAB"
    )
        port map (
      I0 => \rgb_out[23]_i_458_n_0\,
      I1 => \rgb_out[23]_i_224_n_0\,
      I2 => \rgb_out[23]_i_390_n_0\,
      I3 => \rgb_out[23]_i_223_n_0\,
      I4 => \rgb_out[23]_i_233_n_0\,
      I5 => \rgb_out[23]_i_174_n_0\,
      O => \rgb_out[23]_i_170_n_0\
    );
\rgb_out[23]_i_171\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"80808000AAAAAAAA"
    )
        port map (
      I0 => \rgb_out[23]_i_431_n_0\,
      I1 => pixel_x(3),
      I2 => pixel_x(6),
      I3 => pixel_x(2),
      I4 => pixel_x(1),
      I5 => \rgb_out[23]_i_430_n_0\,
      O => \rgb_out[23]_i_171_n_0\
    );
\rgb_out[23]_i_172\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00008000"
    )
        port map (
      I0 => pixel_y(4),
      I1 => pixel_y(3),
      I2 => pixel_y(2),
      I3 => pixel_y(1),
      I4 => \rgb_out[23]_i_455_n_0\,
      O => \rgb_out[23]_i_172_n_0\
    );
\rgb_out[23]_i_173\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000000004"
    )
        port map (
      I0 => pixel_x(9),
      I1 => \rgb_out[11]_i_11_n_0\,
      I2 => pixel_x(7),
      I3 => pixel_x(8),
      I4 => pixel_x(6),
      I5 => pixel_x(5),
      O => \rgb_out[23]_i_173_n_0\
    );
\rgb_out[23]_i_174\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000000001"
    )
        port map (
      I0 => pixel_x(7),
      I1 => pixel_x(11),
      I2 => pixel_x(10),
      I3 => pixel_x(9),
      I4 => pixel_x(8),
      I5 => pixel_x(6),
      O => \rgb_out[23]_i_174_n_0\
    );
\rgb_out[23]_i_175\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"80"
    )
        port map (
      I0 => pixel_x(5),
      I1 => pixel_x(2),
      I2 => pixel_x(1),
      O => \rgb_out[23]_i_175_n_0\
    );
\rgb_out[23]_i_176\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"A8"
    )
        port map (
      I0 => pixel_x(5),
      I1 => pixel_x(4),
      I2 => pixel_x(3),
      O => \rgb_out[23]_i_176_n_0\
    );
\rgb_out[23]_i_177\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"CCCFCCCF888F8888"
    )
        port map (
      I0 => \rgb_out[23]_i_456_n_0\,
      I1 => \rgb_out[23]_i_454_n_0\,
      I2 => \rgb_out[23]_i_459_n_0\,
      I3 => \rgb_out[23]_i_435_n_0\,
      I4 => \rgb_out[23]_i_432_n_0\,
      I5 => \rgb_out[23]_i_421_n_0\,
      O => \rgb_out[23]_i_177_n_0\
    );
\rgb_out[23]_i_178\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"BF00BFBFBFBFBFBF"
    )
        port map (
      I0 => \rgb_out[23]_i_460_n_0\,
      I1 => \rgb_out[23]_i_423_n_0\,
      I2 => \rgb_out[23]_i_461_n_0\,
      I3 => \rgb_out[23]_i_462_n_0\,
      I4 => \rgb_out[23]_i_179_n_0\,
      I5 => \rgb_out[23]_i_463_n_0\,
      O => \rgb_out[23]_i_178_n_0\
    );
\rgb_out[23]_i_179\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00100000"
    )
        port map (
      I0 => \rgb_out[23]_i_455_n_0\,
      I1 => pixel_y(3),
      I2 => pixel_y(4),
      I3 => pixel_y(1),
      I4 => pixel_y(2),
      O => \rgb_out[23]_i_179_n_0\
    );
\rgb_out[23]_i_180\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000D5550000"
    )
        port map (
      I0 => \rgb_out[23]_i_430_n_0\,
      I1 => \rgb_out[11]_i_22_n_0\,
      I2 => pixel_x(6),
      I3 => pixel_x(3),
      I4 => \rgb_out[23]_i_431_n_0\,
      I5 => \rgb_out[23]_i_464_n_0\,
      O => \rgb_out[23]_i_180_n_0\
    );
\rgb_out[23]_i_181\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"D5555555FFFFFFFF"
    )
        port map (
      I0 => \rgb_out[23]_i_465_n_0\,
      I1 => \rgb_out[23]_i_466_n_0\,
      I2 => \rgb_out[23]_i_346_n_0\,
      I3 => \rgb_out[20]_i_23_n_0\,
      I4 => pixel_x(5),
      I5 => \rgb_out[23]_i_390_n_0\,
      O => \rgb_out[23]_i_181_n_0\
    );
\rgb_out[23]_i_182\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"55105555"
    )
        port map (
      I0 => \rgb_out[23]_i_378_n_0\,
      I1 => \rgb_out[23]_i_379_n_0\,
      I2 => \rgb_out[23]_i_390_n_0\,
      I3 => \rgb_out[23]_i_467_n_0\,
      I4 => \rgb_out[23]_i_387_n_0\,
      O => \rgb_out[23]_i_182_n_0\
    );
\rgb_out[23]_i_183\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \rgb_out[23]_i_124_n_0\,
      I1 => \rgb_out[23]_i_131_n_0\,
      O => \rgb_out[23]_i_183_n_0\
    );
\rgb_out[23]_i_184\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0040404000400040"
    )
        port map (
      I0 => \rgb_out[20]_i_22_n_0\,
      I1 => \rgb_out[20]_i_23_n_0\,
      I2 => \rgb_out[11]_i_11_n_0\,
      I3 => \rgb_out[23]_i_468_n_0\,
      I4 => \rgb_out[23]_i_223_n_0\,
      I5 => pixel_x(0),
      O => \rgb_out[23]_i_184_n_0\
    );
\rgb_out[23]_i_185\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000A000A00030000"
    )
        port map (
      I0 => \rgb_out[20]_i_22_n_0\,
      I1 => \rgb_out[20]_i_19_n_0\,
      I2 => pixel_x(5),
      I3 => \rgb_out[20]_i_20_n_0\,
      I4 => \rgb_out[23]_i_382_n_0\,
      I5 => \rgb_out[23]_i_469_n_0\,
      O => \rgb_out[23]_i_185_n_0\
    );
\rgb_out[23]_i_186\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"FE"
    )
        port map (
      I0 => \rgb_out[7]_i_47_n_0\,
      I1 => \rgb_out[23]_i_129_n_0\,
      I2 => \rgb_out[23]_i_79_n_0\,
      O => \rgb_out[23]_i_186_n_0\
    );
\rgb_out[23]_i_187\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"E0000000"
    )
        port map (
      I0 => \pixel_y[2]_13\(0),
      I1 => \pixel_y[5]_2\(0),
      I2 => \rgb_out[23]_i_190_n_0\,
      I3 => \TM_D/pixel_on9\,
      I4 => \pixel_x[3]_2\(0),
      O => \rgb_out[23]_i_187_n_0\
    );
\rgb_out[23]_i_188\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"F888"
    )
        port map (
      I0 => \pixel_y[5]_3\(0),
      I1 => \pixel_y[2]_14\(0),
      I2 => \pixel_y[2]_15\(0),
      I3 => \pixel_y[2]_16\(0),
      O => \rgb_out[23]_i_188_n_0\
    );
\rgb_out[23]_i_19\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000000008AA"
    )
        port map (
      I0 => \rgb_out[23]_i_65_n_0\,
      I1 => \rgb_out[23]_i_66_n_0\,
      I2 => \rgb_out[23]_i_67_n_0\,
      I3 => pixel_y(9),
      I4 => \rgb_out[23]_i_68_n_0\,
      I5 => \rgb_out[23]_i_69_n_0\,
      O => \rgb_out[23]_i_19_n_0\
    );
\rgb_out[23]_i_190\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"57"
    )
        port map (
      I0 => temps_restant(3),
      I1 => temps_restant(1),
      I2 => temps_restant(2),
      O => \rgb_out[23]_i_190_n_0\
    );
\rgb_out[23]_i_192\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"7FFF"
    )
        port map (
      I0 => \pixel_y[2]_11\(0),
      I1 => \pixel_x[3]_0\(0),
      I2 => \pixel_y[2]_12\(0),
      I3 => \pixel_x[3]_1\(0),
      O => \rgb_out[23]_i_192_n_0\
    );
\rgb_out[23]_i_1928\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => local_x_0(6),
      I1 => local_x_0(7),
      O => \rgb_out[23]_i_1928_n_0\
    );
\rgb_out[23]_i_1929\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => local_x_0(5),
      I1 => local_x_0(4),
      O => \rgb_out[23]_i_1929_n_0\
    );
\rgb_out[23]_i_1930\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => local_x_0(0),
      I1 => local_x_0(1),
      O => \rgb_out[23]_i_1930_n_0\
    );
\rgb_out[23]_i_1931\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => local_x_0(7),
      I1 => local_x_0(6),
      O => \rgb_out[23]_i_1931_n_0\
    );
\rgb_out[23]_i_1932\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => local_x_0(4),
      I1 => local_x_0(5),
      O => \rgb_out[23]_i_1932_n_0\
    );
\rgb_out[23]_i_1933\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => local_x_0(2),
      I1 => local_x_0(3),
      O => \rgb_out[23]_i_1933_n_0\
    );
\rgb_out[23]_i_1934\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => local_x_0(1),
      I1 => local_x_0(0),
      O => \rgb_out[23]_i_1934_n_0\
    );
\rgb_out[23]_i_195\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8888808888808888"
    )
        port map (
      I0 => pixel_on75_in,
      I1 => pixel_on66_in,
      I2 => temps_restant(0),
      I3 => temps_restant(3),
      I4 => temps_restant(1),
      I5 => temps_restant(2),
      O => \rgb_out[23]_i_195_n_0\
    );
\rgb_out[23]_i_196\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9200"
    )
        port map (
      I0 => temps_restant(0),
      I1 => temps_restant(3),
      I2 => temps_restant(1),
      I3 => temps_restant(2),
      O => \rgb_out[23]_i_196_n_0\
    );
\rgb_out[23]_i_199\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"F7FF"
    )
        port map (
      I0 => pixel_on75_in,
      I1 => pixel_on66_in,
      I2 => temps_restant(0),
      I3 => pixel_on6,
      O => \rgb_out[23]_i_199_n_0\
    );
\rgb_out[23]_i_1999\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_y(11),
      O => \rgb_out[23]_i_1999_n_0\
    );
\rgb_out[23]_i_20\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFAABA"
    )
        port map (
      I0 => \rgb_out[23]_i_70_n_0\,
      I1 => \rgb_out[23]_i_71_n_0\,
      I2 => \rgb_out[23]_i_72_n_0\,
      I3 => \rgb_out[20]_i_9_n_0\,
      I4 => \rgb_out[23]_i_73_n_0\,
      I5 => \rgb_out[23]_i_74_n_0\,
      O => \rgb_out[23]_i_20_n_0\
    );
\rgb_out[23]_i_200\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"80"
    )
        port map (
      I0 => pixel_on6,
      I1 => pixel_on83_in,
      I2 => pixel_on7,
      O => \rgb_out[23]_i_200_n_0\
    );
\rgb_out[23]_i_2000\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_y(10),
      O => \rgb_out[23]_i_2000_n_0\
    );
\rgb_out[23]_i_2001\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_y(9),
      O => \rgb_out[23]_i_2001_n_0\
    );
\rgb_out[23]_i_2009\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => local_x(6),
      I1 => local_x(7),
      O => \rgb_out[23]_i_2009_n_0\
    );
\rgb_out[23]_i_2010\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => local_x(4),
      I1 => local_x(5),
      O => \rgb_out[23]_i_2010_n_0\
    );
\rgb_out[23]_i_2012\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => local_x(0),
      I1 => local_x(1),
      O => \rgb_out[23]_i_2012_n_0\
    );
\rgb_out[23]_i_2013\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => local_x(7),
      I1 => local_x(6),
      O => \rgb_out[23]_i_2013_n_0\
    );
\rgb_out[23]_i_2014\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => local_x(5),
      I1 => local_x(4),
      O => \rgb_out[23]_i_2014_n_0\
    );
\rgb_out[23]_i_2015\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => local_x(2),
      I1 => local_x(3),
      O => \rgb_out[23]_i_2015_n_0\
    );
\rgb_out[23]_i_2016\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => local_x(1),
      I1 => local_x(0),
      O => \rgb_out[23]_i_2016_n_0\
    );
\rgb_out[23]_i_202\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"82A82AA2"
    )
        port map (
      I0 => pixel_on5,
      I1 => temps_restant(0),
      I2 => temps_restant(3),
      I3 => temps_restant(1),
      I4 => temps_restant(2),
      O => \rgb_out[23]_i_202_n_0\
    );
\rgb_out[23]_i_2024\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \^local_y\(5),
      I1 => \^local_y\(6),
      O => \rgb_out[23]_i_2024_n_0\
    );
\rgb_out[23]_i_2025\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \^local_y\(3),
      I1 => \^local_y\(4),
      O => \rgb_out[23]_i_2025_n_0\
    );
\rgb_out[23]_i_2026\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => pixel_y(0),
      I1 => \^local_y\(0),
      O => \rgb_out[23]_i_2026_n_0\
    );
\rgb_out[23]_i_2027\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \^local_y\(6),
      I1 => \^local_y\(5),
      O => \rgb_out[23]_i_2027_n_0\
    );
\rgb_out[23]_i_2028\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \^local_y\(4),
      I1 => \^local_y\(3),
      O => \rgb_out[23]_i_2028_n_0\
    );
\rgb_out[23]_i_2029\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \^local_y\(1),
      I1 => \^local_y\(2),
      O => \rgb_out[23]_i_2029_n_0\
    );
\rgb_out[23]_i_203\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8088088080888880"
    )
        port map (
      I0 => pixel_on31_in,
      I1 => pixel_on22_in,
      I2 => temps_restant(2),
      I3 => temps_restant(1),
      I4 => temps_restant(3),
      I5 => temps_restant(0),
      O => \rgb_out[23]_i_203_n_0\
    );
\rgb_out[23]_i_2030\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \^local_y\(0),
      I1 => pixel_y(0),
      O => \rgb_out[23]_i_2030_n_0\
    );
\rgb_out[23]_i_2031\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \^local_y\(4),
      I1 => \^local_y\(3),
      O => \rgb_out[23]_i_2031_n_0\
    );
\rgb_out[23]_i_2032\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"7"
    )
        port map (
      I0 => \^local_y\(1),
      I1 => \^local_y\(2),
      O => \rgb_out[23]_i_2032_n_0\
    );
\rgb_out[23]_i_2033\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \^local_y\(0),
      O => \rgb_out[23]_i_2033_n_0\
    );
\rgb_out[23]_i_2034\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \^local_y\(6),
      I1 => \^local_y\(5),
      O => \rgb_out[23]_i_2034_n_0\
    );
\rgb_out[23]_i_2035\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \^local_y\(3),
      I1 => \^local_y\(4),
      O => \rgb_out[23]_i_2035_n_0\
    );
\rgb_out[23]_i_2036\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \^local_y\(2),
      I1 => \^local_y\(1),
      O => \rgb_out[23]_i_2036_n_0\
    );
\rgb_out[23]_i_2037\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \^local_y\(0),
      I1 => pixel_y(0),
      O => \rgb_out[23]_i_2037_n_0\
    );
\rgb_out[23]_i_204\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"7557D55D"
    )
        port map (
      I0 => pixel_on712_in,
      I1 => temps_restant(0),
      I2 => temps_restant(3),
      I3 => temps_restant(1),
      I4 => temps_restant(2),
      O => \rgb_out[23]_i_204_n_0\
    );
\rgb_out[23]_i_2044\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"7"
    )
        port map (
      I0 => \^local_y\(3),
      I1 => \^local_y\(4),
      O => \rgb_out[23]_i_2044_n_0\
    );
\rgb_out[23]_i_2045\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \^local_y\(2),
      I1 => \^local_y\(1),
      O => \rgb_out[23]_i_2045_n_0\
    );
\rgb_out[23]_i_2046\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \^local_y\(0),
      O => \rgb_out[23]_i_2046_n_0\
    );
\rgb_out[23]_i_2047\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \^local_y\(6),
      I1 => \^local_y\(5),
      O => \rgb_out[23]_i_2047_n_0\
    );
\rgb_out[23]_i_2048\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \^local_y\(4),
      I1 => \^local_y\(3),
      O => \rgb_out[23]_i_2048_n_0\
    );
\rgb_out[23]_i_2049\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \^local_y\(1),
      I1 => \^local_y\(2),
      O => \rgb_out[23]_i_2049_n_0\
    );
\rgb_out[23]_i_205\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"2A000000FFFFFFFF"
    )
        port map (
      I0 => \rgb_out[23]_i_521_n_0\,
      I1 => \rgb_out[23]_i_522_n_0\,
      I2 => \rgb_out[23]_i_523_n_0\,
      I3 => \rgb_out[23]_i_524_n_0\,
      I4 => \rgb_out[23]_i_525_n_0\,
      I5 => \rgb_out[23]_i_526_n_0\,
      O => \rgb_out[23]_i_205_n_0\
    );
\rgb_out[23]_i_2050\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \^local_y\(0),
      I1 => pixel_y(0),
      O => \rgb_out[23]_i_2050_n_0\
    );
\rgb_out[23]_i_206\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000FFBAFFBAFFBA"
    )
        port map (
      I0 => \rgb_out[23]_i_527_n_0\,
      I1 => \rgb_out[23]_i_528_n_0\,
      I2 => \rgb_out[23]_i_529_n_0\,
      I3 => \rgb_out[23]_i_530_n_0\,
      I4 => \rgb_out[23]_i_531_n_0\,
      I5 => \rgb_out[23]_i_524_n_0\,
      O => \rgb_out[23]_i_206_n_0\
    );
\rgb_out[23]_i_207\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFD0D0FFD0"
    )
        port map (
      I0 => \rgb_out[23]_i_521_n_0\,
      I1 => \rgb_out[23]_i_532_n_0\,
      I2 => \rgb_out[23]_i_530_n_0\,
      I3 => \rgb_out[23]_i_533_n_0\,
      I4 => \rgb_out[23]_i_531_n_0\,
      I5 => \rgb_out[23]_i_61_n_0\,
      O => \rgb_out[23]_i_207_n_0\
    );
\rgb_out[23]_i_208\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAAAAAA88888A88"
    )
        port map (
      I0 => \rgb_out[23]_i_532_n_0\,
      I1 => \rgb_out[23]_i_533_n_0\,
      I2 => \rgb_out[23]_i_528_n_0\,
      I3 => \rgb_out[11]_i_25_n_0\,
      I4 => \rgb_out[21]_i_6_n_0\,
      I5 => \rgb_out[23]_i_526_n_0\,
      O => \rgb_out[23]_i_208_n_0\
    );
\rgb_out[23]_i_209\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFEEEEEFEE"
    )
        port map (
      I0 => \rgb_out[23]_i_533_n_0\,
      I1 => \rgb_out[23]_i_527_n_0\,
      I2 => \rgb_out[23]_i_528_n_0\,
      I3 => \rgb_out[11]_i_25_n_0\,
      I4 => \rgb_out[21]_i_6_n_0\,
      I5 => \rgb_out[23]_i_530_n_0\,
      O => \rgb_out[23]_i_209_n_0\
    );
\rgb_out[23]_i_21\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \rgb_out[7]_i_19_n_0\,
      I1 => \rgb_out[23]_i_75_n_0\,
      O => \rgb_out[23]_i_21_n_0\
    );
\rgb_out[23]_i_210\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"EEFEEEFEEEFE0000"
    )
        port map (
      I0 => pixel_x(11),
      I1 => \rgb_out[23]_i_534_n_0\,
      I2 => pixel_x(10),
      I3 => \rgb_out[23]_i_535_n_0\,
      I4 => \rgb_out[23]_i_536_n_0\,
      I5 => \rgb_out[23]_i_537_n_0\,
      O => \rgb_out[23]_i_210_n_0\
    );
\rgb_out[23]_i_211\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8880808888888888"
    )
        port map (
      I0 => pixel_on83_in,
      I1 => pixel_on7,
      I2 => decompte_ui(3),
      I3 => decompte_ui(0),
      I4 => decompte_ui(1),
      I5 => decompte_ui(2),
      O => \rgb_out[23]_i_211_n_0\
    );
\rgb_out[23]_i_212\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => pixel_on66_in,
      I1 => pixel_on75_in,
      O => \rgb_out[23]_i_212_n_0\
    );
\rgb_out[23]_i_2125\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_y(8),
      O => \rgb_out[23]_i_2125_n_0\
    );
\rgb_out[23]_i_2126\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_y(7),
      O => \rgb_out[23]_i_2126_n_0\
    );
\rgb_out[23]_i_2127\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_y(6),
      O => \rgb_out[23]_i_2127_n_0\
    );
\rgb_out[23]_i_2128\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_y(5),
      O => \rgb_out[23]_i_2128_n_0\
    );
\rgb_out[23]_i_2129\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_y(4),
      O => \rgb_out[23]_i_2129_n_0\
    );
\rgb_out[23]_i_213\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00101010"
    )
        port map (
      I0 => decompte_ui(0),
      I1 => decompte_ui(1),
      I2 => decompte_ui(2),
      I3 => pixel_on22_in,
      I4 => pixel_on31_in,
      O => \rgb_out[23]_i_213_n_0\
    );
\rgb_out[23]_i_2130\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_y(2),
      O => \rgb_out[23]_i_2130_n_0\
    );
\rgb_out[23]_i_214\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000000000F1"
    )
        port map (
      I0 => pixel_on5,
      I1 => pixel_on712_in,
      I2 => decompte_ui(0),
      I3 => decompte_ui(3),
      I4 => decompte_ui(2),
      I5 => decompte_ui(1),
      O => \rgb_out[23]_i_214_n_0\
    );
\rgb_out[23]_i_215\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"F7FF"
    )
        port map (
      I0 => decompte_ui(0),
      I1 => decompte_ui(1),
      I2 => pixel_on712_in,
      I3 => decompte_ui(2),
      O => \rgb_out[23]_i_215_n_0\
    );
\rgb_out[23]_i_217\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0800080000000800"
    )
        port map (
      I0 => pixel_on75_in,
      I1 => pixel_on66_in,
      I2 => decompte_ui(0),
      I3 => pixel_on6,
      I4 => decompte_ui(2),
      I5 => decompte_ui(1),
      O => \rgb_out[23]_i_217_n_0\
    );
\rgb_out[23]_i_218\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8080800080808080"
    )
        port map (
      I0 => pixel_on7,
      I1 => pixel_on83_in,
      I2 => pixel_on6,
      I3 => decompte_ui(3),
      I4 => \rgb_out[23]_i_538_n_0\,
      I5 => \rgb_out[23]_i_539_n_0\,
      O => \rgb_out[23]_i_218_n_0\
    );
\rgb_out[23]_i_219\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"01"
    )
        port map (
      I0 => pixel_x(10),
      I1 => pixel_x(11),
      I2 => pixel_x(9),
      O => \rgb_out[23]_i_219_n_0\
    );
\rgb_out[23]_i_22\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \rgb_out[23]_i_76_n_0\,
      I1 => \rgb_out[23]_i_77_n_0\,
      O => \rgb_out[23]_i_22_n_0\
    );
\rgb_out[23]_i_220\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0002000200020202"
    )
        port map (
      I0 => \rgb_out[23]_i_540_n_0\,
      I1 => pixel_y(5),
      I2 => pixel_y(4),
      I3 => pixel_y(3),
      I4 => pixel_y(1),
      I5 => pixel_y(2),
      O => \rgb_out[23]_i_220_n_0\
    );
\rgb_out[23]_i_221\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"01"
    )
        port map (
      I0 => pixel_x(10),
      I1 => pixel_x(11),
      I2 => pixel_x(7),
      O => \rgb_out[23]_i_221_n_0\
    );
\rgb_out[23]_i_222\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"80"
    )
        port map (
      I0 => pixel_x(3),
      I1 => pixel_x(4),
      I2 => pixel_x(5),
      O => \rgb_out[23]_i_222_n_0\
    );
\rgb_out[23]_i_223\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"7"
    )
        port map (
      I0 => pixel_x(1),
      I1 => pixel_x(2),
      O => \rgb_out[23]_i_223_n_0\
    );
\rgb_out[23]_i_224\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => pixel_x(9),
      I1 => pixel_x(8),
      O => \rgb_out[23]_i_224_n_0\
    );
\rgb_out[23]_i_225\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_x(3),
      I1 => pixel_x(4),
      O => \rgb_out[23]_i_225_n_0\
    );
\rgb_out[23]_i_226\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => pixel_x(6),
      I1 => pixel_x(5),
      O => \rgb_out[23]_i_226_n_0\
    );
\rgb_out[23]_i_227\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFF020000"
    )
        port map (
      I0 => \rgb_out[7]_i_73_n_0\,
      I1 => pixel_x(0),
      I2 => \rgb_out[11]_i_22_n_0\,
      I3 => \rgb_out[23]_i_541_n_0\,
      I4 => \rgb_out[7]_i_72_n_0\,
      I5 => \rgb_out[23]_i_129_n_0\,
      O => \rgb_out[23]_i_227_n_0\
    );
\rgb_out[23]_i_228\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"0000557F"
    )
        port map (
      I0 => pixel_y(3),
      I1 => pixel_y(0),
      I2 => pixel_y(1),
      I3 => pixel_y(2),
      I4 => \rgb_out[23]_i_256_n_0\,
      O => \rgb_out[23]_i_228_n_0\
    );
\rgb_out[23]_i_229\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00001011"
    )
        port map (
      I0 => \rgb_out[23]_i_257_n_0\,
      I1 => \rgb_out[23]_i_77_n_0\,
      I2 => \rgb_out[23]_i_256_n_0\,
      I3 => \rgb_out[23]_i_349_n_0\,
      I4 => \rgb_out[23]_i_264_n_0\,
      O => \rgb_out[23]_i_229_n_0\
    );
\rgb_out[23]_i_23\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFFEAEE"
    )
        port map (
      I0 => \rgb_out[23]_i_78_n_0\,
      I1 => \rgb_out[23]_i_76_n_0\,
      I2 => \rgb_out[23]_i_79_n_0\,
      I3 => \rgb_out[23]_i_80_n_0\,
      I4 => \rgb_out[23]_i_81_n_0\,
      O => \rgb_out[23]_i_23_n_0\
    );
\rgb_out[23]_i_230\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"EA"
    )
        port map (
      I0 => pixel_x(4),
      I1 => pixel_x(2),
      I2 => pixel_x(3),
      O => \rgb_out[23]_i_230_n_0\
    );
\rgb_out[23]_i_231\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"3F000000AAAAAAAA"
    )
        port map (
      I0 => \rgb_out[23]_i_387_n_0\,
      I1 => \rgb_out[11]_i_20_n_0\,
      I2 => \rgb_out[20]_i_23_n_0\,
      I3 => \rgb_out[11]_i_11_n_0\,
      I4 => \rgb_out[23]_i_384_n_0\,
      I5 => \rgb_out[23]_i_379_n_0\,
      O => \rgb_out[23]_i_231_n_0\
    );
\rgb_out[23]_i_232\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAAAAAAABABAAAB"
    )
        port map (
      I0 => \rgb_out[23]_i_255_n_0\,
      I1 => \rgb_out[7]_i_26_n_0\,
      I2 => \rgb_out[7]_i_25_n_0\,
      I3 => pixel_x(2),
      I4 => \rgb_out[23]_i_370_n_0\,
      I5 => pixel_x(3),
      O => \rgb_out[23]_i_232_n_0\
    );
\rgb_out[23]_i_233\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"7"
    )
        port map (
      I0 => pixel_x(5),
      I1 => pixel_x(4),
      O => \rgb_out[23]_i_233_n_0\
    );
\rgb_out[23]_i_234\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"A8"
    )
        port map (
      I0 => pixel_x(2),
      I1 => pixel_x(1),
      I2 => pixel_x(0),
      O => \rgb_out[23]_i_234_n_0\
    );
\rgb_out[23]_i_235\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"FE"
    )
        port map (
      I0 => pixel_x(8),
      I1 => pixel_x(10),
      I2 => pixel_x(11),
      O => \rgb_out[23]_i_235_n_0\
    );
\rgb_out[23]_i_236\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => pixel_y(7),
      I1 => pixel_y(6),
      O => \rgb_out[23]_i_236_n_0\
    );
\rgb_out[23]_i_237\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"8000"
    )
        port map (
      I0 => pixel_y(3),
      I1 => pixel_y(2),
      I2 => pixel_y(0),
      I3 => pixel_y(1),
      O => \rgb_out[23]_i_237_n_0\
    );
\rgb_out[23]_i_238\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"8000"
    )
        port map (
      I0 => pixel_y(4),
      I1 => pixel_y(5),
      I2 => pixel_y(7),
      I3 => pixel_y(6),
      O => \rgb_out[23]_i_238_n_0\
    );
\rgb_out[23]_i_239\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"EA"
    )
        port map (
      I0 => pixel_y(3),
      I1 => pixel_y(1),
      I2 => pixel_y(2),
      O => \rgb_out[23]_i_239_n_0\
    );
\rgb_out[23]_i_24\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFFE"
    )
        port map (
      I0 => \rgb_out[23]_i_82_n_0\,
      I1 => \rgb_out[23]_i_83_n_0\,
      I2 => \rgb_out[23]_i_84_n_0\,
      I3 => \rgb_out[23]_i_85_n_0\,
      O => \rgb_out[23]_i_24_n_0\
    );
\rgb_out[23]_i_240\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0F000F0400000000"
    )
        port map (
      I0 => \rgb_out[23]_i_233_n_0\,
      I1 => \rgb_out[11]_i_21_n_0\,
      I2 => \rgb_out[23]_i_219_n_0\,
      I3 => \rgb_out[23]_i_235_n_0\,
      I4 => \rgb_out[23]_i_334_n_0\,
      I5 => \rgb_out[7]_i_55_n_0\,
      O => \rgb_out[23]_i_240_n_0\
    );
\rgb_out[23]_i_241\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \rgb_out[20]_i_14_n_0\,
      I1 => \rgb_out[23]_i_252_n_0\,
      O => \rgb_out[23]_i_241_n_0\
    );
\rgb_out[23]_i_242\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000000000FB"
    )
        port map (
      I0 => pixel_y(6),
      I1 => \rgb_out[23]_i_137_n_0\,
      I2 => \rgb_out[23]_i_41_n_0\,
      I3 => \rgb_out[20]_i_29_n_0\,
      I4 => \rgb_out[23]_i_239_n_0\,
      I5 => \rgb_out[20]_i_28_n_0\,
      O => \rgb_out[23]_i_242_n_0\
    );
\rgb_out[23]_i_243\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000055D5FFFF"
    )
        port map (
      I0 => \rgb_out[7]_i_73_n_0\,
      I1 => \rgb_out[20]_i_23_n_0\,
      I2 => pixel_x(3),
      I3 => \rgb_out[23]_i_233_n_0\,
      I4 => \rgb_out[7]_i_72_n_0\,
      I5 => \rgb_out[23]_i_399_n_0\,
      O => \rgb_out[23]_i_243_n_0\
    );
\rgb_out[23]_i_244\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \rgb_out[23]_i_87_n_0\,
      I1 => \rgb_out[23]_i_151_n_0\,
      O => \rgb_out[23]_i_244_n_0\
    );
\rgb_out[23]_i_245\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"8000"
    )
        port map (
      I0 => pixel_x(7),
      I1 => pixel_x(6),
      I2 => pixel_x(5),
      I3 => pixel_x(9),
      O => \rgb_out[23]_i_245_n_0\
    );
\rgb_out[23]_i_246\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"8000"
    )
        port map (
      I0 => pixel_x(2),
      I1 => pixel_x(3),
      I2 => pixel_x(1),
      I3 => pixel_x(0),
      O => \rgb_out[23]_i_246_n_0\
    );
\rgb_out[23]_i_247\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"7F"
    )
        port map (
      I0 => pixel_x(9),
      I1 => pixel_x(7),
      I2 => pixel_x(6),
      O => \rgb_out[23]_i_247_n_0\
    );
\rgb_out[23]_i_248\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000015000000"
    )
        port map (
      I0 => pixel_x(3),
      I1 => pixel_x(1),
      I2 => pixel_x(2),
      I3 => \rgb_out[20]_i_25_n_0\,
      I4 => \rgb_out[11]_i_11_n_0\,
      I5 => pixel_x(8),
      O => \rgb_out[23]_i_248_n_0\
    );
\rgb_out[23]_i_249\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8080800080008000"
    )
        port map (
      I0 => \rgb_out[11]_i_21_n_0\,
      I1 => pixel_x(3),
      I2 => pixel_x(9),
      I3 => pixel_x(2),
      I4 => pixel_x(1),
      I5 => pixel_x(0),
      O => \rgb_out[23]_i_249_n_0\
    );
\rgb_out[23]_i_25\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFAE"
    )
        port map (
      I0 => \rgb_out[23]_i_86_n_0\,
      I1 => \rgb_out[23]_i_87_n_0\,
      I2 => \rgb_out[23]_i_88_n_0\,
      I3 => \rgb_out[23]_i_89_n_0\,
      O => \rgb_out[23]_i_25_n_0\
    );
\rgb_out[23]_i_250\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000080000000"
    )
        port map (
      I0 => pixel_y(4),
      I1 => pixel_y(5),
      I2 => pixel_y(7),
      I3 => pixel_y(6),
      I4 => \rgb_out[23]_i_135_n_0\,
      I5 => \rgb_out[23]_i_136_n_0\,
      O => \rgb_out[23]_i_250_n_0\
    );
\rgb_out[23]_i_251\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000000020"
    )
        port map (
      I0 => \rgb_out[20]_i_23_n_0\,
      I1 => \rgb_out[20]_i_20_n_0\,
      I2 => pixel_x(2),
      I3 => pixel_x(3),
      I4 => pixel_x(5),
      I5 => pixel_x(4),
      O => \rgb_out[23]_i_251_n_0\
    );
\rgb_out[23]_i_252\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000005100000000"
    )
        port map (
      I0 => \rgb_out[23]_i_542_n_0\,
      I1 => \rgb_out[23]_i_239_n_0\,
      I2 => \rgb_out[11]_i_24_n_0\,
      I3 => pixel_y(7),
      I4 => \rgb_out[21]_i_6_n_0\,
      I5 => pixel_y(8),
      O => \rgb_out[23]_i_252_n_0\
    );
\rgb_out[23]_i_253\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0002000000000000"
    )
        port map (
      I0 => \rgb_out[23]_i_135_n_0\,
      I1 => \rgb_out[23]_i_237_n_0\,
      I2 => \rgb_out[23]_i_138_n_0\,
      I3 => \rgb_out[23]_i_137_n_0\,
      I4 => pixel_y(3),
      I5 => pixel_y(4),
      O => \rgb_out[23]_i_253_n_0\
    );
\rgb_out[23]_i_254\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAAAAAABBBBABBB"
    )
        port map (
      I0 => \rgb_out[23]_i_255_n_0\,
      I1 => \rgb_out[7]_i_28_n_0\,
      I2 => pixel_x(6),
      I3 => pixel_x(4),
      I4 => \rgb_out[7]_i_85_n_0\,
      I5 => \rgb_out[7]_i_25_n_0\,
      O => \rgb_out[23]_i_254_n_0\
    );
\rgb_out[23]_i_255\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"F200F2000000F200"
    )
        port map (
      I0 => \rgb_out[23]_i_543_n_0\,
      I1 => \rgb_out[7]_i_69_n_0\,
      I2 => \rgb_out[23]_i_544_n_0\,
      I3 => \rgb_out[11]_i_11_n_0\,
      I4 => \rgb_out[23]_i_545_n_0\,
      I5 => \rgb_out[23]_i_546_n_0\,
      O => \rgb_out[23]_i_255_n_0\
    );
\rgb_out[23]_i_256\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFDDDDDFFF"
    )
        port map (
      I0 => \rgb_out[23]_i_135_n_0\,
      I1 => pixel_y(4),
      I2 => pixel_y(2),
      I3 => pixel_y(1),
      I4 => pixel_y(3),
      I5 => \rgb_out[23]_i_138_n_0\,
      O => \rgb_out[23]_i_256_n_0\
    );
\rgb_out[23]_i_257\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"1310000030300000"
    )
        port map (
      I0 => \rgb_out[23]_i_237_n_0\,
      I1 => \rgb_out[23]_i_138_n_0\,
      I2 => \rgb_out[21]_i_7_n_0\,
      I3 => \rgb_out[23]_i_136_n_0\,
      I4 => \rgb_out[23]_i_135_n_0\,
      I5 => pixel_y(4),
      O => \rgb_out[23]_i_257_n_0\
    );
\rgb_out[23]_i_258\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00800000"
    )
        port map (
      I0 => pixel_x(5),
      I1 => \rgb_out[23]_i_346_n_0\,
      I2 => \rgb_out[20]_i_23_n_0\,
      I3 => \rgb_out[20]_i_24_n_0\,
      I4 => \rgb_out[11]_i_11_n_0\,
      O => \rgb_out[23]_i_258_n_0\
    );
\rgb_out[23]_i_259\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"5555555555555515"
    )
        port map (
      I0 => \rgb_out[23]_i_399_n_0\,
      I1 => \rgb_out[20]_i_23_n_0\,
      I2 => pixel_x(3),
      I3 => \rgb_out[23]_i_233_n_0\,
      I4 => \rgb_out[23]_i_394_n_0\,
      I5 => pixel_x(2),
      O => \rgb_out[23]_i_259_n_0\
    );
\rgb_out[23]_i_26\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000002020002"
    )
        port map (
      I0 => \rgb_out[23]_i_90_n_0\,
      I1 => \rgb_out[23]_i_91_n_0\,
      I2 => \rgb_out[23]_i_92_n_0\,
      I3 => \rgb_out[23]_i_93_n_0\,
      I4 => \rgb_out[23]_i_94_n_0\,
      I5 => \rgb_out[23]_i_95_n_0\,
      O => \rgb_out[23]_i_26_n_0\
    );
\rgb_out[23]_i_260\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000001000010"
    )
        port map (
      I0 => pixel_y(4),
      I1 => \rgb_out[23]_i_267_n_0\,
      I2 => pixel_y(3),
      I3 => pixel_y(1),
      I4 => pixel_y(2),
      I5 => \rgb_out[20]_i_28_n_0\,
      O => \rgb_out[23]_i_260_n_0\
    );
\rgb_out[23]_i_261\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0002000200000002"
    )
        port map (
      I0 => pixel_x(2),
      I1 => pixel_x(3),
      I2 => \rgb_out[23]_i_235_n_0\,
      I3 => pixel_x(4),
      I4 => \rgb_out[20]_i_19_n_0\,
      I5 => \rgb_out[23]_i_245_n_0\,
      O => \rgb_out[23]_i_261_n_0\
    );
\rgb_out[23]_i_262\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \rgb_out[20]_i_13_n_0\,
      I1 => \rgb_out[23]_i_151_n_0\,
      O => \rgb_out[23]_i_262_n_0\
    );
\rgb_out[23]_i_263\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \rgb_out[20]_i_14_n_0\,
      I1 => \rgb_out[20]_i_13_n_0\,
      O => \rgb_out[23]_i_263_n_0\
    );
\rgb_out[23]_i_264\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00300050"
    )
        port map (
      I0 => \rgb_out[23]_i_349_n_0\,
      I1 => \rgb_out[23]_i_136_n_0\,
      I2 => \rgb_out[23]_i_135_n_0\,
      I3 => \rgb_out[23]_i_138_n_0\,
      I4 => pixel_y(4),
      O => \rgb_out[23]_i_264_n_0\
    );
\rgb_out[23]_i_265\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"01"
    )
        port map (
      I0 => \rgb_out[23]_i_77_n_0\,
      I1 => \rgb_out[23]_i_76_n_0\,
      I2 => \rgb_out[23]_i_257_n_0\,
      O => \rgb_out[23]_i_265_n_0\
    );
\rgb_out[23]_i_266\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"A8"
    )
        port map (
      I0 => pixel_y(3),
      I1 => pixel_y(1),
      I2 => pixel_y(2),
      O => \rgb_out[23]_i_266_n_0\
    );
\rgb_out[23]_i_267\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => pixel_y(6),
      I1 => pixel_y(5),
      O => \rgb_out[23]_i_267_n_0\
    );
\rgb_out[23]_i_268\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"7FFF7F5555555555"
    )
        port map (
      I0 => \rgb_out[20]_i_19_n_0\,
      I1 => \rgb_out[23]_i_372_n_0\,
      I2 => \rgb_out[23]_i_547_n_0\,
      I3 => \rgb_out[23]_i_548_n_0\,
      I4 => pixel_x(4),
      I5 => \rgb_out[23]_i_549_n_0\,
      O => \rgb_out[23]_i_268_n_0\
    );
\rgb_out[23]_i_269\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"FE"
    )
        port map (
      I0 => \rgb_out[23]_i_143_n_0\,
      I1 => \rgb_out[23]_i_144_n_0\,
      I2 => \rgb_out[23]_i_399_n_0\,
      O => \rgb_out[23]_i_269_n_0\
    );
\rgb_out[23]_i_27\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFF4F44444444"
    )
        port map (
      I0 => \rgb_out[23]_i_96_n_0\,
      I1 => \rgb_out[23]_i_97_n_0\,
      I2 => \rgb_out[23]_i_98_n_0\,
      I3 => \rgb_out[23]_i_99_n_0\,
      I4 => \rgb_out[23]_i_100_n_0\,
      I5 => \rgb_out[23]_i_101_n_0\,
      O => \rgb_out[23]_i_27_n_0\
    );
\rgb_out[23]_i_270\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFEFFFEFFFFFFFE"
    )
        port map (
      I0 => \rgb_out[23]_i_115_n_0\,
      I1 => \rgb_out[23]_i_278_n_0\,
      I2 => \rgb_out[23]_i_279_n_0\,
      I3 => \rgb_out[23]_i_112_n_0\,
      I4 => \rgb_out[23]_i_550_n_0\,
      I5 => \rgb_out[23]_i_285_n_0\,
      O => \rgb_out[23]_i_270_n_0\
    );
\rgb_out[23]_i_271\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00F2000000220000"
    )
        port map (
      I0 => \rgb_out[23]_i_278_n_0\,
      I1 => \rgb_out[23]_i_551_n_0\,
      I2 => \rgb_out[23]_i_279_n_0\,
      I3 => \rgb_out[23]_i_552_n_0\,
      I4 => \rgb_out[23]_i_219_n_0\,
      I5 => \rgb_out[23]_i_553_n_0\,
      O => \rgb_out[23]_i_271_n_0\
    );
\rgb_out[23]_i_272\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000001000000000"
    )
        port map (
      I0 => pixel_x(4),
      I1 => pixel_x(3),
      I2 => pixel_x(2),
      I3 => \rgb_out[23]_i_226_n_0\,
      I4 => \rgb_out[11]_i_29_n_0\,
      I5 => \rgb_out[23]_i_219_n_0\,
      O => \rgb_out[23]_i_272_n_0\
    );
\rgb_out[23]_i_273\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"2A2A2A2A2A2A2AAA"
    )
        port map (
      I0 => \rgb_out[23]_i_219_n_0\,
      I1 => pixel_x(7),
      I2 => pixel_x(8),
      I3 => pixel_x(4),
      I4 => pixel_x(5),
      I5 => pixel_x(6),
      O => \rgb_out[23]_i_273_n_0\
    );
\rgb_out[23]_i_274\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFABAAAAAAAAAAAA"
    )
        port map (
      I0 => \rgb_out[23]_i_554_n_0\,
      I1 => \rgb_out[23]_i_401_n_0\,
      I2 => pixel_x(6),
      I3 => \rgb_out[11]_i_29_n_0\,
      I4 => \rgb_out[23]_i_219_n_0\,
      I5 => \rgb_out[23]_i_115_n_0\,
      O => \rgb_out[23]_i_274_n_0\
    );
\rgb_out[23]_i_275\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"EEEEEEEEEEEEE0EE"
    )
        port map (
      I0 => \rgb_out[23]_i_308_n_0\,
      I1 => \rgb_out[23]_i_297_n_0\,
      I2 => \rgb_out[23]_i_555_n_0\,
      I3 => \rgb_out[23]_i_556_n_0\,
      I4 => \rgb_out[23]_i_352_n_0\,
      I5 => \rgb_out[23]_i_351_n_0\,
      O => \rgb_out[23]_i_275_n_0\
    );
\rgb_out[23]_i_276\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000F70000"
    )
        port map (
      I0 => \rgb_out[23]_i_557_n_0\,
      I1 => pixel_x(2),
      I2 => \rgb_out[23]_i_339_n_0\,
      I3 => \rgb_out[23]_i_111_n_0\,
      I4 => \rgb_out[23]_i_558_n_0\,
      I5 => \rgb_out[23]_i_341_n_0\,
      O => \rgb_out[23]_i_276_n_0\
    );
\rgb_out[23]_i_277\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"ABBBBBBBBBBBBBBB"
    )
        port map (
      I0 => \rgb_out[23]_i_559_n_0\,
      I1 => \rgb_out[23]_i_560_n_0\,
      I2 => pixel_x(10),
      I3 => pixel_x(6),
      I4 => \rgb_out[23]_i_543_n_0\,
      I5 => pixel_x(7),
      O => \rgb_out[23]_i_277_n_0\
    );
\rgb_out[23]_i_278\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000000704"
    )
        port map (
      I0 => \rgb_out[23]_i_561_n_0\,
      I1 => pixel_y(4),
      I2 => \rgb_out[23]_i_267_n_0\,
      I3 => \rgb_out[23]_i_237_n_0\,
      I4 => \rgb_out[23]_i_40_n_0\,
      I5 => \rgb_out[21]_i_6_n_0\,
      O => \rgb_out[23]_i_278_n_0\
    );
\rgb_out[23]_i_279\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000000080"
    )
        port map (
      I0 => \rgb_out[23]_i_561_n_0\,
      I1 => \rgb_out[23]_i_562_n_0\,
      I2 => pixel_y(4),
      I3 => \rgb_out[23]_i_40_n_0\,
      I4 => \rgb_out[21]_i_6_n_0\,
      I5 => \rgb_out[23]_i_267_n_0\,
      O => \rgb_out[23]_i_279_n_0\
    );
\rgb_out[23]_i_28\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFFFFE"
    )
        port map (
      I0 => \rgb_out[23]_i_102_n_0\,
      I1 => \rgb_out[23]_i_103_n_0\,
      I2 => num_rec_d,
      I3 => num_last_u,
      I4 => num_rec_u,
      I5 => num_last_d,
      O => \rgb_out[23]_i_28_n_0\
    );
\rgb_out[23]_i_280\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000000002"
    )
        port map (
      I0 => pixel_y(5),
      I1 => \rgb_out[23]_i_563_n_0\,
      I2 => \rgb_out[21]_i_6_n_0\,
      I3 => pixel_y(6),
      I4 => \rgb_out[11]_i_8_n_0\,
      I5 => \rgb_out[23]_i_40_n_0\,
      O => \rgb_out[23]_i_280_n_0\
    );
\rgb_out[23]_i_281\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000000000000000E"
    )
        port map (
      I0 => \rgb_out[23]_i_401_n_0\,
      I1 => \rgb_out[23]_i_564_n_0\,
      I2 => \rgb_out[23]_i_392_n_0\,
      I3 => pixel_x(5),
      I4 => \rgb_out[23]_i_337_n_0\,
      I5 => \rgb_out[23]_i_353_n_0\,
      O => \rgb_out[23]_i_281_n_0\
    );
\rgb_out[23]_i_282\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"EAAAAAAA"
    )
        port map (
      I0 => pixel_x(6),
      I1 => pixel_x(5),
      I2 => pixel_x(4),
      I3 => pixel_x(3),
      I4 => pixel_x(2),
      O => \rgb_out[23]_i_282_n_0\
    );
\rgb_out[23]_i_283\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFAEFFFFFF"
    )
        port map (
      I0 => \rgb_out[23]_i_565_n_0\,
      I1 => pixel_x(6),
      I2 => \rgb_out[20]_i_25_n_0\,
      I3 => \rgb_out[23]_i_219_n_0\,
      I4 => pixel_x(8),
      I5 => pixel_x(7),
      O => \rgb_out[23]_i_283_n_0\
    );
\rgb_out[23]_i_284\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000010000"
    )
        port map (
      I0 => \rgb_out[23]_i_340_n_0\,
      I1 => \rgb_out[23]_i_353_n_0\,
      I2 => pixel_x(3),
      I3 => pixel_x(4),
      I4 => pixel_x(5),
      I5 => \rgb_out[23]_i_337_n_0\,
      O => \rgb_out[23]_i_284_n_0\
    );
\rgb_out[23]_i_285\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000EF00FFFFFFFF"
    )
        port map (
      I0 => \rgb_out[23]_i_566_n_0\,
      I1 => pixel_y(4),
      I2 => \rgb_out[7]_i_37_n_0\,
      I3 => pixel_y(5),
      I4 => \rgb_out[23]_i_40_n_0\,
      I5 => \rgb_out[7]_i_32_n_0\,
      O => \rgb_out[23]_i_285_n_0\
    );
\rgb_out[23]_i_286\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000008000000"
    )
        port map (
      I0 => \rgb_out[23]_i_557_n_0\,
      I1 => pixel_x(3),
      I2 => \rgb_out[23]_i_233_n_0\,
      I3 => pixel_x(8),
      I4 => pixel_x(6),
      I5 => pixel_x(2),
      O => \rgb_out[23]_i_286_n_0\
    );
\rgb_out[23]_i_287\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFFBFF"
    )
        port map (
      I0 => \rgb_out[23]_i_366_n_0\,
      I1 => \rgb_out[20]_i_25_n_0\,
      I2 => \rgb_out[23]_i_567_n_0\,
      I3 => \rgb_out[23]_i_334_n_0\,
      I4 => pixel_x(11),
      I5 => pixel_x(8),
      O => \rgb_out[23]_i_287_n_0\
    );
\rgb_out[23]_i_288\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAAEAAAAAAAAAAA"
    )
        port map (
      I0 => \rgb_out[23]_i_341_n_0\,
      I1 => \rgb_out[20]_i_25_n_0\,
      I2 => \rgb_out[23]_i_346_n_0\,
      I3 => pixel_x(6),
      I4 => \rgb_out[11]_i_29_n_0\,
      I5 => \rgb_out[23]_i_219_n_0\,
      O => \rgb_out[23]_i_288_n_0\
    );
\rgb_out[23]_i_289\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000040404"
    )
        port map (
      I0 => \rgb_out[11]_i_11_n_0\,
      I1 => \rgb_out[23]_i_568_n_0\,
      I2 => \rgb_out[23]_i_569_n_0\,
      I3 => \rgb_out[23]_i_570_n_0\,
      I4 => \rgb_out[23]_i_351_n_0\,
      I5 => \rgb_out[23]_i_352_n_0\,
      O => \rgb_out[23]_i_289_n_0\
    );
\rgb_out[23]_i_29\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFDFFF0FFFDF0000"
    )
        port map (
      I0 => \rgb_out[23]_i_108_n_0\,
      I1 => \rgb_out[23]_i_109_n_0\,
      I2 => \rgb_out[23]_i_110_n_0\,
      I3 => \rgb_out[23]_i_111_n_0\,
      I4 => \rgb_out[23]_i_112_n_0\,
      I5 => \rgb_out[23]_i_97_n_0\,
      O => \rgb_out[23]_i_29_n_0\
    );
\rgb_out[23]_i_290\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000004000000"
    )
        port map (
      I0 => pixel_x(2),
      I1 => \rgb_out[23]_i_219_n_0\,
      I2 => \rgb_out[11]_i_29_n_0\,
      I3 => pixel_x(6),
      I4 => \rgb_out[23]_i_392_n_0\,
      I5 => pixel_x(5),
      O => \rgb_out[23]_i_290_n_0\
    );
\rgb_out[23]_i_291\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFF1500"
    )
        port map (
      I0 => \rgb_out[23]_i_352_n_0\,
      I1 => \rgb_out[23]_i_351_n_0\,
      I2 => \rgb_out[23]_i_226_n_0\,
      I3 => \rgb_out[23]_i_571_n_0\,
      I4 => \rgb_out[23]_i_304_n_0\,
      I5 => \rgb_out[23]_i_281_n_0\,
      O => \rgb_out[23]_i_291_n_0\
    );
\rgb_out[23]_i_292\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFF1FFF1FFFFFFF1"
    )
        port map (
      I0 => \rgb_out[23]_i_572_n_0\,
      I1 => \rgb_out[23]_i_352_n_0\,
      I2 => \rgb_out[23]_i_573_n_0\,
      I3 => \rgb_out[23]_i_574_n_0\,
      I4 => \rgb_out[23]_i_575_n_0\,
      I5 => \rgb_out[23]_i_576_n_0\,
      O => \rgb_out[23]_i_292_n_0\
    );
\rgb_out[23]_i_293\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAAAAAAFBFFFAAF"
    )
        port map (
      I0 => \rgb_out[23]_i_278_n_0\,
      I1 => pixel_y(3),
      I2 => \rgb_out[7]_i_37_n_0\,
      I3 => pixel_y(2),
      I4 => \rgb_out[23]_i_267_n_0\,
      I5 => \rgb_out[23]_i_577_n_0\,
      O => \rgb_out[23]_i_293_n_0\
    );
\rgb_out[23]_i_294\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000001000"
    )
        port map (
      I0 => pixel_x(3),
      I1 => \rgb_out[23]_i_233_n_0\,
      I2 => \rgb_out[23]_i_578_n_0\,
      I3 => \rgb_out[23]_i_219_n_0\,
      I4 => \rgb_out[11]_i_29_n_0\,
      I5 => pixel_x(6),
      O => \rgb_out[23]_i_294_n_0\
    );
\rgb_out[23]_i_295\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFFFBF"
    )
        port map (
      I0 => \rgb_out[23]_i_352_n_0\,
      I1 => pixel_x(7),
      I2 => pixel_x(10),
      I3 => pixel_x(4),
      I4 => pixel_x(5),
      I5 => pixel_x(6),
      O => \rgb_out[23]_i_295_n_0\
    );
\rgb_out[23]_i_296\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"CCCCCCCCC8C0C0C0"
    )
        port map (
      I0 => \rgb_out[23]_i_230_n_0\,
      I1 => pixel_x(10),
      I2 => \rgb_out[23]_i_224_n_0\,
      I3 => pixel_x(6),
      I4 => pixel_x(5),
      I5 => pixel_x(7),
      O => \rgb_out[23]_i_296_n_0\
    );
\rgb_out[23]_i_297\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FF00FF00FF008000"
    )
        port map (
      I0 => pixel_x(6),
      I1 => pixel_x(5),
      I2 => pixel_x(4),
      I3 => pixel_x(10),
      I4 => pixel_x(7),
      I5 => \rgb_out[23]_i_224_n_0\,
      O => \rgb_out[23]_i_297_n_0\
    );
\rgb_out[23]_i_298\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000005457"
    )
        port map (
      I0 => pixel_x(10),
      I1 => \rgb_out[23]_i_224_n_0\,
      I2 => pixel_x(7),
      I3 => \rgb_out[23]_i_334_n_0\,
      I4 => pixel_x(11),
      I5 => \rgb_out[23]_i_556_n_0\,
      O => \rgb_out[23]_i_298_n_0\
    );
\rgb_out[23]_i_299\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000000001"
    )
        port map (
      I0 => pixel_y(4),
      I1 => \rgb_out[23]_i_237_n_0\,
      I2 => \rgb_out[21]_i_6_n_0\,
      I3 => \rgb_out[23]_i_349_n_0\,
      I4 => \rgb_out[23]_i_267_n_0\,
      I5 => \rgb_out[23]_i_40_n_0\,
      O => \rgb_out[23]_i_299_n_0\
    );
\rgb_out[23]_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"72"
    )
        port map (
      I0 => mode_ui(1),
      I1 => mode_ui(2),
      I2 => mode_ui(0),
      O => \rgb_out[23]_i_3_n_0\
    );
\rgb_out[23]_i_30\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFEFAAAAAAAAAA"
    )
        port map (
      I0 => \rgb_out[23]_i_113_n_0\,
      I1 => \rgb_out[23]_i_99_n_0\,
      I2 => \rgb_out[23]_i_114_n_0\,
      I3 => \rgb_out[23]_i_115_n_0\,
      I4 => \rgb_out[23]_i_116_n_0\,
      I5 => \rgb_out[23]_i_97_n_0\,
      O => \rgb_out[23]_i_30_n_0\
    );
\rgb_out[23]_i_300\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"FE"
    )
        port map (
      I0 => pixel_x(3),
      I1 => pixel_x(4),
      I2 => pixel_x(5),
      O => \rgb_out[23]_i_300_n_0\
    );
\rgb_out[23]_i_301\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FEFFFFFFFFFFFFFF"
    )
        port map (
      I0 => pixel_x(10),
      I1 => pixel_x(11),
      I2 => pixel_x(9),
      I3 => pixel_x(6),
      I4 => pixel_x(7),
      I5 => pixel_x(8),
      O => \rgb_out[23]_i_301_n_0\
    );
\rgb_out[23]_i_302\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFDFFFFFFFFFF"
    )
        port map (
      I0 => \rgb_out[23]_i_346_n_0\,
      I1 => \rgb_out[11]_i_29_n_0\,
      I2 => pixel_x(6),
      I3 => pixel_x(5),
      I4 => pixel_x(4),
      I5 => \rgb_out[23]_i_219_n_0\,
      O => \rgb_out[23]_i_302_n_0\
    );
\rgb_out[23]_i_303\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0002000000000000"
    )
        port map (
      I0 => \rgb_out[23]_i_219_n_0\,
      I1 => \rgb_out[11]_i_29_n_0\,
      I2 => pixel_x(6),
      I3 => pixel_x(5),
      I4 => \rgb_out[23]_i_392_n_0\,
      I5 => pixel_x(2),
      O => \rgb_out[23]_i_303_n_0\
    );
\rgb_out[23]_i_304\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000000E000000000"
    )
        port map (
      I0 => pixel_x(6),
      I1 => \rgb_out[23]_i_537_n_0\,
      I2 => \rgb_out[11]_i_11_n_0\,
      I3 => pixel_x(9),
      I4 => \rgb_out[11]_i_29_n_0\,
      I5 => \rgb_out[23]_i_367_n_0\,
      O => \rgb_out[23]_i_304_n_0\
    );
\rgb_out[23]_i_305\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0001"
    )
        port map (
      I0 => pixel_x(2),
      I1 => pixel_x(3),
      I2 => pixel_x(4),
      I3 => pixel_x(5),
      O => \rgb_out[23]_i_305_n_0\
    );
\rgb_out[23]_i_306\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000005CCCCC"
    )
        port map (
      I0 => pixel_x(2),
      I1 => pixel_x(6),
      I2 => pixel_x(3),
      I3 => pixel_x(4),
      I4 => pixel_x(5),
      I5 => \rgb_out[11]_i_29_n_0\,
      O => \rgb_out[23]_i_306_n_0\
    );
\rgb_out[23]_i_307\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"01"
    )
        port map (
      I0 => pixel_x(2),
      I1 => pixel_x(3),
      I2 => pixel_x(4),
      O => \rgb_out[23]_i_307_n_0\
    );
\rgb_out[23]_i_308\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFBFFFFFF"
    )
        port map (
      I0 => \rgb_out[23]_i_579_n_0\,
      I1 => pixel_x(10),
      I2 => pixel_x(11),
      I3 => pixel_x(5),
      I4 => pixel_x(6),
      I5 => \rgb_out[23]_i_346_n_0\,
      O => \rgb_out[23]_i_308_n_0\
    );
\rgb_out[23]_i_309\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"0000E000"
    )
        port map (
      I0 => \pixel_y[1]_15\(0),
      I1 => \pixel_y[5]_8\(0),
      I2 => \pixel_x[5]_1\(0),
      I3 => \pixel_x[2]_13\(0),
      I4 => record_diz,
      O => \rgb_out[23]_i_309_n_0\
    );
\rgb_out[23]_i_31\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8888888A8A8A8A8A"
    )
        port map (
      I0 => \rgb_out[23]_i_101_n_0\,
      I1 => \rgb_out[23]_i_117_n_0\,
      I2 => \rgb_out[23]_i_118_n_0\,
      I3 => pixel_x(11),
      I4 => \rgb_out[23]_i_119_n_0\,
      I5 => \rgb_out[23]_i_120_n_0\,
      O => \rgb_out[23]_i_31_n_0\
    );
\rgb_out[23]_i_310\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"F888"
    )
        port map (
      I0 => \pixel_y[5]_9\(0),
      I1 => \pixel_y[1]_16\(0),
      I2 => \pixel_y[1]_17\(0),
      I3 => \pixel_y[1]_18\(0),
      O => \rgb_out[23]_i_310_n_0\
    );
\rgb_out[23]_i_312\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E0"
    )
        port map (
      I0 => record_personnel(2),
      I1 => record_personnel(1),
      I2 => record_personnel(3),
      O => record_diz
    );
\rgb_out[23]_i_314\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"7FFF"
    )
        port map (
      I0 => \pixel_y[1]_13\(0),
      I1 => \pixel_x[2]_11\(0),
      I2 => \pixel_y[1]_14\(0),
      I3 => \pixel_x[2]_12\(0),
      O => \rgb_out[23]_i_314_n_0\
    );
\rgb_out[23]_i_315\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"8000"
    )
        port map (
      I0 => \pixel_x[2]_7\(0),
      I1 => \pixel_y[1]_11\(0),
      I2 => \pixel_x[2]_8\(0),
      I3 => \pixel_y[1]_12\(0),
      O => \rgb_out[23]_i_315_n_0\
    );
\rgb_out[23]_i_316\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8888800080008000"
    )
        port map (
      I0 => \pixel_y[1]_6\(0),
      I1 => \pixel_y[1]_7\(0),
      I2 => \LAST_U/segments\(2),
      I3 => \pixel_x[2]_5\(0),
      I4 => \rgb_out[23]_i_610_n_0\,
      I5 => \pixel_x[2]_6\(0),
      O => \rgb_out[23]_i_316_n_0\
    );
\rgb_out[23]_i_317\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8888800080008000"
    )
        port map (
      I0 => \pixel_y[1]_8\(0),
      I1 => \pixel_y[5]_7\(0),
      I2 => \LAST_U/segments\(1),
      I3 => \pixel_x[2]_5\(0),
      I4 => \rgb_out[23]_i_615_n_0\,
      I5 => \pixel_x[2]_6\(0),
      O => \rgb_out[23]_i_317_n_0\
    );
\rgb_out[23]_i_318\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000080880000"
    )
        port map (
      I0 => \pixel_x[5]_0\(0),
      I1 => \pixel_x[2]_4\(0),
      I2 => \rgb_out[23]_i_618_n_0\,
      I3 => \rgb_out[23]_i_619_n_0\,
      I4 => \pixel_y[1]_5\(0),
      I5 => \rgb_out[23]_i_621_n_0\,
      O => \rgb_out[23]_i_318_n_0\
    );
\rgb_out[23]_i_319\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000800000"
    )
        port map (
      I0 => \pixel_y[1]_9\(0),
      I1 => \pixel_x[2]_4\(0),
      I2 => \pixel_x[5]_0\(0),
      I3 => \rgb_out[23]_i_623_n_0\,
      I4 => \pixel_y[1]_10\(0),
      I5 => \rgb_out[23]_i_625_n_0\,
      O => \rgb_out[23]_i_319_n_0\
    );
\rgb_out[23]_i_32\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"7777777077777777"
    )
        port map (
      I0 => \rgb_out[23]_i_36_n_0\,
      I1 => \rgb_out[23]_i_121_n_0\,
      I2 => \rgb_out[23]_i_122_n_0\,
      I3 => \rgb_out[23]_i_75_n_0\,
      I4 => \rgb_out[23]_i_123_n_0\,
      I5 => \rgb_out[23]_i_124_n_0\,
      O => \rgb_out[23]_i_32_n_0\
    );
\rgb_out[23]_i_320\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"8000"
    )
        port map (
      I0 => \pixel_y[5]_6\(0),
      I1 => \pixel_x[2]_4\(0),
      I2 => \pixel_x[5]_0\(0),
      I3 => \rgb_out[23]_i_627_n_0\,
      O => \rgb_out[23]_i_320_n_0\
    );
\rgb_out[23]_i_321\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"8000"
    )
        port map (
      I0 => \pixel_x[2]_17\(0),
      I1 => \pixel_y[1]_25\(0),
      I2 => \pixel_x[2]_18\(0),
      I3 => \pixel_y[1]_26\(0),
      O => \rgb_out[23]_i_321_n_0\
    );
\rgb_out[23]_i_322\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8888800080008000"
    )
        port map (
      I0 => \pixel_y[1]_20\(0),
      I1 => \pixel_y[1]_21\(0),
      I2 => \REC_U/segments\(2),
      I3 => \pixel_x[2]_15\(0),
      I4 => \rgb_out[23]_i_636_n_0\,
      I5 => \pixel_x[2]_16\(0),
      O => \rgb_out[23]_i_322_n_0\
    );
\rgb_out[23]_i_323\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8888800080008000"
    )
        port map (
      I0 => \pixel_y[1]_22\(0),
      I1 => \pixel_y[5]_11\(0),
      I2 => \REC_U/segments\(1),
      I3 => \pixel_x[2]_15\(0),
      I4 => \rgb_out[23]_i_641_n_0\,
      I5 => \pixel_x[2]_16\(0),
      O => \rgb_out[23]_i_323_n_0\
    );
\rgb_out[23]_i_324\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000080880000"
    )
        port map (
      I0 => \pixel_x[6]_0\(0),
      I1 => \pixel_x[2]_14\(0),
      I2 => \rgb_out[23]_i_644_n_0\,
      I3 => \rgb_out[23]_i_645_n_0\,
      I4 => \pixel_y[1]_19\(0),
      I5 => \rgb_out[23]_i_647_n_0\,
      O => \rgb_out[23]_i_324_n_0\
    );
\rgb_out[23]_i_325\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000800000"
    )
        port map (
      I0 => \pixel_y[1]_23\(0),
      I1 => \pixel_x[2]_14\(0),
      I2 => \pixel_x[6]_0\(0),
      I3 => \rgb_out[23]_i_649_n_0\,
      I4 => \pixel_y[1]_24\(0),
      I5 => \rgb_out[23]_i_651_n_0\,
      O => \rgb_out[23]_i_325_n_0\
    );
\rgb_out[23]_i_326\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"8000"
    )
        port map (
      I0 => \pixel_y[5]_10\(0),
      I1 => \pixel_x[2]_14\(0),
      I2 => \pixel_x[6]_0\(0),
      I3 => \rgb_out[23]_i_653_n_0\,
      O => \rgb_out[23]_i_326_n_0\
    );
\rgb_out[23]_i_327\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"0000E000"
    )
        port map (
      I0 => \pixel_y[1]_1\(0),
      I1 => \pixel_y[5]_4\(0),
      I2 => \pixel_x[7]_0\(0),
      I3 => \pixel_x[2]_3\(0),
      I4 => dernier_diz,
      O => \rgb_out[23]_i_327_n_0\
    );
\rgb_out[23]_i_328\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"F888"
    )
        port map (
      I0 => \pixel_y[5]_5\(0),
      I1 => \pixel_y[1]_2\(0),
      I2 => \pixel_y[1]_3\(0),
      I3 => \pixel_y[1]_4\(0),
      O => \rgb_out[23]_i_328_n_0\
    );
\rgb_out[23]_i_33\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FAFFFFFFFAFEFAFE"
    )
        port map (
      I0 => \rgb_out[23]_i_125_n_0\,
      I1 => \rgb_out[7]_i_15_n_0\,
      I2 => \rgb_out[23]_i_126_n_0\,
      I3 => \rgb_out[23]_i_121_n_0\,
      I4 => \rgb_out[23]_i_36_n_0\,
      I5 => \rgb_out[23]_i_127_n_0\,
      O => \rgb_out[23]_i_33_n_0\
    );
\rgb_out[23]_i_330\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E0"
    )
        port map (
      I0 => score_dernier(1),
      I1 => score_dernier(2),
      I2 => score_dernier(3),
      O => dernier_diz
    );
\rgb_out[23]_i_332\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"7FFF"
    )
        port map (
      I0 => \pixel_y[1]\(0),
      I1 => \pixel_x[2]_1\(0),
      I2 => \pixel_y[1]_0\(0),
      I3 => \pixel_x[2]_2\(0),
      O => \rgb_out[23]_i_332_n_0\
    );
\rgb_out[23]_i_333\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => pixel_x(6),
      I1 => pixel_x(5),
      O => \rgb_out[23]_i_333_n_0\
    );
\rgb_out[23]_i_334\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_x(3),
      I1 => pixel_x(2),
      O => \rgb_out[23]_i_334_n_0\
    );
\rgb_out[23]_i_335\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0001"
    )
        port map (
      I0 => pixel_x(8),
      I1 => pixel_x(7),
      I2 => pixel_x(9),
      I3 => pixel_x(11),
      O => \rgb_out[23]_i_335_n_0\
    );
\rgb_out[23]_i_336\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0006000000000000"
    )
        port map (
      I0 => pixel_x(3),
      I1 => pixel_x(4),
      I2 => pixel_x(5),
      I3 => \rgb_out[23]_i_676_n_0\,
      I4 => \rgb_out[23]_i_219_n_0\,
      I5 => pixel_x(2),
      O => \rgb_out[23]_i_336_n_0\
    );
\rgb_out[23]_i_337\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFEFEFE"
    )
        port map (
      I0 => pixel_x(10),
      I1 => pixel_x(11),
      I2 => pixel_x(9),
      I3 => pixel_x(8),
      I4 => pixel_x(7),
      O => \rgb_out[23]_i_337_n_0\
    );
\rgb_out[23]_i_338\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"8000"
    )
        port map (
      I0 => pixel_x(4),
      I1 => pixel_x(5),
      I2 => pixel_x(8),
      I3 => pixel_x(6),
      O => \rgb_out[23]_i_338_n_0\
    );
\rgb_out[23]_i_339\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"7FFFFFFF"
    )
        port map (
      I0 => pixel_x(3),
      I1 => pixel_x(4),
      I2 => pixel_x(5),
      I3 => pixel_x(8),
      I4 => pixel_x(6),
      O => \rgb_out[23]_i_339_n_0\
    );
\rgb_out[23]_i_34\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00000001"
    )
        port map (
      I0 => \rgb_out[23]_i_128_n_0\,
      I1 => \rgb_out[23]_i_129_n_0\,
      I2 => \rgb_out[23]_i_130_n_0\,
      I3 => \rgb_out[23]_i_131_n_0\,
      I4 => \rgb_out[23]_i_132_n_0\,
      O => \rgb_out[23]_i_34_n_0\
    );
\rgb_out[23]_i_340\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000000001"
    )
        port map (
      I0 => pixel_x(2),
      I1 => pixel_x(3),
      I2 => pixel_x(11),
      I3 => pixel_x(10),
      I4 => pixel_x(9),
      I5 => pixel_x(7),
      O => \rgb_out[23]_i_340_n_0\
    );
\rgb_out[23]_i_341\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000000E00"
    )
        port map (
      I0 => \rgb_out[23]_i_564_n_0\,
      I1 => \rgb_out[23]_i_346_n_0\,
      I2 => pixel_x(4),
      I3 => pixel_x(5),
      I4 => \rgb_out[23]_i_353_n_0\,
      I5 => \rgb_out[23]_i_337_n_0\,
      O => \rgb_out[23]_i_341_n_0\
    );
\rgb_out[23]_i_342\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"5554555544444444"
    )
        port map (
      I0 => \rgb_out[23]_i_569_n_0\,
      I1 => pixel_x(11),
      I2 => pixel_x(9),
      I3 => pixel_x(8),
      I4 => \rgb_out[20]_i_25_n_0\,
      I5 => pixel_x(10),
      O => \rgb_out[23]_i_342_n_0\
    );
\rgb_out[23]_i_343\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0001010155555555"
    )
        port map (
      I0 => pixel_x(11),
      I1 => pixel_x(9),
      I2 => pixel_x(8),
      I3 => pixel_x(6),
      I4 => pixel_x(7),
      I5 => pixel_x(10),
      O => \rgb_out[23]_i_343_n_0\
    );
\rgb_out[23]_i_344\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFEF"
    )
        port map (
      I0 => pixel_x(8),
      I1 => pixel_x(9),
      I2 => pixel_x(10),
      I3 => pixel_x(11),
      O => \rgb_out[23]_i_344_n_0\
    );
\rgb_out[23]_i_345\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFEFEFE"
    )
        port map (
      I0 => pixel_x(11),
      I1 => pixel_x(9),
      I2 => pixel_x(8),
      I3 => pixel_x(7),
      I4 => pixel_x(6),
      O => \rgb_out[23]_i_345_n_0\
    );
\rgb_out[23]_i_346\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => pixel_x(3),
      I1 => pixel_x(2),
      O => \rgb_out[23]_i_346_n_0\
    );
\rgb_out[23]_i_347\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"7F"
    )
        port map (
      I0 => pixel_x(10),
      I1 => pixel_x(7),
      I2 => pixel_x(6),
      O => \rgb_out[23]_i_347_n_0\
    );
\rgb_out[23]_i_348\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"E0000000"
    )
        port map (
      I0 => pixel_x(5),
      I1 => pixel_x(4),
      I2 => pixel_x(6),
      I3 => pixel_x(10),
      I4 => pixel_x(7),
      O => \rgb_out[23]_i_348_n_0\
    );
\rgb_out[23]_i_349\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"15FF"
    )
        port map (
      I0 => pixel_y(2),
      I1 => pixel_y(1),
      I2 => pixel_y(0),
      I3 => pixel_y(3),
      O => \rgb_out[23]_i_349_n_0\
    );
\rgb_out[23]_i_35\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000002A00000000"
    )
        port map (
      I0 => \rgb_out[23]_i_42_n_0\,
      I1 => pixel_y(4),
      I2 => pixel_y(3),
      I3 => pixel_y(5),
      I4 => \rgb_out[23]_i_133_n_0\,
      I5 => \rgb_out[23]_i_134_n_0\,
      O => \rgb_out[23]_i_35_n_0\
    );
\rgb_out[23]_i_350\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"FE"
    )
        port map (
      I0 => pixel_x(4),
      I1 => pixel_x(5),
      I2 => pixel_x(6),
      O => \rgb_out[23]_i_350_n_0\
    );
\rgb_out[23]_i_351\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => pixel_x(7),
      I1 => pixel_x(10),
      O => \rgb_out[23]_i_351_n_0\
    );
\rgb_out[23]_i_352\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FEAA"
    )
        port map (
      I0 => pixel_x(11),
      I1 => pixel_x(9),
      I2 => pixel_x(8),
      I3 => pixel_x(10),
      O => \rgb_out[23]_i_352_n_0\
    );
\rgb_out[23]_i_353\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"7"
    )
        port map (
      I0 => pixel_x(6),
      I1 => pixel_x(8),
      O => \rgb_out[23]_i_353_n_0\
    );
\rgb_out[23]_i_354\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"F307F3FFFFFFFFFF"
    )
        port map (
      I0 => pixel_x(2),
      I1 => \rgb_out[23]_i_392_n_0\,
      I2 => pixel_x(5),
      I3 => pixel_x(6),
      I4 => pixel_x(7),
      I5 => pixel_x(8),
      O => \rgb_out[23]_i_354_n_0\
    );
\rgb_out[23]_i_355\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000008000000000"
    )
        port map (
      I0 => \rgb_out[23]_i_334_n_0\,
      I1 => \rgb_out[23]_i_219_n_0\,
      I2 => pixel_x(6),
      I3 => \rgb_out[11]_i_29_n_0\,
      I4 => pixel_x(5),
      I5 => pixel_x(4),
      O => \rgb_out[23]_i_355_n_0\
    );
\rgb_out[23]_i_356\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"A080AA8AAA8AAA8A"
    )
        port map (
      I0 => \rgb_out[23]_i_677_n_0\,
      I1 => \rgb_out[23]_i_224_n_0\,
      I2 => \rgb_out[20]_i_25_n_0\,
      I3 => \rgb_out[23]_i_346_n_0\,
      I4 => pixel_x(6),
      I5 => \rgb_out[23]_i_351_n_0\,
      O => \rgb_out[23]_i_356_n_0\
    );
\rgb_out[23]_i_357\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0F0F0FFF00000040"
    )
        port map (
      I0 => pixel_x(2),
      I1 => pixel_x(3),
      I2 => \rgb_out[23]_i_557_n_0\,
      I3 => \rgb_out[23]_i_353_n_0\,
      I4 => \rgb_out[23]_i_233_n_0\,
      I5 => \rgb_out[23]_i_340_n_0\,
      O => \rgb_out[23]_i_357_n_0\
    );
\rgb_out[23]_i_358\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"555555557F777F7F"
    )
        port map (
      I0 => pixel_x(10),
      I1 => pixel_x(7),
      I2 => pixel_x(6),
      I3 => \rgb_out[23]_i_233_n_0\,
      I4 => \rgb_out[23]_i_346_n_0\,
      I5 => \rgb_out[23]_i_224_n_0\,
      O => \rgb_out[23]_i_358_n_0\
    );
\rgb_out[23]_i_359\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"1115151515151515"
    )
        port map (
      I0 => \rgb_out[23]_i_352_n_0\,
      I1 => \rgb_out[23]_i_351_n_0\,
      I2 => pixel_x(6),
      I3 => pixel_x(5),
      I4 => pixel_x(4),
      I5 => pixel_x(3),
      O => \rgb_out[23]_i_359_n_0\
    );
\rgb_out[23]_i_36\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFF7F7FFF7F"
    )
        port map (
      I0 => \rgb_out[23]_i_135_n_0\,
      I1 => \rgb_out[23]_i_136_n_0\,
      I2 => pixel_y(4),
      I3 => pixel_y(3),
      I4 => \rgb_out[23]_i_137_n_0\,
      I5 => \rgb_out[23]_i_138_n_0\,
      O => \rgb_out[23]_i_36_n_0\
    );
\rgb_out[23]_i_360\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"1111111111111F11"
    )
        port map (
      I0 => \rgb_out[23]_i_678_n_0\,
      I1 => \rgb_out[23]_i_352_n_0\,
      I2 => \rgb_out[23]_i_567_n_0\,
      I3 => \rgb_out[23]_i_334_n_0\,
      I4 => pixel_x(11),
      I5 => pixel_x(8),
      O => \rgb_out[23]_i_360_n_0\
    );
\rgb_out[23]_i_361\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFF1110"
    )
        port map (
      I0 => \rgb_out[11]_i_11_n_0\,
      I1 => \rgb_out[23]_i_679_n_0\,
      I2 => \rgb_out[23]_i_345_n_0\,
      I3 => \rgb_out[23]_i_680_n_0\,
      I4 => \rgb_out[23]_i_681_n_0\,
      I5 => \rgb_out[23]_i_682_n_0\,
      O => \rgb_out[23]_i_361_n_0\
    );
\rgb_out[23]_i_362\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00000001"
    )
        port map (
      I0 => pixel_x(6),
      I1 => pixel_x(5),
      I2 => pixel_x(9),
      I3 => pixel_x(8),
      I4 => pixel_x(11),
      O => \rgb_out[23]_i_362_n_0\
    );
\rgb_out[23]_i_363\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_x(11),
      I1 => pixel_x(6),
      O => \rgb_out[23]_i_363_n_0\
    );
\rgb_out[23]_i_364\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFEEEEEEEEE"
    )
        port map (
      I0 => pixel_x(8),
      I1 => pixel_x(9),
      I2 => pixel_x(2),
      I3 => pixel_x(3),
      I4 => pixel_x(4),
      I5 => pixel_x(5),
      O => \rgb_out[23]_i_364_n_0\
    );
\rgb_out[23]_i_365\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000101010101"
    )
        port map (
      I0 => pixel_x(8),
      I1 => pixel_x(9),
      I2 => pixel_x(6),
      I3 => pixel_x(3),
      I4 => pixel_x(4),
      I5 => pixel_x(5),
      O => \rgb_out[23]_i_365_n_0\
    );
\rgb_out[23]_i_366\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"01FF"
    )
        port map (
      I0 => pixel_x(9),
      I1 => pixel_x(8),
      I2 => pixel_x(7),
      I3 => pixel_x(10),
      O => \rgb_out[23]_i_366_n_0\
    );
\rgb_out[23]_i_367\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0155"
    )
        port map (
      I0 => pixel_x(6),
      I1 => pixel_x(3),
      I2 => pixel_x(4),
      I3 => pixel_x(5),
      O => \rgb_out[23]_i_367_n_0\
    );
\rgb_out[23]_i_368\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"01FF0000"
    )
        port map (
      I0 => pixel_y(0),
      I1 => pixel_y(1),
      I2 => pixel_y(2),
      I3 => pixel_y(3),
      I4 => \rgb_out[23]_i_683_n_0\,
      O => \rgb_out[23]_i_368_n_0\
    );
\rgb_out[23]_i_369\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FEFF"
    )
        port map (
      I0 => pixel_y(11),
      I1 => pixel_y(10),
      I2 => pixel_y(9),
      I3 => pixel_y(8),
      O => \rgb_out[23]_i_369_n_0\
    );
\rgb_out[23]_i_37\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFCFFFCFFF44444"
    )
        port map (
      I0 => \rgb_out[23]_i_121_n_0\,
      I1 => \rgb_out[23]_i_128_n_0\,
      I2 => \rgb_out[23]_i_123_n_0\,
      I3 => \rgb_out[23]_i_127_n_0\,
      I4 => \rgb_out[23]_i_35_n_0\,
      I5 => \rgb_out[23]_i_139_n_0\,
      O => \rgb_out[23]_i_37_n_0\
    );
\rgb_out[23]_i_370\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_x(0),
      I1 => pixel_x(1),
      O => \rgb_out[23]_i_370_n_0\
    );
\rgb_out[23]_i_371\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFDFFF"
    )
        port map (
      I0 => \rgb_out[20]_i_23_n_0\,
      I1 => pixel_x(3),
      I2 => \rgb_out[20]_i_25_n_0\,
      I3 => \rgb_out[11]_i_11_n_0\,
      I4 => pixel_x(6),
      I5 => pixel_x(7),
      O => \rgb_out[23]_i_371_n_0\
    );
\rgb_out[23]_i_372\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"7FFFFFFF"
    )
        port map (
      I0 => pixel_x(4),
      I1 => pixel_x(5),
      I2 => pixel_x(6),
      I3 => pixel_x(7),
      I4 => pixel_x(9),
      O => \rgb_out[23]_i_372_n_0\
    );
\rgb_out[23]_i_373\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"7FFFFFFF"
    )
        port map (
      I0 => pixel_x(2),
      I1 => pixel_x(1),
      I2 => pixel_x(9),
      I3 => pixel_x(8),
      I4 => pixel_x(0),
      O => \rgb_out[23]_i_373_n_0\
    );
\rgb_out[23]_i_374\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0E000000FFFFFFFF"
    )
        port map (
      I0 => pixel_x(0),
      I1 => \rgb_out[11]_i_22_n_0\,
      I2 => \rgb_out[23]_i_233_n_0\,
      I3 => pixel_x(3),
      I4 => \rgb_out[20]_i_23_n_0\,
      I5 => \rgb_out[7]_i_73_n_0\,
      O => \rgb_out[23]_i_374_n_0\
    );
\rgb_out[23]_i_375\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"1FFF"
    )
        port map (
      I0 => pixel_x(2),
      I1 => pixel_x(3),
      I2 => pixel_x(4),
      I3 => pixel_x(5),
      O => \rgb_out[23]_i_375_n_0\
    );
\rgb_out[23]_i_376\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000080000000"
    )
        port map (
      I0 => pixel_x(9),
      I1 => pixel_x(8),
      I2 => pixel_x(3),
      I3 => pixel_x(4),
      I4 => pixel_x(5),
      I5 => \rgb_out[23]_i_394_n_0\,
      O => \rgb_out[23]_i_376_n_0\
    );
\rgb_out[23]_i_377\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"01"
    )
        port map (
      I0 => pixel_x(1),
      I1 => pixel_x(2),
      I2 => pixel_x(6),
      O => \rgb_out[23]_i_377_n_0\
    );
\rgb_out[23]_i_378\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000002220"
    )
        port map (
      I0 => pixel_x(5),
      I1 => \rgb_out[20]_i_20_n_0\,
      I2 => pixel_x(4),
      I3 => \rgb_out[23]_i_246_n_0\,
      I4 => \rgb_out[20]_i_19_n_0\,
      I5 => \rgb_out[23]_i_684_n_0\,
      O => \rgb_out[23]_i_378_n_0\
    );
\rgb_out[23]_i_379\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"77770000777F0000"
    )
        port map (
      I0 => pixel_x(9),
      I1 => pixel_x(8),
      I2 => pixel_x(7),
      I3 => pixel_x(6),
      I4 => \rgb_out[11]_i_11_n_0\,
      I5 => pixel_x(5),
      O => \rgb_out[23]_i_379_n_0\
    );
\rgb_out[23]_i_38\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FEEEFEFEFEFEFEFE"
    )
        port map (
      I0 => \rgb_out[23]_i_140_n_0\,
      I1 => \rgb_out[23]_i_141_n_0\,
      I2 => \rgb_out[23]_i_135_n_0\,
      I3 => \rgb_out[23]_i_66_n_0\,
      I4 => pixel_y(7),
      I5 => pixel_y(6),
      O => \rgb_out[23]_i_38_n_0\
    );
\rgb_out[23]_i_380\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"7FFF"
    )
        port map (
      I0 => pixel_x(3),
      I1 => pixel_x(9),
      I2 => pixel_x(4),
      I3 => pixel_x(8),
      O => \rgb_out[23]_i_380_n_0\
    );
\rgb_out[23]_i_381\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FEAA"
    )
        port map (
      I0 => pixel_x(3),
      I1 => pixel_x(0),
      I2 => pixel_x(1),
      I3 => pixel_x(2),
      O => \rgb_out[23]_i_381_n_0\
    );
\rgb_out[23]_i_382\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"15FF"
    )
        port map (
      I0 => pixel_x(3),
      I1 => pixel_x(1),
      I2 => pixel_x(2),
      I3 => pixel_x(4),
      O => \rgb_out[23]_i_382_n_0\
    );
\rgb_out[23]_i_383\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00000001"
    )
        port map (
      I0 => pixel_x(5),
      I1 => pixel_x(11),
      I2 => pixel_x(10),
      I3 => pixel_x(6),
      I4 => pixel_x(7),
      O => \rgb_out[23]_i_383_n_0\
    );
\rgb_out[23]_i_384\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"7FFFFFFF"
    )
        port map (
      I0 => pixel_x(8),
      I1 => pixel_x(4),
      I2 => pixel_x(9),
      I3 => pixel_x(3),
      I4 => pixel_x(2),
      O => \rgb_out[23]_i_384_n_0\
    );
\rgb_out[23]_i_385\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"FE"
    )
        port map (
      I0 => pixel_x(5),
      I1 => pixel_x(7),
      I2 => pixel_x(6),
      O => \rgb_out[23]_i_385_n_0\
    );
\rgb_out[23]_i_386\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8000FFFFFFFFFFFF"
    )
        port map (
      I0 => pixel_x(3),
      I1 => pixel_x(4),
      I2 => pixel_x(0),
      I3 => pixel_x(1),
      I4 => pixel_x(8),
      I5 => pixel_x(9),
      O => \rgb_out[23]_i_386_n_0\
    );
\rgb_out[23]_i_387\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"EAEAEAEAEAEAEAAA"
    )
        port map (
      I0 => \rgb_out[23]_i_394_n_0\,
      I1 => \rgb_out[20]_i_23_n_0\,
      I2 => pixel_x(5),
      I3 => pixel_x(4),
      I4 => pixel_x(3),
      I5 => pixel_x(2),
      O => \rgb_out[23]_i_387_n_0\
    );
\rgb_out[23]_i_388\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => pixel_x(3),
      I1 => pixel_x(7),
      O => \rgb_out[23]_i_388_n_0\
    );
\rgb_out[23]_i_389\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => pixel_x(6),
      I1 => pixel_x(4),
      O => \rgb_out[23]_i_389_n_0\
    );
\rgb_out[23]_i_39\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"A8"
    )
        port map (
      I0 => pixel_y(2),
      I1 => pixel_y(0),
      I2 => pixel_y(1),
      O => \rgb_out[23]_i_39_n_0\
    );
\rgb_out[23]_i_390\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFEFFFEFFFEF"
    )
        port map (
      I0 => pixel_x(7),
      I1 => pixel_x(6),
      I2 => \rgb_out[11]_i_11_n_0\,
      I3 => pixel_x(4),
      I4 => \rgb_out[11]_i_22_n_0\,
      I5 => pixel_x(3),
      O => \rgb_out[23]_i_390_n_0\
    );
\rgb_out[23]_i_391\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"4540555000000000"
    )
        port map (
      I0 => \rgb_out[21]_i_6_n_0\,
      I1 => \rgb_out[20]_i_17_n_0\,
      I2 => \rgb_out[23]_i_683_n_0\,
      I3 => \rgb_out[23]_i_133_n_0\,
      I4 => \rgb_out[7]_i_66_n_0\,
      I5 => pixel_y(8),
      O => \rgb_out[23]_i_391_n_0\
    );
\rgb_out[23]_i_392\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => pixel_x(3),
      I1 => pixel_x(4),
      O => \rgb_out[23]_i_392_n_0\
    );
\rgb_out[23]_i_393\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_x(7),
      I1 => pixel_x(8),
      O => \rgb_out[23]_i_393_n_0\
    );
\rgb_out[23]_i_394\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFE000"
    )
        port map (
      I0 => pixel_x(6),
      I1 => pixel_x(7),
      I2 => pixel_x(9),
      I3 => pixel_x(8),
      I4 => pixel_x(11),
      I5 => pixel_x(10),
      O => \rgb_out[23]_i_394_n_0\
    );
\rgb_out[23]_i_395\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"AEFFFEFF"
    )
        port map (
      I0 => \rgb_out[23]_i_397_n_0\,
      I1 => \rgb_out[7]_i_42_n_0\,
      I2 => \rgb_out[23]_i_71_n_0\,
      I3 => \rgb_out[23]_i_396_n_0\,
      I4 => \rgb_out[20]_i_18_n_0\,
      O => \rgb_out[23]_i_395_n_0\
    );
\rgb_out[23]_i_396\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FBFFFFFFFFFFFFFF"
    )
        port map (
      I0 => \rgb_out[23]_i_300_n_0\,
      I1 => \rgb_out[11]_i_11_n_0\,
      I2 => pixel_x(7),
      I3 => pixel_x(2),
      I4 => pixel_x(6),
      I5 => \rgb_out[20]_i_23_n_0\,
      O => \rgb_out[23]_i_396_n_0\
    );
\rgb_out[23]_i_397\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000008000000"
    )
        port map (
      I0 => \rgb_out[20]_i_23_n_0\,
      I1 => pixel_x(6),
      I2 => \rgb_out[23]_i_570_n_0\,
      I3 => \rgb_out[23]_i_401_n_0\,
      I4 => \rgb_out[11]_i_11_n_0\,
      I5 => pixel_x(7),
      O => \rgb_out[23]_i_397_n_0\
    );
\rgb_out[23]_i_398\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8000000000000000"
    )
        port map (
      I0 => \rgb_out[7]_i_73_n_0\,
      I1 => \rgb_out[20]_i_23_n_0\,
      I2 => pixel_x(2),
      I3 => pixel_x(3),
      I4 => pixel_x(4),
      I5 => pixel_x(5),
      O => \rgb_out[23]_i_398_n_0\
    );
\rgb_out[23]_i_399\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000200000000000"
    )
        port map (
      I0 => \rgb_out[23]_i_346_n_0\,
      I1 => pixel_x(4),
      I2 => \rgb_out[20]_i_23_n_0\,
      I3 => pixel_x(5),
      I4 => \rgb_out[20]_i_24_n_0\,
      I5 => \rgb_out[11]_i_11_n_0\,
      O => \rgb_out[23]_i_399_n_0\
    );
\rgb_out[23]_i_4\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"20AAAAAA"
    )
        port map (
      I0 => \rgb_out[11]_i_4_n_0\,
      I1 => \rgb_out[11]_i_5_n_0\,
      I2 => rgb_in(23),
      I3 => \rgb_out[23]_i_9_n_0\,
      I4 => \rgb_out[23]_i_10_n_0\,
      O => \rgb_out[23]_i_4_n_0\
    );
\rgb_out[23]_i_40\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"7"
    )
        port map (
      I0 => pixel_y(8),
      I1 => pixel_y(7),
      O => \rgb_out[23]_i_40_n_0\
    );
\rgb_out[23]_i_400\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000002000000"
    )
        port map (
      I0 => pixel_x(2),
      I1 => pixel_x(3),
      I2 => pixel_x(4),
      I3 => pixel_x(5),
      I4 => \rgb_out[20]_i_23_n_0\,
      I5 => \rgb_out[23]_i_394_n_0\,
      O => \rgb_out[23]_i_400_n_0\
    );
\rgb_out[23]_i_401\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FEAA"
    )
        port map (
      I0 => pixel_x(5),
      I1 => pixel_x(3),
      I2 => pixel_x(2),
      I3 => pixel_x(4),
      O => \rgb_out[23]_i_401_n_0\
    );
\rgb_out[23]_i_402\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"40554040FFFFFFFF"
    )
        port map (
      I0 => \rgb_out[23]_i_685_n_0\,
      I1 => \rgb_out[23]_i_392_n_0\,
      I2 => \rgb_out[23]_i_175_n_0\,
      I3 => \rgb_out[23]_i_282_n_0\,
      I4 => \rgb_out[23]_i_686_n_0\,
      I5 => \rgb_out[23]_i_174_n_0\,
      O => \rgb_out[23]_i_402_n_0\
    );
\rgb_out[23]_i_403\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000000007F000000"
    )
        port map (
      I0 => pixel_x(6),
      I1 => pixel_x(4),
      I2 => pixel_x(3),
      I3 => \rgb_out[23]_i_687_n_0\,
      I4 => \rgb_out[23]_i_219_n_0\,
      I5 => \rgb_out[23]_i_415_n_0\,
      O => \rgb_out[23]_i_403_n_0\
    );
\rgb_out[23]_i_404\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0080000000000000"
    )
        port map (
      I0 => \rgb_out[23]_i_174_n_0\,
      I1 => pixel_x(2),
      I2 => pixel_x(1),
      I3 => pixel_x(4),
      I4 => pixel_x(5),
      I5 => pixel_x(3),
      O => \rgb_out[23]_i_404_n_0\
    );
\rgb_out[23]_i_405\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"E0E0E00000000000"
    )
        port map (
      I0 => pixel_x(11),
      I1 => \rgb_out[23]_i_688_n_0\,
      I2 => \rgb_out[23]_i_352_n_0\,
      I3 => \rgb_out[23]_i_689_n_0\,
      I4 => \rgb_out[23]_i_382_n_0\,
      I5 => \rgb_out[23]_i_159_n_0\,
      O => \rgb_out[23]_i_405_n_0\
    );
\rgb_out[23]_i_406\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000008000000000"
    )
        port map (
      I0 => \rgb_out[23]_i_174_n_0\,
      I1 => pixel_x(3),
      I2 => pixel_x(5),
      I3 => pixel_x(4),
      I4 => pixel_x(1),
      I5 => pixel_x(2),
      O => \rgb_out[23]_i_406_n_0\
    );
\rgb_out[23]_i_407\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFAAAAFBAA"
    )
        port map (
      I0 => \rgb_out[23]_i_454_n_0\,
      I1 => \rgb_out[23]_i_425_n_0\,
      I2 => \rgb_out[23]_i_690_n_0\,
      I3 => \rgb_out[23]_i_423_n_0\,
      I4 => \rgb_out[23]_i_691_n_0\,
      I5 => \rgb_out[23]_i_692_n_0\,
      O => \rgb_out[23]_i_407_n_0\
    );
\rgb_out[23]_i_408\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"01"
    )
        port map (
      I0 => pixel_y(7),
      I1 => pixel_y(5),
      I2 => pixel_y(6),
      O => \rgb_out[23]_i_408_n_0\
    );
\rgb_out[23]_i_409\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFFFFE"
    )
        port map (
      I0 => pixel_y(11),
      I1 => pixel_y(10),
      I2 => pixel_y(9),
      I3 => pixel_y(7),
      I4 => pixel_y(6),
      I5 => pixel_y(8),
      O => \rgb_out[23]_i_409_n_0\
    );
\rgb_out[23]_i_41\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFFFFE"
    )
        port map (
      I0 => pixel_y(11),
      I1 => pixel_y(10),
      I2 => pixel_y(9),
      I3 => pixel_y(5),
      I4 => pixel_y(4),
      I5 => pixel_y(3),
      O => \rgb_out[23]_i_41_n_0\
    );
\rgb_out[23]_i_410\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000E0E0E0E0E0E0E"
    )
        port map (
      I0 => \rgb_out[23]_i_693_n_0\,
      I1 => \rgb_out[23]_i_694_n_0\,
      I2 => \rgb_out[23]_i_695_n_0\,
      I3 => \rgb_out[23]_i_696_n_0\,
      I4 => \rgb_out[23]_i_697_n_0\,
      I5 => \rgb_out[23]_i_698_n_0\,
      O => \rgb_out[23]_i_410_n_0\
    );
\rgb_out[23]_i_411\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"EEFEEEFEEEFEEEEE"
    )
        port map (
      I0 => \rgb_out[23]_i_699_n_0\,
      I1 => \rgb_out[23]_i_700_n_0\,
      I2 => \rgb_out[23]_i_696_n_0\,
      I3 => \rgb_out[23]_i_701_n_0\,
      I4 => \rgb_out[23]_i_537_n_0\,
      I5 => \rgb_out[23]_i_434_n_0\,
      O => \rgb_out[23]_i_411_n_0\
    );
\rgb_out[23]_i_412\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000000888"
    )
        port map (
      I0 => \rgb_out[23]_i_421_n_0\,
      I1 => \rgb_out[23]_i_698_n_0\,
      I2 => \rgb_out[23]_i_702_n_0\,
      I3 => pixel_x(5),
      I4 => \rgb_out[23]_i_703_n_0\,
      I5 => \rgb_out[23]_i_694_n_0\,
      O => \rgb_out[23]_i_412_n_0\
    );
\rgb_out[23]_i_413\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00FF00FFE0FFE0E0"
    )
        port map (
      I0 => \rgb_out[23]_i_224_n_0\,
      I1 => pixel_x(6),
      I2 => \rgb_out[23]_i_414_n_0\,
      I3 => \rgb_out[23]_i_436_n_0\,
      I4 => \rgb_out[23]_i_174_n_0\,
      I5 => \rgb_out[23]_i_704_n_0\,
      O => \rgb_out[23]_i_413_n_0\
    );
\rgb_out[23]_i_414\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000222AAAAAAAAA"
    )
        port map (
      I0 => \rgb_out[23]_i_686_n_0\,
      I1 => pixel_x(4),
      I2 => pixel_x(2),
      I3 => pixel_x(3),
      I4 => pixel_x(5),
      I5 => pixel_x(6),
      O => \rgb_out[23]_i_414_n_0\
    );
\rgb_out[23]_i_415\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"22222AAA222222AA"
    )
        port map (
      I0 => \rgb_out[23]_i_686_n_0\,
      I1 => pixel_x(6),
      I2 => pixel_x(3),
      I3 => pixel_x(4),
      I4 => pixel_x(5),
      I5 => \rgb_out[23]_i_223_n_0\,
      O => \rgb_out[23]_i_415_n_0\
    );
\rgb_out[23]_i_416\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"80000000"
    )
        port map (
      I0 => \rgb_out[23]_i_436_n_0\,
      I1 => pixel_x(6),
      I2 => pixel_x(3),
      I3 => pixel_x(1),
      I4 => pixel_x(2),
      O => \rgb_out[23]_i_416_n_0\
    );
\rgb_out[23]_i_417\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFEFEFEEE"
    )
        port map (
      I0 => pixel_x(2),
      I1 => pixel_x(1),
      I2 => pixel_x(8),
      I3 => pixel_x(7),
      I4 => pixel_x(6),
      I5 => pixel_x(9),
      O => \rgb_out[23]_i_417_n_0\
    );
\rgb_out[23]_i_418\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"F7FFFFFFFFFFFFFF"
    )
        port map (
      I0 => pixel_x(5),
      I1 => pixel_x(8),
      I2 => pixel_x(11),
      I3 => pixel_x(10),
      I4 => pixel_x(4),
      I5 => pixel_x(3),
      O => \rgb_out[23]_i_418_n_0\
    );
\rgb_out[23]_i_419\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"80A0000000000000"
    )
        port map (
      I0 => pixel_y(4),
      I1 => pixel_y(3),
      I2 => pixel_y(2),
      I3 => pixel_y(1),
      I4 => \rgb_out[23]_i_135_n_0\,
      I5 => \rgb_out[23]_i_408_n_0\,
      O => \rgb_out[23]_i_419_n_0\
    );
\rgb_out[23]_i_42\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000000037"
    )
        port map (
      I0 => pixel_y(6),
      I1 => pixel_y(8),
      I2 => pixel_y(7),
      I3 => pixel_y(9),
      I4 => pixel_y(10),
      I5 => pixel_y(11),
      O => \rgb_out[23]_i_42_n_0\
    );
\rgb_out[23]_i_420\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFF7FFF"
    )
        port map (
      I0 => pixel_x(1),
      I1 => pixel_x(2),
      I2 => \rgb_out[23]_i_174_n_0\,
      I3 => pixel_x(5),
      I4 => pixel_x(4),
      I5 => pixel_x(3),
      O => \rgb_out[23]_i_420_n_0\
    );
\rgb_out[23]_i_421\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"1000000080000000"
    )
        port map (
      I0 => pixel_y(1),
      I1 => pixel_y(2),
      I2 => pixel_y(4),
      I3 => \rgb_out[23]_i_135_n_0\,
      I4 => \rgb_out[23]_i_408_n_0\,
      I5 => pixel_y(3),
      O => \rgb_out[23]_i_421_n_0\
    );
\rgb_out[23]_i_422\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"4FFF4FFF4FFFFFFF"
    )
        port map (
      I0 => \rgb_out[11]_i_22_n_0\,
      I1 => \rgb_out[23]_i_705_n_0\,
      I2 => \rgb_out[23]_i_352_n_0\,
      I3 => \rgb_out[23]_i_706_n_0\,
      I4 => \rgb_out[23]_i_707_n_0\,
      I5 => \rgb_out[23]_i_708_n_0\,
      O => \rgb_out[23]_i_422_n_0\
    );
\rgb_out[23]_i_423\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"A8"
    )
        port map (
      I0 => pixel_x(10),
      I1 => pixel_x(8),
      I2 => pixel_x(9),
      O => \rgb_out[23]_i_423_n_0\
    );
\rgb_out[23]_i_424\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"8000"
    )
        port map (
      I0 => pixel_x(4),
      I1 => pixel_x(3),
      I2 => pixel_x(2),
      I3 => pixel_x(1),
      O => \rgb_out[23]_i_424_n_0\
    );
\rgb_out[23]_i_425\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0001"
    )
        port map (
      I0 => pixel_x(7),
      I1 => pixel_x(6),
      I2 => pixel_x(5),
      I3 => pixel_x(9),
      O => \rgb_out[23]_i_425_n_0\
    );
\rgb_out[23]_i_426\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"BFFFFFFFFFFFFFFF"
    )
        port map (
      I0 => pixel_y(3),
      I1 => \rgb_out[23]_i_408_n_0\,
      I2 => \rgb_out[23]_i_135_n_0\,
      I3 => pixel_y(4),
      I4 => pixel_y(2),
      I5 => pixel_y(1),
      O => \rgb_out[23]_i_426_n_0\
    );
\rgb_out[23]_i_427\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000000000E000000"
    )
        port map (
      I0 => \rgb_out[23]_i_709_n_0\,
      I1 => \rgb_out[23]_i_156_n_0\,
      I2 => pixel_x(1),
      I3 => pixel_x(2),
      I4 => \rgb_out[23]_i_392_n_0\,
      I5 => \rgb_out[23]_i_689_n_0\,
      O => \rgb_out[23]_i_427_n_0\
    );
\rgb_out[23]_i_428\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0300000000000C22"
    )
        port map (
      I0 => \rgb_out[23]_i_710_n_0\,
      I1 => pixel_y(3),
      I2 => \rgb_out[23]_i_455_n_0\,
      I3 => pixel_y(4),
      I4 => pixel_y(2),
      I5 => pixel_y(1),
      O => \rgb_out[23]_i_428_n_0\
    );
\rgb_out[23]_i_429\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"808F808080808080"
    )
        port map (
      I0 => pixel_x(6),
      I1 => pixel_x(3),
      I2 => pixel_x(2),
      I3 => pixel_x(1),
      I4 => \rgb_out[20]_i_25_n_0\,
      I5 => \rgb_out[23]_i_686_n_0\,
      O => \rgb_out[23]_i_429_n_0\
    );
\rgb_out[23]_i_43\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFD0000"
    )
        port map (
      I0 => \rgb_out[23]_i_88_n_0\,
      I1 => \rgb_out[23]_i_142_n_0\,
      I2 => \rgb_out[23]_i_143_n_0\,
      I3 => \rgb_out[23]_i_144_n_0\,
      I4 => \rgb_out[23]_i_145_n_0\,
      I5 => \rgb_out[23]_i_146_n_0\,
      O => \rgb_out[23]_i_43_n_0\
    );
\rgb_out[23]_i_430\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000AAAAAAA2"
    )
        port map (
      I0 => \rgb_out[23]_i_436_n_0\,
      I1 => \rgb_out[23]_i_686_n_0\,
      I2 => pixel_x(5),
      I3 => pixel_x(4),
      I4 => pixel_x(3),
      I5 => \rgb_out[23]_i_174_n_0\,
      O => \rgb_out[23]_i_430_n_0\
    );
\rgb_out[23]_i_431\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFF1000FFFF"
    )
        port map (
      I0 => pixel_x(5),
      I1 => pixel_x(9),
      I2 => \rgb_out[11]_i_11_n_0\,
      I3 => \rgb_out[23]_i_711_n_0\,
      I4 => \rgb_out[23]_i_712_n_0\,
      I5 => \rgb_out[23]_i_174_n_0\,
      O => \rgb_out[23]_i_431_n_0\
    );
\rgb_out[23]_i_432\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000000004"
    )
        port map (
      I0 => \rgb_out[23]_i_409_n_0\,
      I1 => pixel_y(5),
      I2 => pixel_y(4),
      I3 => pixel_y(3),
      I4 => pixel_y(2),
      I5 => pixel_y(1),
      O => \rgb_out[23]_i_432_n_0\
    );
\rgb_out[23]_i_433\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0005555501055555"
    )
        port map (
      I0 => pixel_x(11),
      I1 => \rgb_out[20]_i_24_n_0\,
      I2 => pixel_x(9),
      I3 => pixel_x(8),
      I4 => pixel_x(10),
      I5 => \rgb_out[23]_i_222_n_0\,
      O => \rgb_out[23]_i_433_n_0\
    );
\rgb_out[23]_i_434\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFFE"
    )
        port map (
      I0 => pixel_x(7),
      I1 => pixel_x(11),
      I2 => pixel_x(6),
      I3 => pixel_x(9),
      O => \rgb_out[23]_i_434_n_0\
    );
\rgb_out[23]_i_435\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"5555555555554044"
    )
        port map (
      I0 => \rgb_out[23]_i_159_n_0\,
      I1 => pixel_x(4),
      I2 => pixel_x(1),
      I3 => \rgb_out[23]_i_334_n_0\,
      I4 => \rgb_out[20]_i_24_n_0\,
      I5 => \rgb_out[23]_i_713_n_0\,
      O => \rgb_out[23]_i_435_n_0\
    );
\rgb_out[23]_i_436\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0003010300000000"
    )
        port map (
      I0 => pixel_x(5),
      I1 => pixel_x(7),
      I2 => pixel_x(8),
      I3 => pixel_x(6),
      I4 => pixel_x(4),
      I5 => \rgb_out[23]_i_219_n_0\,
      O => \rgb_out[23]_i_436_n_0\
    );
\rgb_out[23]_i_437\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"80000000"
    )
        port map (
      I0 => \rgb_out[23]_i_408_n_0\,
      I1 => \rgb_out[23]_i_135_n_0\,
      I2 => pixel_y(2),
      I3 => pixel_y(3),
      I4 => pixel_y(4),
      O => \rgb_out[23]_i_437_n_0\
    );
\rgb_out[23]_i_44\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"AAFB"
    )
        port map (
      I0 => \rgb_out[20]_i_9_n_0\,
      I1 => \rgb_out[20]_i_10_n_0\,
      I2 => \rgb_out[20]_i_11_n_0\,
      I3 => \rgb_out[20]_i_12_n_0\,
      O => \rgb_out[23]_i_44_n_0\
    );
\rgb_out[23]_i_442\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"8000"
    )
        port map (
      I0 => \pixel_y[5]_0\(0),
      I1 => \pixel_x[1]_4\(0),
      I2 => \SC_U/pixel_on9\,
      I3 => \rgb_out[23]_i_734_n_0\,
      O => \rgb_out[23]_i_442_n_0\
    );
\rgb_out[23]_i_443\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000800000"
    )
        port map (
      I0 => \pixel_y[2]_7\(0),
      I1 => \pixel_x[1]_4\(0),
      I2 => \SC_U/pixel_on9\,
      I3 => \rgb_out[23]_i_736_n_0\,
      I4 => \pixel_y[2]_8\(0),
      I5 => \rgb_out[23]_i_738_n_0\,
      O => \rgb_out[23]_i_443_n_0\
    );
\rgb_out[23]_i_444\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"7557D55D"
    )
        port map (
      I0 => \pixel_y[2]_3\(0),
      I1 => score_courant(0),
      I2 => score_courant(1),
      I3 => score_courant(3),
      I4 => score_courant(2),
      O => \rgb_out[23]_i_444_n_0\
    );
\rgb_out[23]_i_445\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \pixel_x[1]_4\(0),
      I1 => \SC_U/pixel_on9\,
      O => \rgb_out[23]_i_445_n_0\
    );
\rgb_out[23]_i_446\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8888800080008000"
    )
        port map (
      I0 => \pixel_y[2]_6\(0),
      I1 => \pixel_y[5]_1\(0),
      I2 => \SC_U/segments\(1),
      I3 => \pixel_x[6]\(0),
      I4 => \rgb_out[23]_i_744_n_0\,
      I5 => \pixel_x[1]_5\(0),
      O => \rgb_out[23]_i_446_n_0\
    );
\rgb_out[23]_i_447\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8888800080008000"
    )
        port map (
      I0 => \pixel_y[2]_4\(0),
      I1 => \pixel_y[2]_5\(0),
      I2 => \SC_U/segments\(2),
      I3 => \pixel_x[6]\(0),
      I4 => \rgb_out[23]_i_749_n_0\,
      I5 => \pixel_x[1]_5\(0),
      O => \rgb_out[23]_i_447_n_0\
    );
\rgb_out[23]_i_448\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"0000E000"
    )
        port map (
      I0 => \pixel_y[2]_1\(0),
      I1 => \pixel_y[5]\(0),
      I2 => \SC_D/pixel_on9\,
      I3 => \pixel_x[1]_2\(0),
      I4 => score_diz,
      O => \rgb_out[23]_i_448_n_0\
    );
\rgb_out[23]_i_449\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"F888"
    )
        port map (
      I0 => \SC_D/pixel_on83_in\,
      I1 => \SC_D/pixel_on7\,
      I2 => \pixel_y[2]_2\(0),
      I3 => \SC_D/pixel_on66_in\,
      O => \rgb_out[23]_i_449_n_0\
    );
\rgb_out[23]_i_45\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FEFFFEFFFEFFFEFE"
    )
        port map (
      I0 => \rgb_out[23]_i_147_n_0\,
      I1 => \rgb_out[23]_i_148_n_0\,
      I2 => \rgb_out[23]_i_149_n_0\,
      I3 => \rgb_out[23]_i_150_n_0\,
      I4 => \rgb_out[23]_i_145_n_0\,
      I5 => \rgb_out[23]_i_151_n_0\,
      O => \rgb_out[23]_i_45_n_0\
    );
\rgb_out[23]_i_451\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E0"
    )
        port map (
      I0 => score_courant(2),
      I1 => score_courant(1),
      I2 => score_courant(3),
      O => score_diz
    );
\rgb_out[23]_i_453\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"7FFF"
    )
        port map (
      I0 => \pixel_y[2]\(0),
      I1 => \pixel_x[1]_0\(0),
      I2 => \pixel_y[2]_0\(0),
      I3 => \pixel_x[1]_1\(0),
      O => \rgb_out[23]_i_453_n_0\
    );
\rgb_out[23]_i_454\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000000000D0"
    )
        port map (
      I0 => \rgb_out[23]_i_705_n_0\,
      I1 => \rgb_out[23]_i_230_n_0\,
      I2 => \rgb_out[23]_i_352_n_0\,
      I3 => \rgb_out[23]_i_702_n_0\,
      I4 => \rgb_out[23]_i_713_n_0\,
      I5 => \rgb_out[23]_i_772_n_0\,
      O => \rgb_out[23]_i_454_n_0\
    );
\rgb_out[23]_i_455\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FEFF"
    )
        port map (
      I0 => pixel_y(7),
      I1 => pixel_y(5),
      I2 => pixel_y(6),
      I3 => \rgb_out[23]_i_135_n_0\,
      O => \rgb_out[23]_i_455_n_0\
    );
\rgb_out[23]_i_456\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000800000000000"
    )
        port map (
      I0 => \rgb_out[23]_i_408_n_0\,
      I1 => pixel_y(4),
      I2 => pixel_y(3),
      I3 => pixel_y(2),
      I4 => pixel_y(1),
      I5 => \rgb_out[23]_i_135_n_0\,
      O => \rgb_out[23]_i_456_n_0\
    );
\rgb_out[23]_i_457\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000080000000"
    )
        port map (
      I0 => \rgb_out[23]_i_686_n_0\,
      I1 => pixel_x(6),
      I2 => \rgb_out[20]_i_25_n_0\,
      I3 => pixel_x(2),
      I4 => pixel_x(1),
      I5 => pixel_x(3),
      O => \rgb_out[23]_i_457_n_0\
    );
\rgb_out[23]_i_458\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFDDD5D5D5"
    )
        port map (
      I0 => \rgb_out[23]_i_174_n_0\,
      I1 => pixel_x(5),
      I2 => pixel_x(4),
      I3 => pixel_x(2),
      I4 => pixel_x(3),
      I5 => \rgb_out[23]_i_173_n_0\,
      O => \rgb_out[23]_i_458_n_0\
    );
\rgb_out[23]_i_459\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000400FFFFFFFFFF"
    )
        port map (
      I0 => pixel_x(7),
      I1 => \rgb_out[23]_i_233_n_0\,
      I2 => pixel_x(6),
      I3 => pixel_x(9),
      I4 => pixel_x(8),
      I5 => pixel_x(10),
      O => \rgb_out[23]_i_459_n_0\
    );
\rgb_out[23]_i_46\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AF03AF0300000F03"
    )
        port map (
      I0 => \rgb_out[23]_i_152_n_0\,
      I1 => \rgb_out[23]_i_153_n_0\,
      I2 => \rgb_out[23]_i_154_n_0\,
      I3 => \rgb_out[23]_i_155_n_0\,
      I4 => \rgb_out[23]_i_156_n_0\,
      I5 => \rgb_out[23]_i_157_n_0\,
      O => \rgb_out[23]_i_46_n_0\
    );
\rgb_out[23]_i_460\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"F5F5F5F5F5F5F5F7"
    )
        port map (
      I0 => \rgb_out[11]_i_33_n_0\,
      I1 => pixel_x(7),
      I2 => pixel_x(11),
      I3 => pixel_x(2),
      I4 => pixel_x(6),
      I5 => \rgb_out[11]_i_32_n_0\,
      O => \rgb_out[23]_i_460_n_0\
    );
\rgb_out[23]_i_461\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000000001"
    )
        port map (
      I0 => pixel_x(7),
      I1 => pixel_x(6),
      I2 => pixel_x(3),
      I3 => pixel_x(4),
      I4 => pixel_x(9),
      I5 => pixel_x(5),
      O => \rgb_out[23]_i_461_n_0\
    );
\rgb_out[23]_i_462\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"DDDF"
    )
        port map (
      I0 => pixel_x(10),
      I1 => pixel_x(11),
      I2 => pixel_x(8),
      I3 => pixel_x(9),
      O => \rgb_out[23]_i_462_n_0\
    );
\rgb_out[23]_i_463\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFAAAAAAFE"
    )
        port map (
      I0 => \rgb_out[23]_i_773_n_0\,
      I1 => pixel_x(11),
      I2 => pixel_x(1),
      I3 => pixel_x(7),
      I4 => \rgb_out[23]_i_774_n_0\,
      I5 => \rgb_out[23]_i_775_n_0\,
      O => \rgb_out[23]_i_463_n_0\
    );
\rgb_out[23]_i_464\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"22FF333320203030"
    )
        port map (
      I0 => \rgb_out[23]_i_223_n_0\,
      I1 => \rgb_out[23]_i_712_n_0\,
      I2 => \rgb_out[23]_i_174_n_0\,
      I3 => \rgb_out[7]_i_70_n_0\,
      I4 => pixel_x(6),
      I5 => \rgb_out[23]_i_776_n_0\,
      O => \rgb_out[23]_i_464_n_0\
    );
\rgb_out[23]_i_465\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000004000"
    )
        port map (
      I0 => pixel_x(4),
      I1 => \rgb_out[11]_i_11_n_0\,
      I2 => \rgb_out[20]_i_23_n_0\,
      I3 => pixel_x(5),
      I4 => pixel_x(7),
      I5 => pixel_x(6),
      O => \rgb_out[23]_i_465_n_0\
    );
\rgb_out[23]_i_466\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => pixel_x(0),
      I1 => pixel_x(1),
      O => \rgb_out[23]_i_466_n_0\
    );
\rgb_out[23]_i_467\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000000001"
    )
        port map (
      I0 => pixel_x(1),
      I1 => pixel_x(0),
      I2 => pixel_x(3),
      I3 => pixel_x(7),
      I4 => pixel_x(6),
      I5 => pixel_x(4),
      O => \rgb_out[23]_i_467_n_0\
    );
\rgb_out[23]_i_468\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000000010"
    )
        port map (
      I0 => pixel_x(7),
      I1 => pixel_x(6),
      I2 => \rgb_out[11]_i_11_n_0\,
      I3 => pixel_x(5),
      I4 => pixel_x(4),
      I5 => pixel_x(3),
      O => \rgb_out[23]_i_468_n_0\
    );
\rgb_out[23]_i_469\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"0001FFFF"
    )
        port map (
      I0 => pixel_x(3),
      I1 => pixel_x(2),
      I2 => pixel_x(0),
      I3 => pixel_x(1),
      I4 => pixel_x(4),
      O => \rgb_out[23]_i_469_n_0\
    );
\rgb_out[23]_i_47\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFAEFFAEFFAE"
    )
        port map (
      I0 => \rgb_out[23]_i_158_n_0\,
      I1 => \rgb_out[23]_i_159_n_0\,
      I2 => \rgb_out[23]_i_160_n_0\,
      I3 => \rgb_out[23]_i_161_n_0\,
      I4 => \rgb_out[23]_i_162_n_0\,
      I5 => \rgb_out[23]_i_163_n_0\,
      O => \rgb_out[23]_i_47_n_0\
    );
\rgb_out[23]_i_48\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFFFEA"
    )
        port map (
      I0 => \rgb_out[23]_i_164_n_0\,
      I1 => \rgb_out[23]_i_165_n_0\,
      I2 => \SC_U/pixel_on0\,
      I3 => num_sc_d,
      I4 => \rgb_out[23]_i_168_n_0\,
      I5 => \rgb_out[23]_i_169_n_0\,
      O => \rgb_out[23]_i_48_n_0\
    );
\rgb_out[23]_i_49\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"4F44"
    )
        port map (
      I0 => \rgb_out[23]_i_170_n_0\,
      I1 => \rgb_out[23]_i_153_n_0\,
      I2 => \rgb_out[23]_i_171_n_0\,
      I3 => \rgb_out[23]_i_172_n_0\,
      O => \rgb_out[23]_i_49_n_0\
    );
\rgb_out[23]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFF77F70000"
    )
        port map (
      I0 => \rgb_out[23]_i_10_n_0\,
      I1 => \rgb_out[23]_i_11_n_0\,
      I2 => rgb_in(23),
      I3 => \rgb_out[23]_i_12_n_0\,
      I4 => \rgb_out[23]_i_13_n_0\,
      I5 => \rgb_out[23]_i_14_n_0\,
      O => \rgb_out[23]_i_5_n_0\
    );
\rgb_out[23]_i_50\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFF00040000"
    )
        port map (
      I0 => \rgb_out[23]_i_173_n_0\,
      I1 => \rgb_out[23]_i_174_n_0\,
      I2 => \rgb_out[23]_i_175_n_0\,
      I3 => \rgb_out[23]_i_176_n_0\,
      I4 => \rgb_out[23]_i_162_n_0\,
      I5 => \rgb_out[23]_i_177_n_0\,
      O => \rgb_out[23]_i_50_n_0\
    );
\rgb_out[23]_i_51\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00FC00FCFFFFAAFE"
    )
        port map (
      I0 => \rgb_out[23]_i_156_n_0\,
      I1 => \rgb_out[23]_i_153_n_0\,
      I2 => \rgb_out[23]_i_154_n_0\,
      I3 => \rgb_out[23]_i_178_n_0\,
      I4 => \rgb_out[23]_i_179_n_0\,
      I5 => \rgb_out[23]_i_180_n_0\,
      O => \rgb_out[23]_i_51_n_0\
    );
\rgb_out[23]_i_52\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"77FF70FF77FF7070"
    )
        port map (
      I0 => \rgb_out[23]_i_181_n_0\,
      I1 => \rgb_out[23]_i_182_n_0\,
      I2 => \rgb_out[7]_i_9_n_0\,
      I3 => \rgb_out[23]_i_183_n_0\,
      I4 => \rgb_out[7]_i_12_n_0\,
      I5 => \rgb_out[7]_i_13_n_0\,
      O => \rgb_out[23]_i_52_n_0\
    );
\rgb_out[23]_i_521\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFEFFFF"
    )
        port map (
      I0 => \rgb_out[23]_i_522_n_0\,
      I1 => pixel_x(11),
      I2 => pixel_x(5),
      I3 => pixel_x(9),
      I4 => \rgb_out[23]_i_225_n_0\,
      I5 => pixel_x(6),
      O => \rgb_out[23]_i_521_n_0\
    );
\rgb_out[23]_i_522\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"000F070F"
    )
        port map (
      I0 => pixel_x(7),
      I1 => pixel_x(8),
      I2 => pixel_x(11),
      I3 => pixel_x(10),
      I4 => pixel_x(9),
      O => \rgb_out[23]_i_522_n_0\
    );
\rgb_out[23]_i_523\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8000000000000000"
    )
        port map (
      I0 => pixel_x(4),
      I1 => pixel_x(6),
      I2 => pixel_x(5),
      I3 => pixel_x(10),
      I4 => pixel_x(8),
      I5 => \rgb_out[23]_i_346_n_0\,
      O => \rgb_out[23]_i_523_n_0\
    );
\rgb_out[23]_i_524\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFBAFFBAFFFFFFBA"
    )
        port map (
      I0 => \rgb_out[23]_i_909_n_0\,
      I1 => \rgb_out[23]_i_910_n_0\,
      I2 => pixel_x(8),
      I3 => \rgb_out[23]_i_911_n_0\,
      I4 => \rgb_out[23]_i_423_n_0\,
      I5 => \rgb_out[23]_i_912_n_0\,
      O => \rgb_out[23]_i_524_n_0\
    );
\rgb_out[23]_i_525\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFBABB"
    )
        port map (
      I0 => \rgb_out[23]_i_522_n_0\,
      I1 => \rgb_out[23]_i_913_n_0\,
      I2 => \rgb_out[23]_i_334_n_0\,
      I3 => pixel_x(4),
      I4 => \rgb_out[23]_i_914_n_0\,
      I5 => \rgb_out[23]_i_713_n_0\,
      O => \rgb_out[23]_i_525_n_0\
    );
\rgb_out[23]_i_526\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"10FF101010101010"
    )
        port map (
      I0 => \rgb_out[23]_i_409_n_0\,
      I1 => \rgb_out[7]_i_34_n_0\,
      I2 => \rgb_out[23]_i_915_n_0\,
      I3 => \rgb_out[23]_i_916_n_0\,
      I4 => \rgb_out[23]_i_135_n_0\,
      I5 => \rgb_out[23]_i_408_n_0\,
      O => \rgb_out[23]_i_526_n_0\
    );
\rgb_out[23]_i_527\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"1001000000000000"
    )
        port map (
      I0 => \rgb_out[23]_i_917_n_0\,
      I1 => \rgb_out[21]_i_6_n_0\,
      I2 => \rgb_out[7]_i_37_n_0\,
      I3 => pixel_y(2),
      I4 => pixel_y(5),
      I5 => pixel_y(3),
      O => \rgb_out[23]_i_527_n_0\
    );
\rgb_out[23]_i_528\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000004F00000044"
    )
        port map (
      I0 => pixel_y(5),
      I1 => \rgb_out[23]_i_135_n_0\,
      I2 => pixel_y(8),
      I3 => pixel_y(6),
      I4 => pixel_y(7),
      I5 => \rgb_out[23]_i_562_n_0\,
      O => \rgb_out[23]_i_528_n_0\
    );
\rgb_out[23]_i_529\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000015150515"
    )
        port map (
      I0 => \rgb_out[23]_i_67_n_0\,
      I1 => pixel_y(4),
      I2 => pixel_y(5),
      I3 => pixel_y(3),
      I4 => \rgb_out[23]_i_918_n_0\,
      I5 => \rgb_out[21]_i_6_n_0\,
      O => \rgb_out[23]_i_529_n_0\
    );
\rgb_out[23]_i_53\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFEAAFFAAFEAA"
    )
        port map (
      I0 => \rgb_out[7]_i_18_n_0\,
      I1 => \rgb_out[23]_i_184_n_0\,
      I2 => \rgb_out[23]_i_185_n_0\,
      I3 => \rgb_out[7]_i_14_n_0\,
      I4 => \rgb_out[23]_i_186_n_0\,
      I5 => \rgb_out[7]_i_13_n_0\,
      O => \rgb_out[23]_i_53_n_0\
    );
\rgb_out[23]_i_530\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000010010000"
    )
        port map (
      I0 => pixel_y(4),
      I1 => pixel_y(3),
      I2 => pixel_y(2),
      I3 => \rgb_out[7]_i_37_n_0\,
      I4 => pixel_y(5),
      I5 => \rgb_out[23]_i_409_n_0\,
      O => \rgb_out[23]_i_530_n_0\
    );
\rgb_out[23]_i_531\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFF5DFFFF"
    )
        port map (
      I0 => \rgb_out[23]_i_556_n_0\,
      I1 => \rgb_out[7]_i_76_n_0\,
      I2 => \rgb_out[23]_i_919_n_0\,
      I3 => \rgb_out[23]_i_351_n_0\,
      I4 => \rgb_out[23]_i_224_n_0\,
      I5 => \rgb_out[23]_i_713_n_0\,
      O => \rgb_out[23]_i_531_n_0\
    );
\rgb_out[23]_i_532\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000B000000000000"
    )
        port map (
      I0 => \rgb_out[23]_i_920_n_0\,
      I1 => \rgb_out[23]_i_553_n_0\,
      I2 => \rgb_out[23]_i_921_n_0\,
      I3 => \rgb_out[23]_i_922_n_0\,
      I4 => \rgb_out[20]_i_25_n_0\,
      I5 => pixel_x(3),
      O => \rgb_out[23]_i_532_n_0\
    );
\rgb_out[23]_i_533\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000000000F7"
    )
        port map (
      I0 => \rgb_out[23]_i_135_n_0\,
      I1 => \rgb_out[23]_i_408_n_0\,
      I2 => \rgb_out[23]_i_923_n_0\,
      I3 => \rgb_out[23]_i_409_n_0\,
      I4 => \rgb_out[23]_i_924_n_0\,
      I5 => \rgb_out[23]_i_925_n_0\,
      O => \rgb_out[23]_i_533_n_0\
    );
\rgb_out[23]_i_534\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"004F00FFFFFFFFFF"
    )
        port map (
      I0 => pixel_x(6),
      I1 => \rgb_out[20]_i_25_n_0\,
      I2 => pixel_x(7),
      I3 => pixel_x(9),
      I4 => pixel_x(8),
      I5 => pixel_x(10),
      O => \rgb_out[23]_i_534_n_0\
    );
\rgb_out[23]_i_535\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"3031303030313031"
    )
        port map (
      I0 => pixel_x(6),
      I1 => pixel_x(9),
      I2 => \rgb_out[11]_i_29_n_0\,
      I3 => pixel_x(5),
      I4 => \rgb_out[23]_i_334_n_0\,
      I5 => pixel_x(4),
      O => \rgb_out[23]_i_535_n_0\
    );
\rgb_out[23]_i_536\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FBFFFFFFFFFFFFFF"
    )
        port map (
      I0 => \rgb_out[23]_i_713_n_0\,
      I1 => pixel_x(8),
      I2 => pixel_x(6),
      I3 => pixel_x(10),
      I4 => pixel_x(7),
      I5 => \rgb_out[23]_i_913_n_0\,
      O => \rgb_out[23]_i_536_n_0\
    );
\rgb_out[23]_i_537\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"AAA8"
    )
        port map (
      I0 => pixel_x(5),
      I1 => pixel_x(4),
      I2 => pixel_x(3),
      I3 => pixel_x(2),
      O => \rgb_out[23]_i_537_n_0\
    );
\rgb_out[23]_i_538\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => decompte_ui(1),
      I1 => decompte_ui(0),
      O => \rgb_out[23]_i_538_n_0\
    );
\rgb_out[23]_i_539\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"8F"
    )
        port map (
      I0 => decompte_ui(0),
      I1 => decompte_ui(1),
      I2 => decompte_ui(2),
      O => \rgb_out[23]_i_539_n_0\
    );
\rgb_out[23]_i_54\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"FB"
    )
        port map (
      I0 => mode_ui(1),
      I1 => mode_ui(0),
      I2 => mode_ui(2),
      O => \rgb_out[23]_i_54_n_0\
    );
\rgb_out[23]_i_540\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0001"
    )
        port map (
      I0 => pixel_y(7),
      I1 => pixel_y(11),
      I2 => pixel_y(10),
      I3 => pixel_y(9),
      O => \rgb_out[23]_i_540_n_0\
    );
\rgb_out[23]_i_541\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"2AAAAAAAAAAAAAAA"
    )
        port map (
      I0 => \rgb_out[7]_i_73_n_0\,
      I1 => pixel_x(9),
      I2 => pixel_x(8),
      I3 => pixel_x(3),
      I4 => pixel_x(4),
      I5 => pixel_x(5),
      O => \rgb_out[23]_i_541_n_0\
    );
\rgb_out[23]_i_542\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"7F7F7F7F7F7F7FFF"
    )
        port map (
      I0 => pixel_y(6),
      I1 => pixel_y(5),
      I2 => pixel_y(4),
      I3 => pixel_y(2),
      I4 => pixel_y(3),
      I5 => pixel_y(1),
      O => \rgb_out[23]_i_542_n_0\
    );
\rgb_out[23]_i_543\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"EAAA"
    )
        port map (
      I0 => pixel_x(5),
      I1 => pixel_x(3),
      I2 => pixel_x(4),
      I3 => pixel_x(2),
      O => \rgb_out[23]_i_543_n_0\
    );
\rgb_out[23]_i_544\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"80"
    )
        port map (
      I0 => pixel_x(7),
      I1 => pixel_x(8),
      I2 => pixel_x(9),
      O => \rgb_out[23]_i_544_n_0\
    );
\rgb_out[23]_i_545\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFFFFE"
    )
        port map (
      I0 => pixel_x(3),
      I1 => pixel_x(4),
      I2 => pixel_x(1),
      I3 => pixel_x(2),
      I4 => pixel_x(7),
      I5 => pixel_x(0),
      O => \rgb_out[23]_i_545_n_0\
    );
\rgb_out[23]_i_546\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"07FFFFFF"
    )
        port map (
      I0 => pixel_x(6),
      I1 => pixel_x(5),
      I2 => pixel_x(7),
      I3 => pixel_x(8),
      I4 => pixel_x(9),
      O => \rgb_out[23]_i_546_n_0\
    );
\rgb_out[23]_i_547\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"EEFFAAFFEEFFA0FF"
    )
        port map (
      I0 => \rgb_out[23]_i_245_n_0\,
      I1 => pixel_x(9),
      I2 => pixel_x(4),
      I3 => \rgb_out[11]_i_11_n_0\,
      I4 => pixel_x(8),
      I5 => pixel_x(3),
      O => \rgb_out[23]_i_547_n_0\
    );
\rgb_out[23]_i_548\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"7FFFFFFFFFFFFFFF"
    )
        port map (
      I0 => pixel_x(3),
      I1 => pixel_x(2),
      I2 => pixel_x(5),
      I3 => pixel_x(6),
      I4 => pixel_x(7),
      I5 => pixel_x(9),
      O => \rgb_out[23]_i_548_n_0\
    );
\rgb_out[23]_i_549\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0C550C0CCCCCCCCC"
    )
        port map (
      I0 => \rgb_out[23]_i_334_n_0\,
      I1 => \rgb_out[11]_i_11_n_0\,
      I2 => pixel_x(8),
      I3 => \rgb_out[23]_i_233_n_0\,
      I4 => \rgb_out[11]_i_21_n_0\,
      I5 => pixel_x(9),
      O => \rgb_out[23]_i_549_n_0\
    );
\rgb_out[23]_i_55\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000EEEAEAEA"
    )
        port map (
      I0 => \rgb_out[23]_i_187_n_0\,
      I1 => \rgb_out[23]_i_188_n_0\,
      I2 => \pixel_x[7]\(0),
      I3 => \rgb_out[23]_i_190_n_0\,
      I4 => \pixel_x[3]\(0),
      I5 => \rgb_out[23]_i_192_n_0\,
      O => num_tm_d
    );
\rgb_out[23]_i_550\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFF0000FFF8"
    )
        port map (
      I0 => \rgb_out[23]_i_237_n_0\,
      I1 => pixel_y(4),
      I2 => pixel_y(5),
      I3 => pixel_y(6),
      I4 => \rgb_out[23]_i_40_n_0\,
      I5 => \rgb_out[21]_i_6_n_0\,
      O => \rgb_out[23]_i_550_n_0\
    );
\rgb_out[23]_i_551\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0F00FFFF0F000100"
    )
        port map (
      I0 => pixel_x(6),
      I1 => \rgb_out[23]_i_300_n_0\,
      I2 => pixel_x(9),
      I3 => \rgb_out[11]_i_11_n_0\,
      I4 => \rgb_out[11]_i_29_n_0\,
      I5 => \rgb_out[23]_i_346_n_0\,
      O => \rgb_out[23]_i_551_n_0\
    );
\rgb_out[23]_i_552\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FE000000"
    )
        port map (
      I0 => pixel_x(6),
      I1 => pixel_x(5),
      I2 => pixel_x(4),
      I3 => pixel_x(8),
      I4 => pixel_x(7),
      O => \rgb_out[23]_i_552_n_0\
    );
\rgb_out[23]_i_553\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"8000"
    )
        port map (
      I0 => pixel_x(2),
      I1 => pixel_x(3),
      I2 => pixel_x(8),
      I3 => pixel_x(7),
      O => \rgb_out[23]_i_553_n_0\
    );
\rgb_out[23]_i_554\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"4444044444000400"
    )
        port map (
      I0 => \rgb_out[23]_i_226_n_0\,
      I1 => \rgb_out[23]_i_219_n_0\,
      I2 => pixel_x(4),
      I3 => pixel_x(3),
      I4 => \rgb_out[11]_i_29_n_0\,
      I5 => pixel_x(2),
      O => \rgb_out[23]_i_554_n_0\
    );
\rgb_out[23]_i_555\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"8000"
    )
        port map (
      I0 => pixel_x(2),
      I1 => pixel_x(3),
      I2 => pixel_x(4),
      I3 => pixel_x(5),
      O => \rgb_out[23]_i_555_n_0\
    );
\rgb_out[23]_i_556\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"80000000"
    )
        port map (
      I0 => pixel_x(5),
      I1 => pixel_x(4),
      I2 => pixel_x(3),
      I3 => pixel_x(10),
      I4 => pixel_x(6),
      O => \rgb_out[23]_i_556_n_0\
    );
\rgb_out[23]_i_557\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00010101"
    )
        port map (
      I0 => pixel_x(9),
      I1 => pixel_x(11),
      I2 => pixel_x(10),
      I3 => pixel_x(8),
      I4 => pixel_x(7),
      O => \rgb_out[23]_i_557_n_0\
    );
\rgb_out[23]_i_558\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"DFFFFFFFFFFFFFFF"
    )
        port map (
      I0 => \rgb_out[23]_i_219_n_0\,
      I1 => \rgb_out[11]_i_29_n_0\,
      I2 => pixel_x(6),
      I3 => pixel_x(2),
      I4 => pixel_x(3),
      I5 => \rgb_out[20]_i_25_n_0\,
      O => \rgb_out[23]_i_558_n_0\
    );
\rgb_out[23]_i_559\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000080000"
    )
        port map (
      I0 => pixel_x(2),
      I1 => \rgb_out[23]_i_392_n_0\,
      I2 => pixel_x(5),
      I3 => \rgb_out[23]_i_676_n_0\,
      I4 => \rgb_out[11]_i_11_n_0\,
      I5 => pixel_x(9),
      O => \rgb_out[23]_i_559_n_0\
    );
\rgb_out[23]_i_560\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"ABFFABFFABFFFFFF"
    )
        port map (
      I0 => \rgb_out[23]_i_352_n_0\,
      I1 => \rgb_out[23]_i_392_n_0\,
      I2 => pixel_x(5),
      I3 => \rgb_out[23]_i_351_n_0\,
      I4 => pixel_x(6),
      I5 => \rgb_out[23]_i_224_n_0\,
      O => \rgb_out[23]_i_560_n_0\
    );
\rgb_out[23]_i_561\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FEEE"
    )
        port map (
      I0 => pixel_y(3),
      I1 => pixel_y(2),
      I2 => pixel_y(0),
      I3 => pixel_y(1),
      O => \rgb_out[23]_i_561_n_0\
    );
\rgb_out[23]_i_562\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"007F"
    )
        port map (
      I0 => pixel_y(2),
      I1 => pixel_y(0),
      I2 => pixel_y(1),
      I3 => pixel_y(3),
      O => \rgb_out[23]_i_562_n_0\
    );
\rgb_out[23]_i_563\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00010101"
    )
        port map (
      I0 => pixel_y(2),
      I1 => pixel_y(3),
      I2 => pixel_y(4),
      I3 => pixel_y(0),
      I4 => pixel_y(1),
      O => \rgb_out[23]_i_563_n_0\
    );
\rgb_out[23]_i_564\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFFE"
    )
        port map (
      I0 => pixel_x(7),
      I1 => pixel_x(9),
      I2 => pixel_x(10),
      I3 => pixel_x(11),
      O => \rgb_out[23]_i_564_n_0\
    );
\rgb_out[23]_i_565\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"80"
    )
        port map (
      I0 => pixel_x(3),
      I1 => pixel_x(6),
      I2 => pixel_x(2),
      O => \rgb_out[23]_i_565_n_0\
    );
\rgb_out[23]_i_566\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => pixel_y(2),
      I1 => pixel_y(3),
      O => \rgb_out[23]_i_566_n_0\
    );
\rgb_out[23]_i_567\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => pixel_x(9),
      I1 => pixel_x(6),
      O => \rgb_out[23]_i_567_n_0\
    );
\rgb_out[23]_i_568\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFFFFFE"
    )
        port map (
      I0 => pixel_x(11),
      I1 => pixel_x(9),
      I2 => pixel_x(8),
      I3 => pixel_x(4),
      I4 => pixel_x(5),
      O => \rgb_out[23]_i_568_n_0\
    );
\rgb_out[23]_i_569\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000700000005"
    )
        port map (
      I0 => \rgb_out[11]_i_21_n_0\,
      I1 => pixel_x(5),
      I2 => pixel_x(8),
      I3 => pixel_x(9),
      I4 => pixel_x(11),
      I5 => \rgb_out[23]_i_334_n_0\,
      O => \rgb_out[23]_i_569_n_0\
    );
\rgb_out[23]_i_570\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"AA80"
    )
        port map (
      I0 => pixel_x(6),
      I1 => pixel_x(3),
      I2 => pixel_x(4),
      I3 => pixel_x(5),
      O => \rgb_out[23]_i_570_n_0\
    );
\rgb_out[23]_i_571\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00E0E0E0E0E0E0E0"
    )
        port map (
      I0 => \rgb_out[23]_i_708_n_0\,
      I1 => pixel_x(8),
      I2 => \rgb_out[23]_i_351_n_0\,
      I3 => pixel_x(4),
      I4 => pixel_x(3),
      I5 => pixel_x(2),
      O => \rgb_out[23]_i_571_n_0\
    );
\rgb_out[23]_i_572\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"7FFFFFFF"
    )
        port map (
      I0 => pixel_x(5),
      I1 => pixel_x(6),
      I2 => pixel_x(7),
      I3 => pixel_x(10),
      I4 => \rgb_out[23]_i_334_n_0\,
      O => \rgb_out[23]_i_572_n_0\
    );
\rgb_out[23]_i_573\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"1000000000000000"
    )
        port map (
      I0 => \rgb_out[23]_i_337_n_0\,
      I1 => pixel_x(6),
      I2 => pixel_x(8),
      I3 => pixel_x(4),
      I4 => pixel_x(5),
      I5 => \rgb_out[23]_i_346_n_0\,
      O => \rgb_out[23]_i_573_n_0\
    );
\rgb_out[23]_i_574\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000002800000"
    )
        port map (
      I0 => \rgb_out[23]_i_351_n_0\,
      I1 => pixel_x(5),
      I2 => pixel_x(4),
      I3 => pixel_x(6),
      I4 => \rgb_out[23]_i_334_n_0\,
      I5 => \rgb_out[23]_i_926_n_0\,
      O => \rgb_out[23]_i_574_n_0\
    );
\rgb_out[23]_i_575\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFFFFF8"
    )
        port map (
      I0 => pixel_x(3),
      I1 => pixel_x(2),
      I2 => pixel_x(4),
      I3 => pixel_x(7),
      I4 => pixel_x(5),
      O => \rgb_out[23]_i_575_n_0\
    );
\rgb_out[23]_i_576\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFBFFFFF"
    )
        port map (
      I0 => pixel_x(4),
      I1 => \rgb_out[23]_i_219_n_0\,
      I2 => pixel_x(8),
      I3 => pixel_x(7),
      I4 => pixel_x(6),
      I5 => pixel_x(5),
      O => \rgb_out[23]_i_576_n_0\
    );
\rgb_out[23]_i_577\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FEFFFFFFFFFFFFFF"
    )
        port map (
      I0 => pixel_y(5),
      I1 => pixel_y(6),
      I2 => \rgb_out[21]_i_6_n_0\,
      I3 => pixel_y(8),
      I4 => pixel_y(7),
      I5 => pixel_y(4),
      O => \rgb_out[23]_i_577_n_0\
    );
\rgb_out[23]_i_578\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFFE"
    )
        port map (
      I0 => pixel_x(6),
      I1 => pixel_x(9),
      I2 => pixel_x(2),
      I3 => pixel_x(3),
      O => \rgb_out[23]_i_578_n_0\
    );
\rgb_out[23]_i_579\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000000001"
    )
        port map (
      I0 => pixel_x(11),
      I1 => pixel_x(9),
      I2 => pixel_x(7),
      I3 => pixel_x(8),
      I4 => pixel_x(4),
      I5 => pixel_x(3),
      O => \rgb_out[23]_i_579_n_0\
    );
\rgb_out[23]_i_58\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"D75DF7DF15511551"
    )
        port map (
      I0 => \rgb_out[23]_i_199_n_0\,
      I1 => temps_restant(2),
      I2 => temps_restant(1),
      I3 => temps_restant(3),
      I4 => temps_restant(0),
      I5 => \rgb_out[23]_i_200_n_0\,
      O => \rgb_out[23]_i_58_n_0\
    );
\rgb_out[23]_i_6\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \rgb_out[23]_i_15_n_0\,
      I1 => \rgb_out[23]_i_16_n_0\,
      O => \rgb_out[23]_i_6_n_0\
    );
\rgb_out[23]_i_60\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0002000200000002"
    )
        port map (
      I0 => \rgb_out[23]_i_205_n_0\,
      I1 => \rgb_out[23]_i_206_n_0\,
      I2 => \rgb_out[23]_i_207_n_0\,
      I3 => \rgb_out[23]_i_208_n_0\,
      I4 => \rgb_out[23]_i_209_n_0\,
      I5 => \rgb_out[23]_i_210_n_0\,
      O => \rgb_out[23]_i_60_n_0\
    );
\rgb_out[23]_i_608\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"1455"
    )
        port map (
      I0 => score_dernier(0),
      I1 => score_dernier(1),
      I2 => score_dernier(3),
      I3 => score_dernier(2),
      O => \LAST_U/segments\(2)
    );
\rgb_out[23]_i_61\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFFE"
    )
        port map (
      I0 => decompte_ui(2),
      I1 => decompte_ui(3),
      I2 => decompte_ui(0),
      I3 => decompte_ui(1),
      O => \rgb_out[23]_i_61_n_0\
    );
\rgb_out[23]_i_610\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FBEF"
    )
        port map (
      I0 => score_dernier(0),
      I1 => score_dernier(2),
      I2 => score_dernier(1),
      I3 => score_dernier(3),
      O => \rgb_out[23]_i_610_n_0\
    );
\rgb_out[23]_i_614\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"D34D"
    )
        port map (
      I0 => score_dernier(0),
      I1 => score_dernier(2),
      I2 => score_dernier(1),
      I3 => score_dernier(3),
      O => \LAST_U/segments\(1)
    );
\rgb_out[23]_i_615\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"7FB7"
    )
        port map (
      I0 => score_dernier(0),
      I1 => score_dernier(2),
      I2 => score_dernier(1),
      I3 => score_dernier(3),
      O => \rgb_out[23]_i_615_n_0\
    );
\rgb_out[23]_i_618\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"7D"
    )
        port map (
      I0 => score_dernier(2),
      I1 => score_dernier(3),
      I2 => score_dernier(1),
      O => \rgb_out[23]_i_618_n_0\
    );
\rgb_out[23]_i_619\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"00FD"
    )
        port map (
      I0 => score_dernier(3),
      I1 => score_dernier(1),
      I2 => score_dernier(2),
      I3 => score_dernier(0),
      O => \rgb_out[23]_i_619_n_0\
    );
\rgb_out[23]_i_621\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"4100"
    )
        port map (
      I0 => score_dernier(2),
      I1 => score_dernier(3),
      I2 => score_dernier(1),
      I3 => score_dernier(0),
      O => \rgb_out[23]_i_621_n_0\
    );
\rgb_out[23]_i_623\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"09"
    )
        port map (
      I0 => score_dernier(3),
      I1 => score_dernier(1),
      I2 => score_dernier(2),
      O => \rgb_out[23]_i_623_n_0\
    );
\rgb_out[23]_i_625\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"2000"
    )
        port map (
      I0 => score_dernier(2),
      I1 => score_dernier(3),
      I2 => score_dernier(1),
      I3 => score_dernier(0),
      O => \rgb_out[23]_i_625_n_0\
    );
\rgb_out[23]_i_627\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9F79"
    )
        port map (
      I0 => score_dernier(0),
      I1 => score_dernier(2),
      I2 => score_dernier(1),
      I3 => score_dernier(3),
      O => \rgb_out[23]_i_627_n_0\
    );
\rgb_out[23]_i_634\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"1455"
    )
        port map (
      I0 => record_personnel(0),
      I1 => record_personnel(1),
      I2 => record_personnel(3),
      I3 => record_personnel(2),
      O => \REC_U/segments\(2)
    );
\rgb_out[23]_i_636\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"EFFB"
    )
        port map (
      I0 => record_personnel(0),
      I1 => record_personnel(1),
      I2 => record_personnel(2),
      I3 => record_personnel(3),
      O => \rgb_out[23]_i_636_n_0\
    );
\rgb_out[23]_i_640\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"C771"
    )
        port map (
      I0 => record_personnel(0),
      I1 => record_personnel(1),
      I2 => record_personnel(2),
      I3 => record_personnel(3),
      O => \REC_U/segments\(1)
    );
\rgb_out[23]_i_641\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"7F9F"
    )
        port map (
      I0 => record_personnel(0),
      I1 => record_personnel(1),
      I2 => record_personnel(2),
      I3 => record_personnel(3),
      O => \rgb_out[23]_i_641_n_0\
    );
\rgb_out[23]_i_644\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"7D"
    )
        port map (
      I0 => record_personnel(2),
      I1 => record_personnel(3),
      I2 => record_personnel(1),
      O => \rgb_out[23]_i_644_n_0\
    );
\rgb_out[23]_i_645\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"00FD"
    )
        port map (
      I0 => record_personnel(3),
      I1 => record_personnel(2),
      I2 => record_personnel(1),
      I3 => record_personnel(0),
      O => \rgb_out[23]_i_645_n_0\
    );
\rgb_out[23]_i_647\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"4100"
    )
        port map (
      I0 => record_personnel(2),
      I1 => record_personnel(3),
      I2 => record_personnel(1),
      I3 => record_personnel(0),
      O => \rgb_out[23]_i_647_n_0\
    );
\rgb_out[23]_i_649\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"21"
    )
        port map (
      I0 => record_personnel(3),
      I1 => record_personnel(2),
      I2 => record_personnel(1),
      O => \rgb_out[23]_i_649_n_0\
    );
\rgb_out[23]_i_65\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000000001"
    )
        port map (
      I0 => \rgb_out[23]_i_42_n_0\,
      I1 => \rgb_out[23]_i_219_n_0\,
      I2 => pixel_y(11),
      I3 => pixel_y(10),
      I4 => pixel_x(11),
      I5 => \rgb_out[23]_i_220_n_0\,
      O => \rgb_out[23]_i_65_n_0\
    );
\rgb_out[23]_i_651\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"2000"
    )
        port map (
      I0 => record_personnel(2),
      I1 => record_personnel(3),
      I2 => record_personnel(1),
      I3 => record_personnel(0),
      O => \rgb_out[23]_i_651_n_0\
    );
\rgb_out[23]_i_653\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"B76D"
    )
        port map (
      I0 => record_personnel(0),
      I1 => record_personnel(1),
      I2 => record_personnel(2),
      I3 => record_personnel(3),
      O => \rgb_out[23]_i_653_n_0\
    );
\rgb_out[23]_i_66\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000000015"
    )
        port map (
      I0 => pixel_y(2),
      I1 => pixel_y(1),
      I2 => pixel_y(0),
      I3 => pixel_y(5),
      I4 => pixel_y(4),
      I5 => pixel_y(3),
      O => \rgb_out[23]_i_66_n_0\
    );
\rgb_out[23]_i_67\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"FE"
    )
        port map (
      I0 => pixel_y(8),
      I1 => pixel_y(6),
      I2 => pixel_y(7),
      O => \rgb_out[23]_i_67_n_0\
    );
\rgb_out[23]_i_676\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"7F"
    )
        port map (
      I0 => pixel_x(8),
      I1 => pixel_x(7),
      I2 => pixel_x(6),
      O => \rgb_out[23]_i_676_n_0\
    );
\rgb_out[23]_i_677\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000000800"
    )
        port map (
      I0 => pixel_x(7),
      I1 => pixel_x(6),
      I2 => pixel_x(11),
      I3 => pixel_x(10),
      I4 => pixel_x(9),
      I5 => pixel_x(8),
      O => \rgb_out[23]_i_677_n_0\
    );
\rgb_out[23]_i_678\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"C080C000"
    )
        port map (
      I0 => pixel_x(4),
      I1 => pixel_x(7),
      I2 => pixel_x(10),
      I3 => pixel_x(6),
      I4 => pixel_x(5),
      O => \rgb_out[23]_i_678_n_0\
    );
\rgb_out[23]_i_679\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FECCFECCFECCEECC"
    )
        port map (
      I0 => \rgb_out[23]_i_224_n_0\,
      I1 => pixel_x(11),
      I2 => pixel_x(7),
      I3 => pixel_x(10),
      I4 => pixel_x(6),
      I5 => pixel_x(5),
      O => \rgb_out[23]_i_679_n_0\
    );
\rgb_out[23]_i_68\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000400004444"
    )
        port map (
      I0 => pixel_x(8),
      I1 => \rgb_out[23]_i_221_n_0\,
      I2 => pixel_x(1),
      I3 => pixel_x(2),
      I4 => pixel_x(6),
      I5 => \rgb_out[23]_i_222_n_0\,
      O => \rgb_out[23]_i_68_n_0\
    );
\rgb_out[23]_i_680\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"A8888888"
    )
        port map (
      I0 => pixel_x(7),
      I1 => pixel_x(5),
      I2 => pixel_x(3),
      I3 => pixel_x(4),
      I4 => pixel_x(2),
      O => \rgb_out[23]_i_680_n_0\
    );
\rgb_out[23]_i_681\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0444044404440000"
    )
        port map (
      I0 => \rgb_out[23]_i_366_n_0\,
      I1 => \rgb_out[23]_i_343_n_0\,
      I2 => \rgb_out[23]_i_401_n_0\,
      I3 => \rgb_out[23]_i_351_n_0\,
      I4 => pixel_x(6),
      I5 => \rgb_out[23]_i_568_n_0\,
      O => \rgb_out[23]_i_681_n_0\
    );
\rgb_out[23]_i_682\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0004000000000000"
    )
        port map (
      I0 => \rgb_out[23]_i_224_n_0\,
      I1 => pixel_x(10),
      I2 => pixel_x(11),
      I3 => pixel_x(4),
      I4 => \rgb_out[11]_i_21_n_0\,
      I5 => pixel_x(5),
      O => \rgb_out[23]_i_682_n_0\
    );
\rgb_out[23]_i_683\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0001"
    )
        port map (
      I0 => pixel_y(6),
      I1 => pixel_y(7),
      I2 => pixel_y(4),
      I3 => pixel_y(5),
      O => \rgb_out[23]_i_683_n_0\
    );
\rgb_out[23]_i_684\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8000800080000000"
    )
        port map (
      I0 => pixel_x(8),
      I1 => pixel_x(9),
      I2 => pixel_x(5),
      I3 => pixel_x(4),
      I4 => pixel_x(3),
      I5 => pixel_x(2),
      O => \rgb_out[23]_i_684_n_0\
    );
\rgb_out[23]_i_685\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"E0FFE0FFE0E0E0FF"
    )
        port map (
      I0 => \rgb_out[23]_i_224_n_0\,
      I1 => \rgb_out[23]_i_1206_n_0\,
      I2 => \rgb_out[23]_i_375_n_0\,
      I3 => \rgb_out[23]_i_555_n_0\,
      I4 => \rgb_out[23]_i_219_n_0\,
      I5 => \rgb_out[23]_i_1207_n_0\,
      O => \rgb_out[23]_i_685_n_0\
    );
\rgb_out[23]_i_686\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00000001"
    )
        port map (
      I0 => pixel_x(8),
      I1 => pixel_x(7),
      I2 => pixel_x(10),
      I3 => pixel_x(11),
      I4 => pixel_x(9),
      O => \rgb_out[23]_i_686_n_0\
    );
\rgb_out[23]_i_687\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0111"
    )
        port map (
      I0 => pixel_x(8),
      I1 => pixel_x(7),
      I2 => pixel_x(5),
      I3 => pixel_x(6),
      O => \rgb_out[23]_i_687_n_0\
    );
\rgb_out[23]_i_688\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFFFF4"
    )
        port map (
      I0 => \rgb_out[23]_i_334_n_0\,
      I1 => pixel_x(4),
      I2 => pixel_x(9),
      I3 => pixel_x(5),
      I4 => pixel_x(6),
      I5 => pixel_x(7),
      O => \rgb_out[23]_i_688_n_0\
    );
\rgb_out[23]_i_689\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"7"
    )
        port map (
      I0 => pixel_x(8),
      I1 => pixel_x(10),
      O => \rgb_out[23]_i_689_n_0\
    );
\rgb_out[23]_i_69\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAAAAAAAAA2AAAA"
    )
        port map (
      I0 => pixel_x(10),
      I1 => \rgb_out[23]_i_223_n_0\,
      I2 => \rgb_out[23]_i_224_n_0\,
      I3 => pixel_x(7),
      I4 => \rgb_out[23]_i_225_n_0\,
      I5 => \rgb_out[23]_i_226_n_0\,
      O => \rgb_out[23]_i_69_n_0\
    );
\rgb_out[23]_i_690\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"ECCC"
    )
        port map (
      I0 => pixel_x(3),
      I1 => pixel_x(4),
      I2 => pixel_x(1),
      I3 => pixel_x(2),
      O => \rgb_out[23]_i_690_n_0\
    );
\rgb_out[23]_i_691\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FEAAEEAAFEAAFEAA"
    )
        port map (
      I0 => pixel_x(11),
      I1 => pixel_x(9),
      I2 => pixel_x(8),
      I3 => pixel_x(10),
      I4 => \rgb_out[20]_i_24_n_0\,
      I5 => \rgb_out[20]_i_25_n_0\,
      O => \rgb_out[23]_i_691_n_0\
    );
\rgb_out[23]_i_692\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0040004000404040"
    )
        port map (
      I0 => \rgb_out[23]_i_462_n_0\,
      I1 => \rgb_out[23]_i_1208_n_0\,
      I2 => \rgb_out[23]_i_425_n_0\,
      I3 => pixel_x(4),
      I4 => pixel_x(2),
      I5 => pixel_x(3),
      O => \rgb_out[23]_i_692_n_0\
    );
\rgb_out[23]_i_693\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00F04444CCCCCCCC"
    )
        port map (
      I0 => pixel_x(1),
      I1 => \rgb_out[23]_i_1209_n_0\,
      I2 => pixel_x(5),
      I3 => \rgb_out[23]_i_689_n_0\,
      I4 => pixel_x(2),
      I5 => pixel_x(3),
      O => \rgb_out[23]_i_693_n_0\
    );
\rgb_out[23]_i_694\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"EEEEEEEEEEEEEAEE"
    )
        port map (
      I0 => pixel_x(11),
      I1 => \rgb_out[23]_i_423_n_0\,
      I2 => pixel_x(6),
      I3 => \rgb_out[23]_i_233_n_0\,
      I4 => pixel_x(7),
      I5 => pixel_x(9),
      O => \rgb_out[23]_i_694_n_0\
    );
\rgb_out[23]_i_695\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000010000"
    )
        port map (
      I0 => pixel_x(7),
      I1 => pixel_x(11),
      I2 => \rgb_out[23]_i_567_n_0\,
      I3 => pixel_x(4),
      I4 => pixel_x(3),
      I5 => \rgb_out[11]_i_22_n_0\,
      O => \rgb_out[23]_i_695_n_0\
    );
\rgb_out[23]_i_696\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0100111133333333"
    )
        port map (
      I0 => pixel_x(9),
      I1 => pixel_x(11),
      I2 => pixel_x(7),
      I3 => \rgb_out[23]_i_367_n_0\,
      I4 => pixel_x(8),
      I5 => pixel_x(10),
      O => \rgb_out[23]_i_696_n_0\
    );
\rgb_out[23]_i_697\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFFFFD"
    )
        port map (
      I0 => \rgb_out[23]_i_223_n_0\,
      I1 => pixel_x(9),
      I2 => pixel_x(3),
      I3 => pixel_x(7),
      I4 => pixel_x(4),
      I5 => pixel_x(6),
      O => \rgb_out[23]_i_697_n_0\
    );
\rgb_out[23]_i_698\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"C8C8C8C8C8C8C8C0"
    )
        port map (
      I0 => pixel_x(8),
      I1 => pixel_x(10),
      I2 => pixel_x(9),
      I3 => pixel_x(5),
      I4 => pixel_x(6),
      I5 => pixel_x(7),
      O => \rgb_out[23]_i_698_n_0\
    );
\rgb_out[23]_i_699\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000004000000"
    )
        port map (
      I0 => pixel_x(11),
      I1 => \rgb_out[23]_i_225_n_0\,
      I2 => \rgb_out[23]_i_417_n_0\,
      I3 => \rgb_out[23]_i_224_n_0\,
      I4 => pixel_x(10),
      I5 => \rgb_out[23]_i_425_n_0\,
      O => \rgb_out[23]_i_699_n_0\
    );
\rgb_out[23]_i_70\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"D0FFD0FFD0FFD0D0"
    )
        port map (
      I0 => \rgb_out[23]_i_182_n_0\,
      I1 => \rgb_out[23]_i_227_n_0\,
      I2 => \rgb_out[23]_i_228_n_0\,
      I3 => \rgb_out[23]_i_229_n_0\,
      I4 => \rgb_out[7]_i_15_n_0\,
      I5 => \rgb_out[7]_i_50_n_0\,
      O => \rgb_out[23]_i_70_n_0\
    );
\rgb_out[23]_i_700\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000100000000"
    )
        port map (
      I0 => pixel_x(9),
      I1 => pixel_x(5),
      I2 => \rgb_out[20]_i_24_n_0\,
      I3 => \rgb_out[23]_i_462_n_0\,
      I4 => \rgb_out[11]_i_22_n_0\,
      I5 => \rgb_out[23]_i_392_n_0\,
      O => \rgb_out[23]_i_700_n_0\
    );
\rgb_out[23]_i_701\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0F55115500551155"
    )
        port map (
      I0 => pixel_x(11),
      I1 => pixel_x(9),
      I2 => \rgb_out[23]_i_223_n_0\,
      I3 => pixel_x(10),
      I4 => pixel_x(8),
      I5 => pixel_x(5),
      O => \rgb_out[23]_i_701_n_0\
    );
\rgb_out[23]_i_702\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"80000000"
    )
        port map (
      I0 => pixel_x(3),
      I1 => pixel_x(8),
      I2 => pixel_x(10),
      I3 => pixel_x(1),
      I4 => pixel_x(2),
      O => \rgb_out[23]_i_702_n_0\
    );
\rgb_out[23]_i_703\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000001010111"
    )
        port map (
      I0 => pixel_x(4),
      I1 => \rgb_out[23]_i_346_n_0\,
      I2 => pixel_x(8),
      I3 => pixel_x(7),
      I4 => pixel_x(6),
      I5 => pixel_x(9),
      O => \rgb_out[23]_i_703_n_0\
    );
\rgb_out[23]_i_704\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000000010"
    )
        port map (
      I0 => pixel_x(5),
      I1 => pixel_x(9),
      I2 => \rgb_out[11]_i_11_n_0\,
      I3 => pixel_x(7),
      I4 => pixel_x(8),
      I5 => \rgb_out[23]_i_1210_n_0\,
      O => \rgb_out[23]_i_704_n_0\
    );
\rgb_out[23]_i_705\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00000001"
    )
        port map (
      I0 => pixel_x(7),
      I1 => pixel_x(6),
      I2 => pixel_x(5),
      I3 => pixel_x(11),
      I4 => pixel_x(9),
      O => \rgb_out[23]_i_705_n_0\
    );
\rgb_out[23]_i_706\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"7FFFFFFF"
    )
        port map (
      I0 => pixel_x(10),
      I1 => pixel_x(8),
      I2 => pixel_x(3),
      I3 => pixel_x(4),
      I4 => pixel_x(2),
      O => \rgb_out[23]_i_706_n_0\
    );
\rgb_out[23]_i_707\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => pixel_x(11),
      I1 => pixel_x(7),
      O => \rgb_out[23]_i_707_n_0\
    );
\rgb_out[23]_i_708\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFEFEFE"
    )
        port map (
      I0 => pixel_x(6),
      I1 => pixel_x(9),
      I2 => pixel_x(5),
      I3 => pixel_x(4),
      I4 => pixel_x(3),
      O => \rgb_out[23]_i_708_n_0\
    );
\rgb_out[23]_i_709\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000008000000000"
    )
        port map (
      I0 => \rgb_out[23]_i_137_n_0\,
      I1 => pixel_y(3),
      I2 => pixel_y(4),
      I3 => pixel_y(7),
      I4 => \rgb_out[23]_i_267_n_0\,
      I5 => \rgb_out[23]_i_135_n_0\,
      O => \rgb_out[23]_i_709_n_0\
    );
\rgb_out[23]_i_71\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAAFFFF8880FFFF"
    )
        port map (
      I0 => \rgb_out[20]_i_23_n_0\,
      I1 => pixel_x(6),
      I2 => pixel_x(4),
      I3 => pixel_x(5),
      I4 => \rgb_out[11]_i_11_n_0\,
      I5 => pixel_x(7),
      O => \rgb_out[23]_i_71_n_0\
    );
\rgb_out[23]_i_710\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00000002"
    )
        port map (
      I0 => pixel_y(5),
      I1 => pixel_y(8),
      I2 => pixel_y(6),
      I3 => pixel_y(7),
      I4 => \rgb_out[21]_i_6_n_0\,
      O => \rgb_out[23]_i_710_n_0\
    );
\rgb_out[23]_i_711\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000000001"
    )
        port map (
      I0 => pixel_x(8),
      I1 => pixel_x(7),
      I2 => pixel_x(3),
      I3 => pixel_x(4),
      I4 => pixel_x(1),
      I5 => pixel_x(2),
      O => \rgb_out[23]_i_711_n_0\
    );
\rgb_out[23]_i_712\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000002AAAAAAAA"
    )
        port map (
      I0 => \rgb_out[23]_i_686_n_0\,
      I1 => pixel_x(2),
      I2 => pixel_x(3),
      I3 => pixel_x(4),
      I4 => pixel_x(5),
      I5 => pixel_x(6),
      O => \rgb_out[23]_i_712_n_0\
    );
\rgb_out[23]_i_713\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"F8"
    )
        port map (
      I0 => pixel_x(9),
      I1 => pixel_x(10),
      I2 => pixel_x(11),
      O => \rgb_out[23]_i_713_n_0\
    );
\rgb_out[23]_i_72\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"E0E0E0A0FFFFFFFF"
    )
        port map (
      I0 => pixel_x(7),
      I1 => pixel_x(6),
      I2 => \rgb_out[20]_i_23_n_0\,
      I3 => \rgb_out[23]_i_230_n_0\,
      I4 => pixel_x(5),
      I5 => \rgb_out[11]_i_11_n_0\,
      O => \rgb_out[23]_i_72_n_0\
    );
\rgb_out[23]_i_73\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"4FFF4444"
    )
        port map (
      I0 => \rgb_out[23]_i_229_n_0\,
      I1 => \rgb_out[7]_i_47_n_0\,
      I2 => \rgb_out[23]_i_231_n_0\,
      I3 => \rgb_out[23]_i_150_n_0\,
      I4 => \rgb_out[20]_i_10_n_0\,
      O => \rgb_out[23]_i_73_n_0\
    );
\rgb_out[23]_i_734\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"B76D"
    )
        port map (
      I0 => score_courant(0),
      I1 => score_courant(1),
      I2 => score_courant(2),
      I3 => score_courant(3),
      O => \rgb_out[23]_i_734_n_0\
    );
\rgb_out[23]_i_736\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"21"
    )
        port map (
      I0 => score_courant(3),
      I1 => score_courant(2),
      I2 => score_courant(1),
      O => \rgb_out[23]_i_736_n_0\
    );
\rgb_out[23]_i_738\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"2000"
    )
        port map (
      I0 => score_courant(2),
      I1 => score_courant(3),
      I2 => score_courant(1),
      I3 => score_courant(0),
      O => \rgb_out[23]_i_738_n_0\
    );
\rgb_out[23]_i_74\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFE0"
    )
        port map (
      I0 => \rgb_out[23]_i_232_n_0\,
      I1 => \rgb_out[7]_i_16_n_0\,
      I2 => \rgb_out[23]_i_76_n_0\,
      I3 => \rgb_out[23]_i_147_n_0\,
      O => \rgb_out[23]_i_74_n_0\
    );
\rgb_out[23]_i_742\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"C771"
    )
        port map (
      I0 => score_courant(0),
      I1 => score_courant(1),
      I2 => score_courant(2),
      I3 => score_courant(3),
      O => \SC_U/segments\(1)
    );
\rgb_out[23]_i_744\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"7F9F"
    )
        port map (
      I0 => score_courant(0),
      I1 => score_courant(1),
      I2 => score_courant(2),
      I3 => score_courant(3),
      O => \rgb_out[23]_i_744_n_0\
    );
\rgb_out[23]_i_748\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"1455"
    )
        port map (
      I0 => score_courant(0),
      I1 => score_courant(1),
      I2 => score_courant(3),
      I3 => score_courant(2),
      O => \SC_U/segments\(2)
    );
\rgb_out[23]_i_749\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"EFFB"
    )
        port map (
      I0 => score_courant(0),
      I1 => score_courant(1),
      I2 => score_courant(2),
      I3 => score_courant(3),
      O => \rgb_out[23]_i_749_n_0\
    );
\rgb_out[23]_i_75\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000004000000"
    )
        port map (
      I0 => \rgb_out[23]_i_233_n_0\,
      I1 => \rgb_out[11]_i_21_n_0\,
      I2 => \rgb_out[23]_i_234_n_0\,
      I3 => pixel_x(3),
      I4 => pixel_x(9),
      I5 => \rgb_out[23]_i_235_n_0\,
      O => \rgb_out[23]_i_75_n_0\
    );
\rgb_out[23]_i_76\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FF01000100010001"
    )
        port map (
      I0 => \rgb_out[23]_i_41_n_0\,
      I1 => \rgb_out[23]_i_236_n_0\,
      I2 => pixel_y(2),
      I3 => \rgb_out[23]_i_135_n_0\,
      I4 => \rgb_out[23]_i_237_n_0\,
      I5 => \rgb_out[23]_i_238_n_0\,
      O => \rgb_out[23]_i_76_n_0\
    );
\rgb_out[23]_i_77\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000101000001000"
    )
        port map (
      I0 => \rgb_out[23]_i_138_n_0\,
      I1 => \rgb_out[23]_i_239_n_0\,
      I2 => \rgb_out[23]_i_135_n_0\,
      I3 => pixel_y(3),
      I4 => pixel_y(4),
      I5 => \rgb_out[11]_i_31_n_0\,
      O => \rgb_out[23]_i_77_n_0\
    );
\rgb_out[23]_i_772\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFE000000000000"
    )
        port map (
      I0 => pixel_x(5),
      I1 => pixel_x(4),
      I2 => pixel_x(6),
      I3 => pixel_x(7),
      I4 => pixel_x(10),
      I5 => pixel_x(8),
      O => \rgb_out[23]_i_772_n_0\
    );
\rgb_out[23]_i_773\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"1111111011101111"
    )
        port map (
      I0 => \rgb_out[11]_i_32_n_0\,
      I1 => \rgb_out[20]_i_24_n_0\,
      I2 => \rgb_out[23]_i_1208_n_0\,
      I3 => pixel_x(3),
      I4 => pixel_x(2),
      I5 => pixel_x(1),
      O => \rgb_out[23]_i_773_n_0\
    );
\rgb_out[23]_i_774\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFFFFE"
    )
        port map (
      I0 => pixel_x(5),
      I1 => pixel_x(4),
      I2 => pixel_x(9),
      I3 => pixel_x(6),
      I4 => pixel_x(2),
      I5 => pixel_x(3),
      O => \rgb_out[23]_i_774_n_0\
    );
\rgb_out[23]_i_775\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000FEFFFE"
    )
        port map (
      I0 => pixel_x(4),
      I1 => \rgb_out[23]_i_913_n_0\,
      I2 => pixel_x(7),
      I3 => pixel_x(3),
      I4 => \rgb_out[11]_i_22_n_0\,
      I5 => \rgb_out[23]_i_1208_n_0\,
      O => \rgb_out[23]_i_775_n_0\
    );
\rgb_out[23]_i_776\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000000002"
    )
        port map (
      I0 => \rgb_out[23]_i_219_n_0\,
      I1 => pixel_x(7),
      I2 => pixel_x(8),
      I3 => pixel_x(5),
      I4 => pixel_x(4),
      I5 => pixel_x(3),
      O => \rgb_out[23]_i_776_n_0\
    );
\rgb_out[23]_i_78\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"88F888F8FFFF88F8"
    )
        port map (
      I0 => \rgb_out[23]_i_240_n_0\,
      I1 => \rgb_out[23]_i_241_n_0\,
      I2 => \rgb_out[23]_i_242_n_0\,
      I3 => \rgb_out[23]_i_243_n_0\,
      I4 => \rgb_out[23]_i_244_n_0\,
      I5 => \rgb_out[23]_i_150_n_0\,
      O => \rgb_out[23]_i_78_n_0\
    );
\rgb_out[23]_i_788\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => local_x_1(8),
      I1 => local_x_1(9),
      O => \rgb_out[23]_i_788_n_0\
    );
\rgb_out[23]_i_789\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => local_x_1(6),
      I1 => local_x_1(7),
      O => \rgb_out[23]_i_789_n_0\
    );
\rgb_out[23]_i_79\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000080000000000"
    )
        port map (
      I0 => \rgb_out[11]_i_22_n_0\,
      I1 => pixel_x(3),
      I2 => \rgb_out[23]_i_245_n_0\,
      I3 => \rgb_out[20]_i_19_n_0\,
      I4 => \rgb_out[23]_i_246_n_0\,
      I5 => \rgb_out[7]_i_60_n_0\,
      O => \rgb_out[23]_i_79_n_0\
    );
\rgb_out[23]_i_790\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => local_x_1(9),
      I1 => local_x_1(8),
      O => \rgb_out[23]_i_790_n_0\
    );
\rgb_out[23]_i_791\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => local_x_1(7),
      I1 => local_x_1(6),
      O => \rgb_out[23]_i_791_n_0\
    );
\rgb_out[23]_i_8\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0020"
    )
        port map (
      I0 => mode_ui(2),
      I1 => mode_ui(0),
      I2 => mode_ui(1),
      I3 => \rgb_out[23]_i_19_n_0\,
      O => \rgb_out[23]_i_8_n_0\
    );
\rgb_out[23]_i_80\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000000EEF0F000EE"
    )
        port map (
      I0 => \rgb_out[23]_i_247_n_0\,
      I1 => \rgb_out[23]_i_248_n_0\,
      I2 => \rgb_out[7]_i_57_n_0\,
      I3 => \rgb_out[23]_i_249_n_0\,
      I4 => \rgb_out[7]_i_60_n_0\,
      I5 => \rgb_out[7]_i_59_n_0\,
      O => \rgb_out[23]_i_80_n_0\
    );
\rgb_out[23]_i_81\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"E0FFE0E0"
    )
        port map (
      I0 => \rgb_out[23]_i_77_n_0\,
      I1 => \rgb_out[23]_i_250_n_0\,
      I2 => \rgb_out[7]_i_11_n_0\,
      I3 => \rgb_out[20]_i_9_n_0\,
      I4 => \rgb_out[23]_i_251_n_0\,
      O => \rgb_out[23]_i_81_n_0\
    );
\rgb_out[23]_i_82\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFE0E0E0"
    )
        port map (
      I0 => \rgb_out[20]_i_12_n_0\,
      I1 => \rgb_out[23]_i_142_n_0\,
      I2 => \rgb_out[23]_i_252_n_0\,
      I3 => \rgb_out[23]_i_253_n_0\,
      I4 => \rgb_out[23]_i_254_n_0\,
      O => \rgb_out[23]_i_82_n_0\
    );
\rgb_out[23]_i_83\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"4F4F4F44"
    )
        port map (
      I0 => \rgb_out[23]_i_231_n_0\,
      I1 => \rgb_out[23]_i_252_n_0\,
      I2 => \rgb_out[23]_i_36_n_0\,
      I3 => \rgb_out[23]_i_255_n_0\,
      I4 => \rgb_out[7]_i_62_n_0\,
      O => \rgb_out[23]_i_83_n_0\
    );
\rgb_out[23]_i_84\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFD0D0D0D0D0"
    )
        port map (
      I0 => \rgb_out[23]_i_256_n_0\,
      I1 => \rgb_out[23]_i_257_n_0\,
      I2 => \rgb_out[7]_i_56_n_0\,
      I3 => \rgb_out[20]_i_13_n_0\,
      I4 => \rgb_out[23]_i_244_n_0\,
      I5 => \rgb_out[23]_i_258_n_0\,
      O => \rgb_out[23]_i_84_n_0\
    );
\rgb_out[23]_i_85\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"F444F444FFFFF444"
    )
        port map (
      I0 => \rgb_out[23]_i_259_n_0\,
      I1 => \rgb_out[23]_i_260_n_0\,
      I2 => \rgb_out[23]_i_261_n_0\,
      I3 => \rgb_out[23]_i_262_n_0\,
      I4 => \rgb_out[23]_i_263_n_0\,
      I5 => \rgb_out[23]_i_150_n_0\,
      O => \rgb_out[23]_i_85_n_0\
    );
\rgb_out[23]_i_852\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => pixel_x(0),
      I1 => pixel_x(1),
      O => \rgb_out[23]_i_852_n_0\
    );
\rgb_out[23]_i_855\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => pixel_x(3),
      I1 => pixel_x(2),
      O => \rgb_out[23]_i_855_n_0\
    );
\rgb_out[23]_i_856\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => pixel_x(1),
      I1 => pixel_x(0),
      O => \rgb_out[23]_i_856_n_0\
    );
\rgb_out[23]_i_86\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"C4F4C4F4FFFFC4F4"
    )
        port map (
      I0 => \rgb_out[23]_i_181_n_0\,
      I1 => \rgb_out[23]_i_264_n_0\,
      I2 => \rgb_out[23]_i_227_n_0\,
      I3 => \rgb_out[23]_i_265_n_0\,
      I4 => \rgb_out[23]_i_232_n_0\,
      I5 => \rgb_out[23]_i_256_n_0\,
      O => \rgb_out[23]_i_86_n_0\
    );
\rgb_out[23]_i_87\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000000002"
    )
        port map (
      I0 => \rgb_out[23]_i_266_n_0\,
      I1 => \rgb_out[20]_i_17_n_0\,
      I2 => \rgb_out[23]_i_40_n_0\,
      I3 => \rgb_out[21]_i_6_n_0\,
      I4 => \rgb_out[23]_i_267_n_0\,
      I5 => pixel_y(4),
      O => \rgb_out[23]_i_87_n_0\
    );
\rgb_out[23]_i_88\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \rgb_out[23]_i_268_n_0\,
      I1 => \rgb_out[23]_i_261_n_0\,
      O => \rgb_out[23]_i_88_n_0\
    );
\rgb_out[23]_i_886\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => pixel_x(0),
      I1 => pixel_x(1),
      O => \rgb_out[23]_i_886_n_0\
    );
\rgb_out[23]_i_889\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => pixel_x(2),
      I1 => pixel_x(3),
      O => \rgb_out[23]_i_889_n_0\
    );
\rgb_out[23]_i_89\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFD0D0D0"
    )
        port map (
      I0 => \rgb_out[23]_i_268_n_0\,
      I1 => \rgb_out[23]_i_269_n_0\,
      I2 => \rgb_out[23]_i_145_n_0\,
      I3 => \rgb_out[23]_i_250_n_0\,
      I4 => \rgb_out[7]_i_19_n_0\,
      O => \rgb_out[23]_i_89_n_0\
    );
\rgb_out[23]_i_890\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => pixel_x(1),
      I1 => pixel_x(0),
      O => \rgb_out[23]_i_890_n_0\
    );
\rgb_out[23]_i_9\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000000054"
    )
        port map (
      I0 => \rgb_out[23]_i_20_n_0\,
      I1 => \rgb_out[23]_i_21_n_0\,
      I2 => \rgb_out[23]_i_22_n_0\,
      I3 => \rgb_out[23]_i_23_n_0\,
      I4 => \rgb_out[23]_i_24_n_0\,
      I5 => \rgb_out[23]_i_25_n_0\,
      O => \rgb_out[23]_i_9_n_0\
    );
\rgb_out[23]_i_90\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"111F1111111F111F"
    )
        port map (
      I0 => \rgb_out[23]_i_101_n_0\,
      I1 => \rgb_out[23]_i_270_n_0\,
      I2 => \rgb_out[23]_i_271_n_0\,
      I3 => \rgb_out[23]_i_272_n_0\,
      I4 => \rgb_out[23]_i_273_n_0\,
      I5 => \rgb_out[23]_i_274_n_0\,
      O => \rgb_out[23]_i_90_n_0\
    );
\rgb_out[23]_i_909\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00000001"
    )
        port map (
      I0 => pixel_x(6),
      I1 => pixel_x(3),
      I2 => pixel_x(4),
      I3 => pixel_x(9),
      I4 => pixel_x(5),
      O => \rgb_out[23]_i_909_n_0\
    );
\rgb_out[23]_i_91\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"F7F7F7F7F7F7F300"
    )
        port map (
      I0 => \rgb_out[23]_i_275_n_0\,
      I1 => \rgb_out[23]_i_276_n_0\,
      I2 => \rgb_out[23]_i_277_n_0\,
      I3 => \rgb_out[23]_i_278_n_0\,
      I4 => \rgb_out[23]_i_279_n_0\,
      I5 => \rgb_out[23]_i_280_n_0\,
      O => \rgb_out[23]_i_91_n_0\
    );
\rgb_out[23]_i_910\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"7FFF"
    )
        port map (
      I0 => pixel_x(2),
      I1 => pixel_x(3),
      I2 => pixel_x(10),
      I3 => pixel_x(7),
      O => \rgb_out[23]_i_910_n_0\
    );
\rgb_out[23]_i_911\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"F3F7F7F7"
    )
        port map (
      I0 => pixel_x(9),
      I1 => pixel_x(10),
      I2 => pixel_x(11),
      I3 => pixel_x(8),
      I4 => pixel_x(7),
      O => \rgb_out[23]_i_911_n_0\
    );
\rgb_out[23]_i_912\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00550057"
    )
        port map (
      I0 => pixel_x(7),
      I1 => pixel_x(5),
      I2 => pixel_x(4),
      I3 => pixel_x(9),
      I4 => pixel_x(6),
      O => \rgb_out[23]_i_912_n_0\
    );
\rgb_out[23]_i_913\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFFE"
    )
        port map (
      I0 => pixel_x(9),
      I1 => pixel_x(11),
      I2 => pixel_x(5),
      I3 => pixel_x(6),
      O => \rgb_out[23]_i_913_n_0\
    );
\rgb_out[23]_i_914\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"E0000000"
    )
        port map (
      I0 => pixel_x(5),
      I1 => pixel_x(6),
      I2 => pixel_x(10),
      I3 => pixel_x(7),
      I4 => pixel_x(8),
      O => \rgb_out[23]_i_914_n_0\
    );
\rgb_out[23]_i_915\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFF800000000000"
    )
        port map (
      I0 => pixel_y(2),
      I1 => pixel_y(3),
      I2 => pixel_y(0),
      I3 => pixel_y(1),
      I4 => pixel_y(4),
      I5 => pixel_y(5),
      O => \rgb_out[23]_i_915_n_0\
    );
\rgb_out[23]_i_916\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"EA7FFFFF"
    )
        port map (
      I0 => pixel_y(2),
      I1 => pixel_y(0),
      I2 => pixel_y(1),
      I3 => pixel_y(3),
      I4 => pixel_y(4),
      O => \rgb_out[23]_i_916_n_0\
    );
\rgb_out[23]_i_917\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFEFEFE"
    )
        port map (
      I0 => pixel_y(7),
      I1 => pixel_y(6),
      I2 => pixel_y(8),
      I3 => pixel_y(4),
      I4 => pixel_y(5),
      O => \rgb_out[23]_i_917_n_0\
    );
\rgb_out[23]_i_918\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"07"
    )
        port map (
      I0 => pixel_y(0),
      I1 => pixel_y(1),
      I2 => pixel_y(2),
      O => \rgb_out[23]_i_918_n_0\
    );
\rgb_out[23]_i_919\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"7FFFFFFF"
    )
        port map (
      I0 => pixel_x(3),
      I1 => pixel_x(2),
      I2 => pixel_x(8),
      I3 => pixel_x(10),
      I4 => pixel_x(5),
      O => \rgb_out[23]_i_919_n_0\
    );
\rgb_out[23]_i_92\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAA88A8AAAAAAAA"
    )
        port map (
      I0 => \rgb_out[23]_i_101_n_0\,
      I1 => \rgb_out[23]_i_281_n_0\,
      I2 => \rgb_out[23]_i_282_n_0\,
      I3 => \rgb_out[23]_i_283_n_0\,
      I4 => \rgb_out[23]_i_284_n_0\,
      I5 => \rgb_out[23]_i_114_n_0\,
      O => \rgb_out[23]_i_92_n_0\
    );
\rgb_out[23]_i_920\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"7"
    )
        port map (
      I0 => pixel_x(6),
      I1 => pixel_x(10),
      O => \rgb_out[23]_i_920_n_0\
    );
\rgb_out[23]_i_921\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => pixel_x(11),
      I1 => pixel_x(9),
      O => \rgb_out[23]_i_921_n_0\
    );
\rgb_out[23]_i_922\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"7FFF"
    )
        port map (
      I0 => pixel_x(8),
      I1 => pixel_x(6),
      I2 => pixel_x(10),
      I3 => pixel_x(7),
      O => \rgb_out[23]_i_922_n_0\
    );
\rgb_out[23]_i_923\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"88888000"
    )
        port map (
      I0 => pixel_y(4),
      I1 => pixel_y(3),
      I2 => pixel_y(0),
      I3 => pixel_y(1),
      I4 => pixel_y(2),
      O => \rgb_out[23]_i_923_n_0\
    );
\rgb_out[23]_i_924\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"80"
    )
        port map (
      I0 => pixel_y(5),
      I1 => pixel_y(0),
      I2 => pixel_y(1),
      O => \rgb_out[23]_i_924_n_0\
    );
\rgb_out[23]_i_925\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"AAA8"
    )
        port map (
      I0 => pixel_y(5),
      I1 => pixel_y(2),
      I2 => pixel_y(3),
      I3 => pixel_y(4),
      O => \rgb_out[23]_i_925_n_0\
    );
\rgb_out[23]_i_926\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"FE"
    )
        port map (
      I0 => pixel_x(8),
      I1 => pixel_x(9),
      I2 => pixel_x(11),
      O => \rgb_out[23]_i_926_n_0\
    );
\rgb_out[23]_i_93\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000BBBABABA"
    )
        port map (
      I0 => \rgb_out[21]_i_6_n_0\,
      I1 => \rgb_out[23]_i_40_n_0\,
      I2 => \rgb_out[23]_i_267_n_0\,
      I3 => pixel_y(4),
      I4 => \rgb_out[23]_i_237_n_0\,
      I5 => \rgb_out[23]_i_285_n_0\,
      O => \rgb_out[23]_i_93_n_0\
    );
\rgb_out[23]_i_94\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000000010"
    )
        port map (
      I0 => \rgb_out[23]_i_111_n_0\,
      I1 => \rgb_out[23]_i_286_n_0\,
      I2 => \rgb_out[23]_i_287_n_0\,
      I3 => \rgb_out[23]_i_288_n_0\,
      I4 => \rgb_out[23]_i_289_n_0\,
      I5 => \rgb_out[23]_i_290_n_0\,
      O => \rgb_out[23]_i_94_n_0\
    );
\rgb_out[23]_i_95\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFA8FCFCFCA8"
    )
        port map (
      I0 => \rgb_out[23]_i_115_n_0\,
      I1 => \rgb_out[23]_i_291_n_0\,
      I2 => \rgb_out[23]_i_292_n_0\,
      I3 => \rgb_out[23]_i_293_n_0\,
      I4 => \rgb_out[23]_i_93_n_0\,
      I5 => \rgb_out[23]_i_294_n_0\,
      O => \rgb_out[23]_i_95_n_0\
    );
\rgb_out[23]_i_96\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000888888808"
    )
        port map (
      I0 => \rgb_out[23]_i_295_n_0\,
      I1 => \rgb_out[23]_i_108_n_0\,
      I2 => \rgb_out[23]_i_296_n_0\,
      I3 => pixel_x(11),
      I4 => \rgb_out[23]_i_297_n_0\,
      I5 => \rgb_out[23]_i_298_n_0\,
      O => \rgb_out[23]_i_96_n_0\
    );
\rgb_out[23]_i_97\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \rgb_out[23]_i_115_n_0\,
      I1 => \rgb_out[23]_i_299_n_0\,
      O => \rgb_out[23]_i_97_n_0\
    );
\rgb_out[23]_i_98\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000000000000FB00"
    )
        port map (
      I0 => \rgb_out[23]_i_300_n_0\,
      I1 => pixel_x(2),
      I2 => \rgb_out[23]_i_301_n_0\,
      I3 => \rgb_out[23]_i_302_n_0\,
      I4 => \rgb_out[23]_i_303_n_0\,
      I5 => \rgb_out[23]_i_304_n_0\,
      O => \rgb_out[23]_i_98_n_0\
    );
\rgb_out[23]_i_99\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFF0C0A0000"
    )
        port map (
      I0 => \rgb_out[23]_i_222_n_0\,
      I1 => \rgb_out[23]_i_305_n_0\,
      I2 => \rgb_out[11]_i_29_n_0\,
      I3 => pixel_x(6),
      I4 => \rgb_out[23]_i_219_n_0\,
      I5 => \rgb_out[23]_i_294_n_0\,
      O => \rgb_out[23]_i_99_n_0\
    );
\rgb_out[2]_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D5"
    )
        port map (
      I0 => \rgb_out[16]_i_5_n_0\,
      I1 => rgb_in(2),
      I2 => is_pixel_mur,
      O => \rgb_out[2]_i_2_n_0\
    );
\rgb_out[2]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000040004040404"
    )
        port map (
      I0 => mode_ui(0),
      I1 => mode_ui(2),
      I2 => mode_ui(1),
      I3 => rgb_in(2),
      I4 => \rgb_out[23]_i_12_n_0\,
      I5 => \rgb_out[23]_i_11_n_0\,
      O => \rgb_out[2]_i_3_n_0\
    );
\rgb_out[2]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000810081818181"
    )
        port map (
      I0 => mode_ui(2),
      I1 => mode_ui(0),
      I2 => mode_ui(1),
      I3 => rgb_in(2),
      I4 => \rgb_out[11]_i_5_n_0\,
      I5 => \rgb_out[23]_i_9_n_0\,
      O => \rgb_out[2]_i_4_n_0\
    );
\rgb_out[5]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"BABBBBBBBBBBABAB"
    )
        port map (
      I0 => \rgb_out[21]_i_5_n_0\,
      I1 => is_pixel_mur,
      I2 => mode_ui(1),
      I3 => flash_on,
      I4 => mode_ui(0),
      I5 => mode_ui(2),
      O => \rgb_out[5]_i_2_n_0\
    );
\rgb_out[5]_i_3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFFBABB"
    )
        port map (
      I0 => \rgb_out[21]_i_4_n_0\,
      I1 => \rgb_out[17]_i_3_n_0\,
      I2 => rgb_in(5),
      I3 => \rgb_out[23]_i_10_n_0\,
      I4 => \rgb_out[1]_i_3_n_0\,
      O => \rgb_out[5]_i_3_n_0\
    );
\rgb_out[6]_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"8A"
    )
        port map (
      I0 => \rgb_out[16]_i_5_n_0\,
      I1 => rgb_in(6),
      I2 => is_pixel_mur,
      O => \rgb_out[6]_i_2_n_0\
    );
\rgb_out[6]_i_3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"BFBBAAAA"
    )
        port map (
      I0 => \rgb_out[1]_i_3_n_0\,
      I1 => \rgb_out[23]_i_11_n_0\,
      I2 => \rgb_out[23]_i_12_n_0\,
      I3 => rgb_in(6),
      I4 => \rgb_out[23]_i_13_n_0\,
      O => \rgb_out[6]_i_3_n_0\
    );
\rgb_out[6]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000810081818181"
    )
        port map (
      I0 => mode_ui(2),
      I1 => mode_ui(0),
      I2 => mode_ui(1),
      I3 => rgb_in(6),
      I4 => \rgb_out[11]_i_5_n_0\,
      I5 => \rgb_out[23]_i_9_n_0\,
      O => \rgb_out[6]_i_4_n_0\
    );
\rgb_out[7]_i_10\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFFEAA"
    )
        port map (
      I0 => pixel_x(3),
      I1 => pixel_x(0),
      I2 => pixel_x(1),
      I3 => pixel_x(2),
      I4 => \rgb_out[7]_i_25_n_0\,
      I5 => \rgb_out[7]_i_26_n_0\,
      O => \rgb_out[7]_i_10_n_0\
    );
\rgb_out[7]_i_11\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"BABABABAFFFF1030"
    )
        port map (
      I0 => \rgb_out[7]_i_27_n_0\,
      I1 => \rgb_out[7]_i_25_n_0\,
      I2 => \rgb_out[7]_i_26_n_0\,
      I3 => \rgb_out[7]_i_28_n_0\,
      I4 => \rgb_out[7]_i_29_n_0\,
      I5 => \rgb_out[7]_i_30_n_0\,
      O => \rgb_out[7]_i_11_n_0\
    );
\rgb_out[7]_i_12\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000040000000"
    )
        port map (
      I0 => \rgb_out[7]_i_31_n_0\,
      I1 => \rgb_out[7]_i_32_n_0\,
      I2 => pixel_y(3),
      I3 => pixel_y(5),
      I4 => pixel_y(4),
      I5 => \rgb_out[23]_i_40_n_0\,
      O => \rgb_out[7]_i_12_n_0\
    );
\rgb_out[7]_i_13\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"4040454440404044"
    )
        port map (
      I0 => \rgb_out[21]_i_6_n_0\,
      I1 => \rgb_out[7]_i_33_n_0\,
      I2 => \rgb_out[23]_i_40_n_0\,
      I3 => \rgb_out[7]_i_34_n_0\,
      I4 => pixel_y(6),
      I5 => \rgb_out[7]_i_35_n_0\,
      O => \rgb_out[7]_i_13_n_0\
    );
\rgb_out[7]_i_14\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000020200"
    )
        port map (
      I0 => \rgb_out[7]_i_36_n_0\,
      I1 => pixel_y(4),
      I2 => pixel_y(5),
      I3 => pixel_y(3),
      I4 => pixel_y(2),
      I5 => \rgb_out[7]_i_37_n_0\,
      O => \rgb_out[7]_i_14_n_0\
    );
\rgb_out[7]_i_15\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"1313131310101000"
    )
        port map (
      I0 => \rgb_out[7]_i_38_n_0\,
      I1 => \rgb_out[7]_i_39_n_0\,
      I2 => \rgb_out[20]_i_23_n_0\,
      I3 => pixel_x(6),
      I4 => pixel_x(7),
      I5 => \rgb_out[7]_i_40_n_0\,
      O => \rgb_out[7]_i_15_n_0\
    );
\rgb_out[7]_i_16\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFE2E2E2E2E2E2E2"
    )
        port map (
      I0 => \rgb_out[7]_i_41_n_0\,
      I1 => \rgb_out[7]_i_42_n_0\,
      I2 => \rgb_out[7]_i_43_n_0\,
      I3 => \rgb_out[7]_i_44_n_0\,
      I4 => \rgb_out[7]_i_45_n_0\,
      I5 => \rgb_out[7]_i_46_n_0\,
      O => \rgb_out[7]_i_16_n_0\
    );
\rgb_out[7]_i_17\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000000000000001F"
    )
        port map (
      I0 => \rgb_out[23]_i_184_n_0\,
      I1 => \rgb_out[23]_i_185_n_0\,
      I2 => \rgb_out[7]_i_14_n_0\,
      I3 => \rgb_out[23]_i_79_n_0\,
      I4 => \rgb_out[23]_i_129_n_0\,
      I5 => \rgb_out[7]_i_47_n_0\,
      O => \rgb_out[7]_i_17_n_0\
    );
\rgb_out[7]_i_18\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"DDD0DDDD"
    )
        port map (
      I0 => \rgb_out[7]_i_48_n_0\,
      I1 => \rgb_out[7]_i_24_n_0\,
      I2 => \rgb_out[7]_i_49_n_0\,
      I3 => \rgb_out[7]_i_50_n_0\,
      I4 => \rgb_out[23]_i_183_n_0\,
      O => \rgb_out[7]_i_18_n_0\
    );
\rgb_out[7]_i_19\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"DFFFFFFFDFD8D8D8"
    )
        port map (
      I0 => \rgb_out[7]_i_51_n_0\,
      I1 => \rgb_out[7]_i_52_n_0\,
      I2 => \rgb_out[7]_i_53_n_0\,
      I3 => \rgb_out[7]_i_54_n_0\,
      I4 => \rgb_out[20]_i_19_n_0\,
      I5 => \rgb_out[7]_i_55_n_0\,
      O => \rgb_out[7]_i_19_n_0\
    );
\rgb_out[7]_i_20\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"8A"
    )
        port map (
      I0 => \rgb_out[7]_i_56_n_0\,
      I1 => \rgb_out[7]_i_13_n_0\,
      I2 => \rgb_out[7]_i_48_n_0\,
      O => \rgb_out[7]_i_20_n_0\
    );
\rgb_out[7]_i_21\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFF4F0F0C0C4C0C0"
    )
        port map (
      I0 => \rgb_out[7]_i_57_n_0\,
      I1 => \rgb_out[7]_i_58_n_0\,
      I2 => \rgb_out[7]_i_47_n_0\,
      I3 => \rgb_out[7]_i_59_n_0\,
      I4 => \rgb_out[7]_i_60_n_0\,
      I5 => \rgb_out[7]_i_61_n_0\,
      O => \rgb_out[7]_i_21_n_0\
    );
\rgb_out[7]_i_22\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"0E"
    )
        port map (
      I0 => \rgb_out[7]_i_12_n_0\,
      I1 => \rgb_out[7]_i_24_n_0\,
      I2 => \rgb_out[23]_i_80_n_0\,
      O => \rgb_out[7]_i_22_n_0\
    );
\rgb_out[7]_i_23\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"A8AA"
    )
        port map (
      I0 => \rgb_out[7]_i_62_n_0\,
      I1 => \rgb_out[7]_i_12_n_0\,
      I2 => \rgb_out[7]_i_13_n_0\,
      I3 => \rgb_out[7]_i_48_n_0\,
      O => \rgb_out[7]_i_23_n_0\
    );
\rgb_out[7]_i_24\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"2222222220002020"
    )
        port map (
      I0 => \rgb_out[7]_i_32_n_0\,
      I1 => \rgb_out[7]_i_63_n_0\,
      I2 => \rgb_out[7]_i_64_n_0\,
      I3 => \rgb_out[7]_i_65_n_0\,
      I4 => \rgb_out[7]_i_66_n_0\,
      I5 => \rgb_out[21]_i_6_n_0\,
      O => \rgb_out[7]_i_24_n_0\
    );
\rgb_out[7]_i_25\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFFFF80"
    )
        port map (
      I0 => pixel_x(9),
      I1 => pixel_x(8),
      I2 => pixel_x(7),
      I3 => pixel_x(10),
      I4 => pixel_x(11),
      O => \rgb_out[7]_i_25_n_0\
    );
\rgb_out[7]_i_26\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"7FFFFFFF"
    )
        port map (
      I0 => pixel_x(9),
      I1 => pixel_x(8),
      I2 => pixel_x(5),
      I3 => pixel_x(4),
      I4 => pixel_x(6),
      O => \rgb_out[7]_i_26_n_0\
    );
\rgb_out[7]_i_27\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"02AA0AAA02AA02AA"
    )
        port map (
      I0 => \rgb_out[11]_i_11_n_0\,
      I1 => \rgb_out[23]_i_333_n_0\,
      I2 => pixel_x(7),
      I3 => \rgb_out[20]_i_23_n_0\,
      I4 => pixel_x(4),
      I5 => \rgb_out[7]_i_67_n_0\,
      O => \rgb_out[7]_i_27_n_0\
    );
\rgb_out[7]_i_28\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"F1FFFFFFFFFFFFFF"
    )
        port map (
      I0 => \rgb_out[23]_i_466_n_0\,
      I1 => pixel_x(2),
      I2 => \rgb_out[23]_i_353_n_0\,
      I3 => pixel_x(5),
      I4 => pixel_x(9),
      I5 => pixel_x(3),
      O => \rgb_out[7]_i_28_n_0\
    );
\rgb_out[7]_i_29\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"E0E0E0A0E0A0E0A0"
    )
        port map (
      I0 => pixel_x(7),
      I1 => pixel_x(6),
      I2 => \rgb_out[20]_i_23_n_0\,
      I3 => pixel_x(5),
      I4 => \rgb_out[23]_i_392_n_0\,
      I5 => pixel_x(2),
      O => \rgb_out[7]_i_29_n_0\
    );
\rgb_out[7]_i_30\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"E0E0E0C0FFFFFFFF"
    )
        port map (
      I0 => \rgb_out[23]_i_333_n_0\,
      I1 => pixel_x(7),
      I2 => \rgb_out[20]_i_23_n_0\,
      I3 => \rgb_out[11]_i_28_n_0\,
      I4 => pixel_x(0),
      I5 => \rgb_out[11]_i_11_n_0\,
      O => \rgb_out[7]_i_30_n_0\
    );
\rgb_out[7]_i_31\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000040404000"
    )
        port map (
      I0 => \rgb_out[20]_i_27_n_0\,
      I1 => pixel_y(2),
      I2 => pixel_y(3),
      I3 => pixel_y(1),
      I4 => pixel_y(0),
      I5 => \rgb_out[23]_i_40_n_0\,
      O => \rgb_out[7]_i_31_n_0\
    );
\rgb_out[7]_i_32\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0001010101010101"
    )
        port map (
      I0 => pixel_y(9),
      I1 => pixel_y(10),
      I2 => pixel_y(11),
      I3 => pixel_y(8),
      I4 => pixel_y(7),
      I5 => pixel_y(6),
      O => \rgb_out[7]_i_32_n_0\
    );
\rgb_out[7]_i_33\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FF00FFFFFF00FFA8"
    )
        port map (
      I0 => pixel_y(5),
      I1 => pixel_y(4),
      I2 => \rgb_out[20]_i_17_n_0\,
      I3 => \rgb_out[21]_i_6_n_0\,
      I4 => \rgb_out[23]_i_40_n_0\,
      I5 => pixel_y(6),
      O => \rgb_out[7]_i_33_n_0\
    );
\rgb_out[7]_i_34\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8888888088808880"
    )
        port map (
      I0 => pixel_y(4),
      I1 => pixel_y(5),
      I2 => pixel_y(3),
      I3 => pixel_y(2),
      I4 => pixel_y(0),
      I5 => pixel_y(1),
      O => \rgb_out[7]_i_34_n_0\
    );
\rgb_out[7]_i_35\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"7FFFFFFF"
    )
        port map (
      I0 => pixel_y(3),
      I1 => pixel_y(5),
      I2 => pixel_y(4),
      I3 => pixel_y(7),
      I4 => pixel_y(8),
      O => \rgb_out[7]_i_35_n_0\
    );
\rgb_out[7]_i_36\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000000080"
    )
        port map (
      I0 => pixel_y(6),
      I1 => pixel_y(7),
      I2 => pixel_y(8),
      I3 => pixel_y(9),
      I4 => pixel_y(10),
      I5 => pixel_y(11),
      O => \rgb_out[7]_i_36_n_0\
    );
\rgb_out[7]_i_37\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"7"
    )
        port map (
      I0 => pixel_y(1),
      I1 => pixel_y(0),
      O => \rgb_out[7]_i_37_n_0\
    );
\rgb_out[7]_i_38\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"AAAAAAA8"
    )
        port map (
      I0 => pixel_x(6),
      I1 => pixel_x(5),
      I2 => pixel_x(4),
      I3 => pixel_x(3),
      I4 => pixel_x(2),
      O => \rgb_out[7]_i_38_n_0\
    );
\rgb_out[7]_i_39\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"C8FFC0FFC0FFC0FF"
    )
        port map (
      I0 => pixel_x(6),
      I1 => \rgb_out[20]_i_23_n_0\,
      I2 => pixel_x(7),
      I3 => \rgb_out[11]_i_11_n_0\,
      I4 => pixel_x(0),
      I5 => pixel_x(1),
      O => \rgb_out[7]_i_39_n_0\
    );
\rgb_out[7]_i_4\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"55D5"
    )
        port map (
      I0 => \rgb_out[7]_i_9_n_0\,
      I1 => \rgb_out[23]_i_21_n_0\,
      I2 => \rgb_out[7]_i_10_n_0\,
      I3 => \rgb_out[7]_i_11_n_0\,
      O => \rgb_out[7]_i_4_n_0\
    );
\rgb_out[7]_i_40\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"4000000000000000"
    )
        port map (
      I0 => \rgb_out[23]_i_223_n_0\,
      I1 => pixel_x(5),
      I2 => pixel_x(8),
      I3 => pixel_x(4),
      I4 => pixel_x(9),
      I5 => pixel_x(3),
      O => \rgb_out[7]_i_40_n_0\
    );
\rgb_out[7]_i_41\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"A8A8A8A8A0A8A8A8"
    )
        port map (
      I0 => \rgb_out[20]_i_23_n_0\,
      I1 => pixel_x(6),
      I2 => pixel_x(7),
      I3 => \rgb_out[20]_i_25_n_0\,
      I4 => \rgb_out[23]_i_334_n_0\,
      I5 => \rgb_out[23]_i_466_n_0\,
      O => \rgb_out[7]_i_41_n_0\
    );
\rgb_out[7]_i_42\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAAFFFF8088FFFF"
    )
        port map (
      I0 => \rgb_out[20]_i_23_n_0\,
      I1 => pixel_x(6),
      I2 => pixel_x(3),
      I3 => \rgb_out[20]_i_25_n_0\,
      I4 => \rgb_out[11]_i_11_n_0\,
      I5 => pixel_x(7),
      O => \rgb_out[7]_i_42_n_0\
    );
\rgb_out[7]_i_43\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAAAAAA8AAAAAAA"
    )
        port map (
      I0 => \rgb_out[7]_i_68_n_0\,
      I1 => \rgb_out[23]_i_353_n_0\,
      I2 => pixel_x(3),
      I3 => pixel_x(9),
      I4 => pixel_x(2),
      I5 => \rgb_out[23]_i_370_n_0\,
      O => \rgb_out[7]_i_43_n_0\
    );
\rgb_out[7]_i_44\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAAAAAAAABBAABF"
    )
        port map (
      I0 => \rgb_out[7]_i_69_n_0\,
      I1 => pixel_x(4),
      I2 => pixel_x(3),
      I3 => pixel_x(7),
      I4 => \rgb_out[11]_i_22_n_0\,
      I5 => \rgb_out[23]_i_333_n_0\,
      O => \rgb_out[7]_i_44_n_0\
    );
\rgb_out[7]_i_45\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FF00FF00FE000000"
    )
        port map (
      I0 => pixel_x(5),
      I1 => pixel_x(4),
      I2 => \rgb_out[23]_i_346_n_0\,
      I3 => \rgb_out[20]_i_23_n_0\,
      I4 => pixel_x(6),
      I5 => pixel_x(7),
      O => \rgb_out[7]_i_45_n_0\
    );
\rgb_out[7]_i_46\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAAAAAAAAAAAAA8"
    )
        port map (
      I0 => \rgb_out[11]_i_11_n_0\,
      I1 => pixel_x(7),
      I2 => pixel_x(4),
      I3 => pixel_x(5),
      I4 => pixel_x(0),
      I5 => pixel_x(1),
      O => \rgb_out[7]_i_46_n_0\
    );
\rgb_out[7]_i_47\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000040400040"
    )
        port map (
      I0 => \rgb_out[23]_i_249_n_0\,
      I1 => pixel_x(9),
      I2 => \rgb_out[11]_i_21_n_0\,
      I3 => \rgb_out[7]_i_70_n_0\,
      I4 => \rgb_out[23]_i_235_n_0\,
      I5 => \rgb_out[7]_i_60_n_0\,
      O => \rgb_out[7]_i_47_n_0\
    );
\rgb_out[7]_i_48\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000F20DFF"
    )
        port map (
      I0 => pixel_y(6),
      I1 => \rgb_out[23]_i_40_n_0\,
      I2 => \rgb_out[21]_i_6_n_0\,
      I3 => \rgb_out[7]_i_71_n_0\,
      I4 => \rgb_out[7]_i_31_n_0\,
      I5 => \rgb_out[7]_i_58_n_0\,
      O => \rgb_out[7]_i_48_n_0\
    );
\rgb_out[7]_i_49\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0888088808888888"
    )
        port map (
      I0 => \rgb_out[7]_i_72_n_0\,
      I1 => \rgb_out[7]_i_73_n_0\,
      I2 => \rgb_out[20]_i_23_n_0\,
      I3 => \rgb_out[23]_i_222_n_0\,
      I4 => \rgb_out[11]_i_22_n_0\,
      I5 => pixel_x(0),
      O => \rgb_out[7]_i_49_n_0\
    );
\rgb_out[7]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FEFEEEEEFEF00000"
    )
        port map (
      I0 => \rgb_out[7]_i_9_n_0\,
      I1 => \rgb_out[7]_i_12_n_0\,
      I2 => \rgb_out[7]_i_13_n_0\,
      I3 => \rgb_out[7]_i_14_n_0\,
      I4 => \rgb_out[7]_i_15_n_0\,
      I5 => \rgb_out[7]_i_16_n_0\,
      O => \rgb_out[7]_i_5_n_0\
    );
\rgb_out[7]_i_50\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8088888888888888"
    )
        port map (
      I0 => \rgb_out[7]_i_74_n_0\,
      I1 => \rgb_out[7]_i_75_n_0\,
      I2 => \rgb_out[23]_i_223_n_0\,
      I3 => \rgb_out[7]_i_76_n_0\,
      I4 => \rgb_out[20]_i_23_n_0\,
      I5 => pixel_x(0),
      O => \rgb_out[7]_i_50_n_0\
    );
\rgb_out[7]_i_51\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00570057FFFF0057"
    )
        port map (
      I0 => pixel_x(3),
      I1 => \rgb_out[11]_i_22_n_0\,
      I2 => pixel_x(0),
      I3 => \rgb_out[7]_i_77_n_0\,
      I4 => \rgb_out[20]_i_19_n_0\,
      I5 => \rgb_out[23]_i_245_n_0\,
      O => \rgb_out[7]_i_51_n_0\
    );
\rgb_out[7]_i_52\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FF00FFFF4000FFFF"
    )
        port map (
      I0 => \rgb_out[23]_i_307_n_0\,
      I1 => \rgb_out[11]_i_21_n_0\,
      I2 => pixel_x(5),
      I3 => pixel_x(9),
      I4 => \rgb_out[11]_i_11_n_0\,
      I5 => pixel_x(8),
      O => \rgb_out[7]_i_52_n_0\
    );
\rgb_out[7]_i_53\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"222A22AA22AA22AA"
    )
        port map (
      I0 => \rgb_out[20]_i_19_n_0\,
      I1 => \rgb_out[23]_i_245_n_0\,
      I2 => pixel_x(3),
      I3 => pixel_x(4),
      I4 => pixel_x(1),
      I5 => pixel_x(2),
      O => \rgb_out[7]_i_53_n_0\
    );
\rgb_out[7]_i_54\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"F7FFFFFFF7F7F7F7"
    )
        port map (
      I0 => pixel_x(9),
      I1 => \rgb_out[11]_i_21_n_0\,
      I2 => \rgb_out[23]_i_233_n_0\,
      I3 => pixel_x(0),
      I4 => pixel_x(1),
      I5 => \rgb_out[23]_i_334_n_0\,
      O => \rgb_out[7]_i_54_n_0\
    );
\rgb_out[7]_i_55\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"2AAAAAAAAAAAAAAA"
    )
        port map (
      I0 => \rgb_out[20]_i_19_n_0\,
      I1 => pixel_x(9),
      I2 => pixel_x(5),
      I3 => \rgb_out[11]_i_21_n_0\,
      I4 => pixel_x(3),
      I5 => pixel_x(4),
      O => \rgb_out[7]_i_55_n_0\
    );
\rgb_out[7]_i_56\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0003000000020002"
    )
        port map (
      I0 => pixel_x(2),
      I1 => \rgb_out[7]_i_78_n_0\,
      I2 => pixel_x(4),
      I3 => \rgb_out[23]_i_235_n_0\,
      I4 => \rgb_out[7]_i_79_n_0\,
      I5 => pixel_x(3),
      O => \rgb_out[7]_i_56_n_0\
    );
\rgb_out[7]_i_57\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"F3333333F3B33333"
    )
        port map (
      I0 => pixel_x(4),
      I1 => \rgb_out[20]_i_19_n_0\,
      I2 => pixel_x(9),
      I3 => pixel_x(5),
      I4 => \rgb_out[11]_i_21_n_0\,
      I5 => \rgb_out[7]_i_80_n_0\,
      O => \rgb_out[7]_i_57_n_0\
    );
\rgb_out[7]_i_58\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"004400CC00CC00C0"
    )
        port map (
      I0 => pixel_y(0),
      I1 => \rgb_out[7]_i_36_n_0\,
      I2 => \rgb_out[21]_i_6_n_0\,
      I3 => \rgb_out[7]_i_81_n_0\,
      I4 => pixel_y(2),
      I5 => pixel_y(1),
      O => \rgb_out[7]_i_58_n_0\
    );
\rgb_out[7]_i_59\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000000057"
    )
        port map (
      I0 => pixel_x(2),
      I1 => pixel_x(1),
      I2 => pixel_x(0),
      I3 => pixel_x(3),
      I4 => \rgb_out[23]_i_235_n_0\,
      I5 => pixel_x(5),
      O => \rgb_out[7]_i_59_n_0\
    );
\rgb_out[7]_i_6\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFFF0FE"
    )
        port map (
      I0 => \rgb_out[7]_i_14_n_0\,
      I1 => \rgb_out[7]_i_13_n_0\,
      I2 => \rgb_out[23]_i_52_n_0\,
      I3 => \rgb_out[7]_i_17_n_0\,
      I4 => \rgb_out[7]_i_18_n_0\,
      O => \rgb_out[7]_i_6_n_0\
    );
\rgb_out[7]_i_60\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"C0800000FFFFFFFF"
    )
        port map (
      I0 => pixel_x(4),
      I1 => pixel_x(7),
      I2 => pixel_x(6),
      I3 => pixel_x(5),
      I4 => pixel_x(9),
      I5 => \rgb_out[20]_i_19_n_0\,
      O => \rgb_out[7]_i_60_n_0\
    );
\rgb_out[7]_i_61\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00F000F000F04444"
    )
        port map (
      I0 => \rgb_out[7]_i_82_n_0\,
      I1 => \rgb_out[7]_i_83_n_0\,
      I2 => \rgb_out[23]_i_137_n_0\,
      I3 => \rgb_out[23]_i_41_n_0\,
      I4 => \rgb_out[21]_i_6_n_0\,
      I5 => \rgb_out[7]_i_84_n_0\,
      O => \rgb_out[7]_i_61_n_0\
    );
\rgb_out[7]_i_62\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000000000000AA2A"
    )
        port map (
      I0 => \rgb_out[7]_i_28_n_0\,
      I1 => pixel_x(6),
      I2 => pixel_x(4),
      I3 => \rgb_out[7]_i_85_n_0\,
      I4 => \rgb_out[7]_i_25_n_0\,
      I5 => \rgb_out[7]_i_27_n_0\,
      O => \rgb_out[7]_i_62_n_0\
    );
\rgb_out[7]_i_63\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"EAAA"
    )
        port map (
      I0 => pixel_y(4),
      I1 => pixel_y(2),
      I2 => pixel_y(3),
      I3 => pixel_y(1),
      O => \rgb_out[7]_i_63_n_0\
    );
\rgb_out[7]_i_64\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"E000"
    )
        port map (
      I0 => pixel_y(5),
      I1 => pixel_y(6),
      I2 => pixel_y(7),
      I3 => pixel_y(8),
      O => \rgb_out[7]_i_64_n_0\
    );
\rgb_out[7]_i_65\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"EA"
    )
        port map (
      I0 => pixel_y(6),
      I1 => pixel_y(4),
      I2 => pixel_y(5),
      O => \rgb_out[7]_i_65_n_0\
    );
\rgb_out[7]_i_66\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"5557"
    )
        port map (
      I0 => pixel_y(3),
      I1 => pixel_y(2),
      I2 => pixel_y(1),
      I3 => pixel_y(0),
      O => \rgb_out[7]_i_66_n_0\
    );
\rgb_out[7]_i_67\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"07"
    )
        port map (
      I0 => pixel_x(2),
      I1 => pixel_x(1),
      I2 => pixel_x(3),
      O => \rgb_out[7]_i_67_n_0\
    );
\rgb_out[7]_i_68\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000101010101"
    )
        port map (
      I0 => pixel_x(7),
      I1 => pixel_x(11),
      I2 => pixel_x(10),
      I3 => pixel_x(5),
      I4 => pixel_x(4),
      I5 => pixel_x(6),
      O => \rgb_out[7]_i_68_n_0\
    );
\rgb_out[7]_i_69\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"1FFF"
    )
        port map (
      I0 => pixel_x(7),
      I1 => pixel_x(6),
      I2 => pixel_x(8),
      I3 => pixel_x(9),
      O => \rgb_out[7]_i_69_n_0\
    );
\rgb_out[7]_i_7\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFFFF8"
    )
        port map (
      I0 => \rgb_out[7]_i_12_n_0\,
      I1 => \rgb_out[7]_i_19_n_0\,
      I2 => \rgb_out[7]_i_20_n_0\,
      I3 => \rgb_out[7]_i_21_n_0\,
      I4 => \rgb_out[7]_i_22_n_0\,
      I5 => \rgb_out[7]_i_23_n_0\,
      O => \rgb_out[7]_i_7_n_0\
    );
\rgb_out[7]_i_70\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00000111"
    )
        port map (
      I0 => pixel_x(4),
      I1 => pixel_x(5),
      I2 => pixel_x(2),
      I3 => pixel_x(1),
      I4 => pixel_x(3),
      O => \rgb_out[7]_i_70_n_0\
    );
\rgb_out[7]_i_71\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000000001"
    )
        port map (
      I0 => pixel_y(1),
      I1 => pixel_y(2),
      I2 => pixel_y(3),
      I3 => pixel_y(4),
      I4 => pixel_y(5),
      I5 => \rgb_out[21]_i_6_n_0\,
      O => \rgb_out[7]_i_71_n_0\
    );
\rgb_out[7]_i_72\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FEAAAAAAAAAAAAAA"
    )
        port map (
      I0 => \rgb_out[23]_i_394_n_0\,
      I1 => pixel_x(2),
      I2 => pixel_x(3),
      I3 => pixel_x(4),
      I4 => pixel_x(5),
      I5 => \rgb_out[20]_i_23_n_0\,
      O => \rgb_out[7]_i_72_n_0\
    );
\rgb_out[7]_i_73\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000001FFF"
    )
        port map (
      I0 => pixel_x(7),
      I1 => pixel_x(6),
      I2 => pixel_x(9),
      I3 => pixel_x(8),
      I4 => pixel_x(11),
      I5 => pixel_x(10),
      O => \rgb_out[7]_i_73_n_0\
    );
\rgb_out[7]_i_74\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0100000000000000"
    )
        port map (
      I0 => \rgb_out[23]_i_392_n_0\,
      I1 => pixel_x(5),
      I2 => pixel_x(7),
      I3 => pixel_x(6),
      I4 => \rgb_out[20]_i_23_n_0\,
      I5 => \rgb_out[11]_i_11_n_0\,
      O => \rgb_out[7]_i_74_n_0\
    );
\rgb_out[7]_i_75\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFD0FF"
    )
        port map (
      I0 => \rgb_out[23]_i_334_n_0\,
      I1 => pixel_x(1),
      I2 => pixel_x(4),
      I3 => \rgb_out[11]_i_11_n_0\,
      I4 => pixel_x(5),
      I5 => pixel_x(7),
      O => \rgb_out[7]_i_75_n_0\
    );
\rgb_out[7]_i_76\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => pixel_x(6),
      I1 => pixel_x(4),
      O => \rgb_out[7]_i_76_n_0\
    );
\rgb_out[7]_i_77\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFFE"
    )
        port map (
      I0 => pixel_x(4),
      I1 => pixel_x(11),
      I2 => pixel_x(10),
      I3 => pixel_x(8),
      O => \rgb_out[7]_i_77_n_0\
    );
\rgb_out[7]_i_78\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0C4C4C4C4C4C4C4C"
    )
        port map (
      I0 => pixel_x(8),
      I1 => \rgb_out[11]_i_11_n_0\,
      I2 => pixel_x(9),
      I3 => pixel_x(5),
      I4 => pixel_x(6),
      I5 => pixel_x(7),
      O => \rgb_out[7]_i_78_n_0\
    );
\rgb_out[7]_i_79\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"01"
    )
        port map (
      I0 => pixel_x(0),
      I1 => pixel_x(2),
      I2 => pixel_x(1),
      O => \rgb_out[7]_i_79_n_0\
    );
\rgb_out[7]_i_8\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"08"
    )
        port map (
      I0 => mode_ui(1),
      I1 => mode_ui(0),
      I2 => mode_ui(2),
      O => \rgb_out[7]_i_8_n_0\
    );
\rgb_out[7]_i_80\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"57"
    )
        port map (
      I0 => pixel_x(3),
      I1 => pixel_x(2),
      I2 => pixel_x(1),
      O => \rgb_out[7]_i_80_n_0\
    );
\rgb_out[7]_i_81\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"FE"
    )
        port map (
      I0 => pixel_y(3),
      I1 => pixel_y(4),
      I2 => pixel_y(5),
      O => \rgb_out[7]_i_81_n_0\
    );
\rgb_out[7]_i_82\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"777F"
    )
        port map (
      I0 => pixel_y(7),
      I1 => pixel_y(8),
      I2 => pixel_y(0),
      I3 => pixel_y(1),
      O => \rgb_out[7]_i_82_n_0\
    );
\rgb_out[7]_i_83\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"8000"
    )
        port map (
      I0 => pixel_y(3),
      I1 => pixel_y(2),
      I2 => pixel_y(4),
      I3 => pixel_y(5),
      O => \rgb_out[7]_i_83_n_0\
    );
\rgb_out[7]_i_84\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"80"
    )
        port map (
      I0 => pixel_y(6),
      I1 => pixel_y(7),
      I2 => pixel_y(8),
      O => \rgb_out[7]_i_84_n_0\
    );
\rgb_out[7]_i_85\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"7F"
    )
        port map (
      I0 => pixel_x(5),
      I1 => pixel_x(8),
      I2 => pixel_x(9),
      O => \rgb_out[7]_i_85_n_0\
    );
\rgb_out[7]_i_9\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \rgb_out[7]_i_24_n_0\,
      I1 => \rgb_out[7]_i_14_n_0\,
      O => \rgb_out[7]_i_9_n_0\
    );
\rgb_out[8]_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"8A"
    )
        port map (
      I0 => \rgb_out[15]_i_5_n_0\,
      I1 => rgb_in(8),
      I2 => is_pixel_mur,
      O => \rgb_out[8]_i_2_n_0\
    );
\rgb_out[8]_i_3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"BFBBAAAA"
    )
        port map (
      I0 => \rgb_out[1]_i_3_n_0\,
      I1 => \rgb_out[23]_i_11_n_0\,
      I2 => \rgb_out[23]_i_12_n_0\,
      I3 => rgb_in(8),
      I4 => \rgb_out[23]_i_13_n_0\,
      O => \rgb_out[8]_i_3_n_0\
    );
\rgb_out[8]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000810081818181"
    )
        port map (
      I0 => mode_ui(2),
      I1 => mode_ui(0),
      I2 => mode_ui(1),
      I3 => rgb_in(8),
      I4 => \rgb_out[11]_i_5_n_0\,
      I5 => \rgb_out[23]_i_9_n_0\,
      O => \rgb_out[8]_i_4_n_0\
    );
\rgb_out_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => pixel_clk,
      CE => '1',
      D => TM_U_n_24,
      Q => rgb_out(0),
      R => \rgb_out[23]_i_1_n_0\
    );
\rgb_out_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => pixel_clk,
      CE => '1',
      D => TM_U_n_14,
      Q => rgb_out(10),
      R => \rgb_out[23]_i_1_n_0\
    );
\rgb_out_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => pixel_clk,
      CE => '1',
      D => TM_U_n_13,
      Q => rgb_out(11),
      R => \rgb_out[23]_i_1_n_0\
    );
\rgb_out_reg[12]\: unisim.vcomponents.FDRE
     port map (
      C => pixel_clk,
      CE => '1',
      D => TM_U_n_12,
      Q => rgb_out(12),
      R => \rgb_out[23]_i_1_n_0\
    );
\rgb_out_reg[13]\: unisim.vcomponents.FDRE
     port map (
      C => pixel_clk,
      CE => '1',
      D => TM_U_n_11,
      Q => rgb_out(13),
      R => \rgb_out[23]_i_1_n_0\
    );
\rgb_out_reg[14]\: unisim.vcomponents.FDRE
     port map (
      C => pixel_clk,
      CE => '1',
      D => TM_U_n_10,
      Q => rgb_out(14),
      R => \rgb_out[23]_i_1_n_0\
    );
\rgb_out_reg[15]\: unisim.vcomponents.FDRE
     port map (
      C => pixel_clk,
      CE => '1',
      D => TM_U_n_9,
      Q => rgb_out(15),
      R => \rgb_out[23]_i_1_n_0\
    );
\rgb_out_reg[16]\: unisim.vcomponents.FDRE
     port map (
      C => pixel_clk,
      CE => '1',
      D => TM_U_n_8,
      Q => rgb_out(16),
      R => \rgb_out[23]_i_1_n_0\
    );
\rgb_out_reg[17]\: unisim.vcomponents.FDRE
     port map (
      C => pixel_clk,
      CE => '1',
      D => TM_U_n_7,
      Q => rgb_out(17),
      R => \rgb_out[23]_i_1_n_0\
    );
\rgb_out_reg[18]\: unisim.vcomponents.FDRE
     port map (
      C => pixel_clk,
      CE => '1',
      D => TM_U_n_6,
      Q => rgb_out(18),
      R => \rgb_out[23]_i_1_n_0\
    );
\rgb_out_reg[19]\: unisim.vcomponents.FDRE
     port map (
      C => pixel_clk,
      CE => '1',
      D => TM_U_n_5,
      Q => rgb_out(19),
      R => \rgb_out[23]_i_1_n_0\
    );
\rgb_out_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => pixel_clk,
      CE => '1',
      D => TM_U_n_23,
      Q => rgb_out(1),
      R => \rgb_out[23]_i_1_n_0\
    );
\rgb_out_reg[20]\: unisim.vcomponents.FDRE
     port map (
      C => pixel_clk,
      CE => '1',
      D => TM_U_n_4,
      Q => rgb_out(20),
      R => \rgb_out[23]_i_1_n_0\
    );
\rgb_out_reg[21]\: unisim.vcomponents.FDRE
     port map (
      C => pixel_clk,
      CE => '1',
      D => TM_U_n_3,
      Q => rgb_out(21),
      R => \rgb_out[23]_i_1_n_0\
    );
\rgb_out_reg[22]\: unisim.vcomponents.FDRE
     port map (
      C => pixel_clk,
      CE => '1',
      D => TM_U_n_2,
      Q => rgb_out(22),
      R => \rgb_out[23]_i_1_n_0\
    );
\rgb_out_reg[23]\: unisim.vcomponents.FDRE
     port map (
      C => pixel_clk,
      CE => '1',
      D => TM_U_n_1,
      Q => rgb_out(23),
      R => \rgb_out[23]_i_1_n_0\
    );
\rgb_out_reg[23]_i_1253\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_1253_n_0\,
      CO(2) => \rgb_out_reg[23]_i_1253_n_1\,
      CO(1) => \rgb_out_reg[23]_i_1253_n_2\,
      CO(0) => \rgb_out_reg[23]_i_1253_n_3\,
      CYINIT => '1',
      DI(3) => \rgb_out[23]_i_1928_n_0\,
      DI(2) => \rgb_out[23]_i_1929_n_0\,
      DI(1) => local_x_0(3),
      DI(0) => \rgb_out[23]_i_1930_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_1253_O_UNCONNECTED\(3 downto 0),
      S(3) => \rgb_out[23]_i_1931_n_0\,
      S(2) => \rgb_out[23]_i_1932_n_0\,
      S(1) => \rgb_out[23]_i_1933_n_0\,
      S(0) => \rgb_out[23]_i_1934_n_0\
    );
\rgb_out_reg[23]_i_1300\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_1998_n_0\,
      CO(3) => \^rgb_out_reg[0]_0\(0),
      CO(2) => \NLW_rgb_out_reg[23]_i_1300_CO_UNCONNECTED\(2),
      CO(1) => \rgb_out_reg[23]_i_1300_n_2\,
      CO(0) => \rgb_out_reg[23]_i_1300_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2 downto 0) => pixel_y(11 downto 9),
      O(3) => \NLW_rgb_out_reg[23]_i_1300_O_UNCONNECTED\(3),
      O(2 downto 0) => \^local_y\(10 downto 8),
      S(3) => '1',
      S(2) => \rgb_out[23]_i_1999_n_0\,
      S(1) => \rgb_out[23]_i_2000_n_0\,
      S(0) => \rgb_out[23]_i_2001_n_0\
    );
\rgb_out_reg[23]_i_1308\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_1308_n_0\,
      CO(2) => \rgb_out_reg[23]_i_1308_n_1\,
      CO(1) => \rgb_out_reg[23]_i_1308_n_2\,
      CO(0) => \rgb_out_reg[23]_i_1308_n_3\,
      CYINIT => '1',
      DI(3) => \rgb_out[23]_i_2009_n_0\,
      DI(2) => \rgb_out[23]_i_2010_n_0\,
      DI(1) => local_x(3),
      DI(0) => \rgb_out[23]_i_2012_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_1308_O_UNCONNECTED\(3 downto 0),
      S(3) => \rgb_out[23]_i_2013_n_0\,
      S(2) => \rgb_out[23]_i_2014_n_0\,
      S(1) => \rgb_out[23]_i_2015_n_0\,
      S(0) => \rgb_out[23]_i_2016_n_0\
    );
\rgb_out_reg[23]_i_1317\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_1317_n_0\,
      CO(2) => \rgb_out_reg[23]_i_1317_n_1\,
      CO(1) => \rgb_out_reg[23]_i_1317_n_2\,
      CO(0) => \rgb_out_reg[23]_i_1317_n_3\,
      CYINIT => '1',
      DI(3) => \rgb_out[23]_i_2024_n_0\,
      DI(2) => \rgb_out[23]_i_2025_n_0\,
      DI(1) => \^local_y\(2),
      DI(0) => \rgb_out[23]_i_2026_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_1317_O_UNCONNECTED\(3 downto 0),
      S(3) => \rgb_out[23]_i_2027_n_0\,
      S(2) => \rgb_out[23]_i_2028_n_0\,
      S(1) => \rgb_out[23]_i_2029_n_0\,
      S(0) => \rgb_out[23]_i_2030_n_0\
    );
\rgb_out_reg[23]_i_1322\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_1322_n_0\,
      CO(2) => \rgb_out_reg[23]_i_1322_n_1\,
      CO(1) => \rgb_out_reg[23]_i_1322_n_2\,
      CO(0) => \rgb_out_reg[23]_i_1322_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \rgb_out[23]_i_2031_n_0\,
      DI(1) => \rgb_out[23]_i_2032_n_0\,
      DI(0) => \rgb_out[23]_i_2033_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_1322_O_UNCONNECTED\(3 downto 0),
      S(3) => \rgb_out[23]_i_2034_n_0\,
      S(2) => \rgb_out[23]_i_2035_n_0\,
      S(1) => \rgb_out[23]_i_2036_n_0\,
      S(0) => \rgb_out[23]_i_2037_n_0\
    );
\rgb_out_reg[23]_i_1331\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_1331_n_0\,
      CO(2) => \rgb_out_reg[23]_i_1331_n_1\,
      CO(1) => \rgb_out_reg[23]_i_1331_n_2\,
      CO(0) => \rgb_out_reg[23]_i_1331_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \rgb_out[23]_i_2044_n_0\,
      DI(1) => \rgb_out[23]_i_2045_n_0\,
      DI(0) => \rgb_out[23]_i_2046_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_1331_O_UNCONNECTED\(3 downto 0),
      S(3) => \rgb_out[23]_i_2047_n_0\,
      S(2) => \rgb_out[23]_i_2048_n_0\,
      S(1) => \rgb_out[23]_i_2049_n_0\,
      S(0) => \rgb_out[23]_i_2050_n_0\
    );
\rgb_out_reg[23]_i_1998\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_2003_n_0\,
      CO(3) => \rgb_out_reg[23]_i_1998_n_0\,
      CO(2) => \rgb_out_reg[23]_i_1998_n_1\,
      CO(1) => \rgb_out_reg[23]_i_1998_n_2\,
      CO(0) => \rgb_out_reg[23]_i_1998_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => pixel_y(8 downto 5),
      O(3 downto 0) => \^local_y\(7 downto 4),
      S(3) => \rgb_out[23]_i_2125_n_0\,
      S(2) => \rgb_out[23]_i_2126_n_0\,
      S(1) => \rgb_out[23]_i_2127_n_0\,
      S(0) => \rgb_out[23]_i_2128_n_0\
    );
\rgb_out_reg[23]_i_2003\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_2003_n_0\,
      CO(2) => \rgb_out_reg[23]_i_2003_n_1\,
      CO(1) => \rgb_out_reg[23]_i_2003_n_2\,
      CO(0) => \rgb_out_reg[23]_i_2003_n_3\,
      CYINIT => '0',
      DI(3) => pixel_y(4),
      DI(2) => '0',
      DI(1) => pixel_y(2),
      DI(0) => '0',
      O(3 downto 0) => \^local_y\(3 downto 0),
      S(3) => \rgb_out[23]_i_2129_n_0\,
      S(2) => pixel_y(3),
      S(1) => \rgb_out[23]_i_2130_n_0\,
      S(0) => pixel_y(1)
    );
\rgb_out_reg[23]_i_472\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_787_n_0\,
      CO(3) => \NLW_rgb_out_reg[23]_i_472_CO_UNCONNECTED\(3),
      CO(2) => \TM_D/pixel_on9\,
      CO(1) => \rgb_out_reg[23]_i_472_n_2\,
      CO(0) => \rgb_out_reg[23]_i_472_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \rgb_out[23]_i_788_n_0\,
      DI(0) => \rgb_out[23]_i_789_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_472_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \pixel_x[3]_3\(0),
      S(1) => \rgb_out[23]_i_790_n_0\,
      S(0) => \rgb_out[23]_i_791_n_0\
    );
\rgb_out_reg[23]_i_733\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_1253_n_0\,
      CO(3) => \NLW_rgb_out_reg[23]_i_733_CO_UNCONNECTED\(3),
      CO(2) => \SC_U/pixel_on9\,
      CO(1) => \rgb_out_reg[23]_i_733_n_2\,
      CO(0) => \rgb_out_reg[23]_i_733_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \rgb_out[23]_i_1254_n_0\,
      DI(0) => \rgb_out[23]_i_1255_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_733_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \pixel_x[1]_8\(0),
      S(1) => \rgb_out[23]_i_1256_n_0\,
      S(0) => \rgb_out[23]_i_1257_n_0\
    );
\rgb_out_reg[23]_i_752\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_1308_n_0\,
      CO(3) => \NLW_rgb_out_reg[23]_i_752_CO_UNCONNECTED\(3),
      CO(2) => \SC_D/pixel_on9\,
      CO(1) => \rgb_out_reg[23]_i_752_n_2\,
      CO(0) => \rgb_out_reg[23]_i_752_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \rgb_out[23]_i_1309_n_0\,
      DI(0) => \rgb_out[23]_i_1310_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_752_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \pixel_x[1]_3\(0),
      S(1) => \rgb_out[23]_i_1311_n_0\,
      S(0) => \rgb_out[23]_i_1312_n_0\
    );
\rgb_out_reg[23]_i_754\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_1317_n_0\,
      CO(3) => \NLW_rgb_out_reg[23]_i_754_CO_UNCONNECTED\(3),
      CO(2) => \SC_D/pixel_on83_in\,
      CO(1) => \rgb_out_reg[23]_i_754_n_2\,
      CO(0) => \rgb_out_reg[23]_i_754_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \rgb_out[23]_i_1318_n_0\,
      DI(0) => \rgb_out[23]_i_1319_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_754_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \^rgb_out_reg[0]_0\(0),
      S(1) => \rgb_out[23]_i_1320_n_0\,
      S(0) => \rgb_out[23]_i_1321_n_0\
    );
\rgb_out_reg[23]_i_755\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_1322_n_0\,
      CO(3) => \NLW_rgb_out_reg[23]_i_755_CO_UNCONNECTED\(3),
      CO(2) => \SC_D/pixel_on7\,
      CO(1) => \rgb_out_reg[23]_i_755_n_2\,
      CO(0) => \rgb_out_reg[23]_i_755_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \rgb_out[23]_i_1323_n_0\,
      DI(1 downto 0) => B"00",
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_755_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \^rgb_out_reg[0]_0\(0),
      S(1) => \rgb_out[23]_i_1324_n_0\,
      S(0) => \rgb_out[23]_i_1325_n_0\
    );
\rgb_out_reg[23]_i_757\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_1331_n_0\,
      CO(3) => \NLW_rgb_out_reg[23]_i_757_CO_UNCONNECTED\(3),
      CO(2) => \SC_D/pixel_on66_in\,
      CO(1) => \rgb_out_reg[23]_i_757_n_2\,
      CO(0) => \rgb_out_reg[23]_i_757_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \rgb_out[23]_i_1332_n_0\,
      DI(1 downto 0) => B"00",
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_757_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \^rgb_out_reg[0]_0\(0),
      S(1) => \rgb_out[23]_i_1333_n_0\,
      S(0) => \rgb_out[23]_i_1334_n_0\
    );
\rgb_out_reg[23]_i_787\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_787_n_0\,
      CO(2) => \rgb_out_reg[23]_i_787_n_1\,
      CO(1) => \rgb_out_reg[23]_i_787_n_2\,
      CO(0) => \rgb_out_reg[23]_i_787_n_3\,
      CYINIT => '1',
      DI(3) => \rgb_out[23]_i_1382_n_0\,
      DI(2) => \rgb_out[23]_i_1383_n_0\,
      DI(1) => local_x_1(1),
      DI(0) => \rgb_out[23]_i_1384_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_787_O_UNCONNECTED\(3 downto 0),
      S(3) => \rgb_out[23]_i_1385_n_0\,
      S(2) => \rgb_out[23]_i_1386_n_0\,
      S(1) => \rgb_out[23]_i_1387_n_0\,
      S(0) => \rgb_out[23]_i_1388_n_0\
    );
\rgb_out_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => pixel_clk,
      CE => '1',
      D => TM_U_n_22,
      Q => rgb_out(2),
      R => \rgb_out[23]_i_1_n_0\
    );
\rgb_out_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => pixel_clk,
      CE => '1',
      D => TM_U_n_21,
      Q => rgb_out(3),
      R => \rgb_out[23]_i_1_n_0\
    );
\rgb_out_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => pixel_clk,
      CE => '1',
      D => TM_U_n_20,
      Q => rgb_out(4),
      R => \rgb_out[23]_i_1_n_0\
    );
\rgb_out_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => pixel_clk,
      CE => '1',
      D => TM_U_n_19,
      Q => rgb_out(5),
      R => \rgb_out[23]_i_1_n_0\
    );
\rgb_out_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => pixel_clk,
      CE => '1',
      D => TM_U_n_18,
      Q => rgb_out(6),
      R => \rgb_out[23]_i_1_n_0\
    );
\rgb_out_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => pixel_clk,
      CE => '1',
      D => TM_U_n_17,
      Q => rgb_out(7),
      R => \rgb_out[23]_i_1_n_0\
    );
\rgb_out_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => pixel_clk,
      CE => '1',
      D => TM_U_n_16,
      Q => rgb_out(8),
      R => \rgb_out[23]_i_1_n_0\
    );
\rgb_out_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => pixel_clk,
      CE => '1',
      D => TM_U_n_15,
      Q => rgb_out(9),
      R => \rgb_out[23]_i_1_n_0\
    );
vsync_out_i_1: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => vsync_in,
      I1 => reset,
      O => vsync_out_i_1_n_0
    );
vsync_out_reg: unisim.vcomponents.FDRE
     port map (
      C => pixel_clk,
      CE => '1',
      D => vsync_out_i_1_n_0,
      Q => vsync_out,
      R => '0'
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity HDMI_bd_compositeur_0_0 is
  port (
    pixel_clk : in STD_LOGIC;
    reset : in STD_LOGIC;
    rgb_in : in STD_LOGIC_VECTOR ( 23 downto 0 );
    de_in : in STD_LOGIC;
    hsync_in : in STD_LOGIC;
    vsync_in : in STD_LOGIC;
    pixel_x : in STD_LOGIC_VECTOR ( 11 downto 0 );
    pixel_y : in STD_LOGIC_VECTOR ( 11 downto 0 );
    is_pixel_mur : in STD_LOGIC;
    is_pixel_joueur : in STD_LOGIC;
    mode_ui : in STD_LOGIC_VECTOR ( 2 downto 0 );
    decompte_ui : in STD_LOGIC_VECTOR ( 3 downto 0 );
    flash_on : in STD_LOGIC;
    score_courant : in STD_LOGIC_VECTOR ( 3 downto 0 );
    temps_restant : in STD_LOGIC_VECTOR ( 3 downto 0 );
    score_dernier : in STD_LOGIC_VECTOR ( 3 downto 0 );
    record_personnel : in STD_LOGIC_VECTOR ( 3 downto 0 );
    rgb_out : out STD_LOGIC_VECTOR ( 23 downto 0 );
    de_out : out STD_LOGIC;
    hsync_out : out STD_LOGIC;
    vsync_out : out STD_LOGIC
  );
  attribute NotValidForBitStream : boolean;
  attribute NotValidForBitStream of HDMI_bd_compositeur_0_0 : entity is true;
  attribute CHECK_LICENSE_TYPE : string;
  attribute CHECK_LICENSE_TYPE of HDMI_bd_compositeur_0_0 : entity is "HDMI_bd_compositeur_0_0,compositeur,{}";
  attribute downgradeipidentifiedwarnings : string;
  attribute downgradeipidentifiedwarnings of HDMI_bd_compositeur_0_0 : entity is "yes";
  attribute ip_definition_source : string;
  attribute ip_definition_source of HDMI_bd_compositeur_0_0 : entity is "module_ref";
  attribute x_core_info : string;
  attribute x_core_info of HDMI_bd_compositeur_0_0 : entity is "compositeur,Vivado 2018.2.1";
end HDMI_bd_compositeur_0_0;

architecture STRUCTURE of HDMI_bd_compositeur_0_0 is
  signal \LAST_D/local_x\ : STD_LOGIC_VECTOR ( 12 downto 1 );
  signal \LAST_D/local_y\ : STD_LOGIC_VECTOR ( 12 downto 1 );
  signal \LAST_D/pixel_on2\ : STD_LOGIC;
  signal \LAST_D/pixel_on3\ : STD_LOGIC;
  signal \LAST_D/pixel_on4\ : STD_LOGIC;
  signal \LAST_D/pixel_on40_in\ : STD_LOGIC;
  signal \LAST_D/pixel_on5\ : STD_LOGIC;
  signal \LAST_D/pixel_on6\ : STD_LOGIC;
  signal \LAST_D/pixel_on66_in\ : STD_LOGIC;
  signal \LAST_D/pixel_on7\ : STD_LOGIC;
  signal \LAST_D/pixel_on712_in\ : STD_LOGIC;
  signal \LAST_D/pixel_on75_in\ : STD_LOGIC;
  signal \LAST_D/pixel_on8\ : STD_LOGIC;
  signal \LAST_D/pixel_on83_in\ : STD_LOGIC;
  signal \LAST_D/pixel_on9\ : STD_LOGIC;
  signal \LAST_D/pixel_on99_in\ : STD_LOGIC;
  signal \LAST_U/local_x\ : STD_LOGIC_VECTOR ( 12 downto 1 );
  signal \LAST_U/local_y\ : STD_LOGIC_VECTOR ( 12 downto 1 );
  signal \LAST_U/pixel_on2\ : STD_LOGIC;
  signal \LAST_U/pixel_on22_in\ : STD_LOGIC;
  signal \LAST_U/pixel_on3\ : STD_LOGIC;
  signal \LAST_U/pixel_on31_in\ : STD_LOGIC;
  signal \LAST_U/pixel_on4\ : STD_LOGIC;
  signal \LAST_U/pixel_on40_in\ : STD_LOGIC;
  signal \LAST_U/pixel_on5\ : STD_LOGIC;
  signal \LAST_U/pixel_on6\ : STD_LOGIC;
  signal \LAST_U/pixel_on66_in\ : STD_LOGIC;
  signal \LAST_U/pixel_on7\ : STD_LOGIC;
  signal \LAST_U/pixel_on712_in\ : STD_LOGIC;
  signal \LAST_U/pixel_on75_in\ : STD_LOGIC;
  signal \LAST_U/pixel_on8\ : STD_LOGIC;
  signal \LAST_U/pixel_on83_in\ : STD_LOGIC;
  signal \LAST_U/pixel_on9\ : STD_LOGIC;
  signal \LAST_U/pixel_on99_in\ : STD_LOGIC;
  signal \REC_D/local_x\ : STD_LOGIC_VECTOR ( 12 downto 1 );
  signal \REC_D/local_y\ : STD_LOGIC_VECTOR ( 12 downto 1 );
  signal \REC_D/pixel_on2\ : STD_LOGIC;
  signal \REC_D/pixel_on3\ : STD_LOGIC;
  signal \REC_D/pixel_on4\ : STD_LOGIC;
  signal \REC_D/pixel_on40_in\ : STD_LOGIC;
  signal \REC_D/pixel_on5\ : STD_LOGIC;
  signal \REC_D/pixel_on6\ : STD_LOGIC;
  signal \REC_D/pixel_on66_in\ : STD_LOGIC;
  signal \REC_D/pixel_on7\ : STD_LOGIC;
  signal \REC_D/pixel_on712_in\ : STD_LOGIC;
  signal \REC_D/pixel_on75_in\ : STD_LOGIC;
  signal \REC_D/pixel_on8\ : STD_LOGIC;
  signal \REC_D/pixel_on83_in\ : STD_LOGIC;
  signal \REC_D/pixel_on9\ : STD_LOGIC;
  signal \REC_D/pixel_on99_in\ : STD_LOGIC;
  signal \REC_U/local_x\ : STD_LOGIC_VECTOR ( 12 downto 1 );
  signal \REC_U/local_y\ : STD_LOGIC_VECTOR ( 12 downto 1 );
  signal \REC_U/pixel_on2\ : STD_LOGIC;
  signal \REC_U/pixel_on22_in\ : STD_LOGIC;
  signal \REC_U/pixel_on3\ : STD_LOGIC;
  signal \REC_U/pixel_on31_in\ : STD_LOGIC;
  signal \REC_U/pixel_on4\ : STD_LOGIC;
  signal \REC_U/pixel_on40_in\ : STD_LOGIC;
  signal \REC_U/pixel_on5\ : STD_LOGIC;
  signal \REC_U/pixel_on6\ : STD_LOGIC;
  signal \REC_U/pixel_on66_in\ : STD_LOGIC;
  signal \REC_U/pixel_on7\ : STD_LOGIC;
  signal \REC_U/pixel_on712_in\ : STD_LOGIC;
  signal \REC_U/pixel_on75_in\ : STD_LOGIC;
  signal \REC_U/pixel_on8\ : STD_LOGIC;
  signal \REC_U/pixel_on83_in\ : STD_LOGIC;
  signal \REC_U/pixel_on9\ : STD_LOGIC;
  signal \REC_U/pixel_on99_in\ : STD_LOGIC;
  signal \SC_D/local_x\ : STD_LOGIC_VECTOR ( 12 downto 0 );
  signal \SC_D/local_y\ : STD_LOGIC_VECTOR ( 12 downto 1 );
  signal \SC_D/pixel_on2\ : STD_LOGIC;
  signal \SC_D/pixel_on3\ : STD_LOGIC;
  signal \SC_D/pixel_on4\ : STD_LOGIC;
  signal \SC_D/pixel_on40_in\ : STD_LOGIC;
  signal \SC_D/pixel_on5\ : STD_LOGIC;
  signal \SC_D/pixel_on6\ : STD_LOGIC;
  signal \SC_D/pixel_on712_in\ : STD_LOGIC;
  signal \SC_D/pixel_on75_in\ : STD_LOGIC;
  signal \SC_D/pixel_on8\ : STD_LOGIC;
  signal \SC_D/pixel_on99_in\ : STD_LOGIC;
  signal \SC_U/local_x\ : STD_LOGIC_VECTOR ( 12 downto 0 );
  signal \SC_U/local_y\ : STD_LOGIC_VECTOR ( 12 downto 1 );
  signal \SC_U/pixel_on2\ : STD_LOGIC;
  signal \SC_U/pixel_on22_in\ : STD_LOGIC;
  signal \SC_U/pixel_on3\ : STD_LOGIC;
  signal \SC_U/pixel_on31_in\ : STD_LOGIC;
  signal \SC_U/pixel_on4\ : STD_LOGIC;
  signal \SC_U/pixel_on40_in\ : STD_LOGIC;
  signal \SC_U/pixel_on5\ : STD_LOGIC;
  signal \SC_U/pixel_on6\ : STD_LOGIC;
  signal \SC_U/pixel_on66_in\ : STD_LOGIC;
  signal \SC_U/pixel_on7\ : STD_LOGIC;
  signal \SC_U/pixel_on712_in\ : STD_LOGIC;
  signal \SC_U/pixel_on75_in\ : STD_LOGIC;
  signal \SC_U/pixel_on8\ : STD_LOGIC;
  signal \SC_U/pixel_on83_in\ : STD_LOGIC;
  signal \SC_U/pixel_on99_in\ : STD_LOGIC;
  signal \TM_D/local_x\ : STD_LOGIC_VECTOR ( 12 downto 2 );
  signal \TM_D/local_y\ : STD_LOGIC_VECTOR ( 12 downto 1 );
  signal \TM_D/pixel_on2\ : STD_LOGIC;
  signal \TM_D/pixel_on3\ : STD_LOGIC;
  signal \TM_D/pixel_on4\ : STD_LOGIC;
  signal \TM_D/pixel_on40_in\ : STD_LOGIC;
  signal \TM_D/pixel_on5\ : STD_LOGIC;
  signal \TM_D/pixel_on6\ : STD_LOGIC;
  signal \TM_D/pixel_on66_in\ : STD_LOGIC;
  signal \TM_D/pixel_on7\ : STD_LOGIC;
  signal \TM_D/pixel_on712_in\ : STD_LOGIC;
  signal \TM_D/pixel_on75_in\ : STD_LOGIC;
  signal \TM_D/pixel_on8\ : STD_LOGIC;
  signal \TM_D/pixel_on83_in\ : STD_LOGIC;
  signal \TM_D/pixel_on99_in\ : STD_LOGIC;
  signal U0_n_0 : STD_LOGIC;
  signal U0_n_15 : STD_LOGIC;
  signal \rgb_out[23]_i_1003_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1004_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1005_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1006_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1008_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1009_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1010_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1011_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1013_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1014_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1015_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1017_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1018_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1019_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1020_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1022_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1023_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1024_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1026_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1027_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1028_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1029_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1031_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1032_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1033_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1035_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1036_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1037_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1038_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1040_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1041_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1042_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1043_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1045_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1046_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1047_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1049_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1050_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1051_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1053_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1054_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1055_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1057_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1058_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1059_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1060_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1062_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1063_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1064_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1065_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1069_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1074_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1075_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1076_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1077_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1079_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1080_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1081_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1082_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1084_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1085_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1086_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1088_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1089_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1090_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1091_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1093_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1094_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1095_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1097_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1098_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1099_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1100_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1102_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1103_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1104_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1106_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1107_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1108_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1109_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1111_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1112_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1113_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1114_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1116_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1117_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1118_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1120_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1121_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1122_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1124_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1125_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1126_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1128_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1129_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1130_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1131_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1133_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1134_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1135_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1136_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1138_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1140_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1141_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1143_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1144_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1145_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1146_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1148_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1149_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1150_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1151_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1153_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1154_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1155_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1157_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1158_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1159_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1160_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1162_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1163_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1164_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1166_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1167_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1168_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1169_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1171_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1172_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1173_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1174_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1176_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1177_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1178_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1179_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1180_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1181_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1182_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1183_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1184_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1185_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1186_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1187_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1188_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1189_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1191_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1192_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1193_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1194_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1196_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1197_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1198_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1199_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1202_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1205_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1211_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1212_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1213_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1214_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1215_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1216_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1218_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1219_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1220_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1221_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1222_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1223_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1225_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1226_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1227_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1228_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1229_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1230_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1231_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1232_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1233_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1234_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1235_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1236_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1237_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1238_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1239_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1240_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1241_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1242_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1243_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1245_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1246_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1247_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1248_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1250_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1251_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1252_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1259_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1260_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1261_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1263_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1264_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1265_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1266_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1268_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1269_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1270_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1272_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1273_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1274_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1276_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1277_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1278_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1279_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1281_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1282_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1283_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1285_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1286_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1287_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1288_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1290_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1291_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1292_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1294_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1295_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1296_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1297_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1299_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1301_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1302_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1304_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1305_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1306_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1307_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1314_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1315_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1316_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1327_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1328_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1329_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1330_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1335_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1337_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1338_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1339_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1340_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1341_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1343_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1344_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1345_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1346_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1347_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1348_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1350_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1351_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1352_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1353_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1355_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1356_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1357_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1358_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1361_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1364_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1365_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1366_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1367_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1368_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1369_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1370_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1372_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1373_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1374_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1375_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1377_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1378_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1379_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1380_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1381_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1389_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1390_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1391_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1392_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1393_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1394_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1395_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1396_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1397_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1398_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1399_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1400_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1401_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1402_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1403_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1404_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1405_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1406_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1407_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1408_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1409_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1410_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1411_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1412_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1413_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1414_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1415_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1416_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1417_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1418_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1419_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1420_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1421_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1422_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1423_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1424_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1425_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1426_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1427_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1428_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1429_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1430_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1431_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1432_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1433_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1434_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1435_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1436_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1437_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1438_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1439_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1440_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1441_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1442_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1443_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1444_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1445_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1446_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1447_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1448_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1449_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1450_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1451_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1452_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1453_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1467_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1468_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1471_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1472_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1497_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1498_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1499_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1500_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1501_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1502_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1504_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1505_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1506_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1507_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1509_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1510_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1511_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1512_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1513_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1514_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1515_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1517_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1518_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1519_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1520_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1521_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1522_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1523_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1524_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1525_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1526_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1527_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1528_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1529_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1530_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1531_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1532_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1533_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1534_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1535_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1536_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1537_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1538_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1539_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1540_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1541_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1542_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1543_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1544_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1545_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1546_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1547_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1548_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1549_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1550_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1551_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1552_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1553_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1554_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1555_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1556_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1557_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1558_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1559_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1560_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1561_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1562_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1563_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1564_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1565_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1566_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1567_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1568_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1569_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1570_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1571_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1572_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1573_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1574_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1575_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1576_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1577_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1578_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1579_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1580_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1581_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1582_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1583_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1584_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1585_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1586_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1587_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1588_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1589_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1590_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1591_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1592_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1594_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1595_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1596_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1597_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1598_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1599_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1600_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1601_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1602_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1604_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1605_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1606_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1607_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1608_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1609_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1610_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1611_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1612_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1613_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1614_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1615_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1616_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1617_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1618_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1619_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1620_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1621_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1622_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1623_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1624_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1625_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1626_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1627_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1628_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1629_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1630_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1631_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1632_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1633_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1634_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1635_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1636_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1637_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1638_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1639_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1640_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1641_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1642_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1643_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1644_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1645_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1646_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1647_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1648_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1649_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1650_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1651_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1652_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1653_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1654_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1655_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1656_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1658_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1659_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1660_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1661_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1662_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1663_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1664_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1666_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1667_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1668_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1669_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1670_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1671_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1672_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1673_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1674_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1675_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1676_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1677_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1678_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1679_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1680_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1681_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1682_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1683_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1684_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1685_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1686_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1687_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1688_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1689_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1690_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1691_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1692_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1693_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1694_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1695_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1696_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1697_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1698_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1699_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1700_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1701_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1702_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1703_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1704_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1705_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1706_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1707_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1709_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1710_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1711_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1712_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1713_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1714_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1715_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1716_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1718_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1719_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1720_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1721_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1722_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1723_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1724_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1725_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1726_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1727_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1728_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1729_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1730_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1731_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1732_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1733_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1734_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1735_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1736_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1737_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1738_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1739_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1740_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1741_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1742_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1743_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1744_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1745_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1746_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1747_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1748_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1749_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1750_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1751_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1752_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1753_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1754_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1755_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1756_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1757_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1758_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1759_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1760_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1761_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1762_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1763_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1764_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1765_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1766_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1767_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1768_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1769_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1770_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1772_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1773_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1774_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1775_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1776_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1777_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1778_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1780_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1781_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1782_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1783_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1784_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1785_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1786_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1787_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1788_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1789_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1790_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1791_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1792_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1793_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1794_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1795_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1796_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1797_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1798_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1799_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1800_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1801_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1802_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1803_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1804_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1805_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1806_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1807_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1808_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1809_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1810_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1811_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1812_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1813_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1814_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1815_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1816_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1817_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1818_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1819_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1820_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1821_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1823_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1824_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1825_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1826_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1828_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1829_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1830_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1831_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1832_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1833_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1834_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1836_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1837_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1838_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1839_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1840_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1841_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1842_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1843_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1844_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1845_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1846_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1847_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1848_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1849_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1850_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1851_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1852_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1853_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1854_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1855_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1856_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1857_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1858_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1859_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1860_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1861_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1862_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1863_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1864_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1865_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1866_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1867_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1868_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1869_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1870_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1871_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1872_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1873_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1874_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1875_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1876_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1877_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1878_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1879_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1880_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1881_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1882_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1883_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1884_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1885_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1886_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1887_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1888_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1889_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1890_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1891_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1892_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1893_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1894_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1895_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1896_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1897_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1898_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1899_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1900_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1901_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1902_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1903_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1906_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1907_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1908_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1909_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1911_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1912_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1913_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1914_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1915_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1916_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1917_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1918_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1919_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1920_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1921_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1922_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1923_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1924_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1925_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1926_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1927_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1935_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1936_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1937_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1938_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1939_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1940_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1941_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1942_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1943_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1944_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1945_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1946_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1947_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1948_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1949_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1950_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1951_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1952_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1953_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1954_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1955_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1956_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1957_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1958_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1959_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1960_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1961_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1962_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1963_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1964_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1965_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1966_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1967_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1968_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1969_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1970_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1971_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1972_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1973_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1974_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1975_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1976_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1977_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1978_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1979_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1980_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1981_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1982_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1983_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1984_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1985_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1986_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1987_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1988_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1989_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1990_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1991_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1992_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1993_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1994_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1995_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1996_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_1997_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2002_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2004_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2005_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2006_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2007_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2008_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2017_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2018_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2019_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2020_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2021_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2022_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2023_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2038_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2039_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2040_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2041_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2042_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2043_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2051_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2052_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2053_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2054_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2055_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2056_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2057_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2058_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2059_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2060_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2061_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2062_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2063_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2064_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2065_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2066_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2067_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2068_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2069_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2070_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2071_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2072_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2073_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2074_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2075_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2076_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2077_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2078_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2079_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2080_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2081_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2082_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2083_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2084_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2085_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2086_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2087_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2088_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2089_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2090_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2091_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2092_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2093_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2094_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2095_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2096_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2097_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2098_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2099_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2100_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2101_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2102_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2103_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2104_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2105_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2106_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2107_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2108_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2109_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2110_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2111_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2112_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2113_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2114_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2115_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2116_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2117_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2118_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2119_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2120_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2121_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2122_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2123_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2124_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2131_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_2132_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_479_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_480_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_482_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_483_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_485_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_486_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_487_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_589_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_590_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_592_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_593_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_595_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_596_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_597_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_663_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_664_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_666_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_667_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_669_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_670_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_671_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_717_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_722_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_723_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_724_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_725_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_727_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_728_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_729_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_730_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_759_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_760_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_762_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_763_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_765_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_766_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_767_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_778_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_780_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_781_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_783_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_784_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_785_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_786_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_793_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_794_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_795_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_797_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_798_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_799_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_800_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_802_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_803_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_804_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_806_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_807_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_808_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_809_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_811_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_812_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_813_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_814_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_816_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_817_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_818_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_819_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_820_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_822_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_823_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_824_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_825_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_826_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_827_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_828_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_830_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_831_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_832_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_833_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_835_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_836_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_837_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_838_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_841_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_844_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_881_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_928_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_930_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_931_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_933_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_934_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_935_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_936_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_938_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_939_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_940_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_941_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_943_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_944_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_945_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_947_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_948_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_949_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_950_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_952_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_953_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_954_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_956_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_957_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_958_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_959_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_961_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_962_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_963_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_964_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_966_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_967_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_968_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_969_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_970_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_971_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_972_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_973_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_974_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_975_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_976_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_977_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_978_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_980_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_981_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_982_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_983_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_985_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_986_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_987_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_988_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_991_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_994_n_0\ : STD_LOGIC;
  signal \rgb_out[23]_i_998_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1001_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1001_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1001_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1002_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1002_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1002_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1002_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1007_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1007_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1007_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1007_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1012_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1012_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1012_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1012_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1016_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1016_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1016_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1016_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1021_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1021_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1021_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1021_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1025_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1025_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1025_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1025_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1030_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1030_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1030_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1030_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1034_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1034_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1034_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1034_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1039_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1039_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1039_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1039_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1044_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1044_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1044_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1044_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1048_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1048_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1048_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1048_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1052_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1052_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1052_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1052_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1056_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1056_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1056_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1056_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1061_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1061_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1061_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1061_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1066_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1066_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1066_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1066_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1068_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1068_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1068_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1070_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1070_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1070_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1070_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1072_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1072_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1072_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1073_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1073_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1073_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1073_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1078_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1078_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1078_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1078_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1083_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1083_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1083_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1083_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1087_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1087_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1087_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1087_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1092_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1092_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1092_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1092_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1096_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1096_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1096_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1096_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1101_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1101_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1101_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1101_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1105_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1105_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1105_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1105_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1110_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1110_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1110_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1110_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1115_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1115_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1115_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1115_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1119_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1119_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1119_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1119_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1123_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1123_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1123_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1123_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1127_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1127_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1127_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1127_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1132_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1132_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1132_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1132_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1137_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1137_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1137_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1137_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1139_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1139_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1139_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1142_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1142_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1142_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1142_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1147_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1147_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1147_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1147_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1152_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1152_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1152_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1152_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1156_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1156_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1156_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1156_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1161_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1161_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1161_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1161_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1165_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1165_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1165_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1165_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1170_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1170_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1170_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1170_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1175_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1175_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1175_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1175_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1190_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1190_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1190_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1190_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1195_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1195_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1195_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1195_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1200_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1200_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1200_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1200_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1203_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1203_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1203_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1203_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1217_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1217_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1217_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1217_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1224_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1224_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1224_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1224_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1244_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1244_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1244_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1244_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1249_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1249_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1249_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1249_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1258_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1258_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1258_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1258_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1262_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1262_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1262_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1262_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1267_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1267_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1267_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1267_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1271_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1271_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1271_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1271_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1275_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1275_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1275_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1275_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1280_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1280_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1280_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1280_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1284_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1284_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1284_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1284_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1289_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1289_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1289_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1289_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1293_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1293_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1293_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1293_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1298_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1298_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1298_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1298_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1303_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1303_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1303_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1303_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1313_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1313_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1313_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1313_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1326_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1326_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1326_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1326_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1336_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1336_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1336_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1336_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1342_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1342_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1342_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1342_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1349_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1349_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1349_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1349_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1354_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1354_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1354_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1354_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1359_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1359_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1359_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1359_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1362_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1362_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1362_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1362_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1371_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1371_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1371_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1371_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1376_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1376_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1376_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1376_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1503_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1503_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1503_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1503_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1508_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1508_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1508_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1508_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1516_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1516_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1516_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1516_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1593_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1593_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1593_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1593_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1603_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1603_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1603_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1603_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1657_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1657_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1657_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1657_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1665_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1665_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1665_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1665_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1708_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1708_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1708_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1708_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1717_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1717_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1717_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1717_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1771_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1771_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1771_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1771_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1779_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1779_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1779_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1779_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1822_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1822_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1822_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1822_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1827_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1827_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1827_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1827_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1835_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1835_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1835_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1835_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_189_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_189_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1904_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1904_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1904_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1904_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1905_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1905_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1905_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1905_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1910_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1910_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1910_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_1910_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_191_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_191_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_2011_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_2011_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_2011_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_2011_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_311_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_311_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_313_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_313_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_329_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_329_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_331_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_331_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_438_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_440_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_440_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_441_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_441_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_450_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_450_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_452_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_452_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_470_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_470_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_471_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_471_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_473_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_473_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_474_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_474_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_475_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_475_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_476_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_476_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_477_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_477_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_478_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_478_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_478_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_478_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_481_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_481_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_484_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_484_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_484_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_484_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_488_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_488_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_489_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_489_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_490_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_491_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_580_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_580_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_581_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_581_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_582_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_582_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_583_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_583_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_584_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_584_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_585_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_585_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_586_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_586_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_587_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_587_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_588_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_588_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_588_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_588_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_591_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_591_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_591_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_594_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_594_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_594_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_594_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_598_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_598_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_599_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_599_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_600_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_601_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_602_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_604_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_604_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_605_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_605_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_606_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_606_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_607_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_607_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_609_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_609_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_611_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_611_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_612_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_612_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_613_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_613_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_616_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_616_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_617_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_617_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_620_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_620_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_622_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_622_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_624_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_624_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_626_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_626_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_628_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_630_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_630_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_631_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_631_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_632_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_632_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_633_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_633_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_635_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_635_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_637_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_637_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_638_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_638_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_639_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_639_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_642_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_642_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_643_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_643_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_646_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_646_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_648_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_648_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_650_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_650_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_652_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_652_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_654_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_654_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_655_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_655_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_656_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_656_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_657_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_657_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_658_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_658_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_659_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_659_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_660_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_660_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_661_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_661_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_662_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_662_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_662_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_662_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_665_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_665_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_665_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_668_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_668_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_668_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_668_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_672_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_672_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_673_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_673_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_674_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_675_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_714_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_714_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_714_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_714_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_716_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_718_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_718_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_718_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_718_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_720_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_720_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_720_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_721_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_721_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_721_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_721_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_726_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_726_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_726_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_726_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_731_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_731_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_732_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_732_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_735_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_735_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_737_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_737_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_739_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_739_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_740_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_740_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_741_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_741_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_743_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_743_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_745_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_745_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_746_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_746_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_747_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_747_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_750_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_750_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_751_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_751_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_753_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_753_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_756_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_756_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_758_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_758_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_758_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_758_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_761_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_764_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_764_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_764_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_764_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_768_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_768_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_769_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_769_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_770_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_771_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_777_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_777_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_777_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_777_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_779_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_779_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_779_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_782_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_782_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_782_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_782_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_792_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_792_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_792_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_792_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_796_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_796_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_796_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_796_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_801_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_801_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_801_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_801_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_805_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_805_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_805_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_805_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_810_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_810_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_810_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_810_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_815_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_815_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_815_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_815_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_821_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_821_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_821_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_821_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_829_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_829_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_829_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_829_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_834_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_834_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_834_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_834_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_839_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_839_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_839_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_839_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_842_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_842_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_842_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_842_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_927_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_927_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_927_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_927_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_929_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_929_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_929_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_932_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_932_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_932_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_932_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_937_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_937_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_937_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_937_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_942_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_942_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_942_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_942_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_946_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_946_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_946_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_946_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_951_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_951_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_951_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_951_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_955_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_955_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_955_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_955_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_960_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_960_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_960_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_960_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_965_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_965_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_965_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_965_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_979_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_979_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_979_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_979_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_984_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_984_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_984_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_984_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_989_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_989_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_989_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_989_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_992_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_992_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_992_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_992_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_995_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_995_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_995_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_995_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_997_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_997_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_997_n_3\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_999_n_0\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_999_n_1\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_999_n_2\ : STD_LOGIC;
  signal \rgb_out_reg[23]_i_999_n_3\ : STD_LOGIC;
  signal \NLW_rgb_out_reg[23]_i_1001_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 2 to 2 );
  signal \NLW_rgb_out_reg[23]_i_1001_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_rgb_out_reg[23]_i_1002_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_1007_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_1012_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_1016_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_1021_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_1025_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_1030_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_1034_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_1039_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_1044_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_1048_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_1052_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_1056_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_1061_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_1066_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_1068_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 2 to 2 );
  signal \NLW_rgb_out_reg[23]_i_1068_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_rgb_out_reg[23]_i_1070_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_1072_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 2 to 2 );
  signal \NLW_rgb_out_reg[23]_i_1072_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_rgb_out_reg[23]_i_1073_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_1078_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_1083_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_1087_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_1092_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_1096_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_1101_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_1105_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_1110_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_1115_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_1119_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_1123_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_1127_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_1132_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_1137_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_1139_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 2 to 2 );
  signal \NLW_rgb_out_reg[23]_i_1139_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_rgb_out_reg[23]_i_1142_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_1147_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_1152_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_1156_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_1161_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_1165_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_1170_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_1190_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_1195_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_1200_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_1203_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_1244_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_1249_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_1258_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_1262_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_1267_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_1271_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_1275_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_1280_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_1284_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_1289_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_1293_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_1298_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_1303_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_1313_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_1326_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_1349_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_1354_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_1359_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_1362_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_189_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_rgb_out_reg[23]_i_189_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_191_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_rgb_out_reg[23]_i_191_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_311_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_rgb_out_reg[23]_i_311_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_313_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_rgb_out_reg[23]_i_313_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_329_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_rgb_out_reg[23]_i_329_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_331_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_rgb_out_reg[23]_i_331_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_438_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_rgb_out_reg[23]_i_438_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_439_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_rgb_out_reg[23]_i_439_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_440_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_rgb_out_reg[23]_i_440_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_441_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_rgb_out_reg[23]_i_441_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_450_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_rgb_out_reg[23]_i_450_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_452_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_rgb_out_reg[23]_i_452_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_470_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_rgb_out_reg[23]_i_470_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_471_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_rgb_out_reg[23]_i_471_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_473_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_rgb_out_reg[23]_i_473_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_474_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_rgb_out_reg[23]_i_474_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_475_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_rgb_out_reg[23]_i_475_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_476_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_rgb_out_reg[23]_i_476_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_477_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_rgb_out_reg[23]_i_477_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_478_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_481_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_rgb_out_reg[23]_i_481_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_rgb_out_reg[23]_i_484_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_488_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_rgb_out_reg[23]_i_488_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_489_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_rgb_out_reg[23]_i_489_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_490_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_rgb_out_reg[23]_i_490_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_491_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_rgb_out_reg[23]_i_491_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_580_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_rgb_out_reg[23]_i_580_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_581_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_rgb_out_reg[23]_i_581_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_582_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_rgb_out_reg[23]_i_582_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_583_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_rgb_out_reg[23]_i_583_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_584_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_rgb_out_reg[23]_i_584_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_585_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_rgb_out_reg[23]_i_585_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_586_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_rgb_out_reg[23]_i_586_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_587_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_rgb_out_reg[23]_i_587_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_588_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_591_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 2 to 2 );
  signal \NLW_rgb_out_reg[23]_i_591_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_rgb_out_reg[23]_i_594_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_598_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_rgb_out_reg[23]_i_598_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_599_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_rgb_out_reg[23]_i_599_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_600_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_rgb_out_reg[23]_i_600_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_601_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_rgb_out_reg[23]_i_601_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_602_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_rgb_out_reg[23]_i_602_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_603_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_rgb_out_reg[23]_i_603_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_604_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_rgb_out_reg[23]_i_604_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_605_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_rgb_out_reg[23]_i_605_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_606_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_rgb_out_reg[23]_i_606_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_607_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_rgb_out_reg[23]_i_607_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_609_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_rgb_out_reg[23]_i_609_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_611_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_rgb_out_reg[23]_i_611_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_612_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_rgb_out_reg[23]_i_612_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_613_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_rgb_out_reg[23]_i_613_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_616_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_rgb_out_reg[23]_i_616_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_617_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_rgb_out_reg[23]_i_617_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_620_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_rgb_out_reg[23]_i_620_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_622_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_rgb_out_reg[23]_i_622_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_624_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_rgb_out_reg[23]_i_624_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_626_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_rgb_out_reg[23]_i_626_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_628_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_rgb_out_reg[23]_i_628_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_629_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_rgb_out_reg[23]_i_629_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_630_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_rgb_out_reg[23]_i_630_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_631_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_rgb_out_reg[23]_i_631_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_632_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_rgb_out_reg[23]_i_632_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_633_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_rgb_out_reg[23]_i_633_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_635_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_rgb_out_reg[23]_i_635_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_637_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_rgb_out_reg[23]_i_637_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_638_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_rgb_out_reg[23]_i_638_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_639_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_rgb_out_reg[23]_i_639_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_642_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_rgb_out_reg[23]_i_642_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_643_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_rgb_out_reg[23]_i_643_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_646_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_rgb_out_reg[23]_i_646_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_648_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_rgb_out_reg[23]_i_648_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_650_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_rgb_out_reg[23]_i_650_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_652_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_rgb_out_reg[23]_i_652_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_654_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_rgb_out_reg[23]_i_654_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_655_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_rgb_out_reg[23]_i_655_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_656_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_rgb_out_reg[23]_i_656_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_657_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_rgb_out_reg[23]_i_657_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_658_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_rgb_out_reg[23]_i_658_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_659_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_rgb_out_reg[23]_i_659_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_660_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_rgb_out_reg[23]_i_660_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_661_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_rgb_out_reg[23]_i_661_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_662_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_665_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 2 to 2 );
  signal \NLW_rgb_out_reg[23]_i_665_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_rgb_out_reg[23]_i_668_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_672_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_rgb_out_reg[23]_i_672_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_673_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_rgb_out_reg[23]_i_673_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_674_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_rgb_out_reg[23]_i_674_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_675_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_rgb_out_reg[23]_i_675_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_714_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_716_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_rgb_out_reg[23]_i_716_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_718_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_720_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 2 to 2 );
  signal \NLW_rgb_out_reg[23]_i_720_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_rgb_out_reg[23]_i_721_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_726_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_731_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_rgb_out_reg[23]_i_731_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_732_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_rgb_out_reg[23]_i_732_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_735_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_rgb_out_reg[23]_i_735_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_737_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_rgb_out_reg[23]_i_737_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_739_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_rgb_out_reg[23]_i_739_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_740_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_rgb_out_reg[23]_i_740_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_741_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_rgb_out_reg[23]_i_741_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_743_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_rgb_out_reg[23]_i_743_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_745_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_rgb_out_reg[23]_i_745_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_746_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_rgb_out_reg[23]_i_746_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_747_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_rgb_out_reg[23]_i_747_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_750_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_rgb_out_reg[23]_i_750_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_751_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_rgb_out_reg[23]_i_751_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_753_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_rgb_out_reg[23]_i_753_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_756_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_rgb_out_reg[23]_i_756_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_758_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_761_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_rgb_out_reg[23]_i_761_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_764_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_768_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_rgb_out_reg[23]_i_768_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_769_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_rgb_out_reg[23]_i_769_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_770_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_rgb_out_reg[23]_i_770_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_771_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_rgb_out_reg[23]_i_771_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_777_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_779_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 2 to 2 );
  signal \NLW_rgb_out_reg[23]_i_779_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_rgb_out_reg[23]_i_782_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_792_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_796_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_801_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_805_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_810_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_829_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_834_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_839_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_842_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_927_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_929_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 2 to 2 );
  signal \NLW_rgb_out_reg[23]_i_929_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_rgb_out_reg[23]_i_932_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_937_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_942_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_946_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_951_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_955_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_960_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_979_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_984_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_989_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_992_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_995_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_rgb_out_reg[23]_i_997_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 2 to 2 );
  signal \NLW_rgb_out_reg[23]_i_997_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_rgb_out_reg[23]_i_999_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  attribute x_interface_info : string;
  attribute x_interface_info of pixel_clk : signal is "xilinx.com:signal:clock:1.0 pixel_clk CLK";
  attribute x_interface_parameter : string;
  attribute x_interface_parameter of pixel_clk : signal is "XIL_INTERFACENAME pixel_clk, ASSOCIATED_RESET reset, FREQ_HZ 100000000, PHASE 0.000, CLK_DOMAIN HDMI_bd_dvi2rgb_0_0_PixelClk";
  attribute x_interface_info of reset : signal is "xilinx.com:signal:reset:1.0 reset RST";
  attribute x_interface_parameter of reset : signal is "XIL_INTERFACENAME reset, POLARITY ACTIVE_HIGH";
begin
U0: entity work.HDMI_bd_compositeur_0_0_compositeur
     port map (
      CO(0) => U0_n_0,
      DI(1) => \rgb_out[23]_i_1467_n_0\,
      DI(0) => \rgb_out[23]_i_1468_n_0\,
      S(1) => \rgb_out[23]_i_1471_n_0\,
      S(0) => \rgb_out[23]_i_1472_n_0\,
      de_in => de_in,
      de_out => de_out,
      decompte_ui(3 downto 0) => decompte_ui(3 downto 0),
      flash_on => flash_on,
      hsync_in => hsync_in,
      hsync_out => hsync_out,
      is_pixel_mur => is_pixel_mur,
      local_x(11 downto 0) => \SC_D/local_x\(11 downto 0),
      local_x_0(11 downto 0) => \SC_U/local_x\(11 downto 0),
      local_x_1(9 downto 0) => \TM_D/local_x\(11 downto 2),
      local_y(10 downto 0) => \SC_D/local_y\(11 downto 1),
      mode_ui(2 downto 0) => mode_ui(2 downto 0),
      pixel_clk => pixel_clk,
      pixel_x(11 downto 0) => pixel_x(11 downto 0),
      \pixel_x[1]\(0) => \SC_D/pixel_on99_in\,
      \pixel_x[1]_0\(0) => \SC_D/pixel_on40_in\,
      \pixel_x[1]_1\(0) => \SC_D/pixel_on4\,
      \pixel_x[1]_2\(0) => \SC_D/pixel_on8\,
      \pixel_x[1]_3\(0) => \rgb_out_reg[23]_i_761_n_3\,
      \pixel_x[1]_4\(0) => \SC_U/pixel_on8\,
      \pixel_x[1]_5\(0) => \SC_U/pixel_on99_in\,
      \pixel_x[1]_6\(0) => \SC_U/pixel_on4\,
      \pixel_x[1]_7\(0) => \SC_U/pixel_on40_in\,
      \pixel_x[1]_8\(0) => \rgb_out_reg[23]_i_716_n_3\,
      \pixel_x[2]\(0) => \LAST_D/pixel_on99_in\,
      \pixel_x[2]_0\(0) => \LAST_D/pixel_on6\,
      \pixel_x[2]_1\(0) => \LAST_D/pixel_on40_in\,
      \pixel_x[2]_10\(0) => \REC_D/pixel_on6\,
      \pixel_x[2]_11\(0) => \REC_D/pixel_on40_in\,
      \pixel_x[2]_12\(0) => \REC_D/pixel_on4\,
      \pixel_x[2]_13\(0) => \REC_D/pixel_on8\,
      \pixel_x[2]_14\(0) => \REC_U/pixel_on8\,
      \pixel_x[2]_15\(0) => \REC_U/pixel_on6\,
      \pixel_x[2]_16\(0) => \REC_U/pixel_on99_in\,
      \pixel_x[2]_17\(0) => \REC_U/pixel_on4\,
      \pixel_x[2]_18\(0) => \REC_U/pixel_on40_in\,
      \pixel_x[2]_2\(0) => \LAST_D/pixel_on4\,
      \pixel_x[2]_3\(0) => \LAST_D/pixel_on8\,
      \pixel_x[2]_4\(0) => \LAST_U/pixel_on8\,
      \pixel_x[2]_5\(0) => \LAST_U/pixel_on6\,
      \pixel_x[2]_6\(0) => \LAST_U/pixel_on99_in\,
      \pixel_x[2]_7\(0) => \LAST_U/pixel_on4\,
      \pixel_x[2]_8\(0) => \LAST_U/pixel_on40_in\,
      \pixel_x[2]_9\(0) => \REC_D/pixel_on99_in\,
      \pixel_x[3]\(0) => \TM_D/pixel_on6\,
      \pixel_x[3]_0\(0) => \TM_D/pixel_on40_in\,
      \pixel_x[3]_1\(0) => \TM_D/pixel_on4\,
      \pixel_x[3]_2\(0) => \TM_D/pixel_on8\,
      \pixel_x[3]_3\(0) => \rgb_out_reg[23]_i_481_n_1\,
      \pixel_x[5]\(0) => \SC_D/pixel_on6\,
      \pixel_x[5]_0\(0) => \LAST_U/pixel_on9\,
      \pixel_x[5]_1\(0) => \REC_D/pixel_on9\,
      \pixel_x[5]_2\(0) => \rgb_out[23]_i_881_n_0\,
      \pixel_x[6]\(0) => \SC_U/pixel_on6\,
      \pixel_x[6]_0\(0) => \REC_U/pixel_on9\,
      \pixel_x[7]\(0) => \TM_D/pixel_on99_in\,
      \pixel_x[7]_0\(0) => \LAST_D/pixel_on9\,
      pixel_y(11 downto 0) => pixel_y(11 downto 0),
      \pixel_y[1]\(0) => \LAST_D/pixel_on3\,
      \pixel_y[1]_0\(0) => \LAST_D/pixel_on2\,
      \pixel_y[1]_1\(0) => \LAST_D/pixel_on712_in\,
      \pixel_y[1]_10\(0) => \LAST_U/pixel_on31_in\,
      \pixel_y[1]_11\(0) => \LAST_U/pixel_on2\,
      \pixel_y[1]_12\(0) => \LAST_U/pixel_on3\,
      \pixel_y[1]_13\(0) => \REC_D/pixel_on3\,
      \pixel_y[1]_14\(0) => \REC_D/pixel_on2\,
      \pixel_y[1]_15\(0) => \REC_D/pixel_on712_in\,
      \pixel_y[1]_16\(0) => \REC_D/pixel_on7\,
      \pixel_y[1]_17\(0) => \REC_D/pixel_on75_in\,
      \pixel_y[1]_18\(0) => \REC_D/pixel_on66_in\,
      \pixel_y[1]_19\(0) => \REC_U/pixel_on712_in\,
      \pixel_y[1]_2\(0) => \LAST_D/pixel_on7\,
      \pixel_y[1]_20\(0) => \REC_U/pixel_on66_in\,
      \pixel_y[1]_21\(0) => \REC_U/pixel_on75_in\,
      \pixel_y[1]_22\(0) => \REC_U/pixel_on7\,
      \pixel_y[1]_23\(0) => \REC_U/pixel_on22_in\,
      \pixel_y[1]_24\(0) => \REC_U/pixel_on31_in\,
      \pixel_y[1]_25\(0) => \REC_U/pixel_on2\,
      \pixel_y[1]_26\(0) => \REC_U/pixel_on3\,
      \pixel_y[1]_3\(0) => \LAST_D/pixel_on75_in\,
      \pixel_y[1]_4\(0) => \LAST_D/pixel_on66_in\,
      \pixel_y[1]_5\(0) => \LAST_U/pixel_on712_in\,
      \pixel_y[1]_6\(0) => \LAST_U/pixel_on66_in\,
      \pixel_y[1]_7\(0) => \LAST_U/pixel_on75_in\,
      \pixel_y[1]_8\(0) => \LAST_U/pixel_on7\,
      \pixel_y[1]_9\(0) => \LAST_U/pixel_on22_in\,
      \pixel_y[2]\(0) => \SC_D/pixel_on3\,
      \pixel_y[2]_0\(0) => \SC_D/pixel_on2\,
      \pixel_y[2]_1\(0) => \SC_D/pixel_on712_in\,
      \pixel_y[2]_10\(0) => \SC_U/pixel_on3\,
      \pixel_y[2]_11\(0) => \TM_D/pixel_on3\,
      \pixel_y[2]_12\(0) => \TM_D/pixel_on2\,
      \pixel_y[2]_13\(0) => \TM_D/pixel_on712_in\,
      \pixel_y[2]_14\(0) => \TM_D/pixel_on7\,
      \pixel_y[2]_15\(0) => \TM_D/pixel_on75_in\,
      \pixel_y[2]_16\(0) => \TM_D/pixel_on66_in\,
      \pixel_y[2]_2\(0) => \SC_D/pixel_on75_in\,
      \pixel_y[2]_3\(0) => \SC_U/pixel_on712_in\,
      \pixel_y[2]_4\(0) => \SC_U/pixel_on66_in\,
      \pixel_y[2]_5\(0) => \SC_U/pixel_on75_in\,
      \pixel_y[2]_6\(0) => \SC_U/pixel_on7\,
      \pixel_y[2]_7\(0) => \SC_U/pixel_on22_in\,
      \pixel_y[2]_8\(0) => \SC_U/pixel_on31_in\,
      \pixel_y[2]_9\(0) => \SC_U/pixel_on2\,
      \pixel_y[5]\(0) => \SC_D/pixel_on5\,
      \pixel_y[5]_0\(0) => \SC_U/pixel_on5\,
      \pixel_y[5]_1\(0) => \SC_U/pixel_on83_in\,
      \pixel_y[5]_10\(0) => \REC_U/pixel_on5\,
      \pixel_y[5]_11\(0) => \REC_U/pixel_on83_in\,
      \pixel_y[5]_2\(0) => \TM_D/pixel_on5\,
      \pixel_y[5]_3\(0) => \TM_D/pixel_on83_in\,
      \pixel_y[5]_4\(0) => \LAST_D/pixel_on5\,
      \pixel_y[5]_5\(0) => \LAST_D/pixel_on83_in\,
      \pixel_y[5]_6\(0) => \LAST_U/pixel_on5\,
      \pixel_y[5]_7\(0) => \LAST_U/pixel_on83_in\,
      \pixel_y[5]_8\(0) => \REC_D/pixel_on5\,
      \pixel_y[5]_9\(0) => \REC_D/pixel_on83_in\,
      record_personnel(3 downto 0) => record_personnel(3 downto 0),
      reset => reset,
      rgb_in(23 downto 0) => rgb_in(23 downto 0),
      rgb_out(23 downto 0) => rgb_out(23 downto 0),
      \rgb_out_reg[0]_0\(0) => U0_n_15,
      score_courant(3 downto 0) => score_courant(3 downto 0),
      score_dernier(3 downto 0) => score_dernier(3 downto 0),
      temps_restant(3 downto 0) => temps_restant(3 downto 0),
      vsync_in => vsync_in,
      vsync_out => vsync_out
    );
\rgb_out[23]_i_1000\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \rgb_out_reg[23]_i_1001_n_0\,
      O => \LAST_U/local_y\(12)
    );
\rgb_out[23]_i_1003\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \LAST_U/local_x\(10),
      I1 => \LAST_U/local_x\(11),
      O => \rgb_out[23]_i_1003_n_0\
    );
\rgb_out[23]_i_1004\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \LAST_U/local_x\(8),
      I1 => \LAST_U/local_x\(9),
      O => \rgb_out[23]_i_1004_n_0\
    );
\rgb_out[23]_i_1005\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_U/local_x\(11),
      I1 => \LAST_U/local_x\(10),
      O => \rgb_out[23]_i_1005_n_0\
    );
\rgb_out[23]_i_1006\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_U/local_x\(9),
      I1 => \LAST_U/local_x\(8),
      O => \rgb_out[23]_i_1006_n_0\
    );
\rgb_out[23]_i_1008\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \LAST_U/local_y\(10),
      I1 => \LAST_U/local_y\(11),
      O => \rgb_out[23]_i_1008_n_0\
    );
\rgb_out[23]_i_1009\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \LAST_U/local_y\(8),
      I1 => \LAST_U/local_y\(9),
      O => \rgb_out[23]_i_1009_n_0\
    );
\rgb_out[23]_i_1010\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_U/local_y\(11),
      I1 => \LAST_U/local_y\(10),
      O => \rgb_out[23]_i_1010_n_0\
    );
\rgb_out[23]_i_1011\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_U/local_y\(9),
      I1 => \LAST_U/local_y\(8),
      O => \rgb_out[23]_i_1011_n_0\
    );
\rgb_out[23]_i_1013\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \rgb_out_reg[23]_i_1001_n_0\,
      O => \rgb_out[23]_i_1013_n_0\
    );
\rgb_out[23]_i_1014\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_U/local_y\(11),
      I1 => \LAST_U/local_y\(10),
      O => \rgb_out[23]_i_1014_n_0\
    );
\rgb_out[23]_i_1015\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_U/local_y\(9),
      I1 => \LAST_U/local_y\(8),
      O => \rgb_out[23]_i_1015_n_0\
    );
\rgb_out[23]_i_1017\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \LAST_U/local_y\(10),
      I1 => \LAST_U/local_y\(11),
      O => \rgb_out[23]_i_1017_n_0\
    );
\rgb_out[23]_i_1018\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \LAST_U/local_y\(8),
      I1 => \LAST_U/local_y\(9),
      O => \rgb_out[23]_i_1018_n_0\
    );
\rgb_out[23]_i_1019\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_U/local_y\(11),
      I1 => \LAST_U/local_y\(10),
      O => \rgb_out[23]_i_1019_n_0\
    );
\rgb_out[23]_i_1020\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_U/local_y\(9),
      I1 => \LAST_U/local_y\(8),
      O => \rgb_out[23]_i_1020_n_0\
    );
\rgb_out[23]_i_1022\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \rgb_out_reg[23]_i_997_n_0\,
      O => \rgb_out[23]_i_1022_n_0\
    );
\rgb_out[23]_i_1023\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_U/local_x\(11),
      I1 => \LAST_U/local_x\(10),
      O => \rgb_out[23]_i_1023_n_0\
    );
\rgb_out[23]_i_1024\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_U/local_x\(9),
      I1 => \LAST_U/local_x\(8),
      O => \rgb_out[23]_i_1024_n_0\
    );
\rgb_out[23]_i_1026\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \LAST_U/local_x\(10),
      I1 => \LAST_U/local_x\(11),
      O => \rgb_out[23]_i_1026_n_0\
    );
\rgb_out[23]_i_1027\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \LAST_U/local_x\(8),
      I1 => \LAST_U/local_x\(9),
      O => \rgb_out[23]_i_1027_n_0\
    );
\rgb_out[23]_i_1028\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_U/local_x\(11),
      I1 => \LAST_U/local_x\(10),
      O => \rgb_out[23]_i_1028_n_0\
    );
\rgb_out[23]_i_1029\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_U/local_x\(9),
      I1 => \LAST_U/local_x\(8),
      O => \rgb_out[23]_i_1029_n_0\
    );
\rgb_out[23]_i_1031\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \rgb_out_reg[23]_i_1001_n_0\,
      O => \rgb_out[23]_i_1031_n_0\
    );
\rgb_out[23]_i_1032\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_U/local_y\(11),
      I1 => \LAST_U/local_y\(10),
      O => \rgb_out[23]_i_1032_n_0\
    );
\rgb_out[23]_i_1033\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_U/local_y\(9),
      I1 => \LAST_U/local_y\(8),
      O => \rgb_out[23]_i_1033_n_0\
    );
\rgb_out[23]_i_1035\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \LAST_U/local_y\(10),
      I1 => \LAST_U/local_y\(11),
      O => \rgb_out[23]_i_1035_n_0\
    );
\rgb_out[23]_i_1036\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \LAST_U/local_y\(8),
      I1 => \LAST_U/local_y\(9),
      O => \rgb_out[23]_i_1036_n_0\
    );
\rgb_out[23]_i_1037\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_U/local_y\(11),
      I1 => \LAST_U/local_y\(10),
      O => \rgb_out[23]_i_1037_n_0\
    );
\rgb_out[23]_i_1038\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_U/local_y\(9),
      I1 => \LAST_U/local_y\(8),
      O => \rgb_out[23]_i_1038_n_0\
    );
\rgb_out[23]_i_1040\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \LAST_U/local_x\(10),
      I1 => \LAST_U/local_x\(11),
      O => \rgb_out[23]_i_1040_n_0\
    );
\rgb_out[23]_i_1041\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \LAST_U/local_x\(8),
      I1 => \LAST_U/local_x\(9),
      O => \rgb_out[23]_i_1041_n_0\
    );
\rgb_out[23]_i_1042\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_U/local_x\(11),
      I1 => \LAST_U/local_x\(10),
      O => \rgb_out[23]_i_1042_n_0\
    );
\rgb_out[23]_i_1043\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_U/local_x\(9),
      I1 => \LAST_U/local_x\(8),
      O => \rgb_out[23]_i_1043_n_0\
    );
\rgb_out[23]_i_1045\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \rgb_out_reg[23]_i_997_n_0\,
      O => \rgb_out[23]_i_1045_n_0\
    );
\rgb_out[23]_i_1046\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_U/local_x\(11),
      I1 => \LAST_U/local_x\(10),
      O => \rgb_out[23]_i_1046_n_0\
    );
\rgb_out[23]_i_1047\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_U/local_x\(9),
      I1 => \LAST_U/local_x\(8),
      O => \rgb_out[23]_i_1047_n_0\
    );
\rgb_out[23]_i_1049\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \rgb_out_reg[23]_i_1001_n_0\,
      O => \rgb_out[23]_i_1049_n_0\
    );
\rgb_out[23]_i_1050\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_U/local_y\(11),
      I1 => \LAST_U/local_y\(10),
      O => \rgb_out[23]_i_1050_n_0\
    );
\rgb_out[23]_i_1051\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_U/local_y\(9),
      I1 => \LAST_U/local_y\(8),
      O => \rgb_out[23]_i_1051_n_0\
    );
\rgb_out[23]_i_1053\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \rgb_out_reg[23]_i_1001_n_0\,
      O => \rgb_out[23]_i_1053_n_0\
    );
\rgb_out[23]_i_1054\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_U/local_y\(11),
      I1 => \LAST_U/local_y\(10),
      O => \rgb_out[23]_i_1054_n_0\
    );
\rgb_out[23]_i_1055\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_U/local_y\(9),
      I1 => \LAST_U/local_y\(8),
      O => \rgb_out[23]_i_1055_n_0\
    );
\rgb_out[23]_i_1057\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \LAST_U/local_y\(10),
      I1 => \LAST_U/local_y\(11),
      O => \rgb_out[23]_i_1057_n_0\
    );
\rgb_out[23]_i_1058\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \LAST_U/local_y\(8),
      I1 => \LAST_U/local_y\(9),
      O => \rgb_out[23]_i_1058_n_0\
    );
\rgb_out[23]_i_1059\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_U/local_y\(11),
      I1 => \LAST_U/local_y\(10),
      O => \rgb_out[23]_i_1059_n_0\
    );
\rgb_out[23]_i_1060\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_U/local_y\(9),
      I1 => \LAST_U/local_y\(8),
      O => \rgb_out[23]_i_1060_n_0\
    );
\rgb_out[23]_i_1062\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \LAST_U/local_y\(10),
      I1 => \LAST_U/local_y\(11),
      O => \rgb_out[23]_i_1062_n_0\
    );
\rgb_out[23]_i_1063\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \LAST_U/local_y\(8),
      I1 => \LAST_U/local_y\(9),
      O => \rgb_out[23]_i_1063_n_0\
    );
\rgb_out[23]_i_1064\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_U/local_y\(11),
      I1 => \LAST_U/local_y\(10),
      O => \rgb_out[23]_i_1064_n_0\
    );
\rgb_out[23]_i_1065\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_U/local_y\(9),
      I1 => \LAST_U/local_y\(8),
      O => \rgb_out[23]_i_1065_n_0\
    );
\rgb_out[23]_i_1067\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \rgb_out_reg[23]_i_1068_n_0\,
      O => \REC_U/local_x\(12)
    );
\rgb_out[23]_i_1069\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_U/local_x\(11),
      I1 => \REC_U/local_x\(10),
      O => \rgb_out[23]_i_1069_n_0\
    );
\rgb_out[23]_i_1071\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \rgb_out_reg[23]_i_1072_n_0\,
      O => \REC_U/local_y\(12)
    );
\rgb_out[23]_i_1074\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \REC_U/local_x\(10),
      I1 => \REC_U/local_x\(11),
      O => \rgb_out[23]_i_1074_n_0\
    );
\rgb_out[23]_i_1075\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \REC_U/local_x\(8),
      I1 => \REC_U/local_x\(9),
      O => \rgb_out[23]_i_1075_n_0\
    );
\rgb_out[23]_i_1076\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_U/local_x\(11),
      I1 => \REC_U/local_x\(10),
      O => \rgb_out[23]_i_1076_n_0\
    );
\rgb_out[23]_i_1077\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_U/local_x\(9),
      I1 => \REC_U/local_x\(8),
      O => \rgb_out[23]_i_1077_n_0\
    );
\rgb_out[23]_i_1079\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \REC_U/local_y\(10),
      I1 => \REC_U/local_y\(11),
      O => \rgb_out[23]_i_1079_n_0\
    );
\rgb_out[23]_i_1080\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \REC_U/local_y\(8),
      I1 => \REC_U/local_y\(9),
      O => \rgb_out[23]_i_1080_n_0\
    );
\rgb_out[23]_i_1081\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_U/local_y\(11),
      I1 => \REC_U/local_y\(10),
      O => \rgb_out[23]_i_1081_n_0\
    );
\rgb_out[23]_i_1082\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_U/local_y\(9),
      I1 => \REC_U/local_y\(8),
      O => \rgb_out[23]_i_1082_n_0\
    );
\rgb_out[23]_i_1084\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \rgb_out_reg[23]_i_1072_n_0\,
      O => \rgb_out[23]_i_1084_n_0\
    );
\rgb_out[23]_i_1085\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_U/local_y\(11),
      I1 => \REC_U/local_y\(10),
      O => \rgb_out[23]_i_1085_n_0\
    );
\rgb_out[23]_i_1086\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_U/local_y\(9),
      I1 => \REC_U/local_y\(8),
      O => \rgb_out[23]_i_1086_n_0\
    );
\rgb_out[23]_i_1088\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \REC_U/local_y\(10),
      I1 => \REC_U/local_y\(11),
      O => \rgb_out[23]_i_1088_n_0\
    );
\rgb_out[23]_i_1089\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \REC_U/local_y\(8),
      I1 => \REC_U/local_y\(9),
      O => \rgb_out[23]_i_1089_n_0\
    );
\rgb_out[23]_i_1090\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_U/local_y\(11),
      I1 => \REC_U/local_y\(10),
      O => \rgb_out[23]_i_1090_n_0\
    );
\rgb_out[23]_i_1091\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_U/local_y\(9),
      I1 => \REC_U/local_y\(8),
      O => \rgb_out[23]_i_1091_n_0\
    );
\rgb_out[23]_i_1093\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \rgb_out_reg[23]_i_1068_n_0\,
      O => \rgb_out[23]_i_1093_n_0\
    );
\rgb_out[23]_i_1094\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_U/local_x\(11),
      I1 => \REC_U/local_x\(10),
      O => \rgb_out[23]_i_1094_n_0\
    );
\rgb_out[23]_i_1095\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_U/local_x\(9),
      I1 => \REC_U/local_x\(8),
      O => \rgb_out[23]_i_1095_n_0\
    );
\rgb_out[23]_i_1097\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \REC_U/local_x\(10),
      I1 => \REC_U/local_x\(11),
      O => \rgb_out[23]_i_1097_n_0\
    );
\rgb_out[23]_i_1098\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \REC_U/local_x\(8),
      I1 => \REC_U/local_x\(9),
      O => \rgb_out[23]_i_1098_n_0\
    );
\rgb_out[23]_i_1099\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_U/local_x\(11),
      I1 => \REC_U/local_x\(10),
      O => \rgb_out[23]_i_1099_n_0\
    );
\rgb_out[23]_i_1100\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_U/local_x\(9),
      I1 => \REC_U/local_x\(8),
      O => \rgb_out[23]_i_1100_n_0\
    );
\rgb_out[23]_i_1102\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \rgb_out_reg[23]_i_1072_n_0\,
      O => \rgb_out[23]_i_1102_n_0\
    );
\rgb_out[23]_i_1103\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_U/local_y\(11),
      I1 => \REC_U/local_y\(10),
      O => \rgb_out[23]_i_1103_n_0\
    );
\rgb_out[23]_i_1104\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_U/local_y\(9),
      I1 => \REC_U/local_y\(8),
      O => \rgb_out[23]_i_1104_n_0\
    );
\rgb_out[23]_i_1106\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \REC_U/local_y\(10),
      I1 => \REC_U/local_y\(11),
      O => \rgb_out[23]_i_1106_n_0\
    );
\rgb_out[23]_i_1107\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \REC_U/local_y\(8),
      I1 => \REC_U/local_y\(9),
      O => \rgb_out[23]_i_1107_n_0\
    );
\rgb_out[23]_i_1108\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_U/local_y\(11),
      I1 => \REC_U/local_y\(10),
      O => \rgb_out[23]_i_1108_n_0\
    );
\rgb_out[23]_i_1109\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_U/local_y\(9),
      I1 => \REC_U/local_y\(8),
      O => \rgb_out[23]_i_1109_n_0\
    );
\rgb_out[23]_i_1111\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \REC_U/local_x\(10),
      I1 => \REC_U/local_x\(11),
      O => \rgb_out[23]_i_1111_n_0\
    );
\rgb_out[23]_i_1112\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \REC_U/local_x\(8),
      I1 => \REC_U/local_x\(9),
      O => \rgb_out[23]_i_1112_n_0\
    );
\rgb_out[23]_i_1113\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_U/local_x\(11),
      I1 => \REC_U/local_x\(10),
      O => \rgb_out[23]_i_1113_n_0\
    );
\rgb_out[23]_i_1114\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_U/local_x\(9),
      I1 => \REC_U/local_x\(8),
      O => \rgb_out[23]_i_1114_n_0\
    );
\rgb_out[23]_i_1116\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \rgb_out_reg[23]_i_1068_n_0\,
      O => \rgb_out[23]_i_1116_n_0\
    );
\rgb_out[23]_i_1117\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_U/local_x\(11),
      I1 => \REC_U/local_x\(10),
      O => \rgb_out[23]_i_1117_n_0\
    );
\rgb_out[23]_i_1118\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_U/local_x\(9),
      I1 => \REC_U/local_x\(8),
      O => \rgb_out[23]_i_1118_n_0\
    );
\rgb_out[23]_i_1120\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \rgb_out_reg[23]_i_1072_n_0\,
      O => \rgb_out[23]_i_1120_n_0\
    );
\rgb_out[23]_i_1121\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_U/local_y\(11),
      I1 => \REC_U/local_y\(10),
      O => \rgb_out[23]_i_1121_n_0\
    );
\rgb_out[23]_i_1122\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_U/local_y\(9),
      I1 => \REC_U/local_y\(8),
      O => \rgb_out[23]_i_1122_n_0\
    );
\rgb_out[23]_i_1124\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \rgb_out_reg[23]_i_1072_n_0\,
      O => \rgb_out[23]_i_1124_n_0\
    );
\rgb_out[23]_i_1125\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_U/local_y\(11),
      I1 => \REC_U/local_y\(10),
      O => \rgb_out[23]_i_1125_n_0\
    );
\rgb_out[23]_i_1126\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_U/local_y\(9),
      I1 => \REC_U/local_y\(8),
      O => \rgb_out[23]_i_1126_n_0\
    );
\rgb_out[23]_i_1128\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \REC_U/local_y\(10),
      I1 => \REC_U/local_y\(11),
      O => \rgb_out[23]_i_1128_n_0\
    );
\rgb_out[23]_i_1129\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \REC_U/local_y\(8),
      I1 => \REC_U/local_y\(9),
      O => \rgb_out[23]_i_1129_n_0\
    );
\rgb_out[23]_i_1130\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_U/local_y\(11),
      I1 => \REC_U/local_y\(10),
      O => \rgb_out[23]_i_1130_n_0\
    );
\rgb_out[23]_i_1131\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_U/local_y\(9),
      I1 => \REC_U/local_y\(8),
      O => \rgb_out[23]_i_1131_n_0\
    );
\rgb_out[23]_i_1133\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \REC_U/local_y\(10),
      I1 => \REC_U/local_y\(11),
      O => \rgb_out[23]_i_1133_n_0\
    );
\rgb_out[23]_i_1134\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \REC_U/local_y\(8),
      I1 => \REC_U/local_y\(9),
      O => \rgb_out[23]_i_1134_n_0\
    );
\rgb_out[23]_i_1135\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_U/local_y\(11),
      I1 => \REC_U/local_y\(10),
      O => \rgb_out[23]_i_1135_n_0\
    );
\rgb_out[23]_i_1136\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_U/local_y\(9),
      I1 => \REC_U/local_y\(8),
      O => \rgb_out[23]_i_1136_n_0\
    );
\rgb_out[23]_i_1138\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \rgb_out_reg[23]_i_1139_n_0\,
      O => \rgb_out[23]_i_1138_n_0\
    );
\rgb_out[23]_i_1140\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_D/local_y\(11),
      I1 => \LAST_D/local_y\(10),
      O => \rgb_out[23]_i_1140_n_0\
    );
\rgb_out[23]_i_1141\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_D/local_y\(9),
      I1 => \LAST_D/local_y\(8),
      O => \rgb_out[23]_i_1141_n_0\
    );
\rgb_out[23]_i_1143\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \LAST_D/local_y\(10),
      I1 => \LAST_D/local_y\(11),
      O => \rgb_out[23]_i_1143_n_0\
    );
\rgb_out[23]_i_1144\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \LAST_D/local_y\(8),
      I1 => \LAST_D/local_y\(9),
      O => \rgb_out[23]_i_1144_n_0\
    );
\rgb_out[23]_i_1145\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_D/local_y\(11),
      I1 => \LAST_D/local_y\(10),
      O => \rgb_out[23]_i_1145_n_0\
    );
\rgb_out[23]_i_1146\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_D/local_y\(9),
      I1 => \LAST_D/local_y\(8),
      O => \rgb_out[23]_i_1146_n_0\
    );
\rgb_out[23]_i_1148\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \LAST_D/local_x\(10),
      I1 => \LAST_D/local_x\(11),
      O => \rgb_out[23]_i_1148_n_0\
    );
\rgb_out[23]_i_1149\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \LAST_D/local_x\(8),
      I1 => \LAST_D/local_x\(9),
      O => \rgb_out[23]_i_1149_n_0\
    );
\rgb_out[23]_i_1150\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_D/local_x\(11),
      I1 => \LAST_D/local_x\(10),
      O => \rgb_out[23]_i_1150_n_0\
    );
\rgb_out[23]_i_1151\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_D/local_x\(9),
      I1 => \LAST_D/local_x\(8),
      O => \rgb_out[23]_i_1151_n_0\
    );
\rgb_out[23]_i_1153\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \rgb_out_reg[23]_i_665_n_0\,
      O => \rgb_out[23]_i_1153_n_0\
    );
\rgb_out[23]_i_1154\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_D/local_x\(11),
      I1 => \LAST_D/local_x\(10),
      O => \rgb_out[23]_i_1154_n_0\
    );
\rgb_out[23]_i_1155\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_D/local_x\(9),
      I1 => \LAST_D/local_x\(8),
      O => \rgb_out[23]_i_1155_n_0\
    );
\rgb_out[23]_i_1157\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \LAST_D/local_y\(10),
      I1 => \LAST_D/local_y\(11),
      O => \rgb_out[23]_i_1157_n_0\
    );
\rgb_out[23]_i_1158\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \LAST_D/local_y\(8),
      I1 => \LAST_D/local_y\(9),
      O => \rgb_out[23]_i_1158_n_0\
    );
\rgb_out[23]_i_1159\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_D/local_y\(11),
      I1 => \LAST_D/local_y\(10),
      O => \rgb_out[23]_i_1159_n_0\
    );
\rgb_out[23]_i_1160\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_D/local_y\(9),
      I1 => \LAST_D/local_y\(8),
      O => \rgb_out[23]_i_1160_n_0\
    );
\rgb_out[23]_i_1162\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \rgb_out_reg[23]_i_1139_n_0\,
      O => \rgb_out[23]_i_1162_n_0\
    );
\rgb_out[23]_i_1163\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_D/local_y\(11),
      I1 => \LAST_D/local_y\(10),
      O => \rgb_out[23]_i_1163_n_0\
    );
\rgb_out[23]_i_1164\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_D/local_y\(9),
      I1 => \LAST_D/local_y\(8),
      O => \rgb_out[23]_i_1164_n_0\
    );
\rgb_out[23]_i_1166\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \LAST_D/local_y\(10),
      I1 => \LAST_D/local_y\(11),
      O => \rgb_out[23]_i_1166_n_0\
    );
\rgb_out[23]_i_1167\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \LAST_D/local_y\(8),
      I1 => \LAST_D/local_y\(9),
      O => \rgb_out[23]_i_1167_n_0\
    );
\rgb_out[23]_i_1168\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_D/local_y\(11),
      I1 => \LAST_D/local_y\(10),
      O => \rgb_out[23]_i_1168_n_0\
    );
\rgb_out[23]_i_1169\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_D/local_y\(9),
      I1 => \LAST_D/local_y\(8),
      O => \rgb_out[23]_i_1169_n_0\
    );
\rgb_out[23]_i_1171\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \rgb_out_reg[23]_i_1139_n_0\,
      O => \rgb_out[23]_i_1171_n_0\
    );
\rgb_out[23]_i_1172\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_D/local_y\(11),
      I1 => \LAST_D/local_y\(10),
      O => \rgb_out[23]_i_1172_n_0\
    );
\rgb_out[23]_i_1173\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_D/local_y\(9),
      I1 => \LAST_D/local_y\(8),
      O => \rgb_out[23]_i_1173_n_0\
    );
\rgb_out[23]_i_1174\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \LAST_D/local_x\(6),
      I1 => \LAST_D/local_x\(7),
      O => \rgb_out[23]_i_1174_n_0\
    );
\rgb_out[23]_i_1176\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \LAST_D/local_x\(1),
      I1 => pixel_x(0),
      O => \rgb_out[23]_i_1176_n_0\
    );
\rgb_out[23]_i_1177\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_D/local_x\(7),
      I1 => \LAST_D/local_x\(6),
      O => \rgb_out[23]_i_1177_n_0\
    );
\rgb_out[23]_i_1178\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \LAST_D/local_x\(4),
      I1 => \LAST_D/local_x\(5),
      O => \rgb_out[23]_i_1178_n_0\
    );
\rgb_out[23]_i_1179\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \LAST_D/local_x\(3),
      I1 => \LAST_D/local_x\(2),
      O => \rgb_out[23]_i_1179_n_0\
    );
\rgb_out[23]_i_1180\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => pixel_x(0),
      I1 => \LAST_D/local_x\(1),
      O => \rgb_out[23]_i_1180_n_0\
    );
\rgb_out[23]_i_1181\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_x(11),
      O => \rgb_out[23]_i_1181_n_0\
    );
\rgb_out[23]_i_1182\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_x(10),
      O => \rgb_out[23]_i_1182_n_0\
    );
\rgb_out[23]_i_1183\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_x(9),
      O => \rgb_out[23]_i_1183_n_0\
    );
\rgb_out[23]_i_1184\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_D/local_x\(3),
      I1 => \LAST_D/local_x\(2),
      O => \rgb_out[23]_i_1184_n_0\
    );
\rgb_out[23]_i_1185\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_D/local_x\(1),
      O => \rgb_out[23]_i_1185_n_0\
    );
\rgb_out[23]_i_1186\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_D/local_x\(7),
      I1 => \LAST_D/local_x\(6),
      O => \rgb_out[23]_i_1186_n_0\
    );
\rgb_out[23]_i_1187\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_D/local_x\(5),
      I1 => \LAST_D/local_x\(4),
      O => \rgb_out[23]_i_1187_n_0\
    );
\rgb_out[23]_i_1188\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \LAST_D/local_x\(2),
      I1 => \LAST_D/local_x\(3),
      O => \rgb_out[23]_i_1188_n_0\
    );
\rgb_out[23]_i_1189\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => pixel_x(0),
      I1 => \LAST_D/local_x\(1),
      O => \rgb_out[23]_i_1189_n_0\
    );
\rgb_out[23]_i_1191\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \LAST_D/local_y\(10),
      I1 => \LAST_D/local_y\(11),
      O => \rgb_out[23]_i_1191_n_0\
    );
\rgb_out[23]_i_1192\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \LAST_D/local_y\(8),
      I1 => \LAST_D/local_y\(9),
      O => \rgb_out[23]_i_1192_n_0\
    );
\rgb_out[23]_i_1193\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_D/local_y\(11),
      I1 => \LAST_D/local_y\(10),
      O => \rgb_out[23]_i_1193_n_0\
    );
\rgb_out[23]_i_1194\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_D/local_y\(9),
      I1 => \LAST_D/local_y\(8),
      O => \rgb_out[23]_i_1194_n_0\
    );
\rgb_out[23]_i_1196\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \LAST_D/local_x\(10),
      I1 => \LAST_D/local_x\(11),
      O => \rgb_out[23]_i_1196_n_0\
    );
\rgb_out[23]_i_1197\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \LAST_D/local_x\(8),
      I1 => \LAST_D/local_x\(9),
      O => \rgb_out[23]_i_1197_n_0\
    );
\rgb_out[23]_i_1198\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_D/local_x\(11),
      I1 => \LAST_D/local_x\(10),
      O => \rgb_out[23]_i_1198_n_0\
    );
\rgb_out[23]_i_1199\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_D/local_x\(9),
      I1 => \LAST_D/local_x\(8),
      O => \rgb_out[23]_i_1199_n_0\
    );
\rgb_out[23]_i_1201\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \rgb_out_reg[23]_i_1139_n_0\,
      O => \LAST_D/local_y\(12)
    );
\rgb_out[23]_i_1202\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_D/local_y\(11),
      I1 => \LAST_D/local_y\(10),
      O => \rgb_out[23]_i_1202_n_0\
    );
\rgb_out[23]_i_1204\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \rgb_out_reg[23]_i_665_n_0\,
      O => \LAST_D/local_x\(12)
    );
\rgb_out[23]_i_1205\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_D/local_x\(11),
      I1 => \LAST_D/local_x\(10),
      O => \rgb_out[23]_i_1205_n_0\
    );
\rgb_out[23]_i_1211\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \SC_U/local_x\(5),
      O => \rgb_out[23]_i_1211_n_0\
    );
\rgb_out[23]_i_1212\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \SC_U/local_x\(3),
      I1 => \SC_U/local_x\(2),
      O => \rgb_out[23]_i_1212_n_0\
    );
\rgb_out[23]_i_1213\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \SC_U/local_x\(9),
      I1 => \SC_U/local_x\(8),
      O => \rgb_out[23]_i_1213_n_0\
    );
\rgb_out[23]_i_1214\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \SC_U/local_x\(7),
      I1 => \SC_U/local_x\(6),
      O => \rgb_out[23]_i_1214_n_0\
    );
\rgb_out[23]_i_1215\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \SC_U/local_x\(5),
      I1 => \SC_U/local_x\(4),
      O => \rgb_out[23]_i_1215_n_0\
    );
\rgb_out[23]_i_1216\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \SC_U/local_x\(2),
      I1 => \SC_U/local_x\(3),
      O => \rgb_out[23]_i_1216_n_0\
    );
\rgb_out[23]_i_1218\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"7"
    )
        port map (
      I0 => \SC_U/local_y\(3),
      I1 => \SC_U/local_y\(2),
      O => \rgb_out[23]_i_1218_n_0\
    );
\rgb_out[23]_i_1219\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"7"
    )
        port map (
      I0 => \SC_U/local_y\(5),
      I1 => \SC_U/local_y\(4),
      O => \rgb_out[23]_i_1219_n_0\
    );
\rgb_out[23]_i_1220\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \SC_U/local_y\(11),
      I1 => \SC_U/local_y\(10),
      O => \rgb_out[23]_i_1220_n_0\
    );
\rgb_out[23]_i_1221\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \SC_U/local_y\(9),
      I1 => \SC_U/local_y\(8),
      O => \rgb_out[23]_i_1221_n_0\
    );
\rgb_out[23]_i_1222\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \SC_U/local_y\(7),
      I1 => \SC_U/local_y\(6),
      O => \rgb_out[23]_i_1222_n_0\
    );
\rgb_out[23]_i_1223\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \SC_U/local_y\(4),
      I1 => \SC_U/local_y\(5),
      O => \rgb_out[23]_i_1223_n_0\
    );
\rgb_out[23]_i_1225\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_y(11),
      O => \rgb_out[23]_i_1225_n_0\
    );
\rgb_out[23]_i_1226\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_y(10),
      O => \rgb_out[23]_i_1226_n_0\
    );
\rgb_out[23]_i_1227\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_y(9),
      O => \rgb_out[23]_i_1227_n_0\
    );
\rgb_out[23]_i_1228\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \SC_U/local_x\(6),
      I1 => \SC_U/local_x\(7),
      O => \rgb_out[23]_i_1228_n_0\
    );
\rgb_out[23]_i_1229\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \SC_U/local_x\(5),
      I1 => \SC_U/local_x\(4),
      O => \rgb_out[23]_i_1229_n_0\
    );
\rgb_out[23]_i_1230\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \SC_U/local_x\(2),
      I1 => \SC_U/local_x\(3),
      O => \rgb_out[23]_i_1230_n_0\
    );
\rgb_out[23]_i_1231\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \SC_U/local_x\(0),
      I1 => \SC_U/local_x\(1),
      O => \rgb_out[23]_i_1231_n_0\
    );
\rgb_out[23]_i_1232\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \SC_U/local_x\(7),
      I1 => \SC_U/local_x\(6),
      O => \rgb_out[23]_i_1232_n_0\
    );
\rgb_out[23]_i_1233\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \SC_U/local_x\(4),
      I1 => \SC_U/local_x\(5),
      O => \rgb_out[23]_i_1233_n_0\
    );
\rgb_out[23]_i_1234\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \SC_U/local_x\(3),
      I1 => \SC_U/local_x\(2),
      O => \rgb_out[23]_i_1234_n_0\
    );
\rgb_out[23]_i_1235\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \SC_U/local_x\(1),
      I1 => \SC_U/local_x\(0),
      O => \rgb_out[23]_i_1235_n_0\
    );
\rgb_out[23]_i_1236\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \SC_U/local_y\(6),
      I1 => \SC_U/local_y\(7),
      O => \rgb_out[23]_i_1236_n_0\
    );
\rgb_out[23]_i_1237\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \SC_U/local_y\(4),
      I1 => \SC_U/local_y\(5),
      O => \rgb_out[23]_i_1237_n_0\
    );
\rgb_out[23]_i_1238\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \SC_U/local_y\(2),
      I1 => \SC_U/local_y\(3),
      O => \rgb_out[23]_i_1238_n_0\
    );
\rgb_out[23]_i_1239\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => pixel_y(0),
      I1 => \SC_U/local_y\(1),
      O => \rgb_out[23]_i_1239_n_0\
    );
\rgb_out[23]_i_1240\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \SC_U/local_y\(7),
      I1 => \SC_U/local_y\(6),
      O => \rgb_out[23]_i_1240_n_0\
    );
\rgb_out[23]_i_1241\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \SC_U/local_y\(5),
      I1 => \SC_U/local_y\(4),
      O => \rgb_out[23]_i_1241_n_0\
    );
\rgb_out[23]_i_1242\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \SC_U/local_y\(3),
      I1 => \SC_U/local_y\(2),
      O => \rgb_out[23]_i_1242_n_0\
    );
\rgb_out[23]_i_1243\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \SC_U/local_y\(1),
      I1 => pixel_y(0),
      O => \rgb_out[23]_i_1243_n_0\
    );
\rgb_out[23]_i_1245\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \SC_U/local_y\(10),
      I1 => \SC_U/local_y\(11),
      O => \rgb_out[23]_i_1245_n_0\
    );
\rgb_out[23]_i_1246\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \SC_U/local_y\(8),
      I1 => \SC_U/local_y\(9),
      O => \rgb_out[23]_i_1246_n_0\
    );
\rgb_out[23]_i_1247\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \SC_U/local_y\(11),
      I1 => \SC_U/local_y\(10),
      O => \rgb_out[23]_i_1247_n_0\
    );
\rgb_out[23]_i_1248\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \SC_U/local_y\(9),
      I1 => \SC_U/local_y\(8),
      O => \rgb_out[23]_i_1248_n_0\
    );
\rgb_out[23]_i_1250\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \rgb_out_reg[23]_i_716_n_3\,
      O => \rgb_out[23]_i_1250_n_0\
    );
\rgb_out[23]_i_1251\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \SC_U/local_x\(11),
      I1 => \SC_U/local_x\(10),
      O => \rgb_out[23]_i_1251_n_0\
    );
\rgb_out[23]_i_1252\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \SC_U/local_x\(9),
      I1 => \SC_U/local_x\(8),
      O => \rgb_out[23]_i_1252_n_0\
    );
\rgb_out[23]_i_1259\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \rgb_out_reg[23]_i_720_n_0\,
      O => \rgb_out[23]_i_1259_n_0\
    );
\rgb_out[23]_i_1260\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \SC_U/local_y\(11),
      I1 => \SC_U/local_y\(10),
      O => \rgb_out[23]_i_1260_n_0\
    );
\rgb_out[23]_i_1261\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \SC_U/local_y\(9),
      I1 => \SC_U/local_y\(8),
      O => \rgb_out[23]_i_1261_n_0\
    );
\rgb_out[23]_i_1263\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \SC_U/local_y\(10),
      I1 => \SC_U/local_y\(11),
      O => \rgb_out[23]_i_1263_n_0\
    );
\rgb_out[23]_i_1264\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \SC_U/local_y\(8),
      I1 => \SC_U/local_y\(9),
      O => \rgb_out[23]_i_1264_n_0\
    );
\rgb_out[23]_i_1265\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \SC_U/local_y\(11),
      I1 => \SC_U/local_y\(10),
      O => \rgb_out[23]_i_1265_n_0\
    );
\rgb_out[23]_i_1266\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \SC_U/local_y\(9),
      I1 => \SC_U/local_y\(8),
      O => \rgb_out[23]_i_1266_n_0\
    );
\rgb_out[23]_i_1268\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \rgb_out_reg[23]_i_720_n_0\,
      O => \rgb_out[23]_i_1268_n_0\
    );
\rgb_out[23]_i_1269\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \SC_U/local_y\(11),
      I1 => \SC_U/local_y\(10),
      O => \rgb_out[23]_i_1269_n_0\
    );
\rgb_out[23]_i_1270\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \SC_U/local_y\(9),
      I1 => \SC_U/local_y\(8),
      O => \rgb_out[23]_i_1270_n_0\
    );
\rgb_out[23]_i_1272\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \rgb_out_reg[23]_i_720_n_0\,
      O => \rgb_out[23]_i_1272_n_0\
    );
\rgb_out[23]_i_1273\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \SC_U/local_y\(11),
      I1 => \SC_U/local_y\(10),
      O => \rgb_out[23]_i_1273_n_0\
    );
\rgb_out[23]_i_1274\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \SC_U/local_y\(9),
      I1 => \SC_U/local_y\(8),
      O => \rgb_out[23]_i_1274_n_0\
    );
\rgb_out[23]_i_1276\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \SC_U/local_y\(10),
      I1 => \SC_U/local_y\(11),
      O => \rgb_out[23]_i_1276_n_0\
    );
\rgb_out[23]_i_1277\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \SC_U/local_y\(8),
      I1 => \SC_U/local_y\(9),
      O => \rgb_out[23]_i_1277_n_0\
    );
\rgb_out[23]_i_1278\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \SC_U/local_y\(11),
      I1 => \SC_U/local_y\(10),
      O => \rgb_out[23]_i_1278_n_0\
    );
\rgb_out[23]_i_1279\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \SC_U/local_y\(9),
      I1 => \SC_U/local_y\(8),
      O => \rgb_out[23]_i_1279_n_0\
    );
\rgb_out[23]_i_1281\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \rgb_out_reg[23]_i_716_n_3\,
      O => \rgb_out[23]_i_1281_n_0\
    );
\rgb_out[23]_i_1282\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \SC_U/local_x\(11),
      I1 => \SC_U/local_x\(10),
      O => \rgb_out[23]_i_1282_n_0\
    );
\rgb_out[23]_i_1283\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \SC_U/local_x\(9),
      I1 => \SC_U/local_x\(8),
      O => \rgb_out[23]_i_1283_n_0\
    );
\rgb_out[23]_i_1285\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \SC_U/local_x\(10),
      I1 => \SC_U/local_x\(11),
      O => \rgb_out[23]_i_1285_n_0\
    );
\rgb_out[23]_i_1286\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \SC_U/local_x\(8),
      I1 => \SC_U/local_x\(9),
      O => \rgb_out[23]_i_1286_n_0\
    );
\rgb_out[23]_i_1287\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \SC_U/local_x\(11),
      I1 => \SC_U/local_x\(10),
      O => \rgb_out[23]_i_1287_n_0\
    );
\rgb_out[23]_i_1288\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \SC_U/local_x\(9),
      I1 => \SC_U/local_x\(8),
      O => \rgb_out[23]_i_1288_n_0\
    );
\rgb_out[23]_i_1290\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \rgb_out_reg[23]_i_720_n_0\,
      O => \rgb_out[23]_i_1290_n_0\
    );
\rgb_out[23]_i_1291\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \SC_U/local_y\(11),
      I1 => \SC_U/local_y\(10),
      O => \rgb_out[23]_i_1291_n_0\
    );
\rgb_out[23]_i_1292\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \SC_U/local_y\(9),
      I1 => \SC_U/local_y\(8),
      O => \rgb_out[23]_i_1292_n_0\
    );
\rgb_out[23]_i_1294\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \SC_U/local_y\(10),
      I1 => \SC_U/local_y\(11),
      O => \rgb_out[23]_i_1294_n_0\
    );
\rgb_out[23]_i_1295\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \SC_U/local_y\(8),
      I1 => \SC_U/local_y\(9),
      O => \rgb_out[23]_i_1295_n_0\
    );
\rgb_out[23]_i_1296\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \SC_U/local_y\(11),
      I1 => \SC_U/local_y\(10),
      O => \rgb_out[23]_i_1296_n_0\
    );
\rgb_out[23]_i_1297\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \SC_U/local_y\(9),
      I1 => \SC_U/local_y\(8),
      O => \rgb_out[23]_i_1297_n_0\
    );
\rgb_out[23]_i_1299\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => U0_n_15,
      O => \rgb_out[23]_i_1299_n_0\
    );
\rgb_out[23]_i_1301\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \SC_D/local_y\(11),
      I1 => \SC_D/local_y\(10),
      O => \rgb_out[23]_i_1301_n_0\
    );
\rgb_out[23]_i_1302\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \SC_D/local_y\(9),
      I1 => \SC_D/local_y\(8),
      O => \rgb_out[23]_i_1302_n_0\
    );
\rgb_out[23]_i_1304\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \SC_D/local_y\(10),
      I1 => \SC_D/local_y\(11),
      O => \rgb_out[23]_i_1304_n_0\
    );
\rgb_out[23]_i_1305\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \SC_D/local_y\(8),
      I1 => \SC_D/local_y\(9),
      O => \rgb_out[23]_i_1305_n_0\
    );
\rgb_out[23]_i_1306\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \SC_D/local_y\(11),
      I1 => \SC_D/local_y\(10),
      O => \rgb_out[23]_i_1306_n_0\
    );
\rgb_out[23]_i_1307\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \SC_D/local_y\(9),
      I1 => \SC_D/local_y\(8),
      O => \rgb_out[23]_i_1307_n_0\
    );
\rgb_out[23]_i_1314\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \rgb_out_reg[23]_i_761_n_3\,
      O => \rgb_out[23]_i_1314_n_0\
    );
\rgb_out[23]_i_1315\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \SC_D/local_x\(11),
      I1 => \SC_D/local_x\(10),
      O => \rgb_out[23]_i_1315_n_0\
    );
\rgb_out[23]_i_1316\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \SC_D/local_x\(9),
      I1 => \SC_D/local_x\(8),
      O => \rgb_out[23]_i_1316_n_0\
    );
\rgb_out[23]_i_1327\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \SC_D/local_y\(10),
      I1 => \SC_D/local_y\(11),
      O => \rgb_out[23]_i_1327_n_0\
    );
\rgb_out[23]_i_1328\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \SC_D/local_y\(8),
      I1 => \SC_D/local_y\(9),
      O => \rgb_out[23]_i_1328_n_0\
    );
\rgb_out[23]_i_1329\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \SC_D/local_y\(11),
      I1 => \SC_D/local_y\(10),
      O => \rgb_out[23]_i_1329_n_0\
    );
\rgb_out[23]_i_1330\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \SC_D/local_y\(9),
      I1 => \SC_D/local_y\(8),
      O => \rgb_out[23]_i_1330_n_0\
    );
\rgb_out[23]_i_1335\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \SC_D/local_x\(6),
      I1 => \SC_D/local_x\(7),
      O => \rgb_out[23]_i_1335_n_0\
    );
\rgb_out[23]_i_1337\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \SC_D/local_x\(0),
      I1 => \SC_D/local_x\(1),
      O => \rgb_out[23]_i_1337_n_0\
    );
\rgb_out[23]_i_1338\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \SC_D/local_x\(7),
      I1 => \SC_D/local_x\(6),
      O => \rgb_out[23]_i_1338_n_0\
    );
\rgb_out[23]_i_1339\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \SC_D/local_x\(4),
      I1 => \SC_D/local_x\(5),
      O => \rgb_out[23]_i_1339_n_0\
    );
\rgb_out[23]_i_1340\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \SC_D/local_x\(3),
      I1 => \SC_D/local_x\(2),
      O => \rgb_out[23]_i_1340_n_0\
    );
\rgb_out[23]_i_1341\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \SC_D/local_x\(1),
      I1 => \SC_D/local_x\(0),
      O => \rgb_out[23]_i_1341_n_0\
    );
\rgb_out[23]_i_1343\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \SC_D/local_x\(3),
      I1 => \SC_D/local_x\(2),
      O => \rgb_out[23]_i_1343_n_0\
    );
\rgb_out[23]_i_1344\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \SC_D/local_x\(1),
      O => \rgb_out[23]_i_1344_n_0\
    );
\rgb_out[23]_i_1345\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \SC_D/local_x\(7),
      I1 => \SC_D/local_x\(6),
      O => \rgb_out[23]_i_1345_n_0\
    );
\rgb_out[23]_i_1346\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \SC_D/local_x\(5),
      I1 => \SC_D/local_x\(4),
      O => \rgb_out[23]_i_1346_n_0\
    );
\rgb_out[23]_i_1347\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \SC_D/local_x\(2),
      I1 => \SC_D/local_x\(3),
      O => \rgb_out[23]_i_1347_n_0\
    );
\rgb_out[23]_i_1348\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \SC_D/local_x\(1),
      I1 => \SC_D/local_x\(0),
      O => \rgb_out[23]_i_1348_n_0\
    );
\rgb_out[23]_i_1350\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \SC_D/local_y\(10),
      I1 => \SC_D/local_y\(11),
      O => \rgb_out[23]_i_1350_n_0\
    );
\rgb_out[23]_i_1351\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \SC_D/local_y\(8),
      I1 => \SC_D/local_y\(9),
      O => \rgb_out[23]_i_1351_n_0\
    );
\rgb_out[23]_i_1352\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \SC_D/local_y\(11),
      I1 => \SC_D/local_y\(10),
      O => \rgb_out[23]_i_1352_n_0\
    );
\rgb_out[23]_i_1353\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \SC_D/local_y\(9),
      I1 => \SC_D/local_y\(8),
      O => \rgb_out[23]_i_1353_n_0\
    );
\rgb_out[23]_i_1355\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \SC_D/local_x\(10),
      I1 => \SC_D/local_x\(11),
      O => \rgb_out[23]_i_1355_n_0\
    );
\rgb_out[23]_i_1356\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \SC_D/local_x\(8),
      I1 => \SC_D/local_x\(9),
      O => \rgb_out[23]_i_1356_n_0\
    );
\rgb_out[23]_i_1357\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \SC_D/local_x\(11),
      I1 => \SC_D/local_x\(10),
      O => \rgb_out[23]_i_1357_n_0\
    );
\rgb_out[23]_i_1358\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \SC_D/local_x\(9),
      I1 => \SC_D/local_x\(8),
      O => \rgb_out[23]_i_1358_n_0\
    );
\rgb_out[23]_i_1360\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => U0_n_15,
      O => \SC_D/local_y\(12)
    );
\rgb_out[23]_i_1361\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \SC_D/local_y\(11),
      I1 => \SC_D/local_y\(10),
      O => \rgb_out[23]_i_1361_n_0\
    );
\rgb_out[23]_i_1363\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \rgb_out_reg[23]_i_761_n_3\,
      O => \SC_D/local_x\(12)
    );
\rgb_out[23]_i_1364\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \SC_D/local_x\(11),
      I1 => \SC_D/local_x\(10),
      O => \rgb_out[23]_i_1364_n_0\
    );
\rgb_out[23]_i_1365\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \TM_D/local_y\(3),
      I1 => \TM_D/local_y\(2),
      O => \rgb_out[23]_i_1365_n_0\
    );
\rgb_out[23]_i_1366\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \TM_D/local_y\(1),
      O => \rgb_out[23]_i_1366_n_0\
    );
\rgb_out[23]_i_1367\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \TM_D/local_y\(7),
      I1 => \TM_D/local_y\(6),
      O => \rgb_out[23]_i_1367_n_0\
    );
\rgb_out[23]_i_1368\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \TM_D/local_y\(5),
      I1 => \TM_D/local_y\(4),
      O => \rgb_out[23]_i_1368_n_0\
    );
\rgb_out[23]_i_1369\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \TM_D/local_y\(2),
      I1 => \TM_D/local_y\(3),
      O => \rgb_out[23]_i_1369_n_0\
    );
\rgb_out[23]_i_1370\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \TM_D/local_y\(1),
      I1 => pixel_y(0),
      O => \rgb_out[23]_i_1370_n_0\
    );
\rgb_out[23]_i_1372\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_y(11),
      O => \rgb_out[23]_i_1372_n_0\
    );
\rgb_out[23]_i_1373\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_y(10),
      O => \rgb_out[23]_i_1373_n_0\
    );
\rgb_out[23]_i_1374\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_y(9),
      O => \rgb_out[23]_i_1374_n_0\
    );
\rgb_out[23]_i_1375\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \TM_D/local_y\(6),
      I1 => \TM_D/local_y\(7),
      O => \rgb_out[23]_i_1375_n_0\
    );
\rgb_out[23]_i_1377\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => pixel_y(0),
      I1 => \TM_D/local_y\(1),
      O => \rgb_out[23]_i_1377_n_0\
    );
\rgb_out[23]_i_1378\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \TM_D/local_y\(7),
      I1 => \TM_D/local_y\(6),
      O => \rgb_out[23]_i_1378_n_0\
    );
\rgb_out[23]_i_1379\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \TM_D/local_y\(5),
      I1 => \TM_D/local_y\(4),
      O => \rgb_out[23]_i_1379_n_0\
    );
\rgb_out[23]_i_1380\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \TM_D/local_y\(2),
      I1 => \TM_D/local_y\(3),
      O => \rgb_out[23]_i_1380_n_0\
    );
\rgb_out[23]_i_1381\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \TM_D/local_y\(1),
      I1 => pixel_y(0),
      O => \rgb_out[23]_i_1381_n_0\
    );
\rgb_out[23]_i_1389\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \TM_D/local_x\(5),
      I1 => \TM_D/local_x\(4),
      O => \rgb_out[23]_i_1389_n_0\
    );
\rgb_out[23]_i_1390\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"7"
    )
        port map (
      I0 => \TM_D/local_x\(2),
      I1 => \TM_D/local_x\(3),
      O => \rgb_out[23]_i_1390_n_0\
    );
\rgb_out[23]_i_1391\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_x(1),
      O => \rgb_out[23]_i_1391_n_0\
    );
\rgb_out[23]_i_1392\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \TM_D/local_x\(7),
      I1 => \TM_D/local_x\(6),
      O => \rgb_out[23]_i_1392_n_0\
    );
\rgb_out[23]_i_1393\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \TM_D/local_x\(4),
      I1 => \TM_D/local_x\(5),
      O => \rgb_out[23]_i_1393_n_0\
    );
\rgb_out[23]_i_1394\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \TM_D/local_x\(3),
      I1 => \TM_D/local_x\(2),
      O => \rgb_out[23]_i_1394_n_0\
    );
\rgb_out[23]_i_1395\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => pixel_x(1),
      I1 => pixel_x(0),
      O => \rgb_out[23]_i_1395_n_0\
    );
\rgb_out[23]_i_1396\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \TM_D/local_y\(6),
      I1 => \TM_D/local_y\(7),
      O => \rgb_out[23]_i_1396_n_0\
    );
\rgb_out[23]_i_1397\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \TM_D/local_y\(4),
      I1 => \TM_D/local_y\(5),
      O => \rgb_out[23]_i_1397_n_0\
    );
\rgb_out[23]_i_1398\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => pixel_y(0),
      I1 => \TM_D/local_y\(1),
      O => \rgb_out[23]_i_1398_n_0\
    );
\rgb_out[23]_i_1399\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \TM_D/local_y\(7),
      I1 => \TM_D/local_y\(6),
      O => \rgb_out[23]_i_1399_n_0\
    );
\rgb_out[23]_i_1400\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \TM_D/local_y\(5),
      I1 => \TM_D/local_y\(4),
      O => \rgb_out[23]_i_1400_n_0\
    );
\rgb_out[23]_i_1401\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \TM_D/local_y\(2),
      I1 => \TM_D/local_y\(3),
      O => \rgb_out[23]_i_1401_n_0\
    );
\rgb_out[23]_i_1402\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \TM_D/local_y\(1),
      I1 => pixel_y(0),
      O => \rgb_out[23]_i_1402_n_0\
    );
\rgb_out[23]_i_1403\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \TM_D/local_y\(5),
      I1 => \TM_D/local_y\(4),
      O => \rgb_out[23]_i_1403_n_0\
    );
\rgb_out[23]_i_1404\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"7"
    )
        port map (
      I0 => \TM_D/local_y\(2),
      I1 => \TM_D/local_y\(3),
      O => \rgb_out[23]_i_1404_n_0\
    );
\rgb_out[23]_i_1405\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \TM_D/local_y\(1),
      O => \rgb_out[23]_i_1405_n_0\
    );
\rgb_out[23]_i_1406\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \TM_D/local_y\(7),
      I1 => \TM_D/local_y\(6),
      O => \rgb_out[23]_i_1406_n_0\
    );
\rgb_out[23]_i_1407\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \TM_D/local_y\(4),
      I1 => \TM_D/local_y\(5),
      O => \rgb_out[23]_i_1407_n_0\
    );
\rgb_out[23]_i_1408\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \TM_D/local_y\(3),
      I1 => \TM_D/local_y\(2),
      O => \rgb_out[23]_i_1408_n_0\
    );
\rgb_out[23]_i_1409\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \TM_D/local_y\(1),
      I1 => pixel_y(0),
      O => \rgb_out[23]_i_1409_n_0\
    );
\rgb_out[23]_i_1410\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \TM_D/local_y\(6),
      I1 => \TM_D/local_y\(7),
      O => \rgb_out[23]_i_1410_n_0\
    );
\rgb_out[23]_i_1411\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => pixel_y(0),
      I1 => \TM_D/local_y\(1),
      O => \rgb_out[23]_i_1411_n_0\
    );
\rgb_out[23]_i_1412\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \TM_D/local_y\(7),
      I1 => \TM_D/local_y\(6),
      O => \rgb_out[23]_i_1412_n_0\
    );
\rgb_out[23]_i_1413\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \TM_D/local_y\(4),
      I1 => \TM_D/local_y\(5),
      O => \rgb_out[23]_i_1413_n_0\
    );
\rgb_out[23]_i_1414\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \TM_D/local_y\(3),
      I1 => \TM_D/local_y\(2),
      O => \rgb_out[23]_i_1414_n_0\
    );
\rgb_out[23]_i_1415\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \TM_D/local_y\(1),
      I1 => pixel_y(0),
      O => \rgb_out[23]_i_1415_n_0\
    );
\rgb_out[23]_i_1416\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"7"
    )
        port map (
      I0 => \TM_D/local_y\(4),
      I1 => \TM_D/local_y\(5),
      O => \rgb_out[23]_i_1416_n_0\
    );
\rgb_out[23]_i_1417\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \TM_D/local_y\(3),
      I1 => \TM_D/local_y\(2),
      O => \rgb_out[23]_i_1417_n_0\
    );
\rgb_out[23]_i_1418\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \TM_D/local_y\(1),
      O => \rgb_out[23]_i_1418_n_0\
    );
\rgb_out[23]_i_1419\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \TM_D/local_y\(7),
      I1 => \TM_D/local_y\(6),
      O => \rgb_out[23]_i_1419_n_0\
    );
\rgb_out[23]_i_1420\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \TM_D/local_y\(5),
      I1 => \TM_D/local_y\(4),
      O => \rgb_out[23]_i_1420_n_0\
    );
\rgb_out[23]_i_1421\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \TM_D/local_y\(2),
      I1 => \TM_D/local_y\(3),
      O => \rgb_out[23]_i_1421_n_0\
    );
\rgb_out[23]_i_1422\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \TM_D/local_y\(1),
      I1 => pixel_y(0),
      O => \rgb_out[23]_i_1422_n_0\
    );
\rgb_out[23]_i_1423\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_x(3),
      O => \rgb_out[23]_i_1423_n_0\
    );
\rgb_out[23]_i_1424\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_x(9),
      O => \rgb_out[23]_i_1424_n_0\
    );
\rgb_out[23]_i_1425\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_x(7),
      O => \rgb_out[23]_i_1425_n_0\
    );
\rgb_out[23]_i_1426\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \TM_D/local_y\(6),
      I1 => \TM_D/local_y\(7),
      O => \rgb_out[23]_i_1426_n_0\
    );
\rgb_out[23]_i_1427\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \TM_D/local_y\(4),
      I1 => \TM_D/local_y\(5),
      O => \rgb_out[23]_i_1427_n_0\
    );
\rgb_out[23]_i_1428\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \TM_D/local_y\(2),
      I1 => \TM_D/local_y\(3),
      O => \rgb_out[23]_i_1428_n_0\
    );
\rgb_out[23]_i_1429\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \TM_D/local_y\(1),
      I1 => pixel_y(0),
      O => \rgb_out[23]_i_1429_n_0\
    );
\rgb_out[23]_i_1430\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \TM_D/local_y\(7),
      I1 => \TM_D/local_y\(6),
      O => \rgb_out[23]_i_1430_n_0\
    );
\rgb_out[23]_i_1431\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \TM_D/local_y\(5),
      I1 => \TM_D/local_y\(4),
      O => \rgb_out[23]_i_1431_n_0\
    );
\rgb_out[23]_i_1432\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \TM_D/local_y\(3),
      I1 => \TM_D/local_y\(2),
      O => \rgb_out[23]_i_1432_n_0\
    );
\rgb_out[23]_i_1433\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_y(0),
      I1 => \TM_D/local_y\(1),
      O => \rgb_out[23]_i_1433_n_0\
    );
\rgb_out[23]_i_1434\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \TM_D/local_x\(6),
      I1 => \TM_D/local_x\(7),
      O => \rgb_out[23]_i_1434_n_0\
    );
\rgb_out[23]_i_1435\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \TM_D/local_x\(4),
      I1 => \TM_D/local_x\(5),
      O => \rgb_out[23]_i_1435_n_0\
    );
\rgb_out[23]_i_1436\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \TM_D/local_x\(2),
      I1 => \TM_D/local_x\(3),
      O => \rgb_out[23]_i_1436_n_0\
    );
\rgb_out[23]_i_1437\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => pixel_x(1),
      I1 => pixel_x(0),
      O => \rgb_out[23]_i_1437_n_0\
    );
\rgb_out[23]_i_1438\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \TM_D/local_x\(7),
      I1 => \TM_D/local_x\(6),
      O => \rgb_out[23]_i_1438_n_0\
    );
\rgb_out[23]_i_1439\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \TM_D/local_x\(5),
      I1 => \TM_D/local_x\(4),
      O => \rgb_out[23]_i_1439_n_0\
    );
\rgb_out[23]_i_1440\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \TM_D/local_x\(3),
      I1 => \TM_D/local_x\(2),
      O => \rgb_out[23]_i_1440_n_0\
    );
\rgb_out[23]_i_1441\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_x(0),
      I1 => pixel_x(1),
      O => \rgb_out[23]_i_1441_n_0\
    );
\rgb_out[23]_i_1442\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"7"
    )
        port map (
      I0 => \TM_D/local_y\(4),
      I1 => \TM_D/local_y\(5),
      O => \rgb_out[23]_i_1442_n_0\
    );
\rgb_out[23]_i_1443\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"7"
    )
        port map (
      I0 => \TM_D/local_y\(2),
      I1 => \TM_D/local_y\(3),
      O => \rgb_out[23]_i_1443_n_0\
    );
\rgb_out[23]_i_1444\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \TM_D/local_y\(9),
      I1 => \TM_D/local_y\(8),
      O => \rgb_out[23]_i_1444_n_0\
    );
\rgb_out[23]_i_1445\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \TM_D/local_y\(7),
      I1 => \TM_D/local_y\(6),
      O => \rgb_out[23]_i_1445_n_0\
    );
\rgb_out[23]_i_1446\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \TM_D/local_y\(5),
      I1 => \TM_D/local_y\(4),
      O => \rgb_out[23]_i_1446_n_0\
    );
\rgb_out[23]_i_1447\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \TM_D/local_y\(3),
      I1 => \TM_D/local_y\(2),
      O => \rgb_out[23]_i_1447_n_0\
    );
\rgb_out[23]_i_1448\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \TM_D/local_x\(5),
      O => \rgb_out[23]_i_1448_n_0\
    );
\rgb_out[23]_i_1449\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \TM_D/local_x\(3),
      I1 => \TM_D/local_x\(2),
      O => \rgb_out[23]_i_1449_n_0\
    );
\rgb_out[23]_i_1450\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \TM_D/local_x\(9),
      I1 => \TM_D/local_x\(8),
      O => \rgb_out[23]_i_1450_n_0\
    );
\rgb_out[23]_i_1451\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \TM_D/local_x\(7),
      I1 => \TM_D/local_x\(6),
      O => \rgb_out[23]_i_1451_n_0\
    );
\rgb_out[23]_i_1452\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \TM_D/local_x\(5),
      I1 => \TM_D/local_x\(4),
      O => \rgb_out[23]_i_1452_n_0\
    );
\rgb_out[23]_i_1453\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \TM_D/local_x\(2),
      I1 => \TM_D/local_x\(3),
      O => \rgb_out[23]_i_1453_n_0\
    );
\rgb_out[23]_i_1467\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_x(3),
      I1 => pixel_x(2),
      O => \rgb_out[23]_i_1467_n_0\
    );
\rgb_out[23]_i_1468\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_x(1),
      O => \rgb_out[23]_i_1468_n_0\
    );
\rgb_out[23]_i_1471\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => pixel_x(2),
      I1 => pixel_x(3),
      O => \rgb_out[23]_i_1471_n_0\
    );
\rgb_out[23]_i_1472\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => pixel_x(1),
      I1 => pixel_x(0),
      O => \rgb_out[23]_i_1472_n_0\
    );
\rgb_out[23]_i_1497\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_D/local_y\(3),
      I1 => \REC_D/local_y\(2),
      O => \rgb_out[23]_i_1497_n_0\
    );
\rgb_out[23]_i_1498\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_D/local_y\(1),
      O => \rgb_out[23]_i_1498_n_0\
    );
\rgb_out[23]_i_1499\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_D/local_y\(7),
      I1 => \REC_D/local_y\(6),
      O => \rgb_out[23]_i_1499_n_0\
    );
\rgb_out[23]_i_1500\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_D/local_y\(5),
      I1 => \REC_D/local_y\(4),
      O => \rgb_out[23]_i_1500_n_0\
    );
\rgb_out[23]_i_1501\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \REC_D/local_y\(2),
      I1 => \REC_D/local_y\(3),
      O => \rgb_out[23]_i_1501_n_0\
    );
\rgb_out[23]_i_1502\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => pixel_y(0),
      I1 => \REC_D/local_y\(1),
      O => \rgb_out[23]_i_1502_n_0\
    );
\rgb_out[23]_i_1504\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_y(11),
      O => \rgb_out[23]_i_1504_n_0\
    );
\rgb_out[23]_i_1505\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_y(10),
      O => \rgb_out[23]_i_1505_n_0\
    );
\rgb_out[23]_i_1506\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_y(9),
      O => \rgb_out[23]_i_1506_n_0\
    );
\rgb_out[23]_i_1507\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \REC_D/local_y\(6),
      I1 => \REC_D/local_y\(7),
      O => \rgb_out[23]_i_1507_n_0\
    );
\rgb_out[23]_i_1509\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \REC_D/local_y\(1),
      I1 => pixel_y(0),
      O => \rgb_out[23]_i_1509_n_0\
    );
\rgb_out[23]_i_1510\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_D/local_y\(7),
      I1 => \REC_D/local_y\(6),
      O => \rgb_out[23]_i_1510_n_0\
    );
\rgb_out[23]_i_1511\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \REC_D/local_y\(5),
      I1 => \REC_D/local_y\(4),
      O => \rgb_out[23]_i_1511_n_0\
    );
\rgb_out[23]_i_1512\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \REC_D/local_y\(2),
      I1 => \REC_D/local_y\(3),
      O => \rgb_out[23]_i_1512_n_0\
    );
\rgb_out[23]_i_1513\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => pixel_y(0),
      I1 => \REC_D/local_y\(1),
      O => \rgb_out[23]_i_1513_n_0\
    );
\rgb_out[23]_i_1514\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \REC_D/local_x\(6),
      I1 => \REC_D/local_x\(7),
      O => \rgb_out[23]_i_1514_n_0\
    );
\rgb_out[23]_i_1515\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \REC_D/local_x\(4),
      I1 => \REC_D/local_x\(5),
      O => \rgb_out[23]_i_1515_n_0\
    );
\rgb_out[23]_i_1517\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \REC_D/local_x\(1),
      I1 => pixel_x(0),
      O => \rgb_out[23]_i_1517_n_0\
    );
\rgb_out[23]_i_1518\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_D/local_x\(7),
      I1 => \REC_D/local_x\(6),
      O => \rgb_out[23]_i_1518_n_0\
    );
\rgb_out[23]_i_1519\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_D/local_x\(5),
      I1 => \REC_D/local_x\(4),
      O => \rgb_out[23]_i_1519_n_0\
    );
\rgb_out[23]_i_1520\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \REC_D/local_x\(2),
      I1 => \REC_D/local_x\(3),
      O => \rgb_out[23]_i_1520_n_0\
    );
\rgb_out[23]_i_1521\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => pixel_x(0),
      I1 => \REC_D/local_x\(1),
      O => \rgb_out[23]_i_1521_n_0\
    );
\rgb_out[23]_i_1522\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_D/local_x\(5),
      I1 => \REC_D/local_x\(4),
      O => \rgb_out[23]_i_1522_n_0\
    );
\rgb_out[23]_i_1523\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"7"
    )
        port map (
      I0 => \REC_D/local_x\(2),
      I1 => \REC_D/local_x\(3),
      O => \rgb_out[23]_i_1523_n_0\
    );
\rgb_out[23]_i_1524\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_D/local_x\(1),
      O => \rgb_out[23]_i_1524_n_0\
    );
\rgb_out[23]_i_1525\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_D/local_x\(7),
      I1 => \REC_D/local_x\(6),
      O => \rgb_out[23]_i_1525_n_0\
    );
\rgb_out[23]_i_1526\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \REC_D/local_x\(4),
      I1 => \REC_D/local_x\(5),
      O => \rgb_out[23]_i_1526_n_0\
    );
\rgb_out[23]_i_1527\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \REC_D/local_x\(3),
      I1 => \REC_D/local_x\(2),
      O => \rgb_out[23]_i_1527_n_0\
    );
\rgb_out[23]_i_1528\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => pixel_x(0),
      I1 => \REC_D/local_x\(1),
      O => \rgb_out[23]_i_1528_n_0\
    );
\rgb_out[23]_i_1529\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \REC_D/local_y\(6),
      I1 => \REC_D/local_y\(7),
      O => \rgb_out[23]_i_1529_n_0\
    );
\rgb_out[23]_i_1530\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \REC_D/local_y\(4),
      I1 => \REC_D/local_y\(5),
      O => \rgb_out[23]_i_1530_n_0\
    );
\rgb_out[23]_i_1531\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \REC_D/local_y\(1),
      I1 => pixel_y(0),
      O => \rgb_out[23]_i_1531_n_0\
    );
\rgb_out[23]_i_1532\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_D/local_y\(7),
      I1 => \REC_D/local_y\(6),
      O => \rgb_out[23]_i_1532_n_0\
    );
\rgb_out[23]_i_1533\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_D/local_y\(5),
      I1 => \REC_D/local_y\(4),
      O => \rgb_out[23]_i_1533_n_0\
    );
\rgb_out[23]_i_1534\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \REC_D/local_y\(2),
      I1 => \REC_D/local_y\(3),
      O => \rgb_out[23]_i_1534_n_0\
    );
\rgb_out[23]_i_1535\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => pixel_y(0),
      I1 => \REC_D/local_y\(1),
      O => \rgb_out[23]_i_1535_n_0\
    );
\rgb_out[23]_i_1536\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_D/local_y\(5),
      I1 => \REC_D/local_y\(4),
      O => \rgb_out[23]_i_1536_n_0\
    );
\rgb_out[23]_i_1537\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"7"
    )
        port map (
      I0 => \REC_D/local_y\(2),
      I1 => \REC_D/local_y\(3),
      O => \rgb_out[23]_i_1537_n_0\
    );
\rgb_out[23]_i_1538\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_D/local_y\(1),
      O => \rgb_out[23]_i_1538_n_0\
    );
\rgb_out[23]_i_1539\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_D/local_y\(7),
      I1 => \REC_D/local_y\(6),
      O => \rgb_out[23]_i_1539_n_0\
    );
\rgb_out[23]_i_1540\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \REC_D/local_y\(4),
      I1 => \REC_D/local_y\(5),
      O => \rgb_out[23]_i_1540_n_0\
    );
\rgb_out[23]_i_1541\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \REC_D/local_y\(3),
      I1 => \REC_D/local_y\(2),
      O => \rgb_out[23]_i_1541_n_0\
    );
\rgb_out[23]_i_1542\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => pixel_y(0),
      I1 => \REC_D/local_y\(1),
      O => \rgb_out[23]_i_1542_n_0\
    );
\rgb_out[23]_i_1543\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \REC_D/local_y\(6),
      I1 => \REC_D/local_y\(7),
      O => \rgb_out[23]_i_1543_n_0\
    );
\rgb_out[23]_i_1544\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \REC_D/local_y\(1),
      I1 => pixel_y(0),
      O => \rgb_out[23]_i_1544_n_0\
    );
\rgb_out[23]_i_1545\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_D/local_y\(7),
      I1 => \REC_D/local_y\(6),
      O => \rgb_out[23]_i_1545_n_0\
    );
\rgb_out[23]_i_1546\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \REC_D/local_y\(4),
      I1 => \REC_D/local_y\(5),
      O => \rgb_out[23]_i_1546_n_0\
    );
\rgb_out[23]_i_1547\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \REC_D/local_y\(3),
      I1 => \REC_D/local_y\(2),
      O => \rgb_out[23]_i_1547_n_0\
    );
\rgb_out[23]_i_1548\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => pixel_y(0),
      I1 => \REC_D/local_y\(1),
      O => \rgb_out[23]_i_1548_n_0\
    );
\rgb_out[23]_i_1549\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"7"
    )
        port map (
      I0 => \REC_D/local_y\(4),
      I1 => \REC_D/local_y\(5),
      O => \rgb_out[23]_i_1549_n_0\
    );
\rgb_out[23]_i_1550\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_D/local_y\(3),
      I1 => \REC_D/local_y\(2),
      O => \rgb_out[23]_i_1550_n_0\
    );
\rgb_out[23]_i_1551\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_D/local_y\(1),
      O => \rgb_out[23]_i_1551_n_0\
    );
\rgb_out[23]_i_1552\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_D/local_y\(7),
      I1 => \REC_D/local_y\(6),
      O => \rgb_out[23]_i_1552_n_0\
    );
\rgb_out[23]_i_1553\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \REC_D/local_y\(5),
      I1 => \REC_D/local_y\(4),
      O => \rgb_out[23]_i_1553_n_0\
    );
\rgb_out[23]_i_1554\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \REC_D/local_y\(2),
      I1 => \REC_D/local_y\(3),
      O => \rgb_out[23]_i_1554_n_0\
    );
\rgb_out[23]_i_1555\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => pixel_y(0),
      I1 => \REC_D/local_y\(1),
      O => \rgb_out[23]_i_1555_n_0\
    );
\rgb_out[23]_i_1556\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_x(8),
      O => \rgb_out[23]_i_1556_n_0\
    );
\rgb_out[23]_i_1557\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_x(6),
      O => \rgb_out[23]_i_1557_n_0\
    );
\rgb_out[23]_i_1558\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_x(5),
      O => \rgb_out[23]_i_1558_n_0\
    );
\rgb_out[23]_i_1559\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \REC_D/local_y\(6),
      I1 => \REC_D/local_y\(7),
      O => \rgb_out[23]_i_1559_n_0\
    );
\rgb_out[23]_i_1560\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \REC_D/local_y\(4),
      I1 => \REC_D/local_y\(5),
      O => \rgb_out[23]_i_1560_n_0\
    );
\rgb_out[23]_i_1561\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \REC_D/local_y\(2),
      I1 => \REC_D/local_y\(3),
      O => \rgb_out[23]_i_1561_n_0\
    );
\rgb_out[23]_i_1562\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"B"
    )
        port map (
      I0 => \REC_D/local_y\(1),
      I1 => pixel_y(0),
      O => \rgb_out[23]_i_1562_n_0\
    );
\rgb_out[23]_i_1563\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_D/local_y\(7),
      I1 => \REC_D/local_y\(6),
      O => \rgb_out[23]_i_1563_n_0\
    );
\rgb_out[23]_i_1564\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_D/local_y\(5),
      I1 => \REC_D/local_y\(4),
      O => \rgb_out[23]_i_1564_n_0\
    );
\rgb_out[23]_i_1565\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_D/local_y\(3),
      I1 => \REC_D/local_y\(2),
      O => \rgb_out[23]_i_1565_n_0\
    );
\rgb_out[23]_i_1566\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => pixel_y(0),
      I1 => \REC_D/local_y\(1),
      O => \rgb_out[23]_i_1566_n_0\
    );
\rgb_out[23]_i_1567\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \REC_D/local_x\(6),
      I1 => \REC_D/local_x\(7),
      O => \rgb_out[23]_i_1567_n_0\
    );
\rgb_out[23]_i_1568\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \REC_D/local_x\(4),
      I1 => \REC_D/local_x\(5),
      O => \rgb_out[23]_i_1568_n_0\
    );
\rgb_out[23]_i_1569\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \REC_D/local_x\(2),
      I1 => \REC_D/local_x\(3),
      O => \rgb_out[23]_i_1569_n_0\
    );
\rgb_out[23]_i_1570\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"B"
    )
        port map (
      I0 => \REC_D/local_x\(1),
      I1 => pixel_x(0),
      O => \rgb_out[23]_i_1570_n_0\
    );
\rgb_out[23]_i_1571\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_D/local_x\(7),
      I1 => \REC_D/local_x\(6),
      O => \rgb_out[23]_i_1571_n_0\
    );
\rgb_out[23]_i_1572\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_D/local_x\(5),
      I1 => \REC_D/local_x\(4),
      O => \rgb_out[23]_i_1572_n_0\
    );
\rgb_out[23]_i_1573\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_D/local_x\(3),
      I1 => \REC_D/local_x\(2),
      O => \rgb_out[23]_i_1573_n_0\
    );
\rgb_out[23]_i_1574\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => pixel_x(0),
      I1 => \REC_D/local_x\(1),
      O => \rgb_out[23]_i_1574_n_0\
    );
\rgb_out[23]_i_1575\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"7"
    )
        port map (
      I0 => \REC_D/local_y\(4),
      I1 => \REC_D/local_y\(5),
      O => \rgb_out[23]_i_1575_n_0\
    );
\rgb_out[23]_i_1576\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"7"
    )
        port map (
      I0 => \REC_D/local_y\(2),
      I1 => \REC_D/local_y\(3),
      O => \rgb_out[23]_i_1576_n_0\
    );
\rgb_out[23]_i_1577\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_D/local_y\(9),
      I1 => \REC_D/local_y\(8),
      O => \rgb_out[23]_i_1577_n_0\
    );
\rgb_out[23]_i_1578\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_D/local_y\(7),
      I1 => \REC_D/local_y\(6),
      O => \rgb_out[23]_i_1578_n_0\
    );
\rgb_out[23]_i_1579\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \REC_D/local_y\(5),
      I1 => \REC_D/local_y\(4),
      O => \rgb_out[23]_i_1579_n_0\
    );
\rgb_out[23]_i_1580\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \REC_D/local_y\(3),
      I1 => \REC_D/local_y\(2),
      O => \rgb_out[23]_i_1580_n_0\
    );
\rgb_out[23]_i_1581\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_D/local_x\(5),
      O => \rgb_out[23]_i_1581_n_0\
    );
\rgb_out[23]_i_1582\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_D/local_x\(3),
      I1 => \REC_D/local_x\(2),
      O => \rgb_out[23]_i_1582_n_0\
    );
\rgb_out[23]_i_1583\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_D/local_x\(9),
      I1 => \REC_D/local_x\(8),
      O => \rgb_out[23]_i_1583_n_0\
    );
\rgb_out[23]_i_1584\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_D/local_x\(7),
      I1 => \REC_D/local_x\(6),
      O => \rgb_out[23]_i_1584_n_0\
    );
\rgb_out[23]_i_1585\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \REC_D/local_x\(5),
      I1 => \REC_D/local_x\(4),
      O => \rgb_out[23]_i_1585_n_0\
    );
\rgb_out[23]_i_1586\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \REC_D/local_x\(2),
      I1 => \REC_D/local_x\(3),
      O => \rgb_out[23]_i_1586_n_0\
    );
\rgb_out[23]_i_1587\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_U/local_x\(5),
      O => \rgb_out[23]_i_1587_n_0\
    );
\rgb_out[23]_i_1588\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_U/local_x\(3),
      I1 => \LAST_U/local_x\(2),
      O => \rgb_out[23]_i_1588_n_0\
    );
\rgb_out[23]_i_1589\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_U/local_x\(9),
      I1 => \LAST_U/local_x\(8),
      O => \rgb_out[23]_i_1589_n_0\
    );
\rgb_out[23]_i_1590\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_U/local_x\(7),
      I1 => \LAST_U/local_x\(6),
      O => \rgb_out[23]_i_1590_n_0\
    );
\rgb_out[23]_i_1591\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \LAST_U/local_x\(5),
      I1 => \LAST_U/local_x\(4),
      O => \rgb_out[23]_i_1591_n_0\
    );
\rgb_out[23]_i_1592\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \LAST_U/local_x\(2),
      I1 => \LAST_U/local_x\(3),
      O => \rgb_out[23]_i_1592_n_0\
    );
\rgb_out[23]_i_1594\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_x(11),
      O => \rgb_out[23]_i_1594_n_0\
    );
\rgb_out[23]_i_1595\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_x(10),
      O => \rgb_out[23]_i_1595_n_0\
    );
\rgb_out[23]_i_1596\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_x(9),
      O => \rgb_out[23]_i_1596_n_0\
    );
\rgb_out[23]_i_1597\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"7"
    )
        port map (
      I0 => \LAST_U/local_y\(3),
      I1 => \LAST_U/local_y\(2),
      O => \rgb_out[23]_i_1597_n_0\
    );
\rgb_out[23]_i_1598\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"7"
    )
        port map (
      I0 => \LAST_U/local_y\(5),
      I1 => \LAST_U/local_y\(4),
      O => \rgb_out[23]_i_1598_n_0\
    );
\rgb_out[23]_i_1599\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_U/local_y\(11),
      I1 => \LAST_U/local_y\(10),
      O => \rgb_out[23]_i_1599_n_0\
    );
\rgb_out[23]_i_1600\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_U/local_y\(9),
      I1 => \LAST_U/local_y\(8),
      O => \rgb_out[23]_i_1600_n_0\
    );
\rgb_out[23]_i_1601\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_U/local_y\(7),
      I1 => \LAST_U/local_y\(6),
      O => \rgb_out[23]_i_1601_n_0\
    );
\rgb_out[23]_i_1602\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \LAST_U/local_y\(4),
      I1 => \LAST_U/local_y\(5),
      O => \rgb_out[23]_i_1602_n_0\
    );
\rgb_out[23]_i_1604\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_y(11),
      O => \rgb_out[23]_i_1604_n_0\
    );
\rgb_out[23]_i_1605\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_y(10),
      O => \rgb_out[23]_i_1605_n_0\
    );
\rgb_out[23]_i_1606\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_y(9),
      O => \rgb_out[23]_i_1606_n_0\
    );
\rgb_out[23]_i_1607\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \LAST_U/local_x\(6),
      I1 => \LAST_U/local_x\(7),
      O => \rgb_out[23]_i_1607_n_0\
    );
\rgb_out[23]_i_1608\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \LAST_U/local_x\(5),
      I1 => \LAST_U/local_x\(4),
      O => \rgb_out[23]_i_1608_n_0\
    );
\rgb_out[23]_i_1609\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \LAST_U/local_x\(2),
      I1 => \LAST_U/local_x\(3),
      O => \rgb_out[23]_i_1609_n_0\
    );
\rgb_out[23]_i_1610\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"B"
    )
        port map (
      I0 => \LAST_U/local_x\(1),
      I1 => pixel_x(0),
      O => \rgb_out[23]_i_1610_n_0\
    );
\rgb_out[23]_i_1611\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_U/local_x\(7),
      I1 => \LAST_U/local_x\(6),
      O => \rgb_out[23]_i_1611_n_0\
    );
\rgb_out[23]_i_1612\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_U/local_x\(4),
      I1 => \LAST_U/local_x\(5),
      O => \rgb_out[23]_i_1612_n_0\
    );
\rgb_out[23]_i_1613\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_U/local_x\(3),
      I1 => \LAST_U/local_x\(2),
      O => \rgb_out[23]_i_1613_n_0\
    );
\rgb_out[23]_i_1614\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => pixel_x(0),
      I1 => \LAST_U/local_x\(1),
      O => \rgb_out[23]_i_1614_n_0\
    );
\rgb_out[23]_i_1615\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \LAST_U/local_y\(6),
      I1 => \LAST_U/local_y\(7),
      O => \rgb_out[23]_i_1615_n_0\
    );
\rgb_out[23]_i_1616\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \LAST_U/local_y\(4),
      I1 => \LAST_U/local_y\(5),
      O => \rgb_out[23]_i_1616_n_0\
    );
\rgb_out[23]_i_1617\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \LAST_U/local_y\(2),
      I1 => \LAST_U/local_y\(3),
      O => \rgb_out[23]_i_1617_n_0\
    );
\rgb_out[23]_i_1618\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"B"
    )
        port map (
      I0 => \LAST_U/local_y\(1),
      I1 => pixel_y(0),
      O => \rgb_out[23]_i_1618_n_0\
    );
\rgb_out[23]_i_1619\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_U/local_y\(7),
      I1 => \LAST_U/local_y\(6),
      O => \rgb_out[23]_i_1619_n_0\
    );
\rgb_out[23]_i_1620\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_U/local_y\(5),
      I1 => \LAST_U/local_y\(4),
      O => \rgb_out[23]_i_1620_n_0\
    );
\rgb_out[23]_i_1621\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_U/local_y\(3),
      I1 => \LAST_U/local_y\(2),
      O => \rgb_out[23]_i_1621_n_0\
    );
\rgb_out[23]_i_1622\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => pixel_y(0),
      I1 => \LAST_U/local_y\(1),
      O => \rgb_out[23]_i_1622_n_0\
    );
\rgb_out[23]_i_1623\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"7"
    )
        port map (
      I0 => \LAST_U/local_y\(5),
      I1 => \LAST_U/local_y\(4),
      O => \rgb_out[23]_i_1623_n_0\
    );
\rgb_out[23]_i_1624\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_U/local_y\(3),
      I1 => \LAST_U/local_y\(2),
      O => \rgb_out[23]_i_1624_n_0\
    );
\rgb_out[23]_i_1625\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_U/local_y\(1),
      O => \rgb_out[23]_i_1625_n_0\
    );
\rgb_out[23]_i_1626\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_U/local_y\(7),
      I1 => \LAST_U/local_y\(6),
      O => \rgb_out[23]_i_1626_n_0\
    );
\rgb_out[23]_i_1627\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \LAST_U/local_y\(4),
      I1 => \LAST_U/local_y\(5),
      O => \rgb_out[23]_i_1627_n_0\
    );
\rgb_out[23]_i_1628\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \LAST_U/local_y\(2),
      I1 => \LAST_U/local_y\(3),
      O => \rgb_out[23]_i_1628_n_0\
    );
\rgb_out[23]_i_1629\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => pixel_y(0),
      I1 => \LAST_U/local_y\(1),
      O => \rgb_out[23]_i_1629_n_0\
    );
\rgb_out[23]_i_1630\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \LAST_U/local_y\(6),
      I1 => \LAST_U/local_y\(7),
      O => \rgb_out[23]_i_1630_n_0\
    );
\rgb_out[23]_i_1631\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \LAST_U/local_y\(1),
      I1 => pixel_y(0),
      O => \rgb_out[23]_i_1631_n_0\
    );
\rgb_out[23]_i_1632\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_U/local_y\(7),
      I1 => \LAST_U/local_y\(6),
      O => \rgb_out[23]_i_1632_n_0\
    );
\rgb_out[23]_i_1633\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \LAST_U/local_y\(4),
      I1 => \LAST_U/local_y\(5),
      O => \rgb_out[23]_i_1633_n_0\
    );
\rgb_out[23]_i_1634\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \LAST_U/local_y\(2),
      I1 => \LAST_U/local_y\(3),
      O => \rgb_out[23]_i_1634_n_0\
    );
\rgb_out[23]_i_1635\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => pixel_y(0),
      I1 => \LAST_U/local_y\(1),
      O => \rgb_out[23]_i_1635_n_0\
    );
\rgb_out[23]_i_1636\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_U/local_x\(3),
      I1 => \LAST_U/local_x\(2),
      O => \rgb_out[23]_i_1636_n_0\
    );
\rgb_out[23]_i_1637\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_U/local_x\(1),
      O => \rgb_out[23]_i_1637_n_0\
    );
\rgb_out[23]_i_1638\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_U/local_x\(7),
      I1 => \LAST_U/local_x\(6),
      O => \rgb_out[23]_i_1638_n_0\
    );
\rgb_out[23]_i_1639\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_U/local_x\(4),
      I1 => \LAST_U/local_x\(5),
      O => \rgb_out[23]_i_1639_n_0\
    );
\rgb_out[23]_i_1640\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \LAST_U/local_x\(2),
      I1 => \LAST_U/local_x\(3),
      O => \rgb_out[23]_i_1640_n_0\
    );
\rgb_out[23]_i_1641\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => pixel_x(0),
      I1 => \LAST_U/local_x\(1),
      O => \rgb_out[23]_i_1641_n_0\
    );
\rgb_out[23]_i_1642\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \LAST_U/local_x\(6),
      I1 => \LAST_U/local_x\(7),
      O => \rgb_out[23]_i_1642_n_0\
    );
\rgb_out[23]_i_1643\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \LAST_U/local_x\(1),
      I1 => pixel_x(0),
      O => \rgb_out[23]_i_1643_n_0\
    );
\rgb_out[23]_i_1644\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_U/local_x\(7),
      I1 => \LAST_U/local_x\(6),
      O => \rgb_out[23]_i_1644_n_0\
    );
\rgb_out[23]_i_1645\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \LAST_U/local_x\(4),
      I1 => \LAST_U/local_x\(5),
      O => \rgb_out[23]_i_1645_n_0\
    );
\rgb_out[23]_i_1646\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \LAST_U/local_x\(2),
      I1 => \LAST_U/local_x\(3),
      O => \rgb_out[23]_i_1646_n_0\
    );
\rgb_out[23]_i_1647\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => pixel_x(0),
      I1 => \LAST_U/local_x\(1),
      O => \rgb_out[23]_i_1647_n_0\
    );
\rgb_out[23]_i_1648\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_U/local_y\(5),
      I1 => \LAST_U/local_y\(4),
      O => \rgb_out[23]_i_1648_n_0\
    );
\rgb_out[23]_i_1649\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"7"
    )
        port map (
      I0 => \LAST_U/local_y\(3),
      I1 => \LAST_U/local_y\(2),
      O => \rgb_out[23]_i_1649_n_0\
    );
\rgb_out[23]_i_1650\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_U/local_y\(1),
      O => \rgb_out[23]_i_1650_n_0\
    );
\rgb_out[23]_i_1651\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_U/local_y\(7),
      I1 => \LAST_U/local_y\(6),
      O => \rgb_out[23]_i_1651_n_0\
    );
\rgb_out[23]_i_1652\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \LAST_U/local_y\(4),
      I1 => \LAST_U/local_y\(5),
      O => \rgb_out[23]_i_1652_n_0\
    );
\rgb_out[23]_i_1653\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \LAST_U/local_y\(2),
      I1 => \LAST_U/local_y\(3),
      O => \rgb_out[23]_i_1653_n_0\
    );
\rgb_out[23]_i_1654\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => pixel_y(0),
      I1 => \LAST_U/local_y\(1),
      O => \rgb_out[23]_i_1654_n_0\
    );
\rgb_out[23]_i_1655\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \LAST_U/local_y\(6),
      I1 => \LAST_U/local_y\(7),
      O => \rgb_out[23]_i_1655_n_0\
    );
\rgb_out[23]_i_1656\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \LAST_U/local_y\(4),
      I1 => \LAST_U/local_y\(5),
      O => \rgb_out[23]_i_1656_n_0\
    );
\rgb_out[23]_i_1658\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \LAST_U/local_y\(1),
      I1 => pixel_y(0),
      O => \rgb_out[23]_i_1658_n_0\
    );
\rgb_out[23]_i_1659\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_U/local_y\(7),
      I1 => \LAST_U/local_y\(6),
      O => \rgb_out[23]_i_1659_n_0\
    );
\rgb_out[23]_i_1660\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_U/local_y\(5),
      I1 => \LAST_U/local_y\(4),
      O => \rgb_out[23]_i_1660_n_0\
    );
\rgb_out[23]_i_1661\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \LAST_U/local_y\(2),
      I1 => \LAST_U/local_y\(3),
      O => \rgb_out[23]_i_1661_n_0\
    );
\rgb_out[23]_i_1662\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => pixel_y(0),
      I1 => \LAST_U/local_y\(1),
      O => \rgb_out[23]_i_1662_n_0\
    );
\rgb_out[23]_i_1663\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \LAST_U/local_x\(6),
      I1 => \LAST_U/local_x\(7),
      O => \rgb_out[23]_i_1663_n_0\
    );
\rgb_out[23]_i_1664\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \LAST_U/local_x\(5),
      I1 => \LAST_U/local_x\(4),
      O => \rgb_out[23]_i_1664_n_0\
    );
\rgb_out[23]_i_1666\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \LAST_U/local_x\(1),
      I1 => pixel_x(0),
      O => \rgb_out[23]_i_1666_n_0\
    );
\rgb_out[23]_i_1667\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_U/local_x\(7),
      I1 => \LAST_U/local_x\(6),
      O => \rgb_out[23]_i_1667_n_0\
    );
\rgb_out[23]_i_1668\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_U/local_x\(4),
      I1 => \LAST_U/local_x\(5),
      O => \rgb_out[23]_i_1668_n_0\
    );
\rgb_out[23]_i_1669\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \LAST_U/local_x\(2),
      I1 => \LAST_U/local_x\(3),
      O => \rgb_out[23]_i_1669_n_0\
    );
\rgb_out[23]_i_1670\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => pixel_x(0),
      I1 => \LAST_U/local_x\(1),
      O => \rgb_out[23]_i_1670_n_0\
    );
\rgb_out[23]_i_1671\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_U/local_x\(4),
      I1 => \LAST_U/local_x\(5),
      O => \rgb_out[23]_i_1671_n_0\
    );
\rgb_out[23]_i_1672\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"7"
    )
        port map (
      I0 => \LAST_U/local_x\(3),
      I1 => \LAST_U/local_x\(2),
      O => \rgb_out[23]_i_1672_n_0\
    );
\rgb_out[23]_i_1673\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_U/local_x\(1),
      O => \rgb_out[23]_i_1673_n_0\
    );
\rgb_out[23]_i_1674\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_U/local_x\(7),
      I1 => \LAST_U/local_x\(6),
      O => \rgb_out[23]_i_1674_n_0\
    );
\rgb_out[23]_i_1675\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \LAST_U/local_x\(4),
      I1 => \LAST_U/local_x\(5),
      O => \rgb_out[23]_i_1675_n_0\
    );
\rgb_out[23]_i_1676\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \LAST_U/local_x\(2),
      I1 => \LAST_U/local_x\(3),
      O => \rgb_out[23]_i_1676_n_0\
    );
\rgb_out[23]_i_1677\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => pixel_x(0),
      I1 => \LAST_U/local_x\(1),
      O => \rgb_out[23]_i_1677_n_0\
    );
\rgb_out[23]_i_1678\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_U/local_y\(3),
      I1 => \LAST_U/local_y\(2),
      O => \rgb_out[23]_i_1678_n_0\
    );
\rgb_out[23]_i_1679\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_U/local_y\(1),
      O => \rgb_out[23]_i_1679_n_0\
    );
\rgb_out[23]_i_1680\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_U/local_y\(7),
      I1 => \LAST_U/local_y\(6),
      O => \rgb_out[23]_i_1680_n_0\
    );
\rgb_out[23]_i_1681\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_U/local_y\(5),
      I1 => \LAST_U/local_y\(4),
      O => \rgb_out[23]_i_1681_n_0\
    );
\rgb_out[23]_i_1682\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \LAST_U/local_y\(2),
      I1 => \LAST_U/local_y\(3),
      O => \rgb_out[23]_i_1682_n_0\
    );
\rgb_out[23]_i_1683\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => pixel_y(0),
      I1 => \LAST_U/local_y\(1),
      O => \rgb_out[23]_i_1683_n_0\
    );
\rgb_out[23]_i_1684\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_U/local_y\(5),
      O => \rgb_out[23]_i_1684_n_0\
    );
\rgb_out[23]_i_1685\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => pixel_y(0),
      I1 => \LAST_U/local_y\(1),
      O => \rgb_out[23]_i_1685_n_0\
    );
\rgb_out[23]_i_1686\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_U/local_y\(7),
      I1 => \LAST_U/local_y\(6),
      O => \rgb_out[23]_i_1686_n_0\
    );
\rgb_out[23]_i_1687\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \LAST_U/local_y\(5),
      I1 => \LAST_U/local_y\(4),
      O => \rgb_out[23]_i_1687_n_0\
    );
\rgb_out[23]_i_1688\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_U/local_y\(3),
      I1 => \LAST_U/local_y\(2),
      O => \rgb_out[23]_i_1688_n_0\
    );
\rgb_out[23]_i_1689\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_U/local_y\(1),
      I1 => pixel_y(0),
      O => \rgb_out[23]_i_1689_n_0\
    );
\rgb_out[23]_i_1690\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \LAST_U/local_y\(6),
      I1 => \LAST_U/local_y\(7),
      O => \rgb_out[23]_i_1690_n_0\
    );
\rgb_out[23]_i_1691\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \LAST_U/local_y\(2),
      I1 => \LAST_U/local_y\(3),
      O => \rgb_out[23]_i_1691_n_0\
    );
\rgb_out[23]_i_1692\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_U/local_y\(7),
      I1 => \LAST_U/local_y\(6),
      O => \rgb_out[23]_i_1692_n_0\
    );
\rgb_out[23]_i_1693\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \LAST_U/local_y\(4),
      I1 => \LAST_U/local_y\(5),
      O => \rgb_out[23]_i_1693_n_0\
    );
\rgb_out[23]_i_1694\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \LAST_U/local_y\(3),
      I1 => \LAST_U/local_y\(2),
      O => \rgb_out[23]_i_1694_n_0\
    );
\rgb_out[23]_i_1695\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \LAST_U/local_y\(1),
      I1 => pixel_y(0),
      O => \rgb_out[23]_i_1695_n_0\
    );
\rgb_out[23]_i_1696\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \LAST_U/local_y\(6),
      I1 => \LAST_U/local_y\(7),
      O => \rgb_out[23]_i_1696_n_0\
    );
\rgb_out[23]_i_1697\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \LAST_U/local_y\(1),
      I1 => pixel_y(0),
      O => \rgb_out[23]_i_1697_n_0\
    );
\rgb_out[23]_i_1698\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_U/local_y\(7),
      I1 => \LAST_U/local_y\(6),
      O => \rgb_out[23]_i_1698_n_0\
    );
\rgb_out[23]_i_1699\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \LAST_U/local_y\(4),
      I1 => \LAST_U/local_y\(5),
      O => \rgb_out[23]_i_1699_n_0\
    );
\rgb_out[23]_i_1700\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \LAST_U/local_y\(2),
      I1 => \LAST_U/local_y\(3),
      O => \rgb_out[23]_i_1700_n_0\
    );
\rgb_out[23]_i_1701\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => pixel_y(0),
      I1 => \LAST_U/local_y\(1),
      O => \rgb_out[23]_i_1701_n_0\
    );
\rgb_out[23]_i_1702\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_U/local_x\(5),
      O => \rgb_out[23]_i_1702_n_0\
    );
\rgb_out[23]_i_1703\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_U/local_x\(3),
      I1 => \REC_U/local_x\(2),
      O => \rgb_out[23]_i_1703_n_0\
    );
\rgb_out[23]_i_1704\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_U/local_x\(9),
      I1 => \REC_U/local_x\(8),
      O => \rgb_out[23]_i_1704_n_0\
    );
\rgb_out[23]_i_1705\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_U/local_x\(7),
      I1 => \REC_U/local_x\(6),
      O => \rgb_out[23]_i_1705_n_0\
    );
\rgb_out[23]_i_1706\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \REC_U/local_x\(5),
      I1 => \REC_U/local_x\(4),
      O => \rgb_out[23]_i_1706_n_0\
    );
\rgb_out[23]_i_1707\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \REC_U/local_x\(2),
      I1 => \REC_U/local_x\(3),
      O => \rgb_out[23]_i_1707_n_0\
    );
\rgb_out[23]_i_1709\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_x(11),
      O => \rgb_out[23]_i_1709_n_0\
    );
\rgb_out[23]_i_1710\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_x(9),
      O => \rgb_out[23]_i_1710_n_0\
    );
\rgb_out[23]_i_1711\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"7"
    )
        port map (
      I0 => \REC_U/local_y\(3),
      I1 => \REC_U/local_y\(2),
      O => \rgb_out[23]_i_1711_n_0\
    );
\rgb_out[23]_i_1712\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"7"
    )
        port map (
      I0 => \REC_U/local_y\(5),
      I1 => \REC_U/local_y\(4),
      O => \rgb_out[23]_i_1712_n_0\
    );
\rgb_out[23]_i_1713\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_U/local_y\(11),
      I1 => \REC_U/local_y\(10),
      O => \rgb_out[23]_i_1713_n_0\
    );
\rgb_out[23]_i_1714\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_U/local_y\(9),
      I1 => \REC_U/local_y\(8),
      O => \rgb_out[23]_i_1714_n_0\
    );
\rgb_out[23]_i_1715\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_U/local_y\(7),
      I1 => \REC_U/local_y\(6),
      O => \rgb_out[23]_i_1715_n_0\
    );
\rgb_out[23]_i_1716\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \REC_U/local_y\(4),
      I1 => \REC_U/local_y\(5),
      O => \rgb_out[23]_i_1716_n_0\
    );
\rgb_out[23]_i_1718\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_y(11),
      O => \rgb_out[23]_i_1718_n_0\
    );
\rgb_out[23]_i_1719\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_y(10),
      O => \rgb_out[23]_i_1719_n_0\
    );
\rgb_out[23]_i_1720\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_y(9),
      O => \rgb_out[23]_i_1720_n_0\
    );
\rgb_out[23]_i_1721\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \REC_U/local_x\(6),
      I1 => \REC_U/local_x\(7),
      O => \rgb_out[23]_i_1721_n_0\
    );
\rgb_out[23]_i_1722\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \REC_U/local_x\(5),
      I1 => \REC_U/local_x\(4),
      O => \rgb_out[23]_i_1722_n_0\
    );
\rgb_out[23]_i_1723\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \REC_U/local_x\(2),
      I1 => \REC_U/local_x\(3),
      O => \rgb_out[23]_i_1723_n_0\
    );
\rgb_out[23]_i_1724\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"B"
    )
        port map (
      I0 => \REC_U/local_x\(1),
      I1 => pixel_x(0),
      O => \rgb_out[23]_i_1724_n_0\
    );
\rgb_out[23]_i_1725\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_U/local_x\(7),
      I1 => \REC_U/local_x\(6),
      O => \rgb_out[23]_i_1725_n_0\
    );
\rgb_out[23]_i_1726\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_U/local_x\(4),
      I1 => \REC_U/local_x\(5),
      O => \rgb_out[23]_i_1726_n_0\
    );
\rgb_out[23]_i_1727\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_U/local_x\(3),
      I1 => \REC_U/local_x\(2),
      O => \rgb_out[23]_i_1727_n_0\
    );
\rgb_out[23]_i_1728\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => pixel_x(0),
      I1 => \REC_U/local_x\(1),
      O => \rgb_out[23]_i_1728_n_0\
    );
\rgb_out[23]_i_1729\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \REC_U/local_y\(6),
      I1 => \REC_U/local_y\(7),
      O => \rgb_out[23]_i_1729_n_0\
    );
\rgb_out[23]_i_1730\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \REC_U/local_y\(4),
      I1 => \REC_U/local_y\(5),
      O => \rgb_out[23]_i_1730_n_0\
    );
\rgb_out[23]_i_1731\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \REC_U/local_y\(2),
      I1 => \REC_U/local_y\(3),
      O => \rgb_out[23]_i_1731_n_0\
    );
\rgb_out[23]_i_1732\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"B"
    )
        port map (
      I0 => \REC_U/local_y\(1),
      I1 => pixel_y(0),
      O => \rgb_out[23]_i_1732_n_0\
    );
\rgb_out[23]_i_1733\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_U/local_y\(7),
      I1 => \REC_U/local_y\(6),
      O => \rgb_out[23]_i_1733_n_0\
    );
\rgb_out[23]_i_1734\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_U/local_y\(5),
      I1 => \REC_U/local_y\(4),
      O => \rgb_out[23]_i_1734_n_0\
    );
\rgb_out[23]_i_1735\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_U/local_y\(3),
      I1 => \REC_U/local_y\(2),
      O => \rgb_out[23]_i_1735_n_0\
    );
\rgb_out[23]_i_1736\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => pixel_y(0),
      I1 => \REC_U/local_y\(1),
      O => \rgb_out[23]_i_1736_n_0\
    );
\rgb_out[23]_i_1737\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"7"
    )
        port map (
      I0 => \REC_U/local_y\(5),
      I1 => \REC_U/local_y\(4),
      O => \rgb_out[23]_i_1737_n_0\
    );
\rgb_out[23]_i_1738\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_U/local_y\(3),
      I1 => \REC_U/local_y\(2),
      O => \rgb_out[23]_i_1738_n_0\
    );
\rgb_out[23]_i_1739\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_U/local_y\(1),
      O => \rgb_out[23]_i_1739_n_0\
    );
\rgb_out[23]_i_1740\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_U/local_y\(7),
      I1 => \REC_U/local_y\(6),
      O => \rgb_out[23]_i_1740_n_0\
    );
\rgb_out[23]_i_1741\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \REC_U/local_y\(4),
      I1 => \REC_U/local_y\(5),
      O => \rgb_out[23]_i_1741_n_0\
    );
\rgb_out[23]_i_1742\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \REC_U/local_y\(2),
      I1 => \REC_U/local_y\(3),
      O => \rgb_out[23]_i_1742_n_0\
    );
\rgb_out[23]_i_1743\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => pixel_y(0),
      I1 => \REC_U/local_y\(1),
      O => \rgb_out[23]_i_1743_n_0\
    );
\rgb_out[23]_i_1744\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \REC_U/local_y\(6),
      I1 => \REC_U/local_y\(7),
      O => \rgb_out[23]_i_1744_n_0\
    );
\rgb_out[23]_i_1745\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \REC_U/local_y\(1),
      I1 => pixel_y(0),
      O => \rgb_out[23]_i_1745_n_0\
    );
\rgb_out[23]_i_1746\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_U/local_y\(7),
      I1 => \REC_U/local_y\(6),
      O => \rgb_out[23]_i_1746_n_0\
    );
\rgb_out[23]_i_1747\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \REC_U/local_y\(4),
      I1 => \REC_U/local_y\(5),
      O => \rgb_out[23]_i_1747_n_0\
    );
\rgb_out[23]_i_1748\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \REC_U/local_y\(2),
      I1 => \REC_U/local_y\(3),
      O => \rgb_out[23]_i_1748_n_0\
    );
\rgb_out[23]_i_1749\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => pixel_y(0),
      I1 => \REC_U/local_y\(1),
      O => \rgb_out[23]_i_1749_n_0\
    );
\rgb_out[23]_i_1750\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_U/local_x\(3),
      I1 => \REC_U/local_x\(2),
      O => \rgb_out[23]_i_1750_n_0\
    );
\rgb_out[23]_i_1751\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_U/local_x\(1),
      O => \rgb_out[23]_i_1751_n_0\
    );
\rgb_out[23]_i_1752\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_U/local_x\(7),
      I1 => \REC_U/local_x\(6),
      O => \rgb_out[23]_i_1752_n_0\
    );
\rgb_out[23]_i_1753\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_U/local_x\(4),
      I1 => \REC_U/local_x\(5),
      O => \rgb_out[23]_i_1753_n_0\
    );
\rgb_out[23]_i_1754\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \REC_U/local_x\(2),
      I1 => \REC_U/local_x\(3),
      O => \rgb_out[23]_i_1754_n_0\
    );
\rgb_out[23]_i_1755\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => pixel_x(0),
      I1 => \REC_U/local_x\(1),
      O => \rgb_out[23]_i_1755_n_0\
    );
\rgb_out[23]_i_1756\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \REC_U/local_x\(6),
      I1 => \REC_U/local_x\(7),
      O => \rgb_out[23]_i_1756_n_0\
    );
\rgb_out[23]_i_1757\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \REC_U/local_x\(1),
      I1 => pixel_x(0),
      O => \rgb_out[23]_i_1757_n_0\
    );
\rgb_out[23]_i_1758\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_U/local_x\(7),
      I1 => \REC_U/local_x\(6),
      O => \rgb_out[23]_i_1758_n_0\
    );
\rgb_out[23]_i_1759\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \REC_U/local_x\(4),
      I1 => \REC_U/local_x\(5),
      O => \rgb_out[23]_i_1759_n_0\
    );
\rgb_out[23]_i_1760\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \REC_U/local_x\(2),
      I1 => \REC_U/local_x\(3),
      O => \rgb_out[23]_i_1760_n_0\
    );
\rgb_out[23]_i_1761\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => pixel_x(0),
      I1 => \REC_U/local_x\(1),
      O => \rgb_out[23]_i_1761_n_0\
    );
\rgb_out[23]_i_1762\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_U/local_y\(5),
      I1 => \REC_U/local_y\(4),
      O => \rgb_out[23]_i_1762_n_0\
    );
\rgb_out[23]_i_1763\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"7"
    )
        port map (
      I0 => \REC_U/local_y\(3),
      I1 => \REC_U/local_y\(2),
      O => \rgb_out[23]_i_1763_n_0\
    );
\rgb_out[23]_i_1764\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_U/local_y\(1),
      O => \rgb_out[23]_i_1764_n_0\
    );
\rgb_out[23]_i_1765\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_U/local_y\(7),
      I1 => \REC_U/local_y\(6),
      O => \rgb_out[23]_i_1765_n_0\
    );
\rgb_out[23]_i_1766\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \REC_U/local_y\(4),
      I1 => \REC_U/local_y\(5),
      O => \rgb_out[23]_i_1766_n_0\
    );
\rgb_out[23]_i_1767\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \REC_U/local_y\(2),
      I1 => \REC_U/local_y\(3),
      O => \rgb_out[23]_i_1767_n_0\
    );
\rgb_out[23]_i_1768\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => pixel_y(0),
      I1 => \REC_U/local_y\(1),
      O => \rgb_out[23]_i_1768_n_0\
    );
\rgb_out[23]_i_1769\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \REC_U/local_y\(6),
      I1 => \REC_U/local_y\(7),
      O => \rgb_out[23]_i_1769_n_0\
    );
\rgb_out[23]_i_1770\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \REC_U/local_y\(4),
      I1 => \REC_U/local_y\(5),
      O => \rgb_out[23]_i_1770_n_0\
    );
\rgb_out[23]_i_1772\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \REC_U/local_y\(1),
      I1 => pixel_y(0),
      O => \rgb_out[23]_i_1772_n_0\
    );
\rgb_out[23]_i_1773\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_U/local_y\(7),
      I1 => \REC_U/local_y\(6),
      O => \rgb_out[23]_i_1773_n_0\
    );
\rgb_out[23]_i_1774\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_U/local_y\(5),
      I1 => \REC_U/local_y\(4),
      O => \rgb_out[23]_i_1774_n_0\
    );
\rgb_out[23]_i_1775\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \REC_U/local_y\(2),
      I1 => \REC_U/local_y\(3),
      O => \rgb_out[23]_i_1775_n_0\
    );
\rgb_out[23]_i_1776\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => pixel_y(0),
      I1 => \REC_U/local_y\(1),
      O => \rgb_out[23]_i_1776_n_0\
    );
\rgb_out[23]_i_1777\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \REC_U/local_x\(6),
      I1 => \REC_U/local_x\(7),
      O => \rgb_out[23]_i_1777_n_0\
    );
\rgb_out[23]_i_1778\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \REC_U/local_x\(5),
      I1 => \REC_U/local_x\(4),
      O => \rgb_out[23]_i_1778_n_0\
    );
\rgb_out[23]_i_1780\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \REC_U/local_x\(1),
      I1 => pixel_x(0),
      O => \rgb_out[23]_i_1780_n_0\
    );
\rgb_out[23]_i_1781\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_U/local_x\(7),
      I1 => \REC_U/local_x\(6),
      O => \rgb_out[23]_i_1781_n_0\
    );
\rgb_out[23]_i_1782\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_U/local_x\(4),
      I1 => \REC_U/local_x\(5),
      O => \rgb_out[23]_i_1782_n_0\
    );
\rgb_out[23]_i_1783\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \REC_U/local_x\(2),
      I1 => \REC_U/local_x\(3),
      O => \rgb_out[23]_i_1783_n_0\
    );
\rgb_out[23]_i_1784\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => pixel_x(0),
      I1 => \REC_U/local_x\(1),
      O => \rgb_out[23]_i_1784_n_0\
    );
\rgb_out[23]_i_1785\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_U/local_x\(4),
      I1 => \REC_U/local_x\(5),
      O => \rgb_out[23]_i_1785_n_0\
    );
\rgb_out[23]_i_1786\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"7"
    )
        port map (
      I0 => \REC_U/local_x\(3),
      I1 => \REC_U/local_x\(2),
      O => \rgb_out[23]_i_1786_n_0\
    );
\rgb_out[23]_i_1787\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_U/local_x\(1),
      O => \rgb_out[23]_i_1787_n_0\
    );
\rgb_out[23]_i_1788\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_U/local_x\(7),
      I1 => \REC_U/local_x\(6),
      O => \rgb_out[23]_i_1788_n_0\
    );
\rgb_out[23]_i_1789\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \REC_U/local_x\(4),
      I1 => \REC_U/local_x\(5),
      O => \rgb_out[23]_i_1789_n_0\
    );
\rgb_out[23]_i_1790\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \REC_U/local_x\(2),
      I1 => \REC_U/local_x\(3),
      O => \rgb_out[23]_i_1790_n_0\
    );
\rgb_out[23]_i_1791\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => pixel_x(0),
      I1 => \REC_U/local_x\(1),
      O => \rgb_out[23]_i_1791_n_0\
    );
\rgb_out[23]_i_1792\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_U/local_y\(3),
      I1 => \REC_U/local_y\(2),
      O => \rgb_out[23]_i_1792_n_0\
    );
\rgb_out[23]_i_1793\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_U/local_y\(1),
      O => \rgb_out[23]_i_1793_n_0\
    );
\rgb_out[23]_i_1794\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_U/local_y\(7),
      I1 => \REC_U/local_y\(6),
      O => \rgb_out[23]_i_1794_n_0\
    );
\rgb_out[23]_i_1795\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_U/local_y\(5),
      I1 => \REC_U/local_y\(4),
      O => \rgb_out[23]_i_1795_n_0\
    );
\rgb_out[23]_i_1796\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \REC_U/local_y\(2),
      I1 => \REC_U/local_y\(3),
      O => \rgb_out[23]_i_1796_n_0\
    );
\rgb_out[23]_i_1797\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => pixel_y(0),
      I1 => \REC_U/local_y\(1),
      O => \rgb_out[23]_i_1797_n_0\
    );
\rgb_out[23]_i_1798\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_U/local_y\(5),
      O => \rgb_out[23]_i_1798_n_0\
    );
\rgb_out[23]_i_1799\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => pixel_y(0),
      I1 => \REC_U/local_y\(1),
      O => \rgb_out[23]_i_1799_n_0\
    );
\rgb_out[23]_i_1800\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_U/local_y\(7),
      I1 => \REC_U/local_y\(6),
      O => \rgb_out[23]_i_1800_n_0\
    );
\rgb_out[23]_i_1801\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \REC_U/local_y\(5),
      I1 => \REC_U/local_y\(4),
      O => \rgb_out[23]_i_1801_n_0\
    );
\rgb_out[23]_i_1802\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_U/local_y\(3),
      I1 => \REC_U/local_y\(2),
      O => \rgb_out[23]_i_1802_n_0\
    );
\rgb_out[23]_i_1803\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_U/local_y\(1),
      I1 => pixel_y(0),
      O => \rgb_out[23]_i_1803_n_0\
    );
\rgb_out[23]_i_1804\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \REC_U/local_y\(6),
      I1 => \REC_U/local_y\(7),
      O => \rgb_out[23]_i_1804_n_0\
    );
\rgb_out[23]_i_1805\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \REC_U/local_y\(2),
      I1 => \REC_U/local_y\(3),
      O => \rgb_out[23]_i_1805_n_0\
    );
\rgb_out[23]_i_1806\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_U/local_y\(7),
      I1 => \REC_U/local_y\(6),
      O => \rgb_out[23]_i_1806_n_0\
    );
\rgb_out[23]_i_1807\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \REC_U/local_y\(4),
      I1 => \REC_U/local_y\(5),
      O => \rgb_out[23]_i_1807_n_0\
    );
\rgb_out[23]_i_1808\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \REC_U/local_y\(3),
      I1 => \REC_U/local_y\(2),
      O => \rgb_out[23]_i_1808_n_0\
    );
\rgb_out[23]_i_1809\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \REC_U/local_y\(1),
      I1 => pixel_y(0),
      O => \rgb_out[23]_i_1809_n_0\
    );
\rgb_out[23]_i_1810\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \REC_U/local_y\(6),
      I1 => \REC_U/local_y\(7),
      O => \rgb_out[23]_i_1810_n_0\
    );
\rgb_out[23]_i_1811\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \REC_U/local_y\(1),
      I1 => pixel_y(0),
      O => \rgb_out[23]_i_1811_n_0\
    );
\rgb_out[23]_i_1812\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_U/local_y\(7),
      I1 => \REC_U/local_y\(6),
      O => \rgb_out[23]_i_1812_n_0\
    );
\rgb_out[23]_i_1813\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \REC_U/local_y\(4),
      I1 => \REC_U/local_y\(5),
      O => \rgb_out[23]_i_1813_n_0\
    );
\rgb_out[23]_i_1814\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \REC_U/local_y\(2),
      I1 => \REC_U/local_y\(3),
      O => \rgb_out[23]_i_1814_n_0\
    );
\rgb_out[23]_i_1815\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => pixel_y(0),
      I1 => \REC_U/local_y\(1),
      O => \rgb_out[23]_i_1815_n_0\
    );
\rgb_out[23]_i_1816\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_D/local_y\(3),
      I1 => \LAST_D/local_y\(2),
      O => \rgb_out[23]_i_1816_n_0\
    );
\rgb_out[23]_i_1817\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_D/local_y\(1),
      O => \rgb_out[23]_i_1817_n_0\
    );
\rgb_out[23]_i_1818\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_D/local_y\(7),
      I1 => \LAST_D/local_y\(6),
      O => \rgb_out[23]_i_1818_n_0\
    );
\rgb_out[23]_i_1819\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_D/local_y\(5),
      I1 => \LAST_D/local_y\(4),
      O => \rgb_out[23]_i_1819_n_0\
    );
\rgb_out[23]_i_1820\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \LAST_D/local_y\(2),
      I1 => \LAST_D/local_y\(3),
      O => \rgb_out[23]_i_1820_n_0\
    );
\rgb_out[23]_i_1821\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => pixel_y(0),
      I1 => \LAST_D/local_y\(1),
      O => \rgb_out[23]_i_1821_n_0\
    );
\rgb_out[23]_i_1823\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_y(11),
      O => \rgb_out[23]_i_1823_n_0\
    );
\rgb_out[23]_i_1824\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_y(10),
      O => \rgb_out[23]_i_1824_n_0\
    );
\rgb_out[23]_i_1825\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_y(9),
      O => \rgb_out[23]_i_1825_n_0\
    );
\rgb_out[23]_i_1826\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \LAST_D/local_y\(6),
      I1 => \LAST_D/local_y\(7),
      O => \rgb_out[23]_i_1826_n_0\
    );
\rgb_out[23]_i_1828\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \LAST_D/local_y\(1),
      I1 => pixel_y(0),
      O => \rgb_out[23]_i_1828_n_0\
    );
\rgb_out[23]_i_1829\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_D/local_y\(7),
      I1 => \LAST_D/local_y\(6),
      O => \rgb_out[23]_i_1829_n_0\
    );
\rgb_out[23]_i_1830\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \LAST_D/local_y\(5),
      I1 => \LAST_D/local_y\(4),
      O => \rgb_out[23]_i_1830_n_0\
    );
\rgb_out[23]_i_1831\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \LAST_D/local_y\(2),
      I1 => \LAST_D/local_y\(3),
      O => \rgb_out[23]_i_1831_n_0\
    );
\rgb_out[23]_i_1832\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => pixel_y(0),
      I1 => \LAST_D/local_y\(1),
      O => \rgb_out[23]_i_1832_n_0\
    );
\rgb_out[23]_i_1833\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \LAST_D/local_x\(6),
      I1 => \LAST_D/local_x\(7),
      O => \rgb_out[23]_i_1833_n_0\
    );
\rgb_out[23]_i_1834\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \LAST_D/local_x\(4),
      I1 => \LAST_D/local_x\(5),
      O => \rgb_out[23]_i_1834_n_0\
    );
\rgb_out[23]_i_1836\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \LAST_D/local_x\(1),
      I1 => pixel_x(0),
      O => \rgb_out[23]_i_1836_n_0\
    );
\rgb_out[23]_i_1837\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_D/local_x\(7),
      I1 => \LAST_D/local_x\(6),
      O => \rgb_out[23]_i_1837_n_0\
    );
\rgb_out[23]_i_1838\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_D/local_x\(5),
      I1 => \LAST_D/local_x\(4),
      O => \rgb_out[23]_i_1838_n_0\
    );
\rgb_out[23]_i_1839\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \LAST_D/local_x\(2),
      I1 => \LAST_D/local_x\(3),
      O => \rgb_out[23]_i_1839_n_0\
    );
\rgb_out[23]_i_1840\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => pixel_x(0),
      I1 => \LAST_D/local_x\(1),
      O => \rgb_out[23]_i_1840_n_0\
    );
\rgb_out[23]_i_1841\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_D/local_x\(5),
      I1 => \LAST_D/local_x\(4),
      O => \rgb_out[23]_i_1841_n_0\
    );
\rgb_out[23]_i_1842\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"7"
    )
        port map (
      I0 => \LAST_D/local_x\(2),
      I1 => \LAST_D/local_x\(3),
      O => \rgb_out[23]_i_1842_n_0\
    );
\rgb_out[23]_i_1843\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_D/local_x\(1),
      O => \rgb_out[23]_i_1843_n_0\
    );
\rgb_out[23]_i_1844\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_D/local_x\(7),
      I1 => \LAST_D/local_x\(6),
      O => \rgb_out[23]_i_1844_n_0\
    );
\rgb_out[23]_i_1845\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \LAST_D/local_x\(4),
      I1 => \LAST_D/local_x\(5),
      O => \rgb_out[23]_i_1845_n_0\
    );
\rgb_out[23]_i_1846\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \LAST_D/local_x\(3),
      I1 => \LAST_D/local_x\(2),
      O => \rgb_out[23]_i_1846_n_0\
    );
\rgb_out[23]_i_1847\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => pixel_x(0),
      I1 => \LAST_D/local_x\(1),
      O => \rgb_out[23]_i_1847_n_0\
    );
\rgb_out[23]_i_1848\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \LAST_D/local_y\(6),
      I1 => \LAST_D/local_y\(7),
      O => \rgb_out[23]_i_1848_n_0\
    );
\rgb_out[23]_i_1849\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \LAST_D/local_y\(4),
      I1 => \LAST_D/local_y\(5),
      O => \rgb_out[23]_i_1849_n_0\
    );
\rgb_out[23]_i_1850\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \LAST_D/local_y\(1),
      I1 => pixel_y(0),
      O => \rgb_out[23]_i_1850_n_0\
    );
\rgb_out[23]_i_1851\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_D/local_y\(7),
      I1 => \LAST_D/local_y\(6),
      O => \rgb_out[23]_i_1851_n_0\
    );
\rgb_out[23]_i_1852\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_D/local_y\(5),
      I1 => \LAST_D/local_y\(4),
      O => \rgb_out[23]_i_1852_n_0\
    );
\rgb_out[23]_i_1853\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \LAST_D/local_y\(2),
      I1 => \LAST_D/local_y\(3),
      O => \rgb_out[23]_i_1853_n_0\
    );
\rgb_out[23]_i_1854\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => pixel_y(0),
      I1 => \LAST_D/local_y\(1),
      O => \rgb_out[23]_i_1854_n_0\
    );
\rgb_out[23]_i_1855\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_D/local_y\(5),
      I1 => \LAST_D/local_y\(4),
      O => \rgb_out[23]_i_1855_n_0\
    );
\rgb_out[23]_i_1856\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"7"
    )
        port map (
      I0 => \LAST_D/local_y\(2),
      I1 => \LAST_D/local_y\(3),
      O => \rgb_out[23]_i_1856_n_0\
    );
\rgb_out[23]_i_1857\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_D/local_y\(1),
      O => \rgb_out[23]_i_1857_n_0\
    );
\rgb_out[23]_i_1858\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_D/local_y\(7),
      I1 => \LAST_D/local_y\(6),
      O => \rgb_out[23]_i_1858_n_0\
    );
\rgb_out[23]_i_1859\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \LAST_D/local_y\(4),
      I1 => \LAST_D/local_y\(5),
      O => \rgb_out[23]_i_1859_n_0\
    );
\rgb_out[23]_i_1860\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \LAST_D/local_y\(3),
      I1 => \LAST_D/local_y\(2),
      O => \rgb_out[23]_i_1860_n_0\
    );
\rgb_out[23]_i_1861\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => pixel_y(0),
      I1 => \LAST_D/local_y\(1),
      O => \rgb_out[23]_i_1861_n_0\
    );
\rgb_out[23]_i_1862\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \LAST_D/local_y\(6),
      I1 => \LAST_D/local_y\(7),
      O => \rgb_out[23]_i_1862_n_0\
    );
\rgb_out[23]_i_1863\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \LAST_D/local_y\(1),
      I1 => pixel_y(0),
      O => \rgb_out[23]_i_1863_n_0\
    );
\rgb_out[23]_i_1864\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_D/local_y\(7),
      I1 => \LAST_D/local_y\(6),
      O => \rgb_out[23]_i_1864_n_0\
    );
\rgb_out[23]_i_1865\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \LAST_D/local_y\(4),
      I1 => \LAST_D/local_y\(5),
      O => \rgb_out[23]_i_1865_n_0\
    );
\rgb_out[23]_i_1866\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \LAST_D/local_y\(3),
      I1 => \LAST_D/local_y\(2),
      O => \rgb_out[23]_i_1866_n_0\
    );
\rgb_out[23]_i_1867\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => pixel_y(0),
      I1 => \LAST_D/local_y\(1),
      O => \rgb_out[23]_i_1867_n_0\
    );
\rgb_out[23]_i_1868\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"7"
    )
        port map (
      I0 => \LAST_D/local_y\(4),
      I1 => \LAST_D/local_y\(5),
      O => \rgb_out[23]_i_1868_n_0\
    );
\rgb_out[23]_i_1869\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_D/local_y\(3),
      I1 => \LAST_D/local_y\(2),
      O => \rgb_out[23]_i_1869_n_0\
    );
\rgb_out[23]_i_1870\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_D/local_y\(1),
      O => \rgb_out[23]_i_1870_n_0\
    );
\rgb_out[23]_i_1871\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_D/local_y\(7),
      I1 => \LAST_D/local_y\(6),
      O => \rgb_out[23]_i_1871_n_0\
    );
\rgb_out[23]_i_1872\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \LAST_D/local_y\(5),
      I1 => \LAST_D/local_y\(4),
      O => \rgb_out[23]_i_1872_n_0\
    );
\rgb_out[23]_i_1873\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \LAST_D/local_y\(2),
      I1 => \LAST_D/local_y\(3),
      O => \rgb_out[23]_i_1873_n_0\
    );
\rgb_out[23]_i_1874\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => pixel_y(0),
      I1 => \LAST_D/local_y\(1),
      O => \rgb_out[23]_i_1874_n_0\
    );
\rgb_out[23]_i_1875\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_x(7),
      O => \rgb_out[23]_i_1875_n_0\
    );
\rgb_out[23]_i_1876\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \LAST_D/local_y\(6),
      I1 => \LAST_D/local_y\(7),
      O => \rgb_out[23]_i_1876_n_0\
    );
\rgb_out[23]_i_1877\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \LAST_D/local_y\(4),
      I1 => \LAST_D/local_y\(5),
      O => \rgb_out[23]_i_1877_n_0\
    );
\rgb_out[23]_i_1878\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \LAST_D/local_y\(2),
      I1 => \LAST_D/local_y\(3),
      O => \rgb_out[23]_i_1878_n_0\
    );
\rgb_out[23]_i_1879\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"B"
    )
        port map (
      I0 => \LAST_D/local_y\(1),
      I1 => pixel_y(0),
      O => \rgb_out[23]_i_1879_n_0\
    );
\rgb_out[23]_i_1880\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_D/local_y\(7),
      I1 => \LAST_D/local_y\(6),
      O => \rgb_out[23]_i_1880_n_0\
    );
\rgb_out[23]_i_1881\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_D/local_y\(5),
      I1 => \LAST_D/local_y\(4),
      O => \rgb_out[23]_i_1881_n_0\
    );
\rgb_out[23]_i_1882\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_D/local_y\(3),
      I1 => \LAST_D/local_y\(2),
      O => \rgb_out[23]_i_1882_n_0\
    );
\rgb_out[23]_i_1883\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => pixel_y(0),
      I1 => \LAST_D/local_y\(1),
      O => \rgb_out[23]_i_1883_n_0\
    );
\rgb_out[23]_i_1884\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \LAST_D/local_x\(6),
      I1 => \LAST_D/local_x\(7),
      O => \rgb_out[23]_i_1884_n_0\
    );
\rgb_out[23]_i_1885\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \LAST_D/local_x\(4),
      I1 => \LAST_D/local_x\(5),
      O => \rgb_out[23]_i_1885_n_0\
    );
\rgb_out[23]_i_1886\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \LAST_D/local_x\(2),
      I1 => \LAST_D/local_x\(3),
      O => \rgb_out[23]_i_1886_n_0\
    );
\rgb_out[23]_i_1887\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"B"
    )
        port map (
      I0 => \LAST_D/local_x\(1),
      I1 => pixel_x(0),
      O => \rgb_out[23]_i_1887_n_0\
    );
\rgb_out[23]_i_1888\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_D/local_x\(7),
      I1 => \LAST_D/local_x\(6),
      O => \rgb_out[23]_i_1888_n_0\
    );
\rgb_out[23]_i_1889\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_D/local_x\(5),
      I1 => \LAST_D/local_x\(4),
      O => \rgb_out[23]_i_1889_n_0\
    );
\rgb_out[23]_i_1890\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_D/local_x\(3),
      I1 => \LAST_D/local_x\(2),
      O => \rgb_out[23]_i_1890_n_0\
    );
\rgb_out[23]_i_1891\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => pixel_x(0),
      I1 => \LAST_D/local_x\(1),
      O => \rgb_out[23]_i_1891_n_0\
    );
\rgb_out[23]_i_1892\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"7"
    )
        port map (
      I0 => \LAST_D/local_y\(4),
      I1 => \LAST_D/local_y\(5),
      O => \rgb_out[23]_i_1892_n_0\
    );
\rgb_out[23]_i_1893\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"7"
    )
        port map (
      I0 => \LAST_D/local_y\(2),
      I1 => \LAST_D/local_y\(3),
      O => \rgb_out[23]_i_1893_n_0\
    );
\rgb_out[23]_i_1894\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_D/local_y\(9),
      I1 => \LAST_D/local_y\(8),
      O => \rgb_out[23]_i_1894_n_0\
    );
\rgb_out[23]_i_1895\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_D/local_y\(7),
      I1 => \LAST_D/local_y\(6),
      O => \rgb_out[23]_i_1895_n_0\
    );
\rgb_out[23]_i_1896\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \LAST_D/local_y\(5),
      I1 => \LAST_D/local_y\(4),
      O => \rgb_out[23]_i_1896_n_0\
    );
\rgb_out[23]_i_1897\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \LAST_D/local_y\(3),
      I1 => \LAST_D/local_y\(2),
      O => \rgb_out[23]_i_1897_n_0\
    );
\rgb_out[23]_i_1898\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_D/local_x\(5),
      O => \rgb_out[23]_i_1898_n_0\
    );
\rgb_out[23]_i_1899\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_D/local_x\(3),
      I1 => \LAST_D/local_x\(2),
      O => \rgb_out[23]_i_1899_n_0\
    );
\rgb_out[23]_i_1900\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_D/local_x\(9),
      I1 => \LAST_D/local_x\(8),
      O => \rgb_out[23]_i_1900_n_0\
    );
\rgb_out[23]_i_1901\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_D/local_x\(7),
      I1 => \LAST_D/local_x\(6),
      O => \rgb_out[23]_i_1901_n_0\
    );
\rgb_out[23]_i_1902\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \LAST_D/local_x\(5),
      I1 => \LAST_D/local_x\(4),
      O => \rgb_out[23]_i_1902_n_0\
    );
\rgb_out[23]_i_1903\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \LAST_D/local_x\(2),
      I1 => \LAST_D/local_x\(3),
      O => \rgb_out[23]_i_1903_n_0\
    );
\rgb_out[23]_i_1906\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_x(11),
      O => \rgb_out[23]_i_1906_n_0\
    );
\rgb_out[23]_i_1907\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_x(10),
      O => \rgb_out[23]_i_1907_n_0\
    );
\rgb_out[23]_i_1908\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_x(9),
      O => \rgb_out[23]_i_1908_n_0\
    );
\rgb_out[23]_i_1909\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_x(8),
      O => \rgb_out[23]_i_1909_n_0\
    );
\rgb_out[23]_i_1911\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_y(8),
      O => \rgb_out[23]_i_1911_n_0\
    );
\rgb_out[23]_i_1912\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_y(7),
      O => \rgb_out[23]_i_1912_n_0\
    );
\rgb_out[23]_i_1913\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_y(6),
      O => \rgb_out[23]_i_1913_n_0\
    );
\rgb_out[23]_i_1914\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_y(5),
      O => \rgb_out[23]_i_1914_n_0\
    );
\rgb_out[23]_i_1915\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \SC_U/local_y\(6),
      I1 => \SC_U/local_y\(7),
      O => \rgb_out[23]_i_1915_n_0\
    );
\rgb_out[23]_i_1916\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => pixel_y(0),
      I1 => \SC_U/local_y\(1),
      O => \rgb_out[23]_i_1916_n_0\
    );
\rgb_out[23]_i_1917\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \SC_U/local_y\(7),
      I1 => \SC_U/local_y\(6),
      O => \rgb_out[23]_i_1917_n_0\
    );
\rgb_out[23]_i_1918\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \SC_U/local_y\(4),
      I1 => \SC_U/local_y\(5),
      O => \rgb_out[23]_i_1918_n_0\
    );
\rgb_out[23]_i_1919\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \SC_U/local_y\(2),
      I1 => \SC_U/local_y\(3),
      O => \rgb_out[23]_i_1919_n_0\
    );
\rgb_out[23]_i_1920\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \SC_U/local_y\(1),
      I1 => pixel_y(0),
      O => \rgb_out[23]_i_1920_n_0\
    );
\rgb_out[23]_i_1921\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \SC_U/local_x\(4),
      I1 => \SC_U/local_x\(5),
      O => \rgb_out[23]_i_1921_n_0\
    );
\rgb_out[23]_i_1922\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"7"
    )
        port map (
      I0 => \SC_U/local_x\(3),
      I1 => \SC_U/local_x\(2),
      O => \rgb_out[23]_i_1922_n_0\
    );
\rgb_out[23]_i_1923\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \SC_U/local_x\(1),
      O => \rgb_out[23]_i_1923_n_0\
    );
\rgb_out[23]_i_1924\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \SC_U/local_x\(7),
      I1 => \SC_U/local_x\(6),
      O => \rgb_out[23]_i_1924_n_0\
    );
\rgb_out[23]_i_1925\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \SC_U/local_x\(4),
      I1 => \SC_U/local_x\(5),
      O => \rgb_out[23]_i_1925_n_0\
    );
\rgb_out[23]_i_1926\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \SC_U/local_x\(2),
      I1 => \SC_U/local_x\(3),
      O => \rgb_out[23]_i_1926_n_0\
    );
\rgb_out[23]_i_1927\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \SC_U/local_x\(1),
      I1 => \SC_U/local_x\(0),
      O => \rgb_out[23]_i_1927_n_0\
    );
\rgb_out[23]_i_1935\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \SC_U/local_y\(5),
      O => \rgb_out[23]_i_1935_n_0\
    );
\rgb_out[23]_i_1936\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \SC_U/local_y\(1),
      I1 => pixel_y(0),
      O => \rgb_out[23]_i_1936_n_0\
    );
\rgb_out[23]_i_1937\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \SC_U/local_y\(7),
      I1 => \SC_U/local_y\(6),
      O => \rgb_out[23]_i_1937_n_0\
    );
\rgb_out[23]_i_1938\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \SC_U/local_y\(5),
      I1 => \SC_U/local_y\(4),
      O => \rgb_out[23]_i_1938_n_0\
    );
\rgb_out[23]_i_1939\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \SC_U/local_y\(3),
      I1 => \SC_U/local_y\(2),
      O => \rgb_out[23]_i_1939_n_0\
    );
\rgb_out[23]_i_1940\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => pixel_y(0),
      I1 => \SC_U/local_y\(1),
      O => \rgb_out[23]_i_1940_n_0\
    );
\rgb_out[23]_i_1941\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \SC_U/local_y\(6),
      I1 => \SC_U/local_y\(7),
      O => \rgb_out[23]_i_1941_n_0\
    );
\rgb_out[23]_i_1942\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \SC_U/local_y\(2),
      I1 => \SC_U/local_y\(3),
      O => \rgb_out[23]_i_1942_n_0\
    );
\rgb_out[23]_i_1943\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \SC_U/local_y\(7),
      I1 => \SC_U/local_y\(6),
      O => \rgb_out[23]_i_1943_n_0\
    );
\rgb_out[23]_i_1944\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \SC_U/local_y\(4),
      I1 => \SC_U/local_y\(5),
      O => \rgb_out[23]_i_1944_n_0\
    );
\rgb_out[23]_i_1945\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \SC_U/local_y\(3),
      I1 => \SC_U/local_y\(2),
      O => \rgb_out[23]_i_1945_n_0\
    );
\rgb_out[23]_i_1946\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => pixel_y(0),
      I1 => \SC_U/local_y\(1),
      O => \rgb_out[23]_i_1946_n_0\
    );
\rgb_out[23]_i_1947\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \SC_U/local_y\(3),
      I1 => \SC_U/local_y\(2),
      O => \rgb_out[23]_i_1947_n_0\
    );
\rgb_out[23]_i_1948\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \SC_U/local_y\(1),
      O => \rgb_out[23]_i_1948_n_0\
    );
\rgb_out[23]_i_1949\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \SC_U/local_y\(7),
      I1 => \SC_U/local_y\(6),
      O => \rgb_out[23]_i_1949_n_0\
    );
\rgb_out[23]_i_1950\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \SC_U/local_y\(5),
      I1 => \SC_U/local_y\(4),
      O => \rgb_out[23]_i_1950_n_0\
    );
\rgb_out[23]_i_1951\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \SC_U/local_y\(2),
      I1 => \SC_U/local_y\(3),
      O => \rgb_out[23]_i_1951_n_0\
    );
\rgb_out[23]_i_1952\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \SC_U/local_y\(1),
      I1 => pixel_y(0),
      O => \rgb_out[23]_i_1952_n_0\
    );
\rgb_out[23]_i_1953\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \SC_U/local_y\(5),
      I1 => \SC_U/local_y\(4),
      O => \rgb_out[23]_i_1953_n_0\
    );
\rgb_out[23]_i_1954\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"7"
    )
        port map (
      I0 => \SC_U/local_y\(3),
      I1 => \SC_U/local_y\(2),
      O => \rgb_out[23]_i_1954_n_0\
    );
\rgb_out[23]_i_1955\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \SC_U/local_y\(1),
      O => \rgb_out[23]_i_1955_n_0\
    );
\rgb_out[23]_i_1956\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \SC_U/local_y\(7),
      I1 => \SC_U/local_y\(6),
      O => \rgb_out[23]_i_1956_n_0\
    );
\rgb_out[23]_i_1957\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \SC_U/local_y\(4),
      I1 => \SC_U/local_y\(5),
      O => \rgb_out[23]_i_1957_n_0\
    );
\rgb_out[23]_i_1958\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \SC_U/local_y\(2),
      I1 => \SC_U/local_y\(3),
      O => \rgb_out[23]_i_1958_n_0\
    );
\rgb_out[23]_i_1959\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \SC_U/local_y\(1),
      I1 => pixel_y(0),
      O => \rgb_out[23]_i_1959_n_0\
    );
\rgb_out[23]_i_1960\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \SC_U/local_y\(6),
      I1 => \SC_U/local_y\(7),
      O => \rgb_out[23]_i_1960_n_0\
    );
\rgb_out[23]_i_1961\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \SC_U/local_y\(4),
      I1 => \SC_U/local_y\(5),
      O => \rgb_out[23]_i_1961_n_0\
    );
\rgb_out[23]_i_1962\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => pixel_y(0),
      I1 => \SC_U/local_y\(1),
      O => \rgb_out[23]_i_1962_n_0\
    );
\rgb_out[23]_i_1963\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \SC_U/local_y\(7),
      I1 => \SC_U/local_y\(6),
      O => \rgb_out[23]_i_1963_n_0\
    );
\rgb_out[23]_i_1964\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \SC_U/local_y\(5),
      I1 => \SC_U/local_y\(4),
      O => \rgb_out[23]_i_1964_n_0\
    );
\rgb_out[23]_i_1965\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \SC_U/local_y\(2),
      I1 => \SC_U/local_y\(3),
      O => \rgb_out[23]_i_1965_n_0\
    );
\rgb_out[23]_i_1966\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \SC_U/local_y\(1),
      I1 => pixel_y(0),
      O => \rgb_out[23]_i_1966_n_0\
    );
\rgb_out[23]_i_1967\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \SC_U/local_x\(3),
      I1 => \SC_U/local_x\(2),
      O => \rgb_out[23]_i_1967_n_0\
    );
\rgb_out[23]_i_1968\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \SC_U/local_x\(1),
      O => \rgb_out[23]_i_1968_n_0\
    );
\rgb_out[23]_i_1969\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \SC_U/local_x\(7),
      I1 => \SC_U/local_x\(6),
      O => \rgb_out[23]_i_1969_n_0\
    );
\rgb_out[23]_i_1970\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \SC_U/local_x\(4),
      I1 => \SC_U/local_x\(5),
      O => \rgb_out[23]_i_1970_n_0\
    );
\rgb_out[23]_i_1971\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \SC_U/local_x\(2),
      I1 => \SC_U/local_x\(3),
      O => \rgb_out[23]_i_1971_n_0\
    );
\rgb_out[23]_i_1972\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \SC_U/local_x\(1),
      I1 => \SC_U/local_x\(0),
      O => \rgb_out[23]_i_1972_n_0\
    );
\rgb_out[23]_i_1973\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \SC_U/local_x\(6),
      I1 => \SC_U/local_x\(7),
      O => \rgb_out[23]_i_1973_n_0\
    );
\rgb_out[23]_i_1974\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \SC_U/local_x\(0),
      I1 => \SC_U/local_x\(1),
      O => \rgb_out[23]_i_1974_n_0\
    );
\rgb_out[23]_i_1975\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \SC_U/local_x\(7),
      I1 => \SC_U/local_x\(6),
      O => \rgb_out[23]_i_1975_n_0\
    );
\rgb_out[23]_i_1976\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \SC_U/local_x\(4),
      I1 => \SC_U/local_x\(5),
      O => \rgb_out[23]_i_1976_n_0\
    );
\rgb_out[23]_i_1977\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \SC_U/local_x\(2),
      I1 => \SC_U/local_x\(3),
      O => \rgb_out[23]_i_1977_n_0\
    );
\rgb_out[23]_i_1978\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \SC_U/local_x\(1),
      I1 => \SC_U/local_x\(0),
      O => \rgb_out[23]_i_1978_n_0\
    );
\rgb_out[23]_i_1979\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"7"
    )
        port map (
      I0 => \SC_U/local_y\(5),
      I1 => \SC_U/local_y\(4),
      O => \rgb_out[23]_i_1979_n_0\
    );
\rgb_out[23]_i_1980\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \SC_U/local_y\(3),
      I1 => \SC_U/local_y\(2),
      O => \rgb_out[23]_i_1980_n_0\
    );
\rgb_out[23]_i_1981\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \SC_U/local_y\(1),
      O => \rgb_out[23]_i_1981_n_0\
    );
\rgb_out[23]_i_1982\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \SC_U/local_y\(7),
      I1 => \SC_U/local_y\(6),
      O => \rgb_out[23]_i_1982_n_0\
    );
\rgb_out[23]_i_1983\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \SC_U/local_y\(4),
      I1 => \SC_U/local_y\(5),
      O => \rgb_out[23]_i_1983_n_0\
    );
\rgb_out[23]_i_1984\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \SC_U/local_y\(2),
      I1 => \SC_U/local_y\(3),
      O => \rgb_out[23]_i_1984_n_0\
    );
\rgb_out[23]_i_1985\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \SC_U/local_y\(1),
      I1 => pixel_y(0),
      O => \rgb_out[23]_i_1985_n_0\
    );
\rgb_out[23]_i_1986\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \SC_U/local_y\(6),
      I1 => \SC_U/local_y\(7),
      O => \rgb_out[23]_i_1986_n_0\
    );
\rgb_out[23]_i_1987\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => pixel_y(0),
      I1 => \SC_U/local_y\(1),
      O => \rgb_out[23]_i_1987_n_0\
    );
\rgb_out[23]_i_1988\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \SC_U/local_y\(7),
      I1 => \SC_U/local_y\(6),
      O => \rgb_out[23]_i_1988_n_0\
    );
\rgb_out[23]_i_1989\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \SC_U/local_y\(4),
      I1 => \SC_U/local_y\(5),
      O => \rgb_out[23]_i_1989_n_0\
    );
\rgb_out[23]_i_1990\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \SC_U/local_y\(2),
      I1 => \SC_U/local_y\(3),
      O => \rgb_out[23]_i_1990_n_0\
    );
\rgb_out[23]_i_1991\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \SC_U/local_y\(1),
      I1 => pixel_y(0),
      O => \rgb_out[23]_i_1991_n_0\
    );
\rgb_out[23]_i_1992\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \SC_D/local_y\(3),
      I1 => \SC_D/local_y\(2),
      O => \rgb_out[23]_i_1992_n_0\
    );
\rgb_out[23]_i_1993\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \SC_D/local_y\(1),
      O => \rgb_out[23]_i_1993_n_0\
    );
\rgb_out[23]_i_1994\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \SC_D/local_y\(7),
      I1 => \SC_D/local_y\(6),
      O => \rgb_out[23]_i_1994_n_0\
    );
\rgb_out[23]_i_1995\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \SC_D/local_y\(5),
      I1 => \SC_D/local_y\(4),
      O => \rgb_out[23]_i_1995_n_0\
    );
\rgb_out[23]_i_1996\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \SC_D/local_y\(2),
      I1 => \SC_D/local_y\(3),
      O => \rgb_out[23]_i_1996_n_0\
    );
\rgb_out[23]_i_1997\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \SC_D/local_y\(1),
      I1 => pixel_y(0),
      O => \rgb_out[23]_i_1997_n_0\
    );
\rgb_out[23]_i_2002\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \SC_D/local_y\(6),
      I1 => \SC_D/local_y\(7),
      O => \rgb_out[23]_i_2002_n_0\
    );
\rgb_out[23]_i_2004\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => pixel_y(0),
      I1 => \SC_D/local_y\(1),
      O => \rgb_out[23]_i_2004_n_0\
    );
\rgb_out[23]_i_2005\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \SC_D/local_y\(7),
      I1 => \SC_D/local_y\(6),
      O => \rgb_out[23]_i_2005_n_0\
    );
\rgb_out[23]_i_2006\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \SC_D/local_y\(5),
      I1 => \SC_D/local_y\(4),
      O => \rgb_out[23]_i_2006_n_0\
    );
\rgb_out[23]_i_2007\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \SC_D/local_y\(2),
      I1 => \SC_D/local_y\(3),
      O => \rgb_out[23]_i_2007_n_0\
    );
\rgb_out[23]_i_2008\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \SC_D/local_y\(1),
      I1 => pixel_y(0),
      O => \rgb_out[23]_i_2008_n_0\
    );
\rgb_out[23]_i_2017\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \SC_D/local_x\(5),
      I1 => \SC_D/local_x\(4),
      O => \rgb_out[23]_i_2017_n_0\
    );
\rgb_out[23]_i_2018\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"7"
    )
        port map (
      I0 => \SC_D/local_x\(2),
      I1 => \SC_D/local_x\(3),
      O => \rgb_out[23]_i_2018_n_0\
    );
\rgb_out[23]_i_2019\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \SC_D/local_x\(1),
      O => \rgb_out[23]_i_2019_n_0\
    );
\rgb_out[23]_i_2020\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \SC_D/local_x\(7),
      I1 => \SC_D/local_x\(6),
      O => \rgb_out[23]_i_2020_n_0\
    );
\rgb_out[23]_i_2021\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \SC_D/local_x\(4),
      I1 => \SC_D/local_x\(5),
      O => \rgb_out[23]_i_2021_n_0\
    );
\rgb_out[23]_i_2022\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \SC_D/local_x\(3),
      I1 => \SC_D/local_x\(2),
      O => \rgb_out[23]_i_2022_n_0\
    );
\rgb_out[23]_i_2023\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \SC_D/local_x\(1),
      I1 => \SC_D/local_x\(0),
      O => \rgb_out[23]_i_2023_n_0\
    );
\rgb_out[23]_i_2038\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \SC_D/local_y\(6),
      I1 => \SC_D/local_y\(7),
      O => \rgb_out[23]_i_2038_n_0\
    );
\rgb_out[23]_i_2039\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => pixel_y(0),
      I1 => \SC_D/local_y\(1),
      O => \rgb_out[23]_i_2039_n_0\
    );
\rgb_out[23]_i_2040\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \SC_D/local_y\(7),
      I1 => \SC_D/local_y\(6),
      O => \rgb_out[23]_i_2040_n_0\
    );
\rgb_out[23]_i_2041\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \SC_D/local_y\(4),
      I1 => \SC_D/local_y\(5),
      O => \rgb_out[23]_i_2041_n_0\
    );
\rgb_out[23]_i_2042\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \SC_D/local_y\(3),
      I1 => \SC_D/local_y\(2),
      O => \rgb_out[23]_i_2042_n_0\
    );
\rgb_out[23]_i_2043\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \SC_D/local_y\(1),
      I1 => pixel_y(0),
      O => \rgb_out[23]_i_2043_n_0\
    );
\rgb_out[23]_i_2051\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_x(6),
      O => \rgb_out[23]_i_2051_n_0\
    );
\rgb_out[23]_i_2052\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_x(5),
      O => \rgb_out[23]_i_2052_n_0\
    );
\rgb_out[23]_i_2053\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_x(11),
      O => \rgb_out[23]_i_2053_n_0\
    );
\rgb_out[23]_i_2054\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_x(10),
      O => \rgb_out[23]_i_2054_n_0\
    );
\rgb_out[23]_i_2055\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_x(9),
      O => \rgb_out[23]_i_2055_n_0\
    );
\rgb_out[23]_i_2056\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_x(8),
      O => \rgb_out[23]_i_2056_n_0\
    );
\rgb_out[23]_i_2057\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \SC_D/local_y\(6),
      I1 => \SC_D/local_y\(7),
      O => \rgb_out[23]_i_2057_n_0\
    );
\rgb_out[23]_i_2058\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \SC_D/local_y\(4),
      I1 => \SC_D/local_y\(5),
      O => \rgb_out[23]_i_2058_n_0\
    );
\rgb_out[23]_i_2059\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \SC_D/local_y\(2),
      I1 => \SC_D/local_y\(3),
      O => \rgb_out[23]_i_2059_n_0\
    );
\rgb_out[23]_i_2060\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \SC_D/local_y\(1),
      I1 => pixel_y(0),
      O => \rgb_out[23]_i_2060_n_0\
    );
\rgb_out[23]_i_2061\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \SC_D/local_y\(7),
      I1 => \SC_D/local_y\(6),
      O => \rgb_out[23]_i_2061_n_0\
    );
\rgb_out[23]_i_2062\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \SC_D/local_y\(5),
      I1 => \SC_D/local_y\(4),
      O => \rgb_out[23]_i_2062_n_0\
    );
\rgb_out[23]_i_2063\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \SC_D/local_y\(3),
      I1 => \SC_D/local_y\(2),
      O => \rgb_out[23]_i_2063_n_0\
    );
\rgb_out[23]_i_2064\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_y(0),
      I1 => \SC_D/local_y\(1),
      O => \rgb_out[23]_i_2064_n_0\
    );
\rgb_out[23]_i_2065\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \SC_D/local_x\(6),
      I1 => \SC_D/local_x\(7),
      O => \rgb_out[23]_i_2065_n_0\
    );
\rgb_out[23]_i_2066\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \SC_D/local_x\(4),
      I1 => \SC_D/local_x\(5),
      O => \rgb_out[23]_i_2066_n_0\
    );
\rgb_out[23]_i_2067\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \SC_D/local_x\(2),
      I1 => \SC_D/local_x\(3),
      O => \rgb_out[23]_i_2067_n_0\
    );
\rgb_out[23]_i_2068\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \SC_D/local_x\(1),
      I1 => \SC_D/local_x\(0),
      O => \rgb_out[23]_i_2068_n_0\
    );
\rgb_out[23]_i_2069\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \SC_D/local_x\(7),
      I1 => \SC_D/local_x\(6),
      O => \rgb_out[23]_i_2069_n_0\
    );
\rgb_out[23]_i_2070\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \SC_D/local_x\(5),
      I1 => \SC_D/local_x\(4),
      O => \rgb_out[23]_i_2070_n_0\
    );
\rgb_out[23]_i_2071\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \SC_D/local_x\(3),
      I1 => \SC_D/local_x\(2),
      O => \rgb_out[23]_i_2071_n_0\
    );
\rgb_out[23]_i_2072\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \SC_D/local_x\(0),
      I1 => \SC_D/local_x\(1),
      O => \rgb_out[23]_i_2072_n_0\
    );
\rgb_out[23]_i_2073\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"7"
    )
        port map (
      I0 => \SC_D/local_y\(4),
      I1 => \SC_D/local_y\(5),
      O => \rgb_out[23]_i_2073_n_0\
    );
\rgb_out[23]_i_2074\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"7"
    )
        port map (
      I0 => \SC_D/local_y\(2),
      I1 => \SC_D/local_y\(3),
      O => \rgb_out[23]_i_2074_n_0\
    );
\rgb_out[23]_i_2075\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \SC_D/local_y\(9),
      I1 => \SC_D/local_y\(8),
      O => \rgb_out[23]_i_2075_n_0\
    );
\rgb_out[23]_i_2076\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \SC_D/local_y\(7),
      I1 => \SC_D/local_y\(6),
      O => \rgb_out[23]_i_2076_n_0\
    );
\rgb_out[23]_i_2077\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \SC_D/local_y\(5),
      I1 => \SC_D/local_y\(4),
      O => \rgb_out[23]_i_2077_n_0\
    );
\rgb_out[23]_i_2078\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \SC_D/local_y\(3),
      I1 => \SC_D/local_y\(2),
      O => \rgb_out[23]_i_2078_n_0\
    );
\rgb_out[23]_i_2079\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \SC_D/local_x\(5),
      O => \rgb_out[23]_i_2079_n_0\
    );
\rgb_out[23]_i_2080\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \SC_D/local_x\(3),
      I1 => \SC_D/local_x\(2),
      O => \rgb_out[23]_i_2080_n_0\
    );
\rgb_out[23]_i_2081\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \SC_D/local_x\(9),
      I1 => \SC_D/local_x\(8),
      O => \rgb_out[23]_i_2081_n_0\
    );
\rgb_out[23]_i_2082\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \SC_D/local_x\(7),
      I1 => \SC_D/local_x\(6),
      O => \rgb_out[23]_i_2082_n_0\
    );
\rgb_out[23]_i_2083\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \SC_D/local_x\(5),
      I1 => \SC_D/local_x\(4),
      O => \rgb_out[23]_i_2083_n_0\
    );
\rgb_out[23]_i_2084\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \SC_D/local_x\(2),
      I1 => \SC_D/local_x\(3),
      O => \rgb_out[23]_i_2084_n_0\
    );
\rgb_out[23]_i_2085\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_y(8),
      O => \rgb_out[23]_i_2085_n_0\
    );
\rgb_out[23]_i_2086\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_y(7),
      O => \rgb_out[23]_i_2086_n_0\
    );
\rgb_out[23]_i_2087\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_y(6),
      O => \rgb_out[23]_i_2087_n_0\
    );
\rgb_out[23]_i_2088\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_y(5),
      O => \rgb_out[23]_i_2088_n_0\
    );
\rgb_out[23]_i_2089\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_y(4),
      O => \rgb_out[23]_i_2089_n_0\
    );
\rgb_out[23]_i_2090\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_y(2),
      O => \rgb_out[23]_i_2090_n_0\
    );
\rgb_out[23]_i_2091\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_y(5),
      O => \rgb_out[23]_i_2091_n_0\
    );
\rgb_out[23]_i_2092\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_y(4),
      O => \rgb_out[23]_i_2092_n_0\
    );
\rgb_out[23]_i_2093\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_y(3),
      O => \rgb_out[23]_i_2093_n_0\
    );
\rgb_out[23]_i_2094\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_y(1),
      O => \rgb_out[23]_i_2094_n_0\
    );
\rgb_out[23]_i_2095\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_x(4),
      O => \rgb_out[23]_i_2095_n_0\
    );
\rgb_out[23]_i_2096\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_x(3),
      O => \rgb_out[23]_i_2096_n_0\
    );
\rgb_out[23]_i_2097\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_x(2),
      O => \rgb_out[23]_i_2097_n_0\
    );
\rgb_out[23]_i_2098\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_x(6),
      O => \rgb_out[23]_i_2098_n_0\
    );
\rgb_out[23]_i_2099\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_x(5),
      O => \rgb_out[23]_i_2099_n_0\
    );
\rgb_out[23]_i_2100\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_y(5),
      O => \rgb_out[23]_i_2100_n_0\
    );
\rgb_out[23]_i_2101\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_y(4),
      O => \rgb_out[23]_i_2101_n_0\
    );
\rgb_out[23]_i_2102\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_y(3),
      O => \rgb_out[23]_i_2102_n_0\
    );
\rgb_out[23]_i_2103\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_y(1),
      O => \rgb_out[23]_i_2103_n_0\
    );
\rgb_out[23]_i_2104\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_x(4),
      O => \rgb_out[23]_i_2104_n_0\
    );
\rgb_out[23]_i_2105\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_x(2),
      O => \rgb_out[23]_i_2105_n_0\
    );
\rgb_out[23]_i_2106\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_x(8),
      O => \rgb_out[23]_i_2106_n_0\
    );
\rgb_out[23]_i_2107\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_x(6),
      O => \rgb_out[23]_i_2107_n_0\
    );
\rgb_out[23]_i_2108\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_y(5),
      O => \rgb_out[23]_i_2108_n_0\
    );
\rgb_out[23]_i_2109\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_y(4),
      O => \rgb_out[23]_i_2109_n_0\
    );
\rgb_out[23]_i_2110\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_y(3),
      O => \rgb_out[23]_i_2110_n_0\
    );
\rgb_out[23]_i_2111\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_y(1),
      O => \rgb_out[23]_i_2111_n_0\
    );
\rgb_out[23]_i_2112\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_x(4),
      O => \rgb_out[23]_i_2112_n_0\
    );
\rgb_out[23]_i_2113\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_x(2),
      O => \rgb_out[23]_i_2113_n_0\
    );
\rgb_out[23]_i_2114\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_y(5),
      O => \rgb_out[23]_i_2114_n_0\
    );
\rgb_out[23]_i_2115\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_y(4),
      O => \rgb_out[23]_i_2115_n_0\
    );
\rgb_out[23]_i_2116\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_y(3),
      O => \rgb_out[23]_i_2116_n_0\
    );
\rgb_out[23]_i_2117\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_y(1),
      O => \rgb_out[23]_i_2117_n_0\
    );
\rgb_out[23]_i_2118\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_x(4),
      O => \rgb_out[23]_i_2118_n_0\
    );
\rgb_out[23]_i_2119\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_x(3),
      O => \rgb_out[23]_i_2119_n_0\
    );
\rgb_out[23]_i_2120\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_x(2),
      O => \rgb_out[23]_i_2120_n_0\
    );
\rgb_out[23]_i_2121\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_x(6),
      O => \rgb_out[23]_i_2121_n_0\
    );
\rgb_out[23]_i_2122\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_x(1),
      O => \rgb_out[23]_i_2122_n_0\
    );
\rgb_out[23]_i_2123\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_y(4),
      O => \rgb_out[23]_i_2123_n_0\
    );
\rgb_out[23]_i_2124\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_y(2),
      O => \rgb_out[23]_i_2124_n_0\
    );
\rgb_out[23]_i_2131\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_x(3),
      O => \rgb_out[23]_i_2131_n_0\
    );
\rgb_out[23]_i_2132\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_x(1),
      O => \rgb_out[23]_i_2132_n_0\
    );
\rgb_out[23]_i_479\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \TM_D/local_x\(10),
      I1 => \TM_D/local_x\(11),
      O => \rgb_out[23]_i_479_n_0\
    );
\rgb_out[23]_i_480\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \TM_D/local_x\(8),
      I1 => \TM_D/local_x\(9),
      O => \rgb_out[23]_i_480_n_0\
    );
\rgb_out[23]_i_482\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \TM_D/local_x\(11),
      I1 => \TM_D/local_x\(10),
      O => \rgb_out[23]_i_482_n_0\
    );
\rgb_out[23]_i_483\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \TM_D/local_x\(9),
      I1 => \TM_D/local_x\(8),
      O => \rgb_out[23]_i_483_n_0\
    );
\rgb_out[23]_i_485\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \rgb_out_reg[23]_i_481_n_1\,
      O => \rgb_out[23]_i_485_n_0\
    );
\rgb_out[23]_i_486\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \TM_D/local_x\(11),
      I1 => \TM_D/local_x\(10),
      O => \rgb_out[23]_i_486_n_0\
    );
\rgb_out[23]_i_487\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \TM_D/local_x\(9),
      I1 => \TM_D/local_x\(8),
      O => \rgb_out[23]_i_487_n_0\
    );
\rgb_out[23]_i_589\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \REC_D/local_x\(10),
      I1 => \REC_D/local_x\(11),
      O => \rgb_out[23]_i_589_n_0\
    );
\rgb_out[23]_i_590\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \REC_D/local_x\(8),
      I1 => \REC_D/local_x\(9),
      O => \rgb_out[23]_i_590_n_0\
    );
\rgb_out[23]_i_592\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_D/local_x\(11),
      I1 => \REC_D/local_x\(10),
      O => \rgb_out[23]_i_592_n_0\
    );
\rgb_out[23]_i_593\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_D/local_x\(9),
      I1 => \REC_D/local_x\(8),
      O => \rgb_out[23]_i_593_n_0\
    );
\rgb_out[23]_i_595\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \rgb_out_reg[23]_i_591_n_0\,
      O => \rgb_out[23]_i_595_n_0\
    );
\rgb_out[23]_i_596\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_D/local_x\(11),
      I1 => \REC_D/local_x\(10),
      O => \rgb_out[23]_i_596_n_0\
    );
\rgb_out[23]_i_597\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_D/local_x\(9),
      I1 => \REC_D/local_x\(8),
      O => \rgb_out[23]_i_597_n_0\
    );
\rgb_out[23]_i_663\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \LAST_D/local_x\(10),
      I1 => \LAST_D/local_x\(11),
      O => \rgb_out[23]_i_663_n_0\
    );
\rgb_out[23]_i_664\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \LAST_D/local_x\(8),
      I1 => \LAST_D/local_x\(9),
      O => \rgb_out[23]_i_664_n_0\
    );
\rgb_out[23]_i_666\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_D/local_x\(11),
      I1 => \LAST_D/local_x\(10),
      O => \rgb_out[23]_i_666_n_0\
    );
\rgb_out[23]_i_667\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_D/local_x\(9),
      I1 => \LAST_D/local_x\(8),
      O => \rgb_out[23]_i_667_n_0\
    );
\rgb_out[23]_i_669\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \rgb_out_reg[23]_i_665_n_0\,
      O => \rgb_out[23]_i_669_n_0\
    );
\rgb_out[23]_i_670\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_D/local_x\(11),
      I1 => \LAST_D/local_x\(10),
      O => \rgb_out[23]_i_670_n_0\
    );
\rgb_out[23]_i_671\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_D/local_x\(9),
      I1 => \LAST_D/local_x\(8),
      O => \rgb_out[23]_i_671_n_0\
    );
\rgb_out[23]_i_715\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \rgb_out_reg[23]_i_716_n_3\,
      O => \SC_U/local_x\(12)
    );
\rgb_out[23]_i_717\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \SC_U/local_x\(11),
      I1 => \SC_U/local_x\(10),
      O => \rgb_out[23]_i_717_n_0\
    );
\rgb_out[23]_i_719\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \rgb_out_reg[23]_i_720_n_0\,
      O => \SC_U/local_y\(12)
    );
\rgb_out[23]_i_722\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \SC_U/local_x\(10),
      I1 => \SC_U/local_x\(11),
      O => \rgb_out[23]_i_722_n_0\
    );
\rgb_out[23]_i_723\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \SC_U/local_x\(8),
      I1 => \SC_U/local_x\(9),
      O => \rgb_out[23]_i_723_n_0\
    );
\rgb_out[23]_i_724\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \SC_U/local_x\(11),
      I1 => \SC_U/local_x\(10),
      O => \rgb_out[23]_i_724_n_0\
    );
\rgb_out[23]_i_725\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \SC_U/local_x\(9),
      I1 => \SC_U/local_x\(8),
      O => \rgb_out[23]_i_725_n_0\
    );
\rgb_out[23]_i_727\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \SC_U/local_y\(10),
      I1 => \SC_U/local_y\(11),
      O => \rgb_out[23]_i_727_n_0\
    );
\rgb_out[23]_i_728\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \SC_U/local_y\(8),
      I1 => \SC_U/local_y\(9),
      O => \rgb_out[23]_i_728_n_0\
    );
\rgb_out[23]_i_729\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \SC_U/local_y\(11),
      I1 => \SC_U/local_y\(10),
      O => \rgb_out[23]_i_729_n_0\
    );
\rgb_out[23]_i_730\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \SC_U/local_y\(9),
      I1 => \SC_U/local_y\(8),
      O => \rgb_out[23]_i_730_n_0\
    );
\rgb_out[23]_i_759\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \SC_D/local_x\(10),
      I1 => \SC_D/local_x\(11),
      O => \rgb_out[23]_i_759_n_0\
    );
\rgb_out[23]_i_760\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \SC_D/local_x\(8),
      I1 => \SC_D/local_x\(9),
      O => \rgb_out[23]_i_760_n_0\
    );
\rgb_out[23]_i_762\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \SC_D/local_x\(11),
      I1 => \SC_D/local_x\(10),
      O => \rgb_out[23]_i_762_n_0\
    );
\rgb_out[23]_i_763\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \SC_D/local_x\(9),
      I1 => \SC_D/local_x\(8),
      O => \rgb_out[23]_i_763_n_0\
    );
\rgb_out[23]_i_765\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \rgb_out_reg[23]_i_761_n_3\,
      O => \rgb_out[23]_i_765_n_0\
    );
\rgb_out[23]_i_766\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \SC_D/local_x\(11),
      I1 => \SC_D/local_x\(10),
      O => \rgb_out[23]_i_766_n_0\
    );
\rgb_out[23]_i_767\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \SC_D/local_x\(9),
      I1 => \SC_D/local_x\(8),
      O => \rgb_out[23]_i_767_n_0\
    );
\rgb_out[23]_i_778\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \rgb_out_reg[23]_i_779_n_0\,
      O => \rgb_out[23]_i_778_n_0\
    );
\rgb_out[23]_i_780\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \TM_D/local_y\(11),
      I1 => \TM_D/local_y\(10),
      O => \rgb_out[23]_i_780_n_0\
    );
\rgb_out[23]_i_781\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \TM_D/local_y\(9),
      I1 => \TM_D/local_y\(8),
      O => \rgb_out[23]_i_781_n_0\
    );
\rgb_out[23]_i_783\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \TM_D/local_y\(10),
      I1 => \TM_D/local_y\(11),
      O => \rgb_out[23]_i_783_n_0\
    );
\rgb_out[23]_i_784\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \TM_D/local_y\(8),
      I1 => \TM_D/local_y\(9),
      O => \rgb_out[23]_i_784_n_0\
    );
\rgb_out[23]_i_785\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \TM_D/local_y\(11),
      I1 => \TM_D/local_y\(10),
      O => \rgb_out[23]_i_785_n_0\
    );
\rgb_out[23]_i_786\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \TM_D/local_y\(9),
      I1 => \TM_D/local_y\(8),
      O => \rgb_out[23]_i_786_n_0\
    );
\rgb_out[23]_i_793\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \rgb_out_reg[23]_i_481_n_1\,
      O => \rgb_out[23]_i_793_n_0\
    );
\rgb_out[23]_i_794\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \TM_D/local_x\(11),
      I1 => \TM_D/local_x\(10),
      O => \rgb_out[23]_i_794_n_0\
    );
\rgb_out[23]_i_795\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \TM_D/local_x\(9),
      I1 => \TM_D/local_x\(8),
      O => \rgb_out[23]_i_795_n_0\
    );
\rgb_out[23]_i_797\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \TM_D/local_y\(10),
      I1 => \TM_D/local_y\(11),
      O => \rgb_out[23]_i_797_n_0\
    );
\rgb_out[23]_i_798\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \TM_D/local_y\(8),
      I1 => \TM_D/local_y\(9),
      O => \rgb_out[23]_i_798_n_0\
    );
\rgb_out[23]_i_799\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \TM_D/local_y\(11),
      I1 => \TM_D/local_y\(10),
      O => \rgb_out[23]_i_799_n_0\
    );
\rgb_out[23]_i_800\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \TM_D/local_y\(9),
      I1 => \TM_D/local_y\(8),
      O => \rgb_out[23]_i_800_n_0\
    );
\rgb_out[23]_i_802\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \rgb_out_reg[23]_i_779_n_0\,
      O => \rgb_out[23]_i_802_n_0\
    );
\rgb_out[23]_i_803\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \TM_D/local_y\(11),
      I1 => \TM_D/local_y\(10),
      O => \rgb_out[23]_i_803_n_0\
    );
\rgb_out[23]_i_804\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \TM_D/local_y\(9),
      I1 => \TM_D/local_y\(8),
      O => \rgb_out[23]_i_804_n_0\
    );
\rgb_out[23]_i_806\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \TM_D/local_y\(10),
      I1 => \TM_D/local_y\(11),
      O => \rgb_out[23]_i_806_n_0\
    );
\rgb_out[23]_i_807\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \TM_D/local_y\(8),
      I1 => \TM_D/local_y\(9),
      O => \rgb_out[23]_i_807_n_0\
    );
\rgb_out[23]_i_808\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \TM_D/local_y\(11),
      I1 => \TM_D/local_y\(10),
      O => \rgb_out[23]_i_808_n_0\
    );
\rgb_out[23]_i_809\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \TM_D/local_y\(9),
      I1 => \TM_D/local_y\(8),
      O => \rgb_out[23]_i_809_n_0\
    );
\rgb_out[23]_i_811\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \rgb_out_reg[23]_i_779_n_0\,
      O => \rgb_out[23]_i_811_n_0\
    );
\rgb_out[23]_i_812\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \TM_D/local_y\(11),
      I1 => \TM_D/local_y\(10),
      O => \rgb_out[23]_i_812_n_0\
    );
\rgb_out[23]_i_813\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \TM_D/local_y\(9),
      I1 => \TM_D/local_y\(8),
      O => \rgb_out[23]_i_813_n_0\
    );
\rgb_out[23]_i_814\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \TM_D/local_x\(6),
      I1 => \TM_D/local_x\(7),
      O => \rgb_out[23]_i_814_n_0\
    );
\rgb_out[23]_i_816\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => pixel_x(0),
      I1 => pixel_x(1),
      O => \rgb_out[23]_i_816_n_0\
    );
\rgb_out[23]_i_817\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \TM_D/local_x\(7),
      I1 => \TM_D/local_x\(6),
      O => \rgb_out[23]_i_817_n_0\
    );
\rgb_out[23]_i_818\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \TM_D/local_x\(4),
      I1 => \TM_D/local_x\(5),
      O => \rgb_out[23]_i_818_n_0\
    );
\rgb_out[23]_i_819\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \TM_D/local_x\(3),
      I1 => \TM_D/local_x\(2),
      O => \rgb_out[23]_i_819_n_0\
    );
\rgb_out[23]_i_820\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => pixel_x(1),
      I1 => pixel_x(0),
      O => \rgb_out[23]_i_820_n_0\
    );
\rgb_out[23]_i_822\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_x(11),
      O => \rgb_out[23]_i_822_n_0\
    );
\rgb_out[23]_i_823\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \TM_D/local_x\(3),
      I1 => \TM_D/local_x\(2),
      O => \rgb_out[23]_i_823_n_0\
    );
\rgb_out[23]_i_824\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_x(1),
      O => \rgb_out[23]_i_824_n_0\
    );
\rgb_out[23]_i_825\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \TM_D/local_x\(7),
      I1 => \TM_D/local_x\(6),
      O => \rgb_out[23]_i_825_n_0\
    );
\rgb_out[23]_i_826\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \TM_D/local_x\(5),
      I1 => \TM_D/local_x\(4),
      O => \rgb_out[23]_i_826_n_0\
    );
\rgb_out[23]_i_827\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \TM_D/local_x\(2),
      I1 => \TM_D/local_x\(3),
      O => \rgb_out[23]_i_827_n_0\
    );
\rgb_out[23]_i_828\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => pixel_x(1),
      I1 => pixel_x(0),
      O => \rgb_out[23]_i_828_n_0\
    );
\rgb_out[23]_i_830\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \TM_D/local_y\(10),
      I1 => \TM_D/local_y\(11),
      O => \rgb_out[23]_i_830_n_0\
    );
\rgb_out[23]_i_831\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \TM_D/local_y\(8),
      I1 => \TM_D/local_y\(9),
      O => \rgb_out[23]_i_831_n_0\
    );
\rgb_out[23]_i_832\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \TM_D/local_y\(11),
      I1 => \TM_D/local_y\(10),
      O => \rgb_out[23]_i_832_n_0\
    );
\rgb_out[23]_i_833\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \TM_D/local_y\(9),
      I1 => \TM_D/local_y\(8),
      O => \rgb_out[23]_i_833_n_0\
    );
\rgb_out[23]_i_835\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \TM_D/local_x\(10),
      I1 => \TM_D/local_x\(11),
      O => \rgb_out[23]_i_835_n_0\
    );
\rgb_out[23]_i_836\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \TM_D/local_x\(8),
      I1 => \TM_D/local_x\(9),
      O => \rgb_out[23]_i_836_n_0\
    );
\rgb_out[23]_i_837\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \TM_D/local_x\(11),
      I1 => \TM_D/local_x\(10),
      O => \rgb_out[23]_i_837_n_0\
    );
\rgb_out[23]_i_838\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \TM_D/local_x\(9),
      I1 => \TM_D/local_x\(8),
      O => \rgb_out[23]_i_838_n_0\
    );
\rgb_out[23]_i_840\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \rgb_out_reg[23]_i_779_n_0\,
      O => \TM_D/local_y\(12)
    );
\rgb_out[23]_i_841\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \TM_D/local_y\(11),
      I1 => \TM_D/local_y\(10),
      O => \rgb_out[23]_i_841_n_0\
    );
\rgb_out[23]_i_843\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \rgb_out_reg[23]_i_481_n_1\,
      O => \TM_D/local_x\(12)
    );
\rgb_out[23]_i_844\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \TM_D/local_x\(11),
      I1 => \TM_D/local_x\(10),
      O => \rgb_out[23]_i_844_n_0\
    );
\rgb_out[23]_i_881\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => U0_n_0,
      O => \rgb_out[23]_i_881_n_0\
    );
\rgb_out[23]_i_928\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \rgb_out_reg[23]_i_929_n_0\,
      O => \rgb_out[23]_i_928_n_0\
    );
\rgb_out[23]_i_930\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_D/local_y\(11),
      I1 => \REC_D/local_y\(10),
      O => \rgb_out[23]_i_930_n_0\
    );
\rgb_out[23]_i_931\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_D/local_y\(9),
      I1 => \REC_D/local_y\(8),
      O => \rgb_out[23]_i_931_n_0\
    );
\rgb_out[23]_i_933\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \REC_D/local_y\(10),
      I1 => \REC_D/local_y\(11),
      O => \rgb_out[23]_i_933_n_0\
    );
\rgb_out[23]_i_934\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \REC_D/local_y\(8),
      I1 => \REC_D/local_y\(9),
      O => \rgb_out[23]_i_934_n_0\
    );
\rgb_out[23]_i_935\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_D/local_y\(11),
      I1 => \REC_D/local_y\(10),
      O => \rgb_out[23]_i_935_n_0\
    );
\rgb_out[23]_i_936\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_D/local_y\(9),
      I1 => \REC_D/local_y\(8),
      O => \rgb_out[23]_i_936_n_0\
    );
\rgb_out[23]_i_938\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \REC_D/local_x\(10),
      I1 => \REC_D/local_x\(11),
      O => \rgb_out[23]_i_938_n_0\
    );
\rgb_out[23]_i_939\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \REC_D/local_x\(8),
      I1 => \REC_D/local_x\(9),
      O => \rgb_out[23]_i_939_n_0\
    );
\rgb_out[23]_i_940\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_D/local_x\(11),
      I1 => \REC_D/local_x\(10),
      O => \rgb_out[23]_i_940_n_0\
    );
\rgb_out[23]_i_941\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_D/local_x\(9),
      I1 => \REC_D/local_x\(8),
      O => \rgb_out[23]_i_941_n_0\
    );
\rgb_out[23]_i_943\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \rgb_out_reg[23]_i_591_n_0\,
      O => \rgb_out[23]_i_943_n_0\
    );
\rgb_out[23]_i_944\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_D/local_x\(11),
      I1 => \REC_D/local_x\(10),
      O => \rgb_out[23]_i_944_n_0\
    );
\rgb_out[23]_i_945\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_D/local_x\(9),
      I1 => \REC_D/local_x\(8),
      O => \rgb_out[23]_i_945_n_0\
    );
\rgb_out[23]_i_947\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \REC_D/local_y\(10),
      I1 => \REC_D/local_y\(11),
      O => \rgb_out[23]_i_947_n_0\
    );
\rgb_out[23]_i_948\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \REC_D/local_y\(8),
      I1 => \REC_D/local_y\(9),
      O => \rgb_out[23]_i_948_n_0\
    );
\rgb_out[23]_i_949\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_D/local_y\(11),
      I1 => \REC_D/local_y\(10),
      O => \rgb_out[23]_i_949_n_0\
    );
\rgb_out[23]_i_950\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_D/local_y\(9),
      I1 => \REC_D/local_y\(8),
      O => \rgb_out[23]_i_950_n_0\
    );
\rgb_out[23]_i_952\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \rgb_out_reg[23]_i_929_n_0\,
      O => \rgb_out[23]_i_952_n_0\
    );
\rgb_out[23]_i_953\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_D/local_y\(11),
      I1 => \REC_D/local_y\(10),
      O => \rgb_out[23]_i_953_n_0\
    );
\rgb_out[23]_i_954\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_D/local_y\(9),
      I1 => \REC_D/local_y\(8),
      O => \rgb_out[23]_i_954_n_0\
    );
\rgb_out[23]_i_956\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \REC_D/local_y\(10),
      I1 => \REC_D/local_y\(11),
      O => \rgb_out[23]_i_956_n_0\
    );
\rgb_out[23]_i_957\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \REC_D/local_y\(8),
      I1 => \REC_D/local_y\(9),
      O => \rgb_out[23]_i_957_n_0\
    );
\rgb_out[23]_i_958\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_D/local_y\(11),
      I1 => \REC_D/local_y\(10),
      O => \rgb_out[23]_i_958_n_0\
    );
\rgb_out[23]_i_959\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_D/local_y\(9),
      I1 => \REC_D/local_y\(8),
      O => \rgb_out[23]_i_959_n_0\
    );
\rgb_out[23]_i_961\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \rgb_out_reg[23]_i_929_n_0\,
      O => \rgb_out[23]_i_961_n_0\
    );
\rgb_out[23]_i_962\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_D/local_y\(11),
      I1 => \REC_D/local_y\(10),
      O => \rgb_out[23]_i_962_n_0\
    );
\rgb_out[23]_i_963\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_D/local_y\(9),
      I1 => \REC_D/local_y\(8),
      O => \rgb_out[23]_i_963_n_0\
    );
\rgb_out[23]_i_964\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \REC_D/local_x\(6),
      I1 => \REC_D/local_x\(7),
      O => \rgb_out[23]_i_964_n_0\
    );
\rgb_out[23]_i_966\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \REC_D/local_x\(1),
      I1 => pixel_x(0),
      O => \rgb_out[23]_i_966_n_0\
    );
\rgb_out[23]_i_967\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_D/local_x\(7),
      I1 => \REC_D/local_x\(6),
      O => \rgb_out[23]_i_967_n_0\
    );
\rgb_out[23]_i_968\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \REC_D/local_x\(4),
      I1 => \REC_D/local_x\(5),
      O => \rgb_out[23]_i_968_n_0\
    );
\rgb_out[23]_i_969\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \REC_D/local_x\(3),
      I1 => \REC_D/local_x\(2),
      O => \rgb_out[23]_i_969_n_0\
    );
\rgb_out[23]_i_970\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => pixel_x(0),
      I1 => \REC_D/local_x\(1),
      O => \rgb_out[23]_i_970_n_0\
    );
\rgb_out[23]_i_971\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_x(11),
      O => \rgb_out[23]_i_971_n_0\
    );
\rgb_out[23]_i_972\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pixel_x(9),
      O => \rgb_out[23]_i_972_n_0\
    );
\rgb_out[23]_i_973\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_D/local_x\(3),
      I1 => \REC_D/local_x\(2),
      O => \rgb_out[23]_i_973_n_0\
    );
\rgb_out[23]_i_974\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_D/local_x\(1),
      O => \rgb_out[23]_i_974_n_0\
    );
\rgb_out[23]_i_975\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_D/local_x\(7),
      I1 => \REC_D/local_x\(6),
      O => \rgb_out[23]_i_975_n_0\
    );
\rgb_out[23]_i_976\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_D/local_x\(5),
      I1 => \REC_D/local_x\(4),
      O => \rgb_out[23]_i_976_n_0\
    );
\rgb_out[23]_i_977\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \REC_D/local_x\(2),
      I1 => \REC_D/local_x\(3),
      O => \rgb_out[23]_i_977_n_0\
    );
\rgb_out[23]_i_978\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => pixel_x(0),
      I1 => \REC_D/local_x\(1),
      O => \rgb_out[23]_i_978_n_0\
    );
\rgb_out[23]_i_980\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \REC_D/local_y\(10),
      I1 => \REC_D/local_y\(11),
      O => \rgb_out[23]_i_980_n_0\
    );
\rgb_out[23]_i_981\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \REC_D/local_y\(8),
      I1 => \REC_D/local_y\(9),
      O => \rgb_out[23]_i_981_n_0\
    );
\rgb_out[23]_i_982\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_D/local_y\(11),
      I1 => \REC_D/local_y\(10),
      O => \rgb_out[23]_i_982_n_0\
    );
\rgb_out[23]_i_983\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_D/local_y\(9),
      I1 => \REC_D/local_y\(8),
      O => \rgb_out[23]_i_983_n_0\
    );
\rgb_out[23]_i_985\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \REC_D/local_x\(10),
      I1 => \REC_D/local_x\(11),
      O => \rgb_out[23]_i_985_n_0\
    );
\rgb_out[23]_i_986\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \REC_D/local_x\(8),
      I1 => \REC_D/local_x\(9),
      O => \rgb_out[23]_i_986_n_0\
    );
\rgb_out[23]_i_987\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_D/local_x\(11),
      I1 => \REC_D/local_x\(10),
      O => \rgb_out[23]_i_987_n_0\
    );
\rgb_out[23]_i_988\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_D/local_x\(9),
      I1 => \REC_D/local_x\(8),
      O => \rgb_out[23]_i_988_n_0\
    );
\rgb_out[23]_i_990\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \rgb_out_reg[23]_i_929_n_0\,
      O => \REC_D/local_y\(12)
    );
\rgb_out[23]_i_991\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_D/local_y\(11),
      I1 => \REC_D/local_y\(10),
      O => \rgb_out[23]_i_991_n_0\
    );
\rgb_out[23]_i_993\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \rgb_out_reg[23]_i_591_n_0\,
      O => \REC_D/local_x\(12)
    );
\rgb_out[23]_i_994\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \REC_D/local_x\(11),
      I1 => \REC_D/local_x\(10),
      O => \rgb_out[23]_i_994_n_0\
    );
\rgb_out[23]_i_996\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \rgb_out_reg[23]_i_997_n_0\,
      O => \LAST_U/local_x\(12)
    );
\rgb_out[23]_i_998\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \LAST_U/local_x\(11),
      I1 => \LAST_U/local_x\(10),
      O => \rgb_out[23]_i_998_n_0\
    );
\rgb_out_reg[23]_i_1001\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_1603_n_0\,
      CO(3) => \rgb_out_reg[23]_i_1001_n_0\,
      CO(2) => \NLW_rgb_out_reg[23]_i_1001_CO_UNCONNECTED\(2),
      CO(1) => \rgb_out_reg[23]_i_1001_n_2\,
      CO(0) => \rgb_out_reg[23]_i_1001_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2 downto 0) => pixel_y(11 downto 9),
      O(3) => \NLW_rgb_out_reg[23]_i_1001_O_UNCONNECTED\(3),
      O(2 downto 0) => \LAST_U/local_y\(11 downto 9),
      S(3) => '1',
      S(2) => \rgb_out[23]_i_1604_n_0\,
      S(1) => \rgb_out[23]_i_1605_n_0\,
      S(0) => \rgb_out[23]_i_1606_n_0\
    );
\rgb_out_reg[23]_i_1002\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_1002_n_0\,
      CO(2) => \rgb_out_reg[23]_i_1002_n_1\,
      CO(1) => \rgb_out_reg[23]_i_1002_n_2\,
      CO(0) => \rgb_out_reg[23]_i_1002_n_3\,
      CYINIT => '1',
      DI(3) => \rgb_out[23]_i_1607_n_0\,
      DI(2) => \rgb_out[23]_i_1608_n_0\,
      DI(1) => \rgb_out[23]_i_1609_n_0\,
      DI(0) => \rgb_out[23]_i_1610_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_1002_O_UNCONNECTED\(3 downto 0),
      S(3) => \rgb_out[23]_i_1611_n_0\,
      S(2) => \rgb_out[23]_i_1612_n_0\,
      S(1) => \rgb_out[23]_i_1613_n_0\,
      S(0) => \rgb_out[23]_i_1614_n_0\
    );
\rgb_out_reg[23]_i_1007\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_1007_n_0\,
      CO(2) => \rgb_out_reg[23]_i_1007_n_1\,
      CO(1) => \rgb_out_reg[23]_i_1007_n_2\,
      CO(0) => \rgb_out_reg[23]_i_1007_n_3\,
      CYINIT => '1',
      DI(3) => \rgb_out[23]_i_1615_n_0\,
      DI(2) => \rgb_out[23]_i_1616_n_0\,
      DI(1) => \rgb_out[23]_i_1617_n_0\,
      DI(0) => \rgb_out[23]_i_1618_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_1007_O_UNCONNECTED\(3 downto 0),
      S(3) => \rgb_out[23]_i_1619_n_0\,
      S(2) => \rgb_out[23]_i_1620_n_0\,
      S(1) => \rgb_out[23]_i_1621_n_0\,
      S(0) => \rgb_out[23]_i_1622_n_0\
    );
\rgb_out_reg[23]_i_1012\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_1012_n_0\,
      CO(2) => \rgb_out_reg[23]_i_1012_n_1\,
      CO(1) => \rgb_out_reg[23]_i_1012_n_2\,
      CO(0) => \rgb_out_reg[23]_i_1012_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \rgb_out[23]_i_1623_n_0\,
      DI(1) => \rgb_out[23]_i_1624_n_0\,
      DI(0) => \rgb_out[23]_i_1625_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_1012_O_UNCONNECTED\(3 downto 0),
      S(3) => \rgb_out[23]_i_1626_n_0\,
      S(2) => \rgb_out[23]_i_1627_n_0\,
      S(1) => \rgb_out[23]_i_1628_n_0\,
      S(0) => \rgb_out[23]_i_1629_n_0\
    );
\rgb_out_reg[23]_i_1016\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_1016_n_0\,
      CO(2) => \rgb_out_reg[23]_i_1016_n_1\,
      CO(1) => \rgb_out_reg[23]_i_1016_n_2\,
      CO(0) => \rgb_out_reg[23]_i_1016_n_3\,
      CYINIT => '1',
      DI(3) => \rgb_out[23]_i_1630_n_0\,
      DI(2) => \LAST_U/local_y\(5),
      DI(1) => '0',
      DI(0) => \rgb_out[23]_i_1631_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_1016_O_UNCONNECTED\(3 downto 0),
      S(3) => \rgb_out[23]_i_1632_n_0\,
      S(2) => \rgb_out[23]_i_1633_n_0\,
      S(1) => \rgb_out[23]_i_1634_n_0\,
      S(0) => \rgb_out[23]_i_1635_n_0\
    );
\rgb_out_reg[23]_i_1021\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_1021_n_0\,
      CO(2) => \rgb_out_reg[23]_i_1021_n_1\,
      CO(1) => \rgb_out_reg[23]_i_1021_n_2\,
      CO(0) => \rgb_out_reg[23]_i_1021_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \rgb_out[23]_i_1636_n_0\,
      DI(0) => \rgb_out[23]_i_1637_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_1021_O_UNCONNECTED\(3 downto 0),
      S(3) => \rgb_out[23]_i_1638_n_0\,
      S(2) => \rgb_out[23]_i_1639_n_0\,
      S(1) => \rgb_out[23]_i_1640_n_0\,
      S(0) => \rgb_out[23]_i_1641_n_0\
    );
\rgb_out_reg[23]_i_1025\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_1025_n_0\,
      CO(2) => \rgb_out_reg[23]_i_1025_n_1\,
      CO(1) => \rgb_out_reg[23]_i_1025_n_2\,
      CO(0) => \rgb_out_reg[23]_i_1025_n_3\,
      CYINIT => '1',
      DI(3) => \rgb_out[23]_i_1642_n_0\,
      DI(2) => \LAST_U/local_x\(5),
      DI(1) => '0',
      DI(0) => \rgb_out[23]_i_1643_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_1025_O_UNCONNECTED\(3 downto 0),
      S(3) => \rgb_out[23]_i_1644_n_0\,
      S(2) => \rgb_out[23]_i_1645_n_0\,
      S(1) => \rgb_out[23]_i_1646_n_0\,
      S(0) => \rgb_out[23]_i_1647_n_0\
    );
\rgb_out_reg[23]_i_1030\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_1030_n_0\,
      CO(2) => \rgb_out_reg[23]_i_1030_n_1\,
      CO(1) => \rgb_out_reg[23]_i_1030_n_2\,
      CO(0) => \rgb_out_reg[23]_i_1030_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \rgb_out[23]_i_1648_n_0\,
      DI(1) => \rgb_out[23]_i_1649_n_0\,
      DI(0) => \rgb_out[23]_i_1650_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_1030_O_UNCONNECTED\(3 downto 0),
      S(3) => \rgb_out[23]_i_1651_n_0\,
      S(2) => \rgb_out[23]_i_1652_n_0\,
      S(1) => \rgb_out[23]_i_1653_n_0\,
      S(0) => \rgb_out[23]_i_1654_n_0\
    );
\rgb_out_reg[23]_i_1034\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_1034_n_0\,
      CO(2) => \rgb_out_reg[23]_i_1034_n_1\,
      CO(1) => \rgb_out_reg[23]_i_1034_n_2\,
      CO(0) => \rgb_out_reg[23]_i_1034_n_3\,
      CYINIT => '1',
      DI(3) => \rgb_out[23]_i_1655_n_0\,
      DI(2) => \rgb_out[23]_i_1656_n_0\,
      DI(1) => \LAST_U/local_y\(3),
      DI(0) => \rgb_out[23]_i_1658_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_1034_O_UNCONNECTED\(3 downto 0),
      S(3) => \rgb_out[23]_i_1659_n_0\,
      S(2) => \rgb_out[23]_i_1660_n_0\,
      S(1) => \rgb_out[23]_i_1661_n_0\,
      S(0) => \rgb_out[23]_i_1662_n_0\
    );
\rgb_out_reg[23]_i_1039\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_1039_n_0\,
      CO(2) => \rgb_out_reg[23]_i_1039_n_1\,
      CO(1) => \rgb_out_reg[23]_i_1039_n_2\,
      CO(0) => \rgb_out_reg[23]_i_1039_n_3\,
      CYINIT => '1',
      DI(3) => \rgb_out[23]_i_1663_n_0\,
      DI(2) => \rgb_out[23]_i_1664_n_0\,
      DI(1) => \LAST_U/local_x\(3),
      DI(0) => \rgb_out[23]_i_1666_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_1039_O_UNCONNECTED\(3 downto 0),
      S(3) => \rgb_out[23]_i_1667_n_0\,
      S(2) => \rgb_out[23]_i_1668_n_0\,
      S(1) => \rgb_out[23]_i_1669_n_0\,
      S(0) => \rgb_out[23]_i_1670_n_0\
    );
\rgb_out_reg[23]_i_1044\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_1044_n_0\,
      CO(2) => \rgb_out_reg[23]_i_1044_n_1\,
      CO(1) => \rgb_out_reg[23]_i_1044_n_2\,
      CO(0) => \rgb_out_reg[23]_i_1044_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \rgb_out[23]_i_1671_n_0\,
      DI(1) => \rgb_out[23]_i_1672_n_0\,
      DI(0) => \rgb_out[23]_i_1673_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_1044_O_UNCONNECTED\(3 downto 0),
      S(3) => \rgb_out[23]_i_1674_n_0\,
      S(2) => \rgb_out[23]_i_1675_n_0\,
      S(1) => \rgb_out[23]_i_1676_n_0\,
      S(0) => \rgb_out[23]_i_1677_n_0\
    );
\rgb_out_reg[23]_i_1048\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_1048_n_0\,
      CO(2) => \rgb_out_reg[23]_i_1048_n_1\,
      CO(1) => \rgb_out_reg[23]_i_1048_n_2\,
      CO(0) => \rgb_out_reg[23]_i_1048_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \rgb_out[23]_i_1678_n_0\,
      DI(0) => \rgb_out[23]_i_1679_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_1048_O_UNCONNECTED\(3 downto 0),
      S(3) => \rgb_out[23]_i_1680_n_0\,
      S(2) => \rgb_out[23]_i_1681_n_0\,
      S(1) => \rgb_out[23]_i_1682_n_0\,
      S(0) => \rgb_out[23]_i_1683_n_0\
    );
\rgb_out_reg[23]_i_1052\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_1052_n_0\,
      CO(2) => \rgb_out_reg[23]_i_1052_n_1\,
      CO(1) => \rgb_out_reg[23]_i_1052_n_2\,
      CO(0) => \rgb_out_reg[23]_i_1052_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \rgb_out[23]_i_1684_n_0\,
      DI(1) => '0',
      DI(0) => \rgb_out[23]_i_1685_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_1052_O_UNCONNECTED\(3 downto 0),
      S(3) => \rgb_out[23]_i_1686_n_0\,
      S(2) => \rgb_out[23]_i_1687_n_0\,
      S(1) => \rgb_out[23]_i_1688_n_0\,
      S(0) => \rgb_out[23]_i_1689_n_0\
    );
\rgb_out_reg[23]_i_1056\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_1056_n_0\,
      CO(2) => \rgb_out_reg[23]_i_1056_n_1\,
      CO(1) => \rgb_out_reg[23]_i_1056_n_2\,
      CO(0) => \rgb_out_reg[23]_i_1056_n_3\,
      CYINIT => '1',
      DI(3) => \rgb_out[23]_i_1690_n_0\,
      DI(2) => \LAST_U/local_y\(5),
      DI(1) => \rgb_out[23]_i_1691_n_0\,
      DI(0) => '0',
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_1056_O_UNCONNECTED\(3 downto 0),
      S(3) => \rgb_out[23]_i_1692_n_0\,
      S(2) => \rgb_out[23]_i_1693_n_0\,
      S(1) => \rgb_out[23]_i_1694_n_0\,
      S(0) => \rgb_out[23]_i_1695_n_0\
    );
\rgb_out_reg[23]_i_1061\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_1061_n_0\,
      CO(2) => \rgb_out_reg[23]_i_1061_n_1\,
      CO(1) => \rgb_out_reg[23]_i_1061_n_2\,
      CO(0) => \rgb_out_reg[23]_i_1061_n_3\,
      CYINIT => '1',
      DI(3) => \rgb_out[23]_i_1696_n_0\,
      DI(2) => '0',
      DI(1) => \LAST_U/local_y\(3),
      DI(0) => \rgb_out[23]_i_1697_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_1061_O_UNCONNECTED\(3 downto 0),
      S(3) => \rgb_out[23]_i_1698_n_0\,
      S(2) => \rgb_out[23]_i_1699_n_0\,
      S(1) => \rgb_out[23]_i_1700_n_0\,
      S(0) => \rgb_out[23]_i_1701_n_0\
    );
\rgb_out_reg[23]_i_1066\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_1066_n_0\,
      CO(2) => \rgb_out_reg[23]_i_1066_n_1\,
      CO(1) => \rgb_out_reg[23]_i_1066_n_2\,
      CO(0) => \rgb_out_reg[23]_i_1066_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \rgb_out[23]_i_1702_n_0\,
      DI(0) => \rgb_out[23]_i_1703_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_1066_O_UNCONNECTED\(3 downto 0),
      S(3) => \rgb_out[23]_i_1704_n_0\,
      S(2) => \rgb_out[23]_i_1705_n_0\,
      S(1) => \rgb_out[23]_i_1706_n_0\,
      S(0) => \rgb_out[23]_i_1707_n_0\
    );
\rgb_out_reg[23]_i_1068\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_1708_n_0\,
      CO(3) => \rgb_out_reg[23]_i_1068_n_0\,
      CO(2) => \NLW_rgb_out_reg[23]_i_1068_CO_UNCONNECTED\(2),
      CO(1) => \rgb_out_reg[23]_i_1068_n_2\,
      CO(0) => \rgb_out_reg[23]_i_1068_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => pixel_x(11),
      DI(1) => '0',
      DI(0) => pixel_x(9),
      O(3) => \NLW_rgb_out_reg[23]_i_1068_O_UNCONNECTED\(3),
      O(2 downto 0) => \REC_U/local_x\(11 downto 9),
      S(3) => '1',
      S(2) => \rgb_out[23]_i_1709_n_0\,
      S(1) => pixel_x(10),
      S(0) => \rgb_out[23]_i_1710_n_0\
    );
\rgb_out_reg[23]_i_1070\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_1070_n_0\,
      CO(2) => \rgb_out_reg[23]_i_1070_n_1\,
      CO(1) => \rgb_out_reg[23]_i_1070_n_2\,
      CO(0) => \rgb_out_reg[23]_i_1070_n_3\,
      CYINIT => \rgb_out[23]_i_1711_n_0\,
      DI(3 downto 1) => B"000",
      DI(0) => \rgb_out[23]_i_1712_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_1070_O_UNCONNECTED\(3 downto 0),
      S(3) => \rgb_out[23]_i_1713_n_0\,
      S(2) => \rgb_out[23]_i_1714_n_0\,
      S(1) => \rgb_out[23]_i_1715_n_0\,
      S(0) => \rgb_out[23]_i_1716_n_0\
    );
\rgb_out_reg[23]_i_1072\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_1717_n_0\,
      CO(3) => \rgb_out_reg[23]_i_1072_n_0\,
      CO(2) => \NLW_rgb_out_reg[23]_i_1072_CO_UNCONNECTED\(2),
      CO(1) => \rgb_out_reg[23]_i_1072_n_2\,
      CO(0) => \rgb_out_reg[23]_i_1072_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2 downto 0) => pixel_y(11 downto 9),
      O(3) => \NLW_rgb_out_reg[23]_i_1072_O_UNCONNECTED\(3),
      O(2 downto 0) => \REC_U/local_y\(11 downto 9),
      S(3) => '1',
      S(2) => \rgb_out[23]_i_1718_n_0\,
      S(1) => \rgb_out[23]_i_1719_n_0\,
      S(0) => \rgb_out[23]_i_1720_n_0\
    );
\rgb_out_reg[23]_i_1073\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_1073_n_0\,
      CO(2) => \rgb_out_reg[23]_i_1073_n_1\,
      CO(1) => \rgb_out_reg[23]_i_1073_n_2\,
      CO(0) => \rgb_out_reg[23]_i_1073_n_3\,
      CYINIT => '1',
      DI(3) => \rgb_out[23]_i_1721_n_0\,
      DI(2) => \rgb_out[23]_i_1722_n_0\,
      DI(1) => \rgb_out[23]_i_1723_n_0\,
      DI(0) => \rgb_out[23]_i_1724_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_1073_O_UNCONNECTED\(3 downto 0),
      S(3) => \rgb_out[23]_i_1725_n_0\,
      S(2) => \rgb_out[23]_i_1726_n_0\,
      S(1) => \rgb_out[23]_i_1727_n_0\,
      S(0) => \rgb_out[23]_i_1728_n_0\
    );
\rgb_out_reg[23]_i_1078\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_1078_n_0\,
      CO(2) => \rgb_out_reg[23]_i_1078_n_1\,
      CO(1) => \rgb_out_reg[23]_i_1078_n_2\,
      CO(0) => \rgb_out_reg[23]_i_1078_n_3\,
      CYINIT => '1',
      DI(3) => \rgb_out[23]_i_1729_n_0\,
      DI(2) => \rgb_out[23]_i_1730_n_0\,
      DI(1) => \rgb_out[23]_i_1731_n_0\,
      DI(0) => \rgb_out[23]_i_1732_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_1078_O_UNCONNECTED\(3 downto 0),
      S(3) => \rgb_out[23]_i_1733_n_0\,
      S(2) => \rgb_out[23]_i_1734_n_0\,
      S(1) => \rgb_out[23]_i_1735_n_0\,
      S(0) => \rgb_out[23]_i_1736_n_0\
    );
\rgb_out_reg[23]_i_1083\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_1083_n_0\,
      CO(2) => \rgb_out_reg[23]_i_1083_n_1\,
      CO(1) => \rgb_out_reg[23]_i_1083_n_2\,
      CO(0) => \rgb_out_reg[23]_i_1083_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \rgb_out[23]_i_1737_n_0\,
      DI(1) => \rgb_out[23]_i_1738_n_0\,
      DI(0) => \rgb_out[23]_i_1739_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_1083_O_UNCONNECTED\(3 downto 0),
      S(3) => \rgb_out[23]_i_1740_n_0\,
      S(2) => \rgb_out[23]_i_1741_n_0\,
      S(1) => \rgb_out[23]_i_1742_n_0\,
      S(0) => \rgb_out[23]_i_1743_n_0\
    );
\rgb_out_reg[23]_i_1087\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_1087_n_0\,
      CO(2) => \rgb_out_reg[23]_i_1087_n_1\,
      CO(1) => \rgb_out_reg[23]_i_1087_n_2\,
      CO(0) => \rgb_out_reg[23]_i_1087_n_3\,
      CYINIT => '1',
      DI(3) => \rgb_out[23]_i_1744_n_0\,
      DI(2) => \REC_U/local_y\(5),
      DI(1) => '0',
      DI(0) => \rgb_out[23]_i_1745_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_1087_O_UNCONNECTED\(3 downto 0),
      S(3) => \rgb_out[23]_i_1746_n_0\,
      S(2) => \rgb_out[23]_i_1747_n_0\,
      S(1) => \rgb_out[23]_i_1748_n_0\,
      S(0) => \rgb_out[23]_i_1749_n_0\
    );
\rgb_out_reg[23]_i_1092\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_1092_n_0\,
      CO(2) => \rgb_out_reg[23]_i_1092_n_1\,
      CO(1) => \rgb_out_reg[23]_i_1092_n_2\,
      CO(0) => \rgb_out_reg[23]_i_1092_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \rgb_out[23]_i_1750_n_0\,
      DI(0) => \rgb_out[23]_i_1751_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_1092_O_UNCONNECTED\(3 downto 0),
      S(3) => \rgb_out[23]_i_1752_n_0\,
      S(2) => \rgb_out[23]_i_1753_n_0\,
      S(1) => \rgb_out[23]_i_1754_n_0\,
      S(0) => \rgb_out[23]_i_1755_n_0\
    );
\rgb_out_reg[23]_i_1096\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_1096_n_0\,
      CO(2) => \rgb_out_reg[23]_i_1096_n_1\,
      CO(1) => \rgb_out_reg[23]_i_1096_n_2\,
      CO(0) => \rgb_out_reg[23]_i_1096_n_3\,
      CYINIT => '1',
      DI(3) => \rgb_out[23]_i_1756_n_0\,
      DI(2) => \REC_U/local_x\(5),
      DI(1) => '0',
      DI(0) => \rgb_out[23]_i_1757_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_1096_O_UNCONNECTED\(3 downto 0),
      S(3) => \rgb_out[23]_i_1758_n_0\,
      S(2) => \rgb_out[23]_i_1759_n_0\,
      S(1) => \rgb_out[23]_i_1760_n_0\,
      S(0) => \rgb_out[23]_i_1761_n_0\
    );
\rgb_out_reg[23]_i_1101\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_1101_n_0\,
      CO(2) => \rgb_out_reg[23]_i_1101_n_1\,
      CO(1) => \rgb_out_reg[23]_i_1101_n_2\,
      CO(0) => \rgb_out_reg[23]_i_1101_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \rgb_out[23]_i_1762_n_0\,
      DI(1) => \rgb_out[23]_i_1763_n_0\,
      DI(0) => \rgb_out[23]_i_1764_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_1101_O_UNCONNECTED\(3 downto 0),
      S(3) => \rgb_out[23]_i_1765_n_0\,
      S(2) => \rgb_out[23]_i_1766_n_0\,
      S(1) => \rgb_out[23]_i_1767_n_0\,
      S(0) => \rgb_out[23]_i_1768_n_0\
    );
\rgb_out_reg[23]_i_1105\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_1105_n_0\,
      CO(2) => \rgb_out_reg[23]_i_1105_n_1\,
      CO(1) => \rgb_out_reg[23]_i_1105_n_2\,
      CO(0) => \rgb_out_reg[23]_i_1105_n_3\,
      CYINIT => '1',
      DI(3) => \rgb_out[23]_i_1769_n_0\,
      DI(2) => \rgb_out[23]_i_1770_n_0\,
      DI(1) => \REC_U/local_y\(3),
      DI(0) => \rgb_out[23]_i_1772_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_1105_O_UNCONNECTED\(3 downto 0),
      S(3) => \rgb_out[23]_i_1773_n_0\,
      S(2) => \rgb_out[23]_i_1774_n_0\,
      S(1) => \rgb_out[23]_i_1775_n_0\,
      S(0) => \rgb_out[23]_i_1776_n_0\
    );
\rgb_out_reg[23]_i_1110\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_1110_n_0\,
      CO(2) => \rgb_out_reg[23]_i_1110_n_1\,
      CO(1) => \rgb_out_reg[23]_i_1110_n_2\,
      CO(0) => \rgb_out_reg[23]_i_1110_n_3\,
      CYINIT => '1',
      DI(3) => \rgb_out[23]_i_1777_n_0\,
      DI(2) => \rgb_out[23]_i_1778_n_0\,
      DI(1) => \REC_U/local_x\(3),
      DI(0) => \rgb_out[23]_i_1780_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_1110_O_UNCONNECTED\(3 downto 0),
      S(3) => \rgb_out[23]_i_1781_n_0\,
      S(2) => \rgb_out[23]_i_1782_n_0\,
      S(1) => \rgb_out[23]_i_1783_n_0\,
      S(0) => \rgb_out[23]_i_1784_n_0\
    );
\rgb_out_reg[23]_i_1115\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_1115_n_0\,
      CO(2) => \rgb_out_reg[23]_i_1115_n_1\,
      CO(1) => \rgb_out_reg[23]_i_1115_n_2\,
      CO(0) => \rgb_out_reg[23]_i_1115_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \rgb_out[23]_i_1785_n_0\,
      DI(1) => \rgb_out[23]_i_1786_n_0\,
      DI(0) => \rgb_out[23]_i_1787_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_1115_O_UNCONNECTED\(3 downto 0),
      S(3) => \rgb_out[23]_i_1788_n_0\,
      S(2) => \rgb_out[23]_i_1789_n_0\,
      S(1) => \rgb_out[23]_i_1790_n_0\,
      S(0) => \rgb_out[23]_i_1791_n_0\
    );
\rgb_out_reg[23]_i_1119\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_1119_n_0\,
      CO(2) => \rgb_out_reg[23]_i_1119_n_1\,
      CO(1) => \rgb_out_reg[23]_i_1119_n_2\,
      CO(0) => \rgb_out_reg[23]_i_1119_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \rgb_out[23]_i_1792_n_0\,
      DI(0) => \rgb_out[23]_i_1793_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_1119_O_UNCONNECTED\(3 downto 0),
      S(3) => \rgb_out[23]_i_1794_n_0\,
      S(2) => \rgb_out[23]_i_1795_n_0\,
      S(1) => \rgb_out[23]_i_1796_n_0\,
      S(0) => \rgb_out[23]_i_1797_n_0\
    );
\rgb_out_reg[23]_i_1123\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_1123_n_0\,
      CO(2) => \rgb_out_reg[23]_i_1123_n_1\,
      CO(1) => \rgb_out_reg[23]_i_1123_n_2\,
      CO(0) => \rgb_out_reg[23]_i_1123_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \rgb_out[23]_i_1798_n_0\,
      DI(1) => '0',
      DI(0) => \rgb_out[23]_i_1799_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_1123_O_UNCONNECTED\(3 downto 0),
      S(3) => \rgb_out[23]_i_1800_n_0\,
      S(2) => \rgb_out[23]_i_1801_n_0\,
      S(1) => \rgb_out[23]_i_1802_n_0\,
      S(0) => \rgb_out[23]_i_1803_n_0\
    );
\rgb_out_reg[23]_i_1127\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_1127_n_0\,
      CO(2) => \rgb_out_reg[23]_i_1127_n_1\,
      CO(1) => \rgb_out_reg[23]_i_1127_n_2\,
      CO(0) => \rgb_out_reg[23]_i_1127_n_3\,
      CYINIT => '1',
      DI(3) => \rgb_out[23]_i_1804_n_0\,
      DI(2) => \REC_U/local_y\(5),
      DI(1) => \rgb_out[23]_i_1805_n_0\,
      DI(0) => '0',
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_1127_O_UNCONNECTED\(3 downto 0),
      S(3) => \rgb_out[23]_i_1806_n_0\,
      S(2) => \rgb_out[23]_i_1807_n_0\,
      S(1) => \rgb_out[23]_i_1808_n_0\,
      S(0) => \rgb_out[23]_i_1809_n_0\
    );
\rgb_out_reg[23]_i_1132\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_1132_n_0\,
      CO(2) => \rgb_out_reg[23]_i_1132_n_1\,
      CO(1) => \rgb_out_reg[23]_i_1132_n_2\,
      CO(0) => \rgb_out_reg[23]_i_1132_n_3\,
      CYINIT => '1',
      DI(3) => \rgb_out[23]_i_1810_n_0\,
      DI(2) => '0',
      DI(1) => \REC_U/local_y\(3),
      DI(0) => \rgb_out[23]_i_1811_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_1132_O_UNCONNECTED\(3 downto 0),
      S(3) => \rgb_out[23]_i_1812_n_0\,
      S(2) => \rgb_out[23]_i_1813_n_0\,
      S(1) => \rgb_out[23]_i_1814_n_0\,
      S(0) => \rgb_out[23]_i_1815_n_0\
    );
\rgb_out_reg[23]_i_1137\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_1137_n_0\,
      CO(2) => \rgb_out_reg[23]_i_1137_n_1\,
      CO(1) => \rgb_out_reg[23]_i_1137_n_2\,
      CO(0) => \rgb_out_reg[23]_i_1137_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \rgb_out[23]_i_1816_n_0\,
      DI(0) => \rgb_out[23]_i_1817_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_1137_O_UNCONNECTED\(3 downto 0),
      S(3) => \rgb_out[23]_i_1818_n_0\,
      S(2) => \rgb_out[23]_i_1819_n_0\,
      S(1) => \rgb_out[23]_i_1820_n_0\,
      S(0) => \rgb_out[23]_i_1821_n_0\
    );
\rgb_out_reg[23]_i_1139\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_1822_n_0\,
      CO(3) => \rgb_out_reg[23]_i_1139_n_0\,
      CO(2) => \NLW_rgb_out_reg[23]_i_1139_CO_UNCONNECTED\(2),
      CO(1) => \rgb_out_reg[23]_i_1139_n_2\,
      CO(0) => \rgb_out_reg[23]_i_1139_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2 downto 0) => pixel_y(11 downto 9),
      O(3) => \NLW_rgb_out_reg[23]_i_1139_O_UNCONNECTED\(3),
      O(2 downto 0) => \LAST_D/local_y\(11 downto 9),
      S(3) => '1',
      S(2) => \rgb_out[23]_i_1823_n_0\,
      S(1) => \rgb_out[23]_i_1824_n_0\,
      S(0) => \rgb_out[23]_i_1825_n_0\
    );
\rgb_out_reg[23]_i_1142\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_1142_n_0\,
      CO(2) => \rgb_out_reg[23]_i_1142_n_1\,
      CO(1) => \rgb_out_reg[23]_i_1142_n_2\,
      CO(0) => \rgb_out_reg[23]_i_1142_n_3\,
      CYINIT => '1',
      DI(3) => \rgb_out[23]_i_1826_n_0\,
      DI(2) => '0',
      DI(1) => \LAST_D/local_y\(3),
      DI(0) => \rgb_out[23]_i_1828_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_1142_O_UNCONNECTED\(3 downto 0),
      S(3) => \rgb_out[23]_i_1829_n_0\,
      S(2) => \rgb_out[23]_i_1830_n_0\,
      S(1) => \rgb_out[23]_i_1831_n_0\,
      S(0) => \rgb_out[23]_i_1832_n_0\
    );
\rgb_out_reg[23]_i_1147\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_1147_n_0\,
      CO(2) => \rgb_out_reg[23]_i_1147_n_1\,
      CO(1) => \rgb_out_reg[23]_i_1147_n_2\,
      CO(0) => \rgb_out_reg[23]_i_1147_n_3\,
      CYINIT => '1',
      DI(3) => \rgb_out[23]_i_1833_n_0\,
      DI(2) => \rgb_out[23]_i_1834_n_0\,
      DI(1) => \LAST_D/local_x\(3),
      DI(0) => \rgb_out[23]_i_1836_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_1147_O_UNCONNECTED\(3 downto 0),
      S(3) => \rgb_out[23]_i_1837_n_0\,
      S(2) => \rgb_out[23]_i_1838_n_0\,
      S(1) => \rgb_out[23]_i_1839_n_0\,
      S(0) => \rgb_out[23]_i_1840_n_0\
    );
\rgb_out_reg[23]_i_1152\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_1152_n_0\,
      CO(2) => \rgb_out_reg[23]_i_1152_n_1\,
      CO(1) => \rgb_out_reg[23]_i_1152_n_2\,
      CO(0) => \rgb_out_reg[23]_i_1152_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \rgb_out[23]_i_1841_n_0\,
      DI(1) => \rgb_out[23]_i_1842_n_0\,
      DI(0) => \rgb_out[23]_i_1843_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_1152_O_UNCONNECTED\(3 downto 0),
      S(3) => \rgb_out[23]_i_1844_n_0\,
      S(2) => \rgb_out[23]_i_1845_n_0\,
      S(1) => \rgb_out[23]_i_1846_n_0\,
      S(0) => \rgb_out[23]_i_1847_n_0\
    );
\rgb_out_reg[23]_i_1156\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_1156_n_0\,
      CO(2) => \rgb_out_reg[23]_i_1156_n_1\,
      CO(1) => \rgb_out_reg[23]_i_1156_n_2\,
      CO(0) => \rgb_out_reg[23]_i_1156_n_3\,
      CYINIT => '1',
      DI(3) => \rgb_out[23]_i_1848_n_0\,
      DI(2) => \rgb_out[23]_i_1849_n_0\,
      DI(1) => \LAST_D/local_y\(3),
      DI(0) => \rgb_out[23]_i_1850_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_1156_O_UNCONNECTED\(3 downto 0),
      S(3) => \rgb_out[23]_i_1851_n_0\,
      S(2) => \rgb_out[23]_i_1852_n_0\,
      S(1) => \rgb_out[23]_i_1853_n_0\,
      S(0) => \rgb_out[23]_i_1854_n_0\
    );
\rgb_out_reg[23]_i_1161\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_1161_n_0\,
      CO(2) => \rgb_out_reg[23]_i_1161_n_1\,
      CO(1) => \rgb_out_reg[23]_i_1161_n_2\,
      CO(0) => \rgb_out_reg[23]_i_1161_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \rgb_out[23]_i_1855_n_0\,
      DI(1) => \rgb_out[23]_i_1856_n_0\,
      DI(0) => \rgb_out[23]_i_1857_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_1161_O_UNCONNECTED\(3 downto 0),
      S(3) => \rgb_out[23]_i_1858_n_0\,
      S(2) => \rgb_out[23]_i_1859_n_0\,
      S(1) => \rgb_out[23]_i_1860_n_0\,
      S(0) => \rgb_out[23]_i_1861_n_0\
    );
\rgb_out_reg[23]_i_1165\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_1165_n_0\,
      CO(2) => \rgb_out_reg[23]_i_1165_n_1\,
      CO(1) => \rgb_out_reg[23]_i_1165_n_2\,
      CO(0) => \rgb_out_reg[23]_i_1165_n_3\,
      CYINIT => '1',
      DI(3) => \rgb_out[23]_i_1862_n_0\,
      DI(2) => \LAST_D/local_y\(5),
      DI(1) => '0',
      DI(0) => \rgb_out[23]_i_1863_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_1165_O_UNCONNECTED\(3 downto 0),
      S(3) => \rgb_out[23]_i_1864_n_0\,
      S(2) => \rgb_out[23]_i_1865_n_0\,
      S(1) => \rgb_out[23]_i_1866_n_0\,
      S(0) => \rgb_out[23]_i_1867_n_0\
    );
\rgb_out_reg[23]_i_1170\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_1170_n_0\,
      CO(2) => \rgb_out_reg[23]_i_1170_n_1\,
      CO(1) => \rgb_out_reg[23]_i_1170_n_2\,
      CO(0) => \rgb_out_reg[23]_i_1170_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \rgb_out[23]_i_1868_n_0\,
      DI(1) => \rgb_out[23]_i_1869_n_0\,
      DI(0) => \rgb_out[23]_i_1870_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_1170_O_UNCONNECTED\(3 downto 0),
      S(3) => \rgb_out[23]_i_1871_n_0\,
      S(2) => \rgb_out[23]_i_1872_n_0\,
      S(1) => \rgb_out[23]_i_1873_n_0\,
      S(0) => \rgb_out[23]_i_1874_n_0\
    );
\rgb_out_reg[23]_i_1175\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_1835_n_0\,
      CO(3) => \rgb_out_reg[23]_i_1175_n_0\,
      CO(2) => \rgb_out_reg[23]_i_1175_n_1\,
      CO(1) => \rgb_out_reg[23]_i_1175_n_2\,
      CO(0) => \rgb_out_reg[23]_i_1175_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => pixel_x(7),
      DI(1 downto 0) => B"00",
      O(3 downto 0) => \LAST_D/local_x\(8 downto 5),
      S(3) => pixel_x(8),
      S(2) => \rgb_out[23]_i_1875_n_0\,
      S(1 downto 0) => pixel_x(6 downto 5)
    );
\rgb_out_reg[23]_i_1190\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_1190_n_0\,
      CO(2) => \rgb_out_reg[23]_i_1190_n_1\,
      CO(1) => \rgb_out_reg[23]_i_1190_n_2\,
      CO(0) => \rgb_out_reg[23]_i_1190_n_3\,
      CYINIT => '1',
      DI(3) => \rgb_out[23]_i_1876_n_0\,
      DI(2) => \rgb_out[23]_i_1877_n_0\,
      DI(1) => \rgb_out[23]_i_1878_n_0\,
      DI(0) => \rgb_out[23]_i_1879_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_1190_O_UNCONNECTED\(3 downto 0),
      S(3) => \rgb_out[23]_i_1880_n_0\,
      S(2) => \rgb_out[23]_i_1881_n_0\,
      S(1) => \rgb_out[23]_i_1882_n_0\,
      S(0) => \rgb_out[23]_i_1883_n_0\
    );
\rgb_out_reg[23]_i_1195\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_1195_n_0\,
      CO(2) => \rgb_out_reg[23]_i_1195_n_1\,
      CO(1) => \rgb_out_reg[23]_i_1195_n_2\,
      CO(0) => \rgb_out_reg[23]_i_1195_n_3\,
      CYINIT => '1',
      DI(3) => \rgb_out[23]_i_1884_n_0\,
      DI(2) => \rgb_out[23]_i_1885_n_0\,
      DI(1) => \rgb_out[23]_i_1886_n_0\,
      DI(0) => \rgb_out[23]_i_1887_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_1195_O_UNCONNECTED\(3 downto 0),
      S(3) => \rgb_out[23]_i_1888_n_0\,
      S(2) => \rgb_out[23]_i_1889_n_0\,
      S(1) => \rgb_out[23]_i_1890_n_0\,
      S(0) => \rgb_out[23]_i_1891_n_0\
    );
\rgb_out_reg[23]_i_1200\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_1200_n_0\,
      CO(2) => \rgb_out_reg[23]_i_1200_n_1\,
      CO(1) => \rgb_out_reg[23]_i_1200_n_2\,
      CO(0) => \rgb_out_reg[23]_i_1200_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \rgb_out[23]_i_1892_n_0\,
      DI(0) => \rgb_out[23]_i_1893_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_1200_O_UNCONNECTED\(3 downto 0),
      S(3) => \rgb_out[23]_i_1894_n_0\,
      S(2) => \rgb_out[23]_i_1895_n_0\,
      S(1) => \rgb_out[23]_i_1896_n_0\,
      S(0) => \rgb_out[23]_i_1897_n_0\
    );
\rgb_out_reg[23]_i_1203\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_1203_n_0\,
      CO(2) => \rgb_out_reg[23]_i_1203_n_1\,
      CO(1) => \rgb_out_reg[23]_i_1203_n_2\,
      CO(0) => \rgb_out_reg[23]_i_1203_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \rgb_out[23]_i_1898_n_0\,
      DI(0) => \rgb_out[23]_i_1899_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_1203_O_UNCONNECTED\(3 downto 0),
      S(3) => \rgb_out[23]_i_1900_n_0\,
      S(2) => \rgb_out[23]_i_1901_n_0\,
      S(1) => \rgb_out[23]_i_1902_n_0\,
      S(0) => \rgb_out[23]_i_1903_n_0\
    );
\rgb_out_reg[23]_i_1217\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_1904_n_0\,
      CO(3) => \rgb_out_reg[23]_i_1217_n_0\,
      CO(2) => \rgb_out_reg[23]_i_1217_n_1\,
      CO(1) => \rgb_out_reg[23]_i_1217_n_2\,
      CO(0) => \rgb_out_reg[23]_i_1217_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => pixel_x(11 downto 8),
      O(3 downto 0) => \SC_U/local_x\(11 downto 8),
      S(3) => \rgb_out[23]_i_1906_n_0\,
      S(2) => \rgb_out[23]_i_1907_n_0\,
      S(1) => \rgb_out[23]_i_1908_n_0\,
      S(0) => \rgb_out[23]_i_1909_n_0\
    );
\rgb_out_reg[23]_i_1224\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_1910_n_0\,
      CO(3) => \rgb_out_reg[23]_i_1224_n_0\,
      CO(2) => \rgb_out_reg[23]_i_1224_n_1\,
      CO(1) => \rgb_out_reg[23]_i_1224_n_2\,
      CO(0) => \rgb_out_reg[23]_i_1224_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => pixel_y(8 downto 5),
      O(3 downto 0) => \SC_U/local_y\(8 downto 5),
      S(3) => \rgb_out[23]_i_1911_n_0\,
      S(2) => \rgb_out[23]_i_1912_n_0\,
      S(1) => \rgb_out[23]_i_1913_n_0\,
      S(0) => \rgb_out[23]_i_1914_n_0\
    );
\rgb_out_reg[23]_i_1244\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_1244_n_0\,
      CO(2) => \rgb_out_reg[23]_i_1244_n_1\,
      CO(1) => \rgb_out_reg[23]_i_1244_n_2\,
      CO(0) => \rgb_out_reg[23]_i_1244_n_3\,
      CYINIT => '1',
      DI(3) => \rgb_out[23]_i_1915_n_0\,
      DI(2) => '0',
      DI(1) => \SC_U/local_y\(3),
      DI(0) => \rgb_out[23]_i_1916_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_1244_O_UNCONNECTED\(3 downto 0),
      S(3) => \rgb_out[23]_i_1917_n_0\,
      S(2) => \rgb_out[23]_i_1918_n_0\,
      S(1) => \rgb_out[23]_i_1919_n_0\,
      S(0) => \rgb_out[23]_i_1920_n_0\
    );
\rgb_out_reg[23]_i_1249\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_1249_n_0\,
      CO(2) => \rgb_out_reg[23]_i_1249_n_1\,
      CO(1) => \rgb_out_reg[23]_i_1249_n_2\,
      CO(0) => \rgb_out_reg[23]_i_1249_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \rgb_out[23]_i_1921_n_0\,
      DI(1) => \rgb_out[23]_i_1922_n_0\,
      DI(0) => \rgb_out[23]_i_1923_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_1249_O_UNCONNECTED\(3 downto 0),
      S(3) => \rgb_out[23]_i_1924_n_0\,
      S(2) => \rgb_out[23]_i_1925_n_0\,
      S(1) => \rgb_out[23]_i_1926_n_0\,
      S(0) => \rgb_out[23]_i_1927_n_0\
    );
\rgb_out_reg[23]_i_1258\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_1258_n_0\,
      CO(2) => \rgb_out_reg[23]_i_1258_n_1\,
      CO(1) => \rgb_out_reg[23]_i_1258_n_2\,
      CO(0) => \rgb_out_reg[23]_i_1258_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \rgb_out[23]_i_1935_n_0\,
      DI(1) => '0',
      DI(0) => \rgb_out[23]_i_1936_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_1258_O_UNCONNECTED\(3 downto 0),
      S(3) => \rgb_out[23]_i_1937_n_0\,
      S(2) => \rgb_out[23]_i_1938_n_0\,
      S(1) => \rgb_out[23]_i_1939_n_0\,
      S(0) => \rgb_out[23]_i_1940_n_0\
    );
\rgb_out_reg[23]_i_1262\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_1262_n_0\,
      CO(2) => \rgb_out_reg[23]_i_1262_n_1\,
      CO(1) => \rgb_out_reg[23]_i_1262_n_2\,
      CO(0) => \rgb_out_reg[23]_i_1262_n_3\,
      CYINIT => '1',
      DI(3) => \rgb_out[23]_i_1941_n_0\,
      DI(2) => \SC_U/local_y\(5),
      DI(1) => \rgb_out[23]_i_1942_n_0\,
      DI(0) => '0',
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_1262_O_UNCONNECTED\(3 downto 0),
      S(3) => \rgb_out[23]_i_1943_n_0\,
      S(2) => \rgb_out[23]_i_1944_n_0\,
      S(1) => \rgb_out[23]_i_1945_n_0\,
      S(0) => \rgb_out[23]_i_1946_n_0\
    );
\rgb_out_reg[23]_i_1267\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_1267_n_0\,
      CO(2) => \rgb_out_reg[23]_i_1267_n_1\,
      CO(1) => \rgb_out_reg[23]_i_1267_n_2\,
      CO(0) => \rgb_out_reg[23]_i_1267_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \rgb_out[23]_i_1947_n_0\,
      DI(0) => \rgb_out[23]_i_1948_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_1267_O_UNCONNECTED\(3 downto 0),
      S(3) => \rgb_out[23]_i_1949_n_0\,
      S(2) => \rgb_out[23]_i_1950_n_0\,
      S(1) => \rgb_out[23]_i_1951_n_0\,
      S(0) => \rgb_out[23]_i_1952_n_0\
    );
\rgb_out_reg[23]_i_1271\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_1271_n_0\,
      CO(2) => \rgb_out_reg[23]_i_1271_n_1\,
      CO(1) => \rgb_out_reg[23]_i_1271_n_2\,
      CO(0) => \rgb_out_reg[23]_i_1271_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \rgb_out[23]_i_1953_n_0\,
      DI(1) => \rgb_out[23]_i_1954_n_0\,
      DI(0) => \rgb_out[23]_i_1955_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_1271_O_UNCONNECTED\(3 downto 0),
      S(3) => \rgb_out[23]_i_1956_n_0\,
      S(2) => \rgb_out[23]_i_1957_n_0\,
      S(1) => \rgb_out[23]_i_1958_n_0\,
      S(0) => \rgb_out[23]_i_1959_n_0\
    );
\rgb_out_reg[23]_i_1275\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_1275_n_0\,
      CO(2) => \rgb_out_reg[23]_i_1275_n_1\,
      CO(1) => \rgb_out_reg[23]_i_1275_n_2\,
      CO(0) => \rgb_out_reg[23]_i_1275_n_3\,
      CYINIT => '1',
      DI(3) => \rgb_out[23]_i_1960_n_0\,
      DI(2) => \rgb_out[23]_i_1961_n_0\,
      DI(1) => \SC_U/local_y\(3),
      DI(0) => \rgb_out[23]_i_1962_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_1275_O_UNCONNECTED\(3 downto 0),
      S(3) => \rgb_out[23]_i_1963_n_0\,
      S(2) => \rgb_out[23]_i_1964_n_0\,
      S(1) => \rgb_out[23]_i_1965_n_0\,
      S(0) => \rgb_out[23]_i_1966_n_0\
    );
\rgb_out_reg[23]_i_1280\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_1280_n_0\,
      CO(2) => \rgb_out_reg[23]_i_1280_n_1\,
      CO(1) => \rgb_out_reg[23]_i_1280_n_2\,
      CO(0) => \rgb_out_reg[23]_i_1280_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \rgb_out[23]_i_1967_n_0\,
      DI(0) => \rgb_out[23]_i_1968_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_1280_O_UNCONNECTED\(3 downto 0),
      S(3) => \rgb_out[23]_i_1969_n_0\,
      S(2) => \rgb_out[23]_i_1970_n_0\,
      S(1) => \rgb_out[23]_i_1971_n_0\,
      S(0) => \rgb_out[23]_i_1972_n_0\
    );
\rgb_out_reg[23]_i_1284\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_1284_n_0\,
      CO(2) => \rgb_out_reg[23]_i_1284_n_1\,
      CO(1) => \rgb_out_reg[23]_i_1284_n_2\,
      CO(0) => \rgb_out_reg[23]_i_1284_n_3\,
      CYINIT => '1',
      DI(3) => \rgb_out[23]_i_1973_n_0\,
      DI(2) => \SC_U/local_x\(5),
      DI(1) => '0',
      DI(0) => \rgb_out[23]_i_1974_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_1284_O_UNCONNECTED\(3 downto 0),
      S(3) => \rgb_out[23]_i_1975_n_0\,
      S(2) => \rgb_out[23]_i_1976_n_0\,
      S(1) => \rgb_out[23]_i_1977_n_0\,
      S(0) => \rgb_out[23]_i_1978_n_0\
    );
\rgb_out_reg[23]_i_1289\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_1289_n_0\,
      CO(2) => \rgb_out_reg[23]_i_1289_n_1\,
      CO(1) => \rgb_out_reg[23]_i_1289_n_2\,
      CO(0) => \rgb_out_reg[23]_i_1289_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \rgb_out[23]_i_1979_n_0\,
      DI(1) => \rgb_out[23]_i_1980_n_0\,
      DI(0) => \rgb_out[23]_i_1981_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_1289_O_UNCONNECTED\(3 downto 0),
      S(3) => \rgb_out[23]_i_1982_n_0\,
      S(2) => \rgb_out[23]_i_1983_n_0\,
      S(1) => \rgb_out[23]_i_1984_n_0\,
      S(0) => \rgb_out[23]_i_1985_n_0\
    );
\rgb_out_reg[23]_i_1293\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_1293_n_0\,
      CO(2) => \rgb_out_reg[23]_i_1293_n_1\,
      CO(1) => \rgb_out_reg[23]_i_1293_n_2\,
      CO(0) => \rgb_out_reg[23]_i_1293_n_3\,
      CYINIT => '1',
      DI(3) => \rgb_out[23]_i_1986_n_0\,
      DI(2) => \SC_U/local_y\(5),
      DI(1) => '0',
      DI(0) => \rgb_out[23]_i_1987_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_1293_O_UNCONNECTED\(3 downto 0),
      S(3) => \rgb_out[23]_i_1988_n_0\,
      S(2) => \rgb_out[23]_i_1989_n_0\,
      S(1) => \rgb_out[23]_i_1990_n_0\,
      S(0) => \rgb_out[23]_i_1991_n_0\
    );
\rgb_out_reg[23]_i_1298\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_1298_n_0\,
      CO(2) => \rgb_out_reg[23]_i_1298_n_1\,
      CO(1) => \rgb_out_reg[23]_i_1298_n_2\,
      CO(0) => \rgb_out_reg[23]_i_1298_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \rgb_out[23]_i_1992_n_0\,
      DI(0) => \rgb_out[23]_i_1993_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_1298_O_UNCONNECTED\(3 downto 0),
      S(3) => \rgb_out[23]_i_1994_n_0\,
      S(2) => \rgb_out[23]_i_1995_n_0\,
      S(1) => \rgb_out[23]_i_1996_n_0\,
      S(0) => \rgb_out[23]_i_1997_n_0\
    );
\rgb_out_reg[23]_i_1303\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_1303_n_0\,
      CO(2) => \rgb_out_reg[23]_i_1303_n_1\,
      CO(1) => \rgb_out_reg[23]_i_1303_n_2\,
      CO(0) => \rgb_out_reg[23]_i_1303_n_3\,
      CYINIT => '1',
      DI(3) => \rgb_out[23]_i_2002_n_0\,
      DI(2) => '0',
      DI(1) => \SC_D/local_y\(3),
      DI(0) => \rgb_out[23]_i_2004_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_1303_O_UNCONNECTED\(3 downto 0),
      S(3) => \rgb_out[23]_i_2005_n_0\,
      S(2) => \rgb_out[23]_i_2006_n_0\,
      S(1) => \rgb_out[23]_i_2007_n_0\,
      S(0) => \rgb_out[23]_i_2008_n_0\
    );
\rgb_out_reg[23]_i_1313\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_1313_n_0\,
      CO(2) => \rgb_out_reg[23]_i_1313_n_1\,
      CO(1) => \rgb_out_reg[23]_i_1313_n_2\,
      CO(0) => \rgb_out_reg[23]_i_1313_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \rgb_out[23]_i_2017_n_0\,
      DI(1) => \rgb_out[23]_i_2018_n_0\,
      DI(0) => \rgb_out[23]_i_2019_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_1313_O_UNCONNECTED\(3 downto 0),
      S(3) => \rgb_out[23]_i_2020_n_0\,
      S(2) => \rgb_out[23]_i_2021_n_0\,
      S(1) => \rgb_out[23]_i_2022_n_0\,
      S(0) => \rgb_out[23]_i_2023_n_0\
    );
\rgb_out_reg[23]_i_1326\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_1326_n_0\,
      CO(2) => \rgb_out_reg[23]_i_1326_n_1\,
      CO(1) => \rgb_out_reg[23]_i_1326_n_2\,
      CO(0) => \rgb_out_reg[23]_i_1326_n_3\,
      CYINIT => '1',
      DI(3) => \rgb_out[23]_i_2038_n_0\,
      DI(2) => \SC_D/local_y\(5),
      DI(1) => '0',
      DI(0) => \rgb_out[23]_i_2039_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_1326_O_UNCONNECTED\(3 downto 0),
      S(3) => \rgb_out[23]_i_2040_n_0\,
      S(2) => \rgb_out[23]_i_2041_n_0\,
      S(1) => \rgb_out[23]_i_2042_n_0\,
      S(0) => \rgb_out[23]_i_2043_n_0\
    );
\rgb_out_reg[23]_i_1336\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_2011_n_0\,
      CO(3) => \rgb_out_reg[23]_i_1336_n_0\,
      CO(2) => \rgb_out_reg[23]_i_1336_n_1\,
      CO(1) => \rgb_out_reg[23]_i_1336_n_2\,
      CO(0) => \rgb_out_reg[23]_i_1336_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2 downto 1) => pixel_x(6 downto 5),
      DI(0) => '0',
      O(3 downto 0) => \SC_D/local_x\(7 downto 4),
      S(3) => pixel_x(7),
      S(2) => \rgb_out[23]_i_2051_n_0\,
      S(1) => \rgb_out[23]_i_2052_n_0\,
      S(0) => pixel_x(4)
    );
\rgb_out_reg[23]_i_1342\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_1336_n_0\,
      CO(3) => \rgb_out_reg[23]_i_1342_n_0\,
      CO(2) => \rgb_out_reg[23]_i_1342_n_1\,
      CO(1) => \rgb_out_reg[23]_i_1342_n_2\,
      CO(0) => \rgb_out_reg[23]_i_1342_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => pixel_x(11 downto 8),
      O(3 downto 0) => \SC_D/local_x\(11 downto 8),
      S(3) => \rgb_out[23]_i_2053_n_0\,
      S(2) => \rgb_out[23]_i_2054_n_0\,
      S(1) => \rgb_out[23]_i_2055_n_0\,
      S(0) => \rgb_out[23]_i_2056_n_0\
    );
\rgb_out_reg[23]_i_1349\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_1349_n_0\,
      CO(2) => \rgb_out_reg[23]_i_1349_n_1\,
      CO(1) => \rgb_out_reg[23]_i_1349_n_2\,
      CO(0) => \rgb_out_reg[23]_i_1349_n_3\,
      CYINIT => '1',
      DI(3) => \rgb_out[23]_i_2057_n_0\,
      DI(2) => \rgb_out[23]_i_2058_n_0\,
      DI(1) => \rgb_out[23]_i_2059_n_0\,
      DI(0) => \rgb_out[23]_i_2060_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_1349_O_UNCONNECTED\(3 downto 0),
      S(3) => \rgb_out[23]_i_2061_n_0\,
      S(2) => \rgb_out[23]_i_2062_n_0\,
      S(1) => \rgb_out[23]_i_2063_n_0\,
      S(0) => \rgb_out[23]_i_2064_n_0\
    );
\rgb_out_reg[23]_i_1354\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_1354_n_0\,
      CO(2) => \rgb_out_reg[23]_i_1354_n_1\,
      CO(1) => \rgb_out_reg[23]_i_1354_n_2\,
      CO(0) => \rgb_out_reg[23]_i_1354_n_3\,
      CYINIT => '1',
      DI(3) => \rgb_out[23]_i_2065_n_0\,
      DI(2) => \rgb_out[23]_i_2066_n_0\,
      DI(1) => \rgb_out[23]_i_2067_n_0\,
      DI(0) => \rgb_out[23]_i_2068_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_1354_O_UNCONNECTED\(3 downto 0),
      S(3) => \rgb_out[23]_i_2069_n_0\,
      S(2) => \rgb_out[23]_i_2070_n_0\,
      S(1) => \rgb_out[23]_i_2071_n_0\,
      S(0) => \rgb_out[23]_i_2072_n_0\
    );
\rgb_out_reg[23]_i_1359\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_1359_n_0\,
      CO(2) => \rgb_out_reg[23]_i_1359_n_1\,
      CO(1) => \rgb_out_reg[23]_i_1359_n_2\,
      CO(0) => \rgb_out_reg[23]_i_1359_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \rgb_out[23]_i_2073_n_0\,
      DI(0) => \rgb_out[23]_i_2074_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_1359_O_UNCONNECTED\(3 downto 0),
      S(3) => \rgb_out[23]_i_2075_n_0\,
      S(2) => \rgb_out[23]_i_2076_n_0\,
      S(1) => \rgb_out[23]_i_2077_n_0\,
      S(0) => \rgb_out[23]_i_2078_n_0\
    );
\rgb_out_reg[23]_i_1362\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_1362_n_0\,
      CO(2) => \rgb_out_reg[23]_i_1362_n_1\,
      CO(1) => \rgb_out_reg[23]_i_1362_n_2\,
      CO(0) => \rgb_out_reg[23]_i_1362_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \rgb_out[23]_i_2079_n_0\,
      DI(0) => \rgb_out[23]_i_2080_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_1362_O_UNCONNECTED\(3 downto 0),
      S(3) => \rgb_out[23]_i_2081_n_0\,
      S(2) => \rgb_out[23]_i_2082_n_0\,
      S(1) => \rgb_out[23]_i_2083_n_0\,
      S(0) => \rgb_out[23]_i_2084_n_0\
    );
\rgb_out_reg[23]_i_1371\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_1376_n_0\,
      CO(3) => \rgb_out_reg[23]_i_1371_n_0\,
      CO(2) => \rgb_out_reg[23]_i_1371_n_1\,
      CO(1) => \rgb_out_reg[23]_i_1371_n_2\,
      CO(0) => \rgb_out_reg[23]_i_1371_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => pixel_y(8 downto 5),
      O(3 downto 0) => \TM_D/local_y\(8 downto 5),
      S(3) => \rgb_out[23]_i_2085_n_0\,
      S(2) => \rgb_out[23]_i_2086_n_0\,
      S(1) => \rgb_out[23]_i_2087_n_0\,
      S(0) => \rgb_out[23]_i_2088_n_0\
    );
\rgb_out_reg[23]_i_1376\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_1376_n_0\,
      CO(2) => \rgb_out_reg[23]_i_1376_n_1\,
      CO(1) => \rgb_out_reg[23]_i_1376_n_2\,
      CO(0) => \rgb_out_reg[23]_i_1376_n_3\,
      CYINIT => '0',
      DI(3) => pixel_y(4),
      DI(2) => '0',
      DI(1) => pixel_y(2),
      DI(0) => '0',
      O(3 downto 0) => \TM_D/local_y\(4 downto 1),
      S(3) => \rgb_out[23]_i_2089_n_0\,
      S(2) => pixel_y(3),
      S(1) => \rgb_out[23]_i_2090_n_0\,
      S(0) => pixel_y(1)
    );
\rgb_out_reg[23]_i_1503\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_1508_n_0\,
      CO(3) => \rgb_out_reg[23]_i_1503_n_0\,
      CO(2) => \rgb_out_reg[23]_i_1503_n_1\,
      CO(1) => \rgb_out_reg[23]_i_1503_n_2\,
      CO(0) => \rgb_out_reg[23]_i_1503_n_3\,
      CYINIT => '0',
      DI(3 downto 1) => B"000",
      DI(0) => pixel_y(5),
      O(3 downto 0) => \REC_D/local_y\(8 downto 5),
      S(3 downto 1) => pixel_y(8 downto 6),
      S(0) => \rgb_out[23]_i_2091_n_0\
    );
\rgb_out_reg[23]_i_1508\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_1508_n_0\,
      CO(2) => \rgb_out_reg[23]_i_1508_n_1\,
      CO(1) => \rgb_out_reg[23]_i_1508_n_2\,
      CO(0) => \rgb_out_reg[23]_i_1508_n_3\,
      CYINIT => pixel_y(0),
      DI(3 downto 2) => pixel_y(4 downto 3),
      DI(1) => '0',
      DI(0) => pixel_y(1),
      O(3 downto 0) => \REC_D/local_y\(4 downto 1),
      S(3) => \rgb_out[23]_i_2092_n_0\,
      S(2) => \rgb_out[23]_i_2093_n_0\,
      S(1) => pixel_y(2),
      S(0) => \rgb_out[23]_i_2094_n_0\
    );
\rgb_out_reg[23]_i_1516\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_1516_n_0\,
      CO(2) => \rgb_out_reg[23]_i_1516_n_1\,
      CO(1) => \rgb_out_reg[23]_i_1516_n_2\,
      CO(0) => \rgb_out_reg[23]_i_1516_n_3\,
      CYINIT => pixel_x(0),
      DI(3 downto 1) => pixel_x(4 downto 2),
      DI(0) => '0',
      O(3 downto 0) => \REC_D/local_x\(4 downto 1),
      S(3) => \rgb_out[23]_i_2095_n_0\,
      S(2) => \rgb_out[23]_i_2096_n_0\,
      S(1) => \rgb_out[23]_i_2097_n_0\,
      S(0) => pixel_x(1)
    );
\rgb_out_reg[23]_i_1593\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_1665_n_0\,
      CO(3) => \rgb_out_reg[23]_i_1593_n_0\,
      CO(2) => \rgb_out_reg[23]_i_1593_n_1\,
      CO(1) => \rgb_out_reg[23]_i_1593_n_2\,
      CO(0) => \rgb_out_reg[23]_i_1593_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1 downto 0) => pixel_x(6 downto 5),
      O(3 downto 0) => \LAST_U/local_x\(8 downto 5),
      S(3 downto 2) => pixel_x(8 downto 7),
      S(1) => \rgb_out[23]_i_2098_n_0\,
      S(0) => \rgb_out[23]_i_2099_n_0\
    );
\rgb_out_reg[23]_i_1603\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_1657_n_0\,
      CO(3) => \rgb_out_reg[23]_i_1603_n_0\,
      CO(2) => \rgb_out_reg[23]_i_1603_n_1\,
      CO(1) => \rgb_out_reg[23]_i_1603_n_2\,
      CO(0) => \rgb_out_reg[23]_i_1603_n_3\,
      CYINIT => '0',
      DI(3 downto 1) => B"000",
      DI(0) => pixel_y(5),
      O(3 downto 0) => \LAST_U/local_y\(8 downto 5),
      S(3 downto 1) => pixel_y(8 downto 6),
      S(0) => \rgb_out[23]_i_2100_n_0\
    );
\rgb_out_reg[23]_i_1657\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_1657_n_0\,
      CO(2) => \rgb_out_reg[23]_i_1657_n_1\,
      CO(1) => \rgb_out_reg[23]_i_1657_n_2\,
      CO(0) => \rgb_out_reg[23]_i_1657_n_3\,
      CYINIT => pixel_y(0),
      DI(3 downto 2) => pixel_y(4 downto 3),
      DI(1) => '0',
      DI(0) => pixel_y(1),
      O(3 downto 0) => \LAST_U/local_y\(4 downto 1),
      S(3) => \rgb_out[23]_i_2101_n_0\,
      S(2) => \rgb_out[23]_i_2102_n_0\,
      S(1) => pixel_y(2),
      S(0) => \rgb_out[23]_i_2103_n_0\
    );
\rgb_out_reg[23]_i_1665\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_1665_n_0\,
      CO(2) => \rgb_out_reg[23]_i_1665_n_1\,
      CO(1) => \rgb_out_reg[23]_i_1665_n_2\,
      CO(0) => \rgb_out_reg[23]_i_1665_n_3\,
      CYINIT => pixel_x(0),
      DI(3) => pixel_x(4),
      DI(2) => '0',
      DI(1) => pixel_x(2),
      DI(0) => '0',
      O(3 downto 0) => \LAST_U/local_x\(4 downto 1),
      S(3) => \rgb_out[23]_i_2104_n_0\,
      S(2) => pixel_x(3),
      S(1) => \rgb_out[23]_i_2105_n_0\,
      S(0) => pixel_x(1)
    );
\rgb_out_reg[23]_i_1708\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_1779_n_0\,
      CO(3) => \rgb_out_reg[23]_i_1708_n_0\,
      CO(2) => \rgb_out_reg[23]_i_1708_n_1\,
      CO(1) => \rgb_out_reg[23]_i_1708_n_2\,
      CO(0) => \rgb_out_reg[23]_i_1708_n_3\,
      CYINIT => '0',
      DI(3) => pixel_x(8),
      DI(2) => '0',
      DI(1) => pixel_x(6),
      DI(0) => '0',
      O(3 downto 0) => \REC_U/local_x\(8 downto 5),
      S(3) => \rgb_out[23]_i_2106_n_0\,
      S(2) => pixel_x(7),
      S(1) => \rgb_out[23]_i_2107_n_0\,
      S(0) => pixel_x(5)
    );
\rgb_out_reg[23]_i_1717\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_1771_n_0\,
      CO(3) => \rgb_out_reg[23]_i_1717_n_0\,
      CO(2) => \rgb_out_reg[23]_i_1717_n_1\,
      CO(1) => \rgb_out_reg[23]_i_1717_n_2\,
      CO(0) => \rgb_out_reg[23]_i_1717_n_3\,
      CYINIT => '0',
      DI(3 downto 1) => B"000",
      DI(0) => pixel_y(5),
      O(3 downto 0) => \REC_U/local_y\(8 downto 5),
      S(3 downto 1) => pixel_y(8 downto 6),
      S(0) => \rgb_out[23]_i_2108_n_0\
    );
\rgb_out_reg[23]_i_1771\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_1771_n_0\,
      CO(2) => \rgb_out_reg[23]_i_1771_n_1\,
      CO(1) => \rgb_out_reg[23]_i_1771_n_2\,
      CO(0) => \rgb_out_reg[23]_i_1771_n_3\,
      CYINIT => pixel_y(0),
      DI(3 downto 2) => pixel_y(4 downto 3),
      DI(1) => '0',
      DI(0) => pixel_y(1),
      O(3 downto 0) => \REC_U/local_y\(4 downto 1),
      S(3) => \rgb_out[23]_i_2109_n_0\,
      S(2) => \rgb_out[23]_i_2110_n_0\,
      S(1) => pixel_y(2),
      S(0) => \rgb_out[23]_i_2111_n_0\
    );
\rgb_out_reg[23]_i_1779\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_1779_n_0\,
      CO(2) => \rgb_out_reg[23]_i_1779_n_1\,
      CO(1) => \rgb_out_reg[23]_i_1779_n_2\,
      CO(0) => \rgb_out_reg[23]_i_1779_n_3\,
      CYINIT => pixel_x(0),
      DI(3) => pixel_x(4),
      DI(2) => '0',
      DI(1) => pixel_x(2),
      DI(0) => '0',
      O(3 downto 0) => \REC_U/local_x\(4 downto 1),
      S(3) => \rgb_out[23]_i_2112_n_0\,
      S(2) => pixel_x(3),
      S(1) => \rgb_out[23]_i_2113_n_0\,
      S(0) => pixel_x(1)
    );
\rgb_out_reg[23]_i_1822\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_1827_n_0\,
      CO(3) => \rgb_out_reg[23]_i_1822_n_0\,
      CO(2) => \rgb_out_reg[23]_i_1822_n_1\,
      CO(1) => \rgb_out_reg[23]_i_1822_n_2\,
      CO(0) => \rgb_out_reg[23]_i_1822_n_3\,
      CYINIT => '0',
      DI(3 downto 1) => B"000",
      DI(0) => pixel_y(5),
      O(3 downto 0) => \LAST_D/local_y\(8 downto 5),
      S(3 downto 1) => pixel_y(8 downto 6),
      S(0) => \rgb_out[23]_i_2114_n_0\
    );
\rgb_out_reg[23]_i_1827\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_1827_n_0\,
      CO(2) => \rgb_out_reg[23]_i_1827_n_1\,
      CO(1) => \rgb_out_reg[23]_i_1827_n_2\,
      CO(0) => \rgb_out_reg[23]_i_1827_n_3\,
      CYINIT => pixel_y(0),
      DI(3 downto 2) => pixel_y(4 downto 3),
      DI(1) => '0',
      DI(0) => pixel_y(1),
      O(3 downto 0) => \LAST_D/local_y\(4 downto 1),
      S(3) => \rgb_out[23]_i_2115_n_0\,
      S(2) => \rgb_out[23]_i_2116_n_0\,
      S(1) => pixel_y(2),
      S(0) => \rgb_out[23]_i_2117_n_0\
    );
\rgb_out_reg[23]_i_1835\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_1835_n_0\,
      CO(2) => \rgb_out_reg[23]_i_1835_n_1\,
      CO(1) => \rgb_out_reg[23]_i_1835_n_2\,
      CO(0) => \rgb_out_reg[23]_i_1835_n_3\,
      CYINIT => pixel_x(0),
      DI(3 downto 1) => pixel_x(4 downto 2),
      DI(0) => '0',
      O(3 downto 0) => \LAST_D/local_x\(4 downto 1),
      S(3) => \rgb_out[23]_i_2118_n_0\,
      S(2) => \rgb_out[23]_i_2119_n_0\,
      S(1) => \rgb_out[23]_i_2120_n_0\,
      S(0) => pixel_x(1)
    );
\rgb_out_reg[23]_i_189\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_478_n_0\,
      CO(3) => \NLW_rgb_out_reg[23]_i_189_CO_UNCONNECTED\(3),
      CO(2) => \TM_D/pixel_on99_in\,
      CO(1) => \rgb_out_reg[23]_i_189_n_2\,
      CO(0) => \rgb_out_reg[23]_i_189_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \rgb_out[23]_i_479_n_0\,
      DI(0) => \rgb_out[23]_i_480_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_189_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \rgb_out_reg[23]_i_481_n_1\,
      S(1) => \rgb_out[23]_i_482_n_0\,
      S(0) => \rgb_out[23]_i_483_n_0\
    );
\rgb_out_reg[23]_i_1904\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_1905_n_0\,
      CO(3) => \rgb_out_reg[23]_i_1904_n_0\,
      CO(2) => \rgb_out_reg[23]_i_1904_n_1\,
      CO(1) => \rgb_out_reg[23]_i_1904_n_2\,
      CO(0) => \rgb_out_reg[23]_i_1904_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => pixel_x(6),
      DI(1 downto 0) => B"00",
      O(3 downto 0) => \SC_U/local_x\(7 downto 4),
      S(3) => pixel_x(7),
      S(2) => \rgb_out[23]_i_2121_n_0\,
      S(1 downto 0) => pixel_x(5 downto 4)
    );
\rgb_out_reg[23]_i_1905\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_1905_n_0\,
      CO(2) => \rgb_out_reg[23]_i_1905_n_1\,
      CO(1) => \rgb_out_reg[23]_i_1905_n_2\,
      CO(0) => \rgb_out_reg[23]_i_1905_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => pixel_x(1),
      DI(0) => '0',
      O(3 downto 0) => \SC_U/local_x\(3 downto 0),
      S(3 downto 2) => pixel_x(3 downto 2),
      S(1) => \rgb_out[23]_i_2122_n_0\,
      S(0) => pixel_x(0)
    );
\rgb_out_reg[23]_i_191\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_484_n_0\,
      CO(3) => \NLW_rgb_out_reg[23]_i_191_CO_UNCONNECTED\(3),
      CO(2) => \TM_D/pixel_on6\,
      CO(1) => \rgb_out_reg[23]_i_191_n_2\,
      CO(0) => \rgb_out_reg[23]_i_191_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \rgb_out[23]_i_485_n_0\,
      DI(1 downto 0) => B"00",
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_191_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \rgb_out_reg[23]_i_481_n_1\,
      S(1) => \rgb_out[23]_i_486_n_0\,
      S(0) => \rgb_out[23]_i_487_n_0\
    );
\rgb_out_reg[23]_i_1910\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_1910_n_0\,
      CO(2) => \rgb_out_reg[23]_i_1910_n_1\,
      CO(1) => \rgb_out_reg[23]_i_1910_n_2\,
      CO(0) => \rgb_out_reg[23]_i_1910_n_3\,
      CYINIT => '0',
      DI(3) => pixel_y(4),
      DI(2) => '0',
      DI(1) => pixel_y(2),
      DI(0) => '0',
      O(3 downto 0) => \SC_U/local_y\(4 downto 1),
      S(3) => \rgb_out[23]_i_2123_n_0\,
      S(2) => pixel_y(3),
      S(1) => \rgb_out[23]_i_2124_n_0\,
      S(0) => pixel_y(1)
    );
\rgb_out_reg[23]_i_2011\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_2011_n_0\,
      CO(2) => \rgb_out_reg[23]_i_2011_n_1\,
      CO(1) => \rgb_out_reg[23]_i_2011_n_2\,
      CO(0) => \rgb_out_reg[23]_i_2011_n_3\,
      CYINIT => '0',
      DI(3) => pixel_x(3),
      DI(2) => '0',
      DI(1) => pixel_x(1),
      DI(0) => '0',
      O(3 downto 0) => \SC_D/local_x\(3 downto 0),
      S(3) => \rgb_out[23]_i_2131_n_0\,
      S(2) => pixel_x(2),
      S(1) => \rgb_out[23]_i_2132_n_0\,
      S(0) => pixel_x(0)
    );
\rgb_out_reg[23]_i_311\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_588_n_0\,
      CO(3) => \NLW_rgb_out_reg[23]_i_311_CO_UNCONNECTED\(3),
      CO(2) => \REC_D/pixel_on99_in\,
      CO(1) => \rgb_out_reg[23]_i_311_n_2\,
      CO(0) => \rgb_out_reg[23]_i_311_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \rgb_out[23]_i_589_n_0\,
      DI(0) => \rgb_out[23]_i_590_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_311_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \rgb_out_reg[23]_i_591_n_0\,
      S(1) => \rgb_out[23]_i_592_n_0\,
      S(0) => \rgb_out[23]_i_593_n_0\
    );
\rgb_out_reg[23]_i_313\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_594_n_0\,
      CO(3) => \NLW_rgb_out_reg[23]_i_313_CO_UNCONNECTED\(3),
      CO(2) => \REC_D/pixel_on6\,
      CO(1) => \rgb_out_reg[23]_i_313_n_2\,
      CO(0) => \rgb_out_reg[23]_i_313_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \rgb_out[23]_i_595_n_0\,
      DI(1 downto 0) => B"00",
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_313_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \rgb_out_reg[23]_i_591_n_0\,
      S(1) => \rgb_out[23]_i_596_n_0\,
      S(0) => \rgb_out[23]_i_597_n_0\
    );
\rgb_out_reg[23]_i_329\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_662_n_0\,
      CO(3) => \NLW_rgb_out_reg[23]_i_329_CO_UNCONNECTED\(3),
      CO(2) => \LAST_D/pixel_on99_in\,
      CO(1) => \rgb_out_reg[23]_i_329_n_2\,
      CO(0) => \rgb_out_reg[23]_i_329_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \rgb_out[23]_i_663_n_0\,
      DI(0) => \rgb_out[23]_i_664_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_329_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \rgb_out_reg[23]_i_665_n_0\,
      S(1) => \rgb_out[23]_i_666_n_0\,
      S(0) => \rgb_out[23]_i_667_n_0\
    );
\rgb_out_reg[23]_i_331\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_668_n_0\,
      CO(3) => \NLW_rgb_out_reg[23]_i_331_CO_UNCONNECTED\(3),
      CO(2) => \LAST_D/pixel_on6\,
      CO(1) => \rgb_out_reg[23]_i_331_n_2\,
      CO(0) => \rgb_out_reg[23]_i_331_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \rgb_out[23]_i_669_n_0\,
      DI(1 downto 0) => B"00",
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_331_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \rgb_out_reg[23]_i_665_n_0\,
      S(1) => \rgb_out[23]_i_670_n_0\,
      S(0) => \rgb_out[23]_i_671_n_0\
    );
\rgb_out_reg[23]_i_438\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_714_n_0\,
      CO(3 downto 2) => \NLW_rgb_out_reg[23]_i_438_CO_UNCONNECTED\(3 downto 2),
      CO(1) => \SC_U/pixel_on4\,
      CO(0) => \rgb_out_reg[23]_i_438_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \SC_U/local_x\(12),
      DI(0) => '0',
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_438_O_UNCONNECTED\(3 downto 0),
      S(3 downto 2) => B"00",
      S(1) => \rgb_out_reg[23]_i_716_n_3\,
      S(0) => \rgb_out[23]_i_717_n_0\
    );
\rgb_out_reg[23]_i_439\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_718_n_0\,
      CO(3 downto 1) => \NLW_rgb_out_reg[23]_i_439_CO_UNCONNECTED\(3 downto 1),
      CO(0) => \SC_U/pixel_on2\,
      CYINIT => '0',
      DI(3 downto 1) => B"000",
      DI(0) => \SC_U/local_y\(12),
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_439_O_UNCONNECTED\(3 downto 0),
      S(3 downto 1) => B"000",
      S(0) => \rgb_out_reg[23]_i_720_n_0\
    );
\rgb_out_reg[23]_i_440\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_721_n_0\,
      CO(3) => \NLW_rgb_out_reg[23]_i_440_CO_UNCONNECTED\(3),
      CO(2) => \SC_U/pixel_on40_in\,
      CO(1) => \rgb_out_reg[23]_i_440_n_2\,
      CO(0) => \rgb_out_reg[23]_i_440_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \rgb_out[23]_i_722_n_0\,
      DI(0) => \rgb_out[23]_i_723_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_440_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \rgb_out_reg[23]_i_716_n_3\,
      S(1) => \rgb_out[23]_i_724_n_0\,
      S(0) => \rgb_out[23]_i_725_n_0\
    );
\rgb_out_reg[23]_i_441\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_726_n_0\,
      CO(3) => \NLW_rgb_out_reg[23]_i_441_CO_UNCONNECTED\(3),
      CO(2) => \SC_U/pixel_on3\,
      CO(1) => \rgb_out_reg[23]_i_441_n_2\,
      CO(0) => \rgb_out_reg[23]_i_441_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \rgb_out[23]_i_727_n_0\,
      DI(0) => \rgb_out[23]_i_728_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_441_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \rgb_out_reg[23]_i_720_n_0\,
      S(1) => \rgb_out[23]_i_729_n_0\,
      S(0) => \rgb_out[23]_i_730_n_0\
    );
\rgb_out_reg[23]_i_450\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_758_n_0\,
      CO(3) => \NLW_rgb_out_reg[23]_i_450_CO_UNCONNECTED\(3),
      CO(2) => \SC_D/pixel_on99_in\,
      CO(1) => \rgb_out_reg[23]_i_450_n_2\,
      CO(0) => \rgb_out_reg[23]_i_450_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \rgb_out[23]_i_759_n_0\,
      DI(0) => \rgb_out[23]_i_760_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_450_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \rgb_out_reg[23]_i_761_n_3\,
      S(1) => \rgb_out[23]_i_762_n_0\,
      S(0) => \rgb_out[23]_i_763_n_0\
    );
\rgb_out_reg[23]_i_452\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_764_n_0\,
      CO(3) => \NLW_rgb_out_reg[23]_i_452_CO_UNCONNECTED\(3),
      CO(2) => \SC_D/pixel_on6\,
      CO(1) => \rgb_out_reg[23]_i_452_n_2\,
      CO(0) => \rgb_out_reg[23]_i_452_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \rgb_out[23]_i_765_n_0\,
      DI(1 downto 0) => B"00",
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_452_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \rgb_out_reg[23]_i_761_n_3\,
      S(1) => \rgb_out[23]_i_766_n_0\,
      S(0) => \rgb_out[23]_i_767_n_0\
    );
\rgb_out_reg[23]_i_470\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_777_n_0\,
      CO(3) => \NLW_rgb_out_reg[23]_i_470_CO_UNCONNECTED\(3),
      CO(2) => \TM_D/pixel_on712_in\,
      CO(1) => \rgb_out_reg[23]_i_470_n_2\,
      CO(0) => \rgb_out_reg[23]_i_470_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \rgb_out[23]_i_778_n_0\,
      DI(1 downto 0) => B"00",
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_470_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \rgb_out_reg[23]_i_779_n_0\,
      S(1) => \rgb_out[23]_i_780_n_0\,
      S(0) => \rgb_out[23]_i_781_n_0\
    );
\rgb_out_reg[23]_i_471\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_782_n_0\,
      CO(3) => \NLW_rgb_out_reg[23]_i_471_CO_UNCONNECTED\(3),
      CO(2) => \TM_D/pixel_on5\,
      CO(1) => \rgb_out_reg[23]_i_471_n_2\,
      CO(0) => \rgb_out_reg[23]_i_471_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \rgb_out[23]_i_783_n_0\,
      DI(0) => \rgb_out[23]_i_784_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_471_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \rgb_out_reg[23]_i_779_n_0\,
      S(1) => \rgb_out[23]_i_785_n_0\,
      S(0) => \rgb_out[23]_i_786_n_0\
    );
\rgb_out_reg[23]_i_473\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_792_n_0\,
      CO(3) => \NLW_rgb_out_reg[23]_i_473_CO_UNCONNECTED\(3),
      CO(2) => \TM_D/pixel_on8\,
      CO(1) => \rgb_out_reg[23]_i_473_n_2\,
      CO(0) => \rgb_out_reg[23]_i_473_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \rgb_out[23]_i_793_n_0\,
      DI(1 downto 0) => B"00",
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_473_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \rgb_out_reg[23]_i_481_n_1\,
      S(1) => \rgb_out[23]_i_794_n_0\,
      S(0) => \rgb_out[23]_i_795_n_0\
    );
\rgb_out_reg[23]_i_474\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_796_n_0\,
      CO(3) => \NLW_rgb_out_reg[23]_i_474_CO_UNCONNECTED\(3),
      CO(2) => \TM_D/pixel_on83_in\,
      CO(1) => \rgb_out_reg[23]_i_474_n_2\,
      CO(0) => \rgb_out_reg[23]_i_474_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \rgb_out[23]_i_797_n_0\,
      DI(0) => \rgb_out[23]_i_798_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_474_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \rgb_out_reg[23]_i_779_n_0\,
      S(1) => \rgb_out[23]_i_799_n_0\,
      S(0) => \rgb_out[23]_i_800_n_0\
    );
\rgb_out_reg[23]_i_475\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_801_n_0\,
      CO(3) => \NLW_rgb_out_reg[23]_i_475_CO_UNCONNECTED\(3),
      CO(2) => \TM_D/pixel_on7\,
      CO(1) => \rgb_out_reg[23]_i_475_n_2\,
      CO(0) => \rgb_out_reg[23]_i_475_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \rgb_out[23]_i_802_n_0\,
      DI(1 downto 0) => B"00",
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_475_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \rgb_out_reg[23]_i_779_n_0\,
      S(1) => \rgb_out[23]_i_803_n_0\,
      S(0) => \rgb_out[23]_i_804_n_0\
    );
\rgb_out_reg[23]_i_476\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_805_n_0\,
      CO(3) => \NLW_rgb_out_reg[23]_i_476_CO_UNCONNECTED\(3),
      CO(2) => \TM_D/pixel_on75_in\,
      CO(1) => \rgb_out_reg[23]_i_476_n_2\,
      CO(0) => \rgb_out_reg[23]_i_476_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \rgb_out[23]_i_806_n_0\,
      DI(0) => \rgb_out[23]_i_807_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_476_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \rgb_out_reg[23]_i_779_n_0\,
      S(1) => \rgb_out[23]_i_808_n_0\,
      S(0) => \rgb_out[23]_i_809_n_0\
    );
\rgb_out_reg[23]_i_477\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_810_n_0\,
      CO(3) => \NLW_rgb_out_reg[23]_i_477_CO_UNCONNECTED\(3),
      CO(2) => \TM_D/pixel_on66_in\,
      CO(1) => \rgb_out_reg[23]_i_477_n_2\,
      CO(0) => \rgb_out_reg[23]_i_477_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \rgb_out[23]_i_811_n_0\,
      DI(1 downto 0) => B"00",
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_477_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \rgb_out_reg[23]_i_779_n_0\,
      S(1) => \rgb_out[23]_i_812_n_0\,
      S(0) => \rgb_out[23]_i_813_n_0\
    );
\rgb_out_reg[23]_i_478\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_478_n_0\,
      CO(2) => \rgb_out_reg[23]_i_478_n_1\,
      CO(1) => \rgb_out_reg[23]_i_478_n_2\,
      CO(0) => \rgb_out_reg[23]_i_478_n_3\,
      CYINIT => '1',
      DI(3) => \rgb_out[23]_i_814_n_0\,
      DI(2) => \TM_D/local_x\(5),
      DI(1) => '0',
      DI(0) => \rgb_out[23]_i_816_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_478_O_UNCONNECTED\(3 downto 0),
      S(3) => \rgb_out[23]_i_817_n_0\,
      S(2) => \rgb_out[23]_i_818_n_0\,
      S(1) => \rgb_out[23]_i_819_n_0\,
      S(0) => \rgb_out[23]_i_820_n_0\
    );
\rgb_out_reg[23]_i_481\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_821_n_0\,
      CO(3) => \NLW_rgb_out_reg[23]_i_481_CO_UNCONNECTED\(3),
      CO(2) => \rgb_out_reg[23]_i_481_n_1\,
      CO(1) => \NLW_rgb_out_reg[23]_i_481_CO_UNCONNECTED\(1),
      CO(0) => \rgb_out_reg[23]_i_481_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => pixel_x(11),
      DI(0) => '0',
      O(3 downto 2) => \NLW_rgb_out_reg[23]_i_481_O_UNCONNECTED\(3 downto 2),
      O(1 downto 0) => \TM_D/local_x\(11 downto 10),
      S(3 downto 2) => B"01",
      S(1) => \rgb_out[23]_i_822_n_0\,
      S(0) => pixel_x(10)
    );
\rgb_out_reg[23]_i_484\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_484_n_0\,
      CO(2) => \rgb_out_reg[23]_i_484_n_1\,
      CO(1) => \rgb_out_reg[23]_i_484_n_2\,
      CO(0) => \rgb_out_reg[23]_i_484_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \rgb_out[23]_i_823_n_0\,
      DI(0) => \rgb_out[23]_i_824_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_484_O_UNCONNECTED\(3 downto 0),
      S(3) => \rgb_out[23]_i_825_n_0\,
      S(2) => \rgb_out[23]_i_826_n_0\,
      S(1) => \rgb_out[23]_i_827_n_0\,
      S(0) => \rgb_out[23]_i_828_n_0\
    );
\rgb_out_reg[23]_i_488\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_829_n_0\,
      CO(3) => \NLW_rgb_out_reg[23]_i_488_CO_UNCONNECTED\(3),
      CO(2) => \TM_D/pixel_on3\,
      CO(1) => \rgb_out_reg[23]_i_488_n_2\,
      CO(0) => \rgb_out_reg[23]_i_488_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \rgb_out[23]_i_830_n_0\,
      DI(0) => \rgb_out[23]_i_831_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_488_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \rgb_out_reg[23]_i_779_n_0\,
      S(1) => \rgb_out[23]_i_832_n_0\,
      S(0) => \rgb_out[23]_i_833_n_0\
    );
\rgb_out_reg[23]_i_489\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_834_n_0\,
      CO(3) => \NLW_rgb_out_reg[23]_i_489_CO_UNCONNECTED\(3),
      CO(2) => \TM_D/pixel_on40_in\,
      CO(1) => \rgb_out_reg[23]_i_489_n_2\,
      CO(0) => \rgb_out_reg[23]_i_489_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \rgb_out[23]_i_835_n_0\,
      DI(0) => \rgb_out[23]_i_836_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_489_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \rgb_out_reg[23]_i_481_n_1\,
      S(1) => \rgb_out[23]_i_837_n_0\,
      S(0) => \rgb_out[23]_i_838_n_0\
    );
\rgb_out_reg[23]_i_490\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_839_n_0\,
      CO(3 downto 2) => \NLW_rgb_out_reg[23]_i_490_CO_UNCONNECTED\(3 downto 2),
      CO(1) => \TM_D/pixel_on2\,
      CO(0) => \rgb_out_reg[23]_i_490_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \TM_D/local_y\(12),
      DI(0) => '0',
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_490_O_UNCONNECTED\(3 downto 0),
      S(3 downto 2) => B"00",
      S(1) => \rgb_out_reg[23]_i_779_n_0\,
      S(0) => \rgb_out[23]_i_841_n_0\
    );
\rgb_out_reg[23]_i_491\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_842_n_0\,
      CO(3 downto 2) => \NLW_rgb_out_reg[23]_i_491_CO_UNCONNECTED\(3 downto 2),
      CO(1) => \TM_D/pixel_on4\,
      CO(0) => \rgb_out_reg[23]_i_491_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \TM_D/local_x\(12),
      DI(0) => '0',
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_491_O_UNCONNECTED\(3 downto 0),
      S(3 downto 2) => B"00",
      S(1) => \rgb_out_reg[23]_i_481_n_1\,
      S(0) => \rgb_out[23]_i_844_n_0\
    );
\rgb_out_reg[23]_i_580\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_927_n_0\,
      CO(3) => \NLW_rgb_out_reg[23]_i_580_CO_UNCONNECTED\(3),
      CO(2) => \REC_D/pixel_on712_in\,
      CO(1) => \rgb_out_reg[23]_i_580_n_2\,
      CO(0) => \rgb_out_reg[23]_i_580_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \rgb_out[23]_i_928_n_0\,
      DI(1 downto 0) => B"00",
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_580_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \rgb_out_reg[23]_i_929_n_0\,
      S(1) => \rgb_out[23]_i_930_n_0\,
      S(0) => \rgb_out[23]_i_931_n_0\
    );
\rgb_out_reg[23]_i_581\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_932_n_0\,
      CO(3) => \NLW_rgb_out_reg[23]_i_581_CO_UNCONNECTED\(3),
      CO(2) => \REC_D/pixel_on5\,
      CO(1) => \rgb_out_reg[23]_i_581_n_2\,
      CO(0) => \rgb_out_reg[23]_i_581_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \rgb_out[23]_i_933_n_0\,
      DI(0) => \rgb_out[23]_i_934_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_581_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \rgb_out_reg[23]_i_929_n_0\,
      S(1) => \rgb_out[23]_i_935_n_0\,
      S(0) => \rgb_out[23]_i_936_n_0\
    );
\rgb_out_reg[23]_i_582\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_937_n_0\,
      CO(3) => \NLW_rgb_out_reg[23]_i_582_CO_UNCONNECTED\(3),
      CO(2) => \REC_D/pixel_on9\,
      CO(1) => \rgb_out_reg[23]_i_582_n_2\,
      CO(0) => \rgb_out_reg[23]_i_582_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \rgb_out[23]_i_938_n_0\,
      DI(0) => \rgb_out[23]_i_939_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_582_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \rgb_out_reg[23]_i_591_n_0\,
      S(1) => \rgb_out[23]_i_940_n_0\,
      S(0) => \rgb_out[23]_i_941_n_0\
    );
\rgb_out_reg[23]_i_583\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_942_n_0\,
      CO(3) => \NLW_rgb_out_reg[23]_i_583_CO_UNCONNECTED\(3),
      CO(2) => \REC_D/pixel_on8\,
      CO(1) => \rgb_out_reg[23]_i_583_n_2\,
      CO(0) => \rgb_out_reg[23]_i_583_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \rgb_out[23]_i_943_n_0\,
      DI(1 downto 0) => B"00",
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_583_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \rgb_out_reg[23]_i_591_n_0\,
      S(1) => \rgb_out[23]_i_944_n_0\,
      S(0) => \rgb_out[23]_i_945_n_0\
    );
\rgb_out_reg[23]_i_584\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_946_n_0\,
      CO(3) => \NLW_rgb_out_reg[23]_i_584_CO_UNCONNECTED\(3),
      CO(2) => \REC_D/pixel_on83_in\,
      CO(1) => \rgb_out_reg[23]_i_584_n_2\,
      CO(0) => \rgb_out_reg[23]_i_584_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \rgb_out[23]_i_947_n_0\,
      DI(0) => \rgb_out[23]_i_948_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_584_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \rgb_out_reg[23]_i_929_n_0\,
      S(1) => \rgb_out[23]_i_949_n_0\,
      S(0) => \rgb_out[23]_i_950_n_0\
    );
\rgb_out_reg[23]_i_585\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_951_n_0\,
      CO(3) => \NLW_rgb_out_reg[23]_i_585_CO_UNCONNECTED\(3),
      CO(2) => \REC_D/pixel_on7\,
      CO(1) => \rgb_out_reg[23]_i_585_n_2\,
      CO(0) => \rgb_out_reg[23]_i_585_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \rgb_out[23]_i_952_n_0\,
      DI(1 downto 0) => B"00",
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_585_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \rgb_out_reg[23]_i_929_n_0\,
      S(1) => \rgb_out[23]_i_953_n_0\,
      S(0) => \rgb_out[23]_i_954_n_0\
    );
\rgb_out_reg[23]_i_586\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_955_n_0\,
      CO(3) => \NLW_rgb_out_reg[23]_i_586_CO_UNCONNECTED\(3),
      CO(2) => \REC_D/pixel_on75_in\,
      CO(1) => \rgb_out_reg[23]_i_586_n_2\,
      CO(0) => \rgb_out_reg[23]_i_586_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \rgb_out[23]_i_956_n_0\,
      DI(0) => \rgb_out[23]_i_957_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_586_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \rgb_out_reg[23]_i_929_n_0\,
      S(1) => \rgb_out[23]_i_958_n_0\,
      S(0) => \rgb_out[23]_i_959_n_0\
    );
\rgb_out_reg[23]_i_587\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_960_n_0\,
      CO(3) => \NLW_rgb_out_reg[23]_i_587_CO_UNCONNECTED\(3),
      CO(2) => \REC_D/pixel_on66_in\,
      CO(1) => \rgb_out_reg[23]_i_587_n_2\,
      CO(0) => \rgb_out_reg[23]_i_587_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \rgb_out[23]_i_961_n_0\,
      DI(1 downto 0) => B"00",
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_587_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \rgb_out_reg[23]_i_929_n_0\,
      S(1) => \rgb_out[23]_i_962_n_0\,
      S(0) => \rgb_out[23]_i_963_n_0\
    );
\rgb_out_reg[23]_i_588\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_588_n_0\,
      CO(2) => \rgb_out_reg[23]_i_588_n_1\,
      CO(1) => \rgb_out_reg[23]_i_588_n_2\,
      CO(0) => \rgb_out_reg[23]_i_588_n_3\,
      CYINIT => '1',
      DI(3) => \rgb_out[23]_i_964_n_0\,
      DI(2) => \REC_D/local_x\(5),
      DI(1) => '0',
      DI(0) => \rgb_out[23]_i_966_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_588_O_UNCONNECTED\(3 downto 0),
      S(3) => \rgb_out[23]_i_967_n_0\,
      S(2) => \rgb_out[23]_i_968_n_0\,
      S(1) => \rgb_out[23]_i_969_n_0\,
      S(0) => \rgb_out[23]_i_970_n_0\
    );
\rgb_out_reg[23]_i_591\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_965_n_0\,
      CO(3) => \rgb_out_reg[23]_i_591_n_0\,
      CO(2) => \NLW_rgb_out_reg[23]_i_591_CO_UNCONNECTED\(2),
      CO(1) => \rgb_out_reg[23]_i_591_n_2\,
      CO(0) => \rgb_out_reg[23]_i_591_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => pixel_x(11),
      DI(1) => '0',
      DI(0) => pixel_x(9),
      O(3) => \NLW_rgb_out_reg[23]_i_591_O_UNCONNECTED\(3),
      O(2 downto 0) => \REC_D/local_x\(11 downto 9),
      S(3) => '1',
      S(2) => \rgb_out[23]_i_971_n_0\,
      S(1) => pixel_x(10),
      S(0) => \rgb_out[23]_i_972_n_0\
    );
\rgb_out_reg[23]_i_594\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_594_n_0\,
      CO(2) => \rgb_out_reg[23]_i_594_n_1\,
      CO(1) => \rgb_out_reg[23]_i_594_n_2\,
      CO(0) => \rgb_out_reg[23]_i_594_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \rgb_out[23]_i_973_n_0\,
      DI(0) => \rgb_out[23]_i_974_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_594_O_UNCONNECTED\(3 downto 0),
      S(3) => \rgb_out[23]_i_975_n_0\,
      S(2) => \rgb_out[23]_i_976_n_0\,
      S(1) => \rgb_out[23]_i_977_n_0\,
      S(0) => \rgb_out[23]_i_978_n_0\
    );
\rgb_out_reg[23]_i_598\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_979_n_0\,
      CO(3) => \NLW_rgb_out_reg[23]_i_598_CO_UNCONNECTED\(3),
      CO(2) => \REC_D/pixel_on3\,
      CO(1) => \rgb_out_reg[23]_i_598_n_2\,
      CO(0) => \rgb_out_reg[23]_i_598_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \rgb_out[23]_i_980_n_0\,
      DI(0) => \rgb_out[23]_i_981_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_598_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \rgb_out_reg[23]_i_929_n_0\,
      S(1) => \rgb_out[23]_i_982_n_0\,
      S(0) => \rgb_out[23]_i_983_n_0\
    );
\rgb_out_reg[23]_i_599\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_984_n_0\,
      CO(3) => \NLW_rgb_out_reg[23]_i_599_CO_UNCONNECTED\(3),
      CO(2) => \REC_D/pixel_on40_in\,
      CO(1) => \rgb_out_reg[23]_i_599_n_2\,
      CO(0) => \rgb_out_reg[23]_i_599_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \rgb_out[23]_i_985_n_0\,
      DI(0) => \rgb_out[23]_i_986_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_599_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \rgb_out_reg[23]_i_591_n_0\,
      S(1) => \rgb_out[23]_i_987_n_0\,
      S(0) => \rgb_out[23]_i_988_n_0\
    );
\rgb_out_reg[23]_i_600\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_989_n_0\,
      CO(3 downto 2) => \NLW_rgb_out_reg[23]_i_600_CO_UNCONNECTED\(3 downto 2),
      CO(1) => \REC_D/pixel_on2\,
      CO(0) => \rgb_out_reg[23]_i_600_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \REC_D/local_y\(12),
      DI(0) => '0',
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_600_O_UNCONNECTED\(3 downto 0),
      S(3 downto 2) => B"00",
      S(1) => \rgb_out_reg[23]_i_929_n_0\,
      S(0) => \rgb_out[23]_i_991_n_0\
    );
\rgb_out_reg[23]_i_601\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_992_n_0\,
      CO(3 downto 2) => \NLW_rgb_out_reg[23]_i_601_CO_UNCONNECTED\(3 downto 2),
      CO(1) => \REC_D/pixel_on4\,
      CO(0) => \rgb_out_reg[23]_i_601_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \REC_D/local_x\(12),
      DI(0) => '0',
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_601_O_UNCONNECTED\(3 downto 0),
      S(3 downto 2) => B"00",
      S(1) => \rgb_out_reg[23]_i_591_n_0\,
      S(0) => \rgb_out[23]_i_994_n_0\
    );
\rgb_out_reg[23]_i_602\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_995_n_0\,
      CO(3 downto 2) => \NLW_rgb_out_reg[23]_i_602_CO_UNCONNECTED\(3 downto 2),
      CO(1) => \LAST_U/pixel_on4\,
      CO(0) => \rgb_out_reg[23]_i_602_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \LAST_U/local_x\(12),
      DI(0) => '0',
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_602_O_UNCONNECTED\(3 downto 0),
      S(3 downto 2) => B"00",
      S(1) => \rgb_out_reg[23]_i_997_n_0\,
      S(0) => \rgb_out[23]_i_998_n_0\
    );
\rgb_out_reg[23]_i_603\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_999_n_0\,
      CO(3 downto 1) => \NLW_rgb_out_reg[23]_i_603_CO_UNCONNECTED\(3 downto 1),
      CO(0) => \LAST_U/pixel_on2\,
      CYINIT => '0',
      DI(3 downto 1) => B"000",
      DI(0) => \LAST_U/local_y\(12),
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_603_O_UNCONNECTED\(3 downto 0),
      S(3 downto 1) => B"000",
      S(0) => \rgb_out_reg[23]_i_1001_n_0\
    );
\rgb_out_reg[23]_i_604\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_1002_n_0\,
      CO(3) => \NLW_rgb_out_reg[23]_i_604_CO_UNCONNECTED\(3),
      CO(2) => \LAST_U/pixel_on40_in\,
      CO(1) => \rgb_out_reg[23]_i_604_n_2\,
      CO(0) => \rgb_out_reg[23]_i_604_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \rgb_out[23]_i_1003_n_0\,
      DI(0) => \rgb_out[23]_i_1004_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_604_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \rgb_out_reg[23]_i_997_n_0\,
      S(1) => \rgb_out[23]_i_1005_n_0\,
      S(0) => \rgb_out[23]_i_1006_n_0\
    );
\rgb_out_reg[23]_i_605\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_1007_n_0\,
      CO(3) => \NLW_rgb_out_reg[23]_i_605_CO_UNCONNECTED\(3),
      CO(2) => \LAST_U/pixel_on3\,
      CO(1) => \rgb_out_reg[23]_i_605_n_2\,
      CO(0) => \rgb_out_reg[23]_i_605_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \rgb_out[23]_i_1008_n_0\,
      DI(0) => \rgb_out[23]_i_1009_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_605_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \rgb_out_reg[23]_i_1001_n_0\,
      S(1) => \rgb_out[23]_i_1010_n_0\,
      S(0) => \rgb_out[23]_i_1011_n_0\
    );
\rgb_out_reg[23]_i_606\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_1012_n_0\,
      CO(3) => \NLW_rgb_out_reg[23]_i_606_CO_UNCONNECTED\(3),
      CO(2) => \LAST_U/pixel_on66_in\,
      CO(1) => \rgb_out_reg[23]_i_606_n_2\,
      CO(0) => \rgb_out_reg[23]_i_606_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \rgb_out[23]_i_1013_n_0\,
      DI(1 downto 0) => B"00",
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_606_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \rgb_out_reg[23]_i_1001_n_0\,
      S(1) => \rgb_out[23]_i_1014_n_0\,
      S(0) => \rgb_out[23]_i_1015_n_0\
    );
\rgb_out_reg[23]_i_607\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_1016_n_0\,
      CO(3) => \NLW_rgb_out_reg[23]_i_607_CO_UNCONNECTED\(3),
      CO(2) => \LAST_U/pixel_on75_in\,
      CO(1) => \rgb_out_reg[23]_i_607_n_2\,
      CO(0) => \rgb_out_reg[23]_i_607_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \rgb_out[23]_i_1017_n_0\,
      DI(0) => \rgb_out[23]_i_1018_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_607_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \rgb_out_reg[23]_i_1001_n_0\,
      S(1) => \rgb_out[23]_i_1019_n_0\,
      S(0) => \rgb_out[23]_i_1020_n_0\
    );
\rgb_out_reg[23]_i_609\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_1021_n_0\,
      CO(3) => \NLW_rgb_out_reg[23]_i_609_CO_UNCONNECTED\(3),
      CO(2) => \LAST_U/pixel_on6\,
      CO(1) => \rgb_out_reg[23]_i_609_n_2\,
      CO(0) => \rgb_out_reg[23]_i_609_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \rgb_out[23]_i_1022_n_0\,
      DI(1 downto 0) => B"00",
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_609_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \rgb_out_reg[23]_i_997_n_0\,
      S(1) => \rgb_out[23]_i_1023_n_0\,
      S(0) => \rgb_out[23]_i_1024_n_0\
    );
\rgb_out_reg[23]_i_611\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_1025_n_0\,
      CO(3) => \NLW_rgb_out_reg[23]_i_611_CO_UNCONNECTED\(3),
      CO(2) => \LAST_U/pixel_on99_in\,
      CO(1) => \rgb_out_reg[23]_i_611_n_2\,
      CO(0) => \rgb_out_reg[23]_i_611_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \rgb_out[23]_i_1026_n_0\,
      DI(0) => \rgb_out[23]_i_1027_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_611_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \rgb_out_reg[23]_i_997_n_0\,
      S(1) => \rgb_out[23]_i_1028_n_0\,
      S(0) => \rgb_out[23]_i_1029_n_0\
    );
\rgb_out_reg[23]_i_612\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_1030_n_0\,
      CO(3) => \NLW_rgb_out_reg[23]_i_612_CO_UNCONNECTED\(3),
      CO(2) => \LAST_U/pixel_on7\,
      CO(1) => \rgb_out_reg[23]_i_612_n_2\,
      CO(0) => \rgb_out_reg[23]_i_612_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \rgb_out[23]_i_1031_n_0\,
      DI(1 downto 0) => B"00",
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_612_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \rgb_out_reg[23]_i_1001_n_0\,
      S(1) => \rgb_out[23]_i_1032_n_0\,
      S(0) => \rgb_out[23]_i_1033_n_0\
    );
\rgb_out_reg[23]_i_613\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_1034_n_0\,
      CO(3) => \NLW_rgb_out_reg[23]_i_613_CO_UNCONNECTED\(3),
      CO(2) => \LAST_U/pixel_on83_in\,
      CO(1) => \rgb_out_reg[23]_i_613_n_2\,
      CO(0) => \rgb_out_reg[23]_i_613_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \rgb_out[23]_i_1035_n_0\,
      DI(0) => \rgb_out[23]_i_1036_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_613_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \rgb_out_reg[23]_i_1001_n_0\,
      S(1) => \rgb_out[23]_i_1037_n_0\,
      S(0) => \rgb_out[23]_i_1038_n_0\
    );
\rgb_out_reg[23]_i_616\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_1039_n_0\,
      CO(3) => \NLW_rgb_out_reg[23]_i_616_CO_UNCONNECTED\(3),
      CO(2) => \LAST_U/pixel_on9\,
      CO(1) => \rgb_out_reg[23]_i_616_n_2\,
      CO(0) => \rgb_out_reg[23]_i_616_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \rgb_out[23]_i_1040_n_0\,
      DI(0) => \rgb_out[23]_i_1041_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_616_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \rgb_out_reg[23]_i_997_n_0\,
      S(1) => \rgb_out[23]_i_1042_n_0\,
      S(0) => \rgb_out[23]_i_1043_n_0\
    );
\rgb_out_reg[23]_i_617\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_1044_n_0\,
      CO(3) => \NLW_rgb_out_reg[23]_i_617_CO_UNCONNECTED\(3),
      CO(2) => \LAST_U/pixel_on8\,
      CO(1) => \rgb_out_reg[23]_i_617_n_2\,
      CO(0) => \rgb_out_reg[23]_i_617_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \rgb_out[23]_i_1045_n_0\,
      DI(1 downto 0) => B"00",
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_617_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \rgb_out_reg[23]_i_997_n_0\,
      S(1) => \rgb_out[23]_i_1046_n_0\,
      S(0) => \rgb_out[23]_i_1047_n_0\
    );
\rgb_out_reg[23]_i_620\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_1048_n_0\,
      CO(3) => \NLW_rgb_out_reg[23]_i_620_CO_UNCONNECTED\(3),
      CO(2) => \LAST_U/pixel_on712_in\,
      CO(1) => \rgb_out_reg[23]_i_620_n_2\,
      CO(0) => \rgb_out_reg[23]_i_620_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \rgb_out[23]_i_1049_n_0\,
      DI(1 downto 0) => B"00",
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_620_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \rgb_out_reg[23]_i_1001_n_0\,
      S(1) => \rgb_out[23]_i_1050_n_0\,
      S(0) => \rgb_out[23]_i_1051_n_0\
    );
\rgb_out_reg[23]_i_622\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_1052_n_0\,
      CO(3) => \NLW_rgb_out_reg[23]_i_622_CO_UNCONNECTED\(3),
      CO(2) => \LAST_U/pixel_on22_in\,
      CO(1) => \rgb_out_reg[23]_i_622_n_2\,
      CO(0) => \rgb_out_reg[23]_i_622_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \rgb_out[23]_i_1053_n_0\,
      DI(1 downto 0) => B"00",
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_622_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \rgb_out_reg[23]_i_1001_n_0\,
      S(1) => \rgb_out[23]_i_1054_n_0\,
      S(0) => \rgb_out[23]_i_1055_n_0\
    );
\rgb_out_reg[23]_i_624\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_1056_n_0\,
      CO(3) => \NLW_rgb_out_reg[23]_i_624_CO_UNCONNECTED\(3),
      CO(2) => \LAST_U/pixel_on31_in\,
      CO(1) => \rgb_out_reg[23]_i_624_n_2\,
      CO(0) => \rgb_out_reg[23]_i_624_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \rgb_out[23]_i_1057_n_0\,
      DI(0) => \rgb_out[23]_i_1058_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_624_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \rgb_out_reg[23]_i_1001_n_0\,
      S(1) => \rgb_out[23]_i_1059_n_0\,
      S(0) => \rgb_out[23]_i_1060_n_0\
    );
\rgb_out_reg[23]_i_626\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_1061_n_0\,
      CO(3) => \NLW_rgb_out_reg[23]_i_626_CO_UNCONNECTED\(3),
      CO(2) => \LAST_U/pixel_on5\,
      CO(1) => \rgb_out_reg[23]_i_626_n_2\,
      CO(0) => \rgb_out_reg[23]_i_626_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \rgb_out[23]_i_1062_n_0\,
      DI(0) => \rgb_out[23]_i_1063_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_626_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \rgb_out_reg[23]_i_1001_n_0\,
      S(1) => \rgb_out[23]_i_1064_n_0\,
      S(0) => \rgb_out[23]_i_1065_n_0\
    );
\rgb_out_reg[23]_i_628\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_1066_n_0\,
      CO(3 downto 2) => \NLW_rgb_out_reg[23]_i_628_CO_UNCONNECTED\(3 downto 2),
      CO(1) => \REC_U/pixel_on4\,
      CO(0) => \rgb_out_reg[23]_i_628_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \REC_U/local_x\(12),
      DI(0) => '0',
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_628_O_UNCONNECTED\(3 downto 0),
      S(3 downto 2) => B"00",
      S(1) => \rgb_out_reg[23]_i_1068_n_0\,
      S(0) => \rgb_out[23]_i_1069_n_0\
    );
\rgb_out_reg[23]_i_629\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_1070_n_0\,
      CO(3 downto 1) => \NLW_rgb_out_reg[23]_i_629_CO_UNCONNECTED\(3 downto 1),
      CO(0) => \REC_U/pixel_on2\,
      CYINIT => '0',
      DI(3 downto 1) => B"000",
      DI(0) => \REC_U/local_y\(12),
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_629_O_UNCONNECTED\(3 downto 0),
      S(3 downto 1) => B"000",
      S(0) => \rgb_out_reg[23]_i_1072_n_0\
    );
\rgb_out_reg[23]_i_630\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_1073_n_0\,
      CO(3) => \NLW_rgb_out_reg[23]_i_630_CO_UNCONNECTED\(3),
      CO(2) => \REC_U/pixel_on40_in\,
      CO(1) => \rgb_out_reg[23]_i_630_n_2\,
      CO(0) => \rgb_out_reg[23]_i_630_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \rgb_out[23]_i_1074_n_0\,
      DI(0) => \rgb_out[23]_i_1075_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_630_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \rgb_out_reg[23]_i_1068_n_0\,
      S(1) => \rgb_out[23]_i_1076_n_0\,
      S(0) => \rgb_out[23]_i_1077_n_0\
    );
\rgb_out_reg[23]_i_631\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_1078_n_0\,
      CO(3) => \NLW_rgb_out_reg[23]_i_631_CO_UNCONNECTED\(3),
      CO(2) => \REC_U/pixel_on3\,
      CO(1) => \rgb_out_reg[23]_i_631_n_2\,
      CO(0) => \rgb_out_reg[23]_i_631_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \rgb_out[23]_i_1079_n_0\,
      DI(0) => \rgb_out[23]_i_1080_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_631_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \rgb_out_reg[23]_i_1072_n_0\,
      S(1) => \rgb_out[23]_i_1081_n_0\,
      S(0) => \rgb_out[23]_i_1082_n_0\
    );
\rgb_out_reg[23]_i_632\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_1083_n_0\,
      CO(3) => \NLW_rgb_out_reg[23]_i_632_CO_UNCONNECTED\(3),
      CO(2) => \REC_U/pixel_on66_in\,
      CO(1) => \rgb_out_reg[23]_i_632_n_2\,
      CO(0) => \rgb_out_reg[23]_i_632_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \rgb_out[23]_i_1084_n_0\,
      DI(1 downto 0) => B"00",
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_632_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \rgb_out_reg[23]_i_1072_n_0\,
      S(1) => \rgb_out[23]_i_1085_n_0\,
      S(0) => \rgb_out[23]_i_1086_n_0\
    );
\rgb_out_reg[23]_i_633\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_1087_n_0\,
      CO(3) => \NLW_rgb_out_reg[23]_i_633_CO_UNCONNECTED\(3),
      CO(2) => \REC_U/pixel_on75_in\,
      CO(1) => \rgb_out_reg[23]_i_633_n_2\,
      CO(0) => \rgb_out_reg[23]_i_633_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \rgb_out[23]_i_1088_n_0\,
      DI(0) => \rgb_out[23]_i_1089_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_633_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \rgb_out_reg[23]_i_1072_n_0\,
      S(1) => \rgb_out[23]_i_1090_n_0\,
      S(0) => \rgb_out[23]_i_1091_n_0\
    );
\rgb_out_reg[23]_i_635\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_1092_n_0\,
      CO(3) => \NLW_rgb_out_reg[23]_i_635_CO_UNCONNECTED\(3),
      CO(2) => \REC_U/pixel_on6\,
      CO(1) => \rgb_out_reg[23]_i_635_n_2\,
      CO(0) => \rgb_out_reg[23]_i_635_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \rgb_out[23]_i_1093_n_0\,
      DI(1 downto 0) => B"00",
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_635_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \rgb_out_reg[23]_i_1068_n_0\,
      S(1) => \rgb_out[23]_i_1094_n_0\,
      S(0) => \rgb_out[23]_i_1095_n_0\
    );
\rgb_out_reg[23]_i_637\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_1096_n_0\,
      CO(3) => \NLW_rgb_out_reg[23]_i_637_CO_UNCONNECTED\(3),
      CO(2) => \REC_U/pixel_on99_in\,
      CO(1) => \rgb_out_reg[23]_i_637_n_2\,
      CO(0) => \rgb_out_reg[23]_i_637_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \rgb_out[23]_i_1097_n_0\,
      DI(0) => \rgb_out[23]_i_1098_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_637_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \rgb_out_reg[23]_i_1068_n_0\,
      S(1) => \rgb_out[23]_i_1099_n_0\,
      S(0) => \rgb_out[23]_i_1100_n_0\
    );
\rgb_out_reg[23]_i_638\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_1101_n_0\,
      CO(3) => \NLW_rgb_out_reg[23]_i_638_CO_UNCONNECTED\(3),
      CO(2) => \REC_U/pixel_on7\,
      CO(1) => \rgb_out_reg[23]_i_638_n_2\,
      CO(0) => \rgb_out_reg[23]_i_638_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \rgb_out[23]_i_1102_n_0\,
      DI(1 downto 0) => B"00",
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_638_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \rgb_out_reg[23]_i_1072_n_0\,
      S(1) => \rgb_out[23]_i_1103_n_0\,
      S(0) => \rgb_out[23]_i_1104_n_0\
    );
\rgb_out_reg[23]_i_639\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_1105_n_0\,
      CO(3) => \NLW_rgb_out_reg[23]_i_639_CO_UNCONNECTED\(3),
      CO(2) => \REC_U/pixel_on83_in\,
      CO(1) => \rgb_out_reg[23]_i_639_n_2\,
      CO(0) => \rgb_out_reg[23]_i_639_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \rgb_out[23]_i_1106_n_0\,
      DI(0) => \rgb_out[23]_i_1107_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_639_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \rgb_out_reg[23]_i_1072_n_0\,
      S(1) => \rgb_out[23]_i_1108_n_0\,
      S(0) => \rgb_out[23]_i_1109_n_0\
    );
\rgb_out_reg[23]_i_642\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_1110_n_0\,
      CO(3) => \NLW_rgb_out_reg[23]_i_642_CO_UNCONNECTED\(3),
      CO(2) => \REC_U/pixel_on9\,
      CO(1) => \rgb_out_reg[23]_i_642_n_2\,
      CO(0) => \rgb_out_reg[23]_i_642_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \rgb_out[23]_i_1111_n_0\,
      DI(0) => \rgb_out[23]_i_1112_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_642_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \rgb_out_reg[23]_i_1068_n_0\,
      S(1) => \rgb_out[23]_i_1113_n_0\,
      S(0) => \rgb_out[23]_i_1114_n_0\
    );
\rgb_out_reg[23]_i_643\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_1115_n_0\,
      CO(3) => \NLW_rgb_out_reg[23]_i_643_CO_UNCONNECTED\(3),
      CO(2) => \REC_U/pixel_on8\,
      CO(1) => \rgb_out_reg[23]_i_643_n_2\,
      CO(0) => \rgb_out_reg[23]_i_643_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \rgb_out[23]_i_1116_n_0\,
      DI(1 downto 0) => B"00",
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_643_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \rgb_out_reg[23]_i_1068_n_0\,
      S(1) => \rgb_out[23]_i_1117_n_0\,
      S(0) => \rgb_out[23]_i_1118_n_0\
    );
\rgb_out_reg[23]_i_646\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_1119_n_0\,
      CO(3) => \NLW_rgb_out_reg[23]_i_646_CO_UNCONNECTED\(3),
      CO(2) => \REC_U/pixel_on712_in\,
      CO(1) => \rgb_out_reg[23]_i_646_n_2\,
      CO(0) => \rgb_out_reg[23]_i_646_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \rgb_out[23]_i_1120_n_0\,
      DI(1 downto 0) => B"00",
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_646_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \rgb_out_reg[23]_i_1072_n_0\,
      S(1) => \rgb_out[23]_i_1121_n_0\,
      S(0) => \rgb_out[23]_i_1122_n_0\
    );
\rgb_out_reg[23]_i_648\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_1123_n_0\,
      CO(3) => \NLW_rgb_out_reg[23]_i_648_CO_UNCONNECTED\(3),
      CO(2) => \REC_U/pixel_on22_in\,
      CO(1) => \rgb_out_reg[23]_i_648_n_2\,
      CO(0) => \rgb_out_reg[23]_i_648_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \rgb_out[23]_i_1124_n_0\,
      DI(1 downto 0) => B"00",
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_648_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \rgb_out_reg[23]_i_1072_n_0\,
      S(1) => \rgb_out[23]_i_1125_n_0\,
      S(0) => \rgb_out[23]_i_1126_n_0\
    );
\rgb_out_reg[23]_i_650\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_1127_n_0\,
      CO(3) => \NLW_rgb_out_reg[23]_i_650_CO_UNCONNECTED\(3),
      CO(2) => \REC_U/pixel_on31_in\,
      CO(1) => \rgb_out_reg[23]_i_650_n_2\,
      CO(0) => \rgb_out_reg[23]_i_650_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \rgb_out[23]_i_1128_n_0\,
      DI(0) => \rgb_out[23]_i_1129_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_650_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \rgb_out_reg[23]_i_1072_n_0\,
      S(1) => \rgb_out[23]_i_1130_n_0\,
      S(0) => \rgb_out[23]_i_1131_n_0\
    );
\rgb_out_reg[23]_i_652\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_1132_n_0\,
      CO(3) => \NLW_rgb_out_reg[23]_i_652_CO_UNCONNECTED\(3),
      CO(2) => \REC_U/pixel_on5\,
      CO(1) => \rgb_out_reg[23]_i_652_n_2\,
      CO(0) => \rgb_out_reg[23]_i_652_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \rgb_out[23]_i_1133_n_0\,
      DI(0) => \rgb_out[23]_i_1134_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_652_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \rgb_out_reg[23]_i_1072_n_0\,
      S(1) => \rgb_out[23]_i_1135_n_0\,
      S(0) => \rgb_out[23]_i_1136_n_0\
    );
\rgb_out_reg[23]_i_654\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_1137_n_0\,
      CO(3) => \NLW_rgb_out_reg[23]_i_654_CO_UNCONNECTED\(3),
      CO(2) => \LAST_D/pixel_on712_in\,
      CO(1) => \rgb_out_reg[23]_i_654_n_2\,
      CO(0) => \rgb_out_reg[23]_i_654_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \rgb_out[23]_i_1138_n_0\,
      DI(1 downto 0) => B"00",
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_654_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \rgb_out_reg[23]_i_1139_n_0\,
      S(1) => \rgb_out[23]_i_1140_n_0\,
      S(0) => \rgb_out[23]_i_1141_n_0\
    );
\rgb_out_reg[23]_i_655\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_1142_n_0\,
      CO(3) => \NLW_rgb_out_reg[23]_i_655_CO_UNCONNECTED\(3),
      CO(2) => \LAST_D/pixel_on5\,
      CO(1) => \rgb_out_reg[23]_i_655_n_2\,
      CO(0) => \rgb_out_reg[23]_i_655_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \rgb_out[23]_i_1143_n_0\,
      DI(0) => \rgb_out[23]_i_1144_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_655_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \rgb_out_reg[23]_i_1139_n_0\,
      S(1) => \rgb_out[23]_i_1145_n_0\,
      S(0) => \rgb_out[23]_i_1146_n_0\
    );
\rgb_out_reg[23]_i_656\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_1147_n_0\,
      CO(3) => \NLW_rgb_out_reg[23]_i_656_CO_UNCONNECTED\(3),
      CO(2) => \LAST_D/pixel_on9\,
      CO(1) => \rgb_out_reg[23]_i_656_n_2\,
      CO(0) => \rgb_out_reg[23]_i_656_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \rgb_out[23]_i_1148_n_0\,
      DI(0) => \rgb_out[23]_i_1149_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_656_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \rgb_out_reg[23]_i_665_n_0\,
      S(1) => \rgb_out[23]_i_1150_n_0\,
      S(0) => \rgb_out[23]_i_1151_n_0\
    );
\rgb_out_reg[23]_i_657\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_1152_n_0\,
      CO(3) => \NLW_rgb_out_reg[23]_i_657_CO_UNCONNECTED\(3),
      CO(2) => \LAST_D/pixel_on8\,
      CO(1) => \rgb_out_reg[23]_i_657_n_2\,
      CO(0) => \rgb_out_reg[23]_i_657_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \rgb_out[23]_i_1153_n_0\,
      DI(1 downto 0) => B"00",
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_657_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \rgb_out_reg[23]_i_665_n_0\,
      S(1) => \rgb_out[23]_i_1154_n_0\,
      S(0) => \rgb_out[23]_i_1155_n_0\
    );
\rgb_out_reg[23]_i_658\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_1156_n_0\,
      CO(3) => \NLW_rgb_out_reg[23]_i_658_CO_UNCONNECTED\(3),
      CO(2) => \LAST_D/pixel_on83_in\,
      CO(1) => \rgb_out_reg[23]_i_658_n_2\,
      CO(0) => \rgb_out_reg[23]_i_658_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \rgb_out[23]_i_1157_n_0\,
      DI(0) => \rgb_out[23]_i_1158_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_658_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \rgb_out_reg[23]_i_1139_n_0\,
      S(1) => \rgb_out[23]_i_1159_n_0\,
      S(0) => \rgb_out[23]_i_1160_n_0\
    );
\rgb_out_reg[23]_i_659\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_1161_n_0\,
      CO(3) => \NLW_rgb_out_reg[23]_i_659_CO_UNCONNECTED\(3),
      CO(2) => \LAST_D/pixel_on7\,
      CO(1) => \rgb_out_reg[23]_i_659_n_2\,
      CO(0) => \rgb_out_reg[23]_i_659_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \rgb_out[23]_i_1162_n_0\,
      DI(1 downto 0) => B"00",
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_659_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \rgb_out_reg[23]_i_1139_n_0\,
      S(1) => \rgb_out[23]_i_1163_n_0\,
      S(0) => \rgb_out[23]_i_1164_n_0\
    );
\rgb_out_reg[23]_i_660\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_1165_n_0\,
      CO(3) => \NLW_rgb_out_reg[23]_i_660_CO_UNCONNECTED\(3),
      CO(2) => \LAST_D/pixel_on75_in\,
      CO(1) => \rgb_out_reg[23]_i_660_n_2\,
      CO(0) => \rgb_out_reg[23]_i_660_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \rgb_out[23]_i_1166_n_0\,
      DI(0) => \rgb_out[23]_i_1167_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_660_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \rgb_out_reg[23]_i_1139_n_0\,
      S(1) => \rgb_out[23]_i_1168_n_0\,
      S(0) => \rgb_out[23]_i_1169_n_0\
    );
\rgb_out_reg[23]_i_661\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_1170_n_0\,
      CO(3) => \NLW_rgb_out_reg[23]_i_661_CO_UNCONNECTED\(3),
      CO(2) => \LAST_D/pixel_on66_in\,
      CO(1) => \rgb_out_reg[23]_i_661_n_2\,
      CO(0) => \rgb_out_reg[23]_i_661_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \rgb_out[23]_i_1171_n_0\,
      DI(1 downto 0) => B"00",
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_661_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \rgb_out_reg[23]_i_1139_n_0\,
      S(1) => \rgb_out[23]_i_1172_n_0\,
      S(0) => \rgb_out[23]_i_1173_n_0\
    );
\rgb_out_reg[23]_i_662\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_662_n_0\,
      CO(2) => \rgb_out_reg[23]_i_662_n_1\,
      CO(1) => \rgb_out_reg[23]_i_662_n_2\,
      CO(0) => \rgb_out_reg[23]_i_662_n_3\,
      CYINIT => '1',
      DI(3) => \rgb_out[23]_i_1174_n_0\,
      DI(2) => \LAST_D/local_x\(5),
      DI(1) => '0',
      DI(0) => \rgb_out[23]_i_1176_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_662_O_UNCONNECTED\(3 downto 0),
      S(3) => \rgb_out[23]_i_1177_n_0\,
      S(2) => \rgb_out[23]_i_1178_n_0\,
      S(1) => \rgb_out[23]_i_1179_n_0\,
      S(0) => \rgb_out[23]_i_1180_n_0\
    );
\rgb_out_reg[23]_i_665\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_1175_n_0\,
      CO(3) => \rgb_out_reg[23]_i_665_n_0\,
      CO(2) => \NLW_rgb_out_reg[23]_i_665_CO_UNCONNECTED\(2),
      CO(1) => \rgb_out_reg[23]_i_665_n_2\,
      CO(0) => \rgb_out_reg[23]_i_665_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2 downto 0) => pixel_x(11 downto 9),
      O(3) => \NLW_rgb_out_reg[23]_i_665_O_UNCONNECTED\(3),
      O(2 downto 0) => \LAST_D/local_x\(11 downto 9),
      S(3) => '1',
      S(2) => \rgb_out[23]_i_1181_n_0\,
      S(1) => \rgb_out[23]_i_1182_n_0\,
      S(0) => \rgb_out[23]_i_1183_n_0\
    );
\rgb_out_reg[23]_i_668\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_668_n_0\,
      CO(2) => \rgb_out_reg[23]_i_668_n_1\,
      CO(1) => \rgb_out_reg[23]_i_668_n_2\,
      CO(0) => \rgb_out_reg[23]_i_668_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \rgb_out[23]_i_1184_n_0\,
      DI(0) => \rgb_out[23]_i_1185_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_668_O_UNCONNECTED\(3 downto 0),
      S(3) => \rgb_out[23]_i_1186_n_0\,
      S(2) => \rgb_out[23]_i_1187_n_0\,
      S(1) => \rgb_out[23]_i_1188_n_0\,
      S(0) => \rgb_out[23]_i_1189_n_0\
    );
\rgb_out_reg[23]_i_672\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_1190_n_0\,
      CO(3) => \NLW_rgb_out_reg[23]_i_672_CO_UNCONNECTED\(3),
      CO(2) => \LAST_D/pixel_on3\,
      CO(1) => \rgb_out_reg[23]_i_672_n_2\,
      CO(0) => \rgb_out_reg[23]_i_672_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \rgb_out[23]_i_1191_n_0\,
      DI(0) => \rgb_out[23]_i_1192_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_672_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \rgb_out_reg[23]_i_1139_n_0\,
      S(1) => \rgb_out[23]_i_1193_n_0\,
      S(0) => \rgb_out[23]_i_1194_n_0\
    );
\rgb_out_reg[23]_i_673\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_1195_n_0\,
      CO(3) => \NLW_rgb_out_reg[23]_i_673_CO_UNCONNECTED\(3),
      CO(2) => \LAST_D/pixel_on40_in\,
      CO(1) => \rgb_out_reg[23]_i_673_n_2\,
      CO(0) => \rgb_out_reg[23]_i_673_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \rgb_out[23]_i_1196_n_0\,
      DI(0) => \rgb_out[23]_i_1197_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_673_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \rgb_out_reg[23]_i_665_n_0\,
      S(1) => \rgb_out[23]_i_1198_n_0\,
      S(0) => \rgb_out[23]_i_1199_n_0\
    );
\rgb_out_reg[23]_i_674\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_1200_n_0\,
      CO(3 downto 2) => \NLW_rgb_out_reg[23]_i_674_CO_UNCONNECTED\(3 downto 2),
      CO(1) => \LAST_D/pixel_on2\,
      CO(0) => \rgb_out_reg[23]_i_674_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \LAST_D/local_y\(12),
      DI(0) => '0',
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_674_O_UNCONNECTED\(3 downto 0),
      S(3 downto 2) => B"00",
      S(1) => \rgb_out_reg[23]_i_1139_n_0\,
      S(0) => \rgb_out[23]_i_1202_n_0\
    );
\rgb_out_reg[23]_i_675\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_1203_n_0\,
      CO(3 downto 2) => \NLW_rgb_out_reg[23]_i_675_CO_UNCONNECTED\(3 downto 2),
      CO(1) => \LAST_D/pixel_on4\,
      CO(0) => \rgb_out_reg[23]_i_675_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \LAST_D/local_x\(12),
      DI(0) => '0',
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_675_O_UNCONNECTED\(3 downto 0),
      S(3 downto 2) => B"00",
      S(1) => \rgb_out_reg[23]_i_665_n_0\,
      S(0) => \rgb_out[23]_i_1205_n_0\
    );
\rgb_out_reg[23]_i_714\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_714_n_0\,
      CO(2) => \rgb_out_reg[23]_i_714_n_1\,
      CO(1) => \rgb_out_reg[23]_i_714_n_2\,
      CO(0) => \rgb_out_reg[23]_i_714_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \rgb_out[23]_i_1211_n_0\,
      DI(0) => \rgb_out[23]_i_1212_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_714_O_UNCONNECTED\(3 downto 0),
      S(3) => \rgb_out[23]_i_1213_n_0\,
      S(2) => \rgb_out[23]_i_1214_n_0\,
      S(1) => \rgb_out[23]_i_1215_n_0\,
      S(0) => \rgb_out[23]_i_1216_n_0\
    );
\rgb_out_reg[23]_i_716\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_1217_n_0\,
      CO(3 downto 1) => \NLW_rgb_out_reg[23]_i_716_CO_UNCONNECTED\(3 downto 1),
      CO(0) => \rgb_out_reg[23]_i_716_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_716_O_UNCONNECTED\(3 downto 0),
      S(3 downto 0) => B"0001"
    );
\rgb_out_reg[23]_i_718\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_718_n_0\,
      CO(2) => \rgb_out_reg[23]_i_718_n_1\,
      CO(1) => \rgb_out_reg[23]_i_718_n_2\,
      CO(0) => \rgb_out_reg[23]_i_718_n_3\,
      CYINIT => \rgb_out[23]_i_1218_n_0\,
      DI(3 downto 1) => B"000",
      DI(0) => \rgb_out[23]_i_1219_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_718_O_UNCONNECTED\(3 downto 0),
      S(3) => \rgb_out[23]_i_1220_n_0\,
      S(2) => \rgb_out[23]_i_1221_n_0\,
      S(1) => \rgb_out[23]_i_1222_n_0\,
      S(0) => \rgb_out[23]_i_1223_n_0\
    );
\rgb_out_reg[23]_i_720\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_1224_n_0\,
      CO(3) => \rgb_out_reg[23]_i_720_n_0\,
      CO(2) => \NLW_rgb_out_reg[23]_i_720_CO_UNCONNECTED\(2),
      CO(1) => \rgb_out_reg[23]_i_720_n_2\,
      CO(0) => \rgb_out_reg[23]_i_720_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2 downto 0) => pixel_y(11 downto 9),
      O(3) => \NLW_rgb_out_reg[23]_i_720_O_UNCONNECTED\(3),
      O(2 downto 0) => \SC_U/local_y\(11 downto 9),
      S(3) => '1',
      S(2) => \rgb_out[23]_i_1225_n_0\,
      S(1) => \rgb_out[23]_i_1226_n_0\,
      S(0) => \rgb_out[23]_i_1227_n_0\
    );
\rgb_out_reg[23]_i_721\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_721_n_0\,
      CO(2) => \rgb_out_reg[23]_i_721_n_1\,
      CO(1) => \rgb_out_reg[23]_i_721_n_2\,
      CO(0) => \rgb_out_reg[23]_i_721_n_3\,
      CYINIT => '1',
      DI(3) => \rgb_out[23]_i_1228_n_0\,
      DI(2) => \rgb_out[23]_i_1229_n_0\,
      DI(1) => \rgb_out[23]_i_1230_n_0\,
      DI(0) => \rgb_out[23]_i_1231_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_721_O_UNCONNECTED\(3 downto 0),
      S(3) => \rgb_out[23]_i_1232_n_0\,
      S(2) => \rgb_out[23]_i_1233_n_0\,
      S(1) => \rgb_out[23]_i_1234_n_0\,
      S(0) => \rgb_out[23]_i_1235_n_0\
    );
\rgb_out_reg[23]_i_726\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_726_n_0\,
      CO(2) => \rgb_out_reg[23]_i_726_n_1\,
      CO(1) => \rgb_out_reg[23]_i_726_n_2\,
      CO(0) => \rgb_out_reg[23]_i_726_n_3\,
      CYINIT => '1',
      DI(3) => \rgb_out[23]_i_1236_n_0\,
      DI(2) => \rgb_out[23]_i_1237_n_0\,
      DI(1) => \rgb_out[23]_i_1238_n_0\,
      DI(0) => \rgb_out[23]_i_1239_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_726_O_UNCONNECTED\(3 downto 0),
      S(3) => \rgb_out[23]_i_1240_n_0\,
      S(2) => \rgb_out[23]_i_1241_n_0\,
      S(1) => \rgb_out[23]_i_1242_n_0\,
      S(0) => \rgb_out[23]_i_1243_n_0\
    );
\rgb_out_reg[23]_i_731\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_1244_n_0\,
      CO(3) => \NLW_rgb_out_reg[23]_i_731_CO_UNCONNECTED\(3),
      CO(2) => \SC_U/pixel_on5\,
      CO(1) => \rgb_out_reg[23]_i_731_n_2\,
      CO(0) => \rgb_out_reg[23]_i_731_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \rgb_out[23]_i_1245_n_0\,
      DI(0) => \rgb_out[23]_i_1246_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_731_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \rgb_out_reg[23]_i_720_n_0\,
      S(1) => \rgb_out[23]_i_1247_n_0\,
      S(0) => \rgb_out[23]_i_1248_n_0\
    );
\rgb_out_reg[23]_i_732\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_1249_n_0\,
      CO(3) => \NLW_rgb_out_reg[23]_i_732_CO_UNCONNECTED\(3),
      CO(2) => \SC_U/pixel_on8\,
      CO(1) => \rgb_out_reg[23]_i_732_n_2\,
      CO(0) => \rgb_out_reg[23]_i_732_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \rgb_out[23]_i_1250_n_0\,
      DI(1 downto 0) => B"00",
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_732_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \rgb_out_reg[23]_i_716_n_3\,
      S(1) => \rgb_out[23]_i_1251_n_0\,
      S(0) => \rgb_out[23]_i_1252_n_0\
    );
\rgb_out_reg[23]_i_735\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_1258_n_0\,
      CO(3) => \NLW_rgb_out_reg[23]_i_735_CO_UNCONNECTED\(3),
      CO(2) => \SC_U/pixel_on22_in\,
      CO(1) => \rgb_out_reg[23]_i_735_n_2\,
      CO(0) => \rgb_out_reg[23]_i_735_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \rgb_out[23]_i_1259_n_0\,
      DI(1 downto 0) => B"00",
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_735_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \rgb_out_reg[23]_i_720_n_0\,
      S(1) => \rgb_out[23]_i_1260_n_0\,
      S(0) => \rgb_out[23]_i_1261_n_0\
    );
\rgb_out_reg[23]_i_737\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_1262_n_0\,
      CO(3) => \NLW_rgb_out_reg[23]_i_737_CO_UNCONNECTED\(3),
      CO(2) => \SC_U/pixel_on31_in\,
      CO(1) => \rgb_out_reg[23]_i_737_n_2\,
      CO(0) => \rgb_out_reg[23]_i_737_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \rgb_out[23]_i_1263_n_0\,
      DI(0) => \rgb_out[23]_i_1264_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_737_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \rgb_out_reg[23]_i_720_n_0\,
      S(1) => \rgb_out[23]_i_1265_n_0\,
      S(0) => \rgb_out[23]_i_1266_n_0\
    );
\rgb_out_reg[23]_i_739\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_1267_n_0\,
      CO(3) => \NLW_rgb_out_reg[23]_i_739_CO_UNCONNECTED\(3),
      CO(2) => \SC_U/pixel_on712_in\,
      CO(1) => \rgb_out_reg[23]_i_739_n_2\,
      CO(0) => \rgb_out_reg[23]_i_739_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \rgb_out[23]_i_1268_n_0\,
      DI(1 downto 0) => B"00",
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_739_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \rgb_out_reg[23]_i_720_n_0\,
      S(1) => \rgb_out[23]_i_1269_n_0\,
      S(0) => \rgb_out[23]_i_1270_n_0\
    );
\rgb_out_reg[23]_i_740\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_1271_n_0\,
      CO(3) => \NLW_rgb_out_reg[23]_i_740_CO_UNCONNECTED\(3),
      CO(2) => \SC_U/pixel_on7\,
      CO(1) => \rgb_out_reg[23]_i_740_n_2\,
      CO(0) => \rgb_out_reg[23]_i_740_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \rgb_out[23]_i_1272_n_0\,
      DI(1 downto 0) => B"00",
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_740_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \rgb_out_reg[23]_i_720_n_0\,
      S(1) => \rgb_out[23]_i_1273_n_0\,
      S(0) => \rgb_out[23]_i_1274_n_0\
    );
\rgb_out_reg[23]_i_741\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_1275_n_0\,
      CO(3) => \NLW_rgb_out_reg[23]_i_741_CO_UNCONNECTED\(3),
      CO(2) => \SC_U/pixel_on83_in\,
      CO(1) => \rgb_out_reg[23]_i_741_n_2\,
      CO(0) => \rgb_out_reg[23]_i_741_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \rgb_out[23]_i_1276_n_0\,
      DI(0) => \rgb_out[23]_i_1277_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_741_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \rgb_out_reg[23]_i_720_n_0\,
      S(1) => \rgb_out[23]_i_1278_n_0\,
      S(0) => \rgb_out[23]_i_1279_n_0\
    );
\rgb_out_reg[23]_i_743\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_1280_n_0\,
      CO(3) => \NLW_rgb_out_reg[23]_i_743_CO_UNCONNECTED\(3),
      CO(2) => \SC_U/pixel_on6\,
      CO(1) => \rgb_out_reg[23]_i_743_n_2\,
      CO(0) => \rgb_out_reg[23]_i_743_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \rgb_out[23]_i_1281_n_0\,
      DI(1 downto 0) => B"00",
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_743_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \rgb_out_reg[23]_i_716_n_3\,
      S(1) => \rgb_out[23]_i_1282_n_0\,
      S(0) => \rgb_out[23]_i_1283_n_0\
    );
\rgb_out_reg[23]_i_745\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_1284_n_0\,
      CO(3) => \NLW_rgb_out_reg[23]_i_745_CO_UNCONNECTED\(3),
      CO(2) => \SC_U/pixel_on99_in\,
      CO(1) => \rgb_out_reg[23]_i_745_n_2\,
      CO(0) => \rgb_out_reg[23]_i_745_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \rgb_out[23]_i_1285_n_0\,
      DI(0) => \rgb_out[23]_i_1286_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_745_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \rgb_out_reg[23]_i_716_n_3\,
      S(1) => \rgb_out[23]_i_1287_n_0\,
      S(0) => \rgb_out[23]_i_1288_n_0\
    );
\rgb_out_reg[23]_i_746\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_1289_n_0\,
      CO(3) => \NLW_rgb_out_reg[23]_i_746_CO_UNCONNECTED\(3),
      CO(2) => \SC_U/pixel_on66_in\,
      CO(1) => \rgb_out_reg[23]_i_746_n_2\,
      CO(0) => \rgb_out_reg[23]_i_746_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \rgb_out[23]_i_1290_n_0\,
      DI(1 downto 0) => B"00",
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_746_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \rgb_out_reg[23]_i_720_n_0\,
      S(1) => \rgb_out[23]_i_1291_n_0\,
      S(0) => \rgb_out[23]_i_1292_n_0\
    );
\rgb_out_reg[23]_i_747\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_1293_n_0\,
      CO(3) => \NLW_rgb_out_reg[23]_i_747_CO_UNCONNECTED\(3),
      CO(2) => \SC_U/pixel_on75_in\,
      CO(1) => \rgb_out_reg[23]_i_747_n_2\,
      CO(0) => \rgb_out_reg[23]_i_747_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \rgb_out[23]_i_1294_n_0\,
      DI(0) => \rgb_out[23]_i_1295_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_747_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \rgb_out_reg[23]_i_720_n_0\,
      S(1) => \rgb_out[23]_i_1296_n_0\,
      S(0) => \rgb_out[23]_i_1297_n_0\
    );
\rgb_out_reg[23]_i_750\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_1298_n_0\,
      CO(3) => \NLW_rgb_out_reg[23]_i_750_CO_UNCONNECTED\(3),
      CO(2) => \SC_D/pixel_on712_in\,
      CO(1) => \rgb_out_reg[23]_i_750_n_2\,
      CO(0) => \rgb_out_reg[23]_i_750_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \rgb_out[23]_i_1299_n_0\,
      DI(1 downto 0) => B"00",
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_750_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => U0_n_15,
      S(1) => \rgb_out[23]_i_1301_n_0\,
      S(0) => \rgb_out[23]_i_1302_n_0\
    );
\rgb_out_reg[23]_i_751\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_1303_n_0\,
      CO(3) => \NLW_rgb_out_reg[23]_i_751_CO_UNCONNECTED\(3),
      CO(2) => \SC_D/pixel_on5\,
      CO(1) => \rgb_out_reg[23]_i_751_n_2\,
      CO(0) => \rgb_out_reg[23]_i_751_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \rgb_out[23]_i_1304_n_0\,
      DI(0) => \rgb_out[23]_i_1305_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_751_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => U0_n_15,
      S(1) => \rgb_out[23]_i_1306_n_0\,
      S(0) => \rgb_out[23]_i_1307_n_0\
    );
\rgb_out_reg[23]_i_753\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_1313_n_0\,
      CO(3) => \NLW_rgb_out_reg[23]_i_753_CO_UNCONNECTED\(3),
      CO(2) => \SC_D/pixel_on8\,
      CO(1) => \rgb_out_reg[23]_i_753_n_2\,
      CO(0) => \rgb_out_reg[23]_i_753_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \rgb_out[23]_i_1314_n_0\,
      DI(1 downto 0) => B"00",
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_753_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \rgb_out_reg[23]_i_761_n_3\,
      S(1) => \rgb_out[23]_i_1315_n_0\,
      S(0) => \rgb_out[23]_i_1316_n_0\
    );
\rgb_out_reg[23]_i_756\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_1326_n_0\,
      CO(3) => \NLW_rgb_out_reg[23]_i_756_CO_UNCONNECTED\(3),
      CO(2) => \SC_D/pixel_on75_in\,
      CO(1) => \rgb_out_reg[23]_i_756_n_2\,
      CO(0) => \rgb_out_reg[23]_i_756_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \rgb_out[23]_i_1327_n_0\,
      DI(0) => \rgb_out[23]_i_1328_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_756_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => U0_n_15,
      S(1) => \rgb_out[23]_i_1329_n_0\,
      S(0) => \rgb_out[23]_i_1330_n_0\
    );
\rgb_out_reg[23]_i_758\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_758_n_0\,
      CO(2) => \rgb_out_reg[23]_i_758_n_1\,
      CO(1) => \rgb_out_reg[23]_i_758_n_2\,
      CO(0) => \rgb_out_reg[23]_i_758_n_3\,
      CYINIT => '1',
      DI(3) => \rgb_out[23]_i_1335_n_0\,
      DI(2) => \SC_D/local_x\(5),
      DI(1) => '0',
      DI(0) => \rgb_out[23]_i_1337_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_758_O_UNCONNECTED\(3 downto 0),
      S(3) => \rgb_out[23]_i_1338_n_0\,
      S(2) => \rgb_out[23]_i_1339_n_0\,
      S(1) => \rgb_out[23]_i_1340_n_0\,
      S(0) => \rgb_out[23]_i_1341_n_0\
    );
\rgb_out_reg[23]_i_761\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_1342_n_0\,
      CO(3 downto 1) => \NLW_rgb_out_reg[23]_i_761_CO_UNCONNECTED\(3 downto 1),
      CO(0) => \rgb_out_reg[23]_i_761_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_761_O_UNCONNECTED\(3 downto 0),
      S(3 downto 0) => B"0001"
    );
\rgb_out_reg[23]_i_764\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_764_n_0\,
      CO(2) => \rgb_out_reg[23]_i_764_n_1\,
      CO(1) => \rgb_out_reg[23]_i_764_n_2\,
      CO(0) => \rgb_out_reg[23]_i_764_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \rgb_out[23]_i_1343_n_0\,
      DI(0) => \rgb_out[23]_i_1344_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_764_O_UNCONNECTED\(3 downto 0),
      S(3) => \rgb_out[23]_i_1345_n_0\,
      S(2) => \rgb_out[23]_i_1346_n_0\,
      S(1) => \rgb_out[23]_i_1347_n_0\,
      S(0) => \rgb_out[23]_i_1348_n_0\
    );
\rgb_out_reg[23]_i_768\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_1349_n_0\,
      CO(3) => \NLW_rgb_out_reg[23]_i_768_CO_UNCONNECTED\(3),
      CO(2) => \SC_D/pixel_on3\,
      CO(1) => \rgb_out_reg[23]_i_768_n_2\,
      CO(0) => \rgb_out_reg[23]_i_768_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \rgb_out[23]_i_1350_n_0\,
      DI(0) => \rgb_out[23]_i_1351_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_768_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => U0_n_15,
      S(1) => \rgb_out[23]_i_1352_n_0\,
      S(0) => \rgb_out[23]_i_1353_n_0\
    );
\rgb_out_reg[23]_i_769\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_1354_n_0\,
      CO(3) => \NLW_rgb_out_reg[23]_i_769_CO_UNCONNECTED\(3),
      CO(2) => \SC_D/pixel_on40_in\,
      CO(1) => \rgb_out_reg[23]_i_769_n_2\,
      CO(0) => \rgb_out_reg[23]_i_769_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \rgb_out[23]_i_1355_n_0\,
      DI(0) => \rgb_out[23]_i_1356_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_769_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \rgb_out_reg[23]_i_761_n_3\,
      S(1) => \rgb_out[23]_i_1357_n_0\,
      S(0) => \rgb_out[23]_i_1358_n_0\
    );
\rgb_out_reg[23]_i_770\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_1359_n_0\,
      CO(3 downto 2) => \NLW_rgb_out_reg[23]_i_770_CO_UNCONNECTED\(3 downto 2),
      CO(1) => \SC_D/pixel_on2\,
      CO(0) => \rgb_out_reg[23]_i_770_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \SC_D/local_y\(12),
      DI(0) => '0',
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_770_O_UNCONNECTED\(3 downto 0),
      S(3 downto 2) => B"00",
      S(1) => U0_n_15,
      S(0) => \rgb_out[23]_i_1361_n_0\
    );
\rgb_out_reg[23]_i_771\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_1362_n_0\,
      CO(3 downto 2) => \NLW_rgb_out_reg[23]_i_771_CO_UNCONNECTED\(3 downto 2),
      CO(1) => \SC_D/pixel_on4\,
      CO(0) => \rgb_out_reg[23]_i_771_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \SC_D/local_x\(12),
      DI(0) => '0',
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_771_O_UNCONNECTED\(3 downto 0),
      S(3 downto 2) => B"00",
      S(1) => \rgb_out_reg[23]_i_761_n_3\,
      S(0) => \rgb_out[23]_i_1364_n_0\
    );
\rgb_out_reg[23]_i_777\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_777_n_0\,
      CO(2) => \rgb_out_reg[23]_i_777_n_1\,
      CO(1) => \rgb_out_reg[23]_i_777_n_2\,
      CO(0) => \rgb_out_reg[23]_i_777_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \rgb_out[23]_i_1365_n_0\,
      DI(0) => \rgb_out[23]_i_1366_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_777_O_UNCONNECTED\(3 downto 0),
      S(3) => \rgb_out[23]_i_1367_n_0\,
      S(2) => \rgb_out[23]_i_1368_n_0\,
      S(1) => \rgb_out[23]_i_1369_n_0\,
      S(0) => \rgb_out[23]_i_1370_n_0\
    );
\rgb_out_reg[23]_i_779\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_1371_n_0\,
      CO(3) => \rgb_out_reg[23]_i_779_n_0\,
      CO(2) => \NLW_rgb_out_reg[23]_i_779_CO_UNCONNECTED\(2),
      CO(1) => \rgb_out_reg[23]_i_779_n_2\,
      CO(0) => \rgb_out_reg[23]_i_779_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2 downto 0) => pixel_y(11 downto 9),
      O(3) => \NLW_rgb_out_reg[23]_i_779_O_UNCONNECTED\(3),
      O(2 downto 0) => \TM_D/local_y\(11 downto 9),
      S(3) => '1',
      S(2) => \rgb_out[23]_i_1372_n_0\,
      S(1) => \rgb_out[23]_i_1373_n_0\,
      S(0) => \rgb_out[23]_i_1374_n_0\
    );
\rgb_out_reg[23]_i_782\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_782_n_0\,
      CO(2) => \rgb_out_reg[23]_i_782_n_1\,
      CO(1) => \rgb_out_reg[23]_i_782_n_2\,
      CO(0) => \rgb_out_reg[23]_i_782_n_3\,
      CYINIT => '1',
      DI(3) => \rgb_out[23]_i_1375_n_0\,
      DI(2) => '0',
      DI(1) => \TM_D/local_y\(3),
      DI(0) => \rgb_out[23]_i_1377_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_782_O_UNCONNECTED\(3 downto 0),
      S(3) => \rgb_out[23]_i_1378_n_0\,
      S(2) => \rgb_out[23]_i_1379_n_0\,
      S(1) => \rgb_out[23]_i_1380_n_0\,
      S(0) => \rgb_out[23]_i_1381_n_0\
    );
\rgb_out_reg[23]_i_792\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_792_n_0\,
      CO(2) => \rgb_out_reg[23]_i_792_n_1\,
      CO(1) => \rgb_out_reg[23]_i_792_n_2\,
      CO(0) => \rgb_out_reg[23]_i_792_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \rgb_out[23]_i_1389_n_0\,
      DI(1) => \rgb_out[23]_i_1390_n_0\,
      DI(0) => \rgb_out[23]_i_1391_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_792_O_UNCONNECTED\(3 downto 0),
      S(3) => \rgb_out[23]_i_1392_n_0\,
      S(2) => \rgb_out[23]_i_1393_n_0\,
      S(1) => \rgb_out[23]_i_1394_n_0\,
      S(0) => \rgb_out[23]_i_1395_n_0\
    );
\rgb_out_reg[23]_i_796\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_796_n_0\,
      CO(2) => \rgb_out_reg[23]_i_796_n_1\,
      CO(1) => \rgb_out_reg[23]_i_796_n_2\,
      CO(0) => \rgb_out_reg[23]_i_796_n_3\,
      CYINIT => '1',
      DI(3) => \rgb_out[23]_i_1396_n_0\,
      DI(2) => \rgb_out[23]_i_1397_n_0\,
      DI(1) => \TM_D/local_y\(3),
      DI(0) => \rgb_out[23]_i_1398_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_796_O_UNCONNECTED\(3 downto 0),
      S(3) => \rgb_out[23]_i_1399_n_0\,
      S(2) => \rgb_out[23]_i_1400_n_0\,
      S(1) => \rgb_out[23]_i_1401_n_0\,
      S(0) => \rgb_out[23]_i_1402_n_0\
    );
\rgb_out_reg[23]_i_801\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_801_n_0\,
      CO(2) => \rgb_out_reg[23]_i_801_n_1\,
      CO(1) => \rgb_out_reg[23]_i_801_n_2\,
      CO(0) => \rgb_out_reg[23]_i_801_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \rgb_out[23]_i_1403_n_0\,
      DI(1) => \rgb_out[23]_i_1404_n_0\,
      DI(0) => \rgb_out[23]_i_1405_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_801_O_UNCONNECTED\(3 downto 0),
      S(3) => \rgb_out[23]_i_1406_n_0\,
      S(2) => \rgb_out[23]_i_1407_n_0\,
      S(1) => \rgb_out[23]_i_1408_n_0\,
      S(0) => \rgb_out[23]_i_1409_n_0\
    );
\rgb_out_reg[23]_i_805\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_805_n_0\,
      CO(2) => \rgb_out_reg[23]_i_805_n_1\,
      CO(1) => \rgb_out_reg[23]_i_805_n_2\,
      CO(0) => \rgb_out_reg[23]_i_805_n_3\,
      CYINIT => '1',
      DI(3) => \rgb_out[23]_i_1410_n_0\,
      DI(2) => \TM_D/local_y\(5),
      DI(1) => '0',
      DI(0) => \rgb_out[23]_i_1411_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_805_O_UNCONNECTED\(3 downto 0),
      S(3) => \rgb_out[23]_i_1412_n_0\,
      S(2) => \rgb_out[23]_i_1413_n_0\,
      S(1) => \rgb_out[23]_i_1414_n_0\,
      S(0) => \rgb_out[23]_i_1415_n_0\
    );
\rgb_out_reg[23]_i_810\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_810_n_0\,
      CO(2) => \rgb_out_reg[23]_i_810_n_1\,
      CO(1) => \rgb_out_reg[23]_i_810_n_2\,
      CO(0) => \rgb_out_reg[23]_i_810_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \rgb_out[23]_i_1416_n_0\,
      DI(1) => \rgb_out[23]_i_1417_n_0\,
      DI(0) => \rgb_out[23]_i_1418_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_810_O_UNCONNECTED\(3 downto 0),
      S(3) => \rgb_out[23]_i_1419_n_0\,
      S(2) => \rgb_out[23]_i_1420_n_0\,
      S(1) => \rgb_out[23]_i_1421_n_0\,
      S(0) => \rgb_out[23]_i_1422_n_0\
    );
\rgb_out_reg[23]_i_815\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_815_n_0\,
      CO(2) => \rgb_out_reg[23]_i_815_n_1\,
      CO(1) => \rgb_out_reg[23]_i_815_n_2\,
      CO(0) => \rgb_out_reg[23]_i_815_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => pixel_x(3),
      DI(0) => '0',
      O(3 downto 0) => \TM_D/local_x\(5 downto 2),
      S(3 downto 2) => pixel_x(5 downto 4),
      S(1) => \rgb_out[23]_i_1423_n_0\,
      S(0) => pixel_x(2)
    );
\rgb_out_reg[23]_i_821\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_815_n_0\,
      CO(3) => \rgb_out_reg[23]_i_821_n_0\,
      CO(2) => \rgb_out_reg[23]_i_821_n_1\,
      CO(1) => \rgb_out_reg[23]_i_821_n_2\,
      CO(0) => \rgb_out_reg[23]_i_821_n_3\,
      CYINIT => '0',
      DI(3) => pixel_x(9),
      DI(2) => '0',
      DI(1) => pixel_x(7),
      DI(0) => '0',
      O(3 downto 0) => \TM_D/local_x\(9 downto 6),
      S(3) => \rgb_out[23]_i_1424_n_0\,
      S(2) => pixel_x(8),
      S(1) => \rgb_out[23]_i_1425_n_0\,
      S(0) => pixel_x(6)
    );
\rgb_out_reg[23]_i_829\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_829_n_0\,
      CO(2) => \rgb_out_reg[23]_i_829_n_1\,
      CO(1) => \rgb_out_reg[23]_i_829_n_2\,
      CO(0) => \rgb_out_reg[23]_i_829_n_3\,
      CYINIT => '1',
      DI(3) => \rgb_out[23]_i_1426_n_0\,
      DI(2) => \rgb_out[23]_i_1427_n_0\,
      DI(1) => \rgb_out[23]_i_1428_n_0\,
      DI(0) => \rgb_out[23]_i_1429_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_829_O_UNCONNECTED\(3 downto 0),
      S(3) => \rgb_out[23]_i_1430_n_0\,
      S(2) => \rgb_out[23]_i_1431_n_0\,
      S(1) => \rgb_out[23]_i_1432_n_0\,
      S(0) => \rgb_out[23]_i_1433_n_0\
    );
\rgb_out_reg[23]_i_834\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_834_n_0\,
      CO(2) => \rgb_out_reg[23]_i_834_n_1\,
      CO(1) => \rgb_out_reg[23]_i_834_n_2\,
      CO(0) => \rgb_out_reg[23]_i_834_n_3\,
      CYINIT => '1',
      DI(3) => \rgb_out[23]_i_1434_n_0\,
      DI(2) => \rgb_out[23]_i_1435_n_0\,
      DI(1) => \rgb_out[23]_i_1436_n_0\,
      DI(0) => \rgb_out[23]_i_1437_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_834_O_UNCONNECTED\(3 downto 0),
      S(3) => \rgb_out[23]_i_1438_n_0\,
      S(2) => \rgb_out[23]_i_1439_n_0\,
      S(1) => \rgb_out[23]_i_1440_n_0\,
      S(0) => \rgb_out[23]_i_1441_n_0\
    );
\rgb_out_reg[23]_i_839\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_839_n_0\,
      CO(2) => \rgb_out_reg[23]_i_839_n_1\,
      CO(1) => \rgb_out_reg[23]_i_839_n_2\,
      CO(0) => \rgb_out_reg[23]_i_839_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \rgb_out[23]_i_1442_n_0\,
      DI(0) => \rgb_out[23]_i_1443_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_839_O_UNCONNECTED\(3 downto 0),
      S(3) => \rgb_out[23]_i_1444_n_0\,
      S(2) => \rgb_out[23]_i_1445_n_0\,
      S(1) => \rgb_out[23]_i_1446_n_0\,
      S(0) => \rgb_out[23]_i_1447_n_0\
    );
\rgb_out_reg[23]_i_842\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_842_n_0\,
      CO(2) => \rgb_out_reg[23]_i_842_n_1\,
      CO(1) => \rgb_out_reg[23]_i_842_n_2\,
      CO(0) => \rgb_out_reg[23]_i_842_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \rgb_out[23]_i_1448_n_0\,
      DI(0) => \rgb_out[23]_i_1449_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_842_O_UNCONNECTED\(3 downto 0),
      S(3) => \rgb_out[23]_i_1450_n_0\,
      S(2) => \rgb_out[23]_i_1451_n_0\,
      S(1) => \rgb_out[23]_i_1452_n_0\,
      S(0) => \rgb_out[23]_i_1453_n_0\
    );
\rgb_out_reg[23]_i_927\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_927_n_0\,
      CO(2) => \rgb_out_reg[23]_i_927_n_1\,
      CO(1) => \rgb_out_reg[23]_i_927_n_2\,
      CO(0) => \rgb_out_reg[23]_i_927_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \rgb_out[23]_i_1497_n_0\,
      DI(0) => \rgb_out[23]_i_1498_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_927_O_UNCONNECTED\(3 downto 0),
      S(3) => \rgb_out[23]_i_1499_n_0\,
      S(2) => \rgb_out[23]_i_1500_n_0\,
      S(1) => \rgb_out[23]_i_1501_n_0\,
      S(0) => \rgb_out[23]_i_1502_n_0\
    );
\rgb_out_reg[23]_i_929\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_1503_n_0\,
      CO(3) => \rgb_out_reg[23]_i_929_n_0\,
      CO(2) => \NLW_rgb_out_reg[23]_i_929_CO_UNCONNECTED\(2),
      CO(1) => \rgb_out_reg[23]_i_929_n_2\,
      CO(0) => \rgb_out_reg[23]_i_929_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2 downto 0) => pixel_y(11 downto 9),
      O(3) => \NLW_rgb_out_reg[23]_i_929_O_UNCONNECTED\(3),
      O(2 downto 0) => \REC_D/local_y\(11 downto 9),
      S(3) => '1',
      S(2) => \rgb_out[23]_i_1504_n_0\,
      S(1) => \rgb_out[23]_i_1505_n_0\,
      S(0) => \rgb_out[23]_i_1506_n_0\
    );
\rgb_out_reg[23]_i_932\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_932_n_0\,
      CO(2) => \rgb_out_reg[23]_i_932_n_1\,
      CO(1) => \rgb_out_reg[23]_i_932_n_2\,
      CO(0) => \rgb_out_reg[23]_i_932_n_3\,
      CYINIT => '1',
      DI(3) => \rgb_out[23]_i_1507_n_0\,
      DI(2) => '0',
      DI(1) => \REC_D/local_y\(3),
      DI(0) => \rgb_out[23]_i_1509_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_932_O_UNCONNECTED\(3 downto 0),
      S(3) => \rgb_out[23]_i_1510_n_0\,
      S(2) => \rgb_out[23]_i_1511_n_0\,
      S(1) => \rgb_out[23]_i_1512_n_0\,
      S(0) => \rgb_out[23]_i_1513_n_0\
    );
\rgb_out_reg[23]_i_937\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_937_n_0\,
      CO(2) => \rgb_out_reg[23]_i_937_n_1\,
      CO(1) => \rgb_out_reg[23]_i_937_n_2\,
      CO(0) => \rgb_out_reg[23]_i_937_n_3\,
      CYINIT => '1',
      DI(3) => \rgb_out[23]_i_1514_n_0\,
      DI(2) => \rgb_out[23]_i_1515_n_0\,
      DI(1) => \REC_D/local_x\(3),
      DI(0) => \rgb_out[23]_i_1517_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_937_O_UNCONNECTED\(3 downto 0),
      S(3) => \rgb_out[23]_i_1518_n_0\,
      S(2) => \rgb_out[23]_i_1519_n_0\,
      S(1) => \rgb_out[23]_i_1520_n_0\,
      S(0) => \rgb_out[23]_i_1521_n_0\
    );
\rgb_out_reg[23]_i_942\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_942_n_0\,
      CO(2) => \rgb_out_reg[23]_i_942_n_1\,
      CO(1) => \rgb_out_reg[23]_i_942_n_2\,
      CO(0) => \rgb_out_reg[23]_i_942_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \rgb_out[23]_i_1522_n_0\,
      DI(1) => \rgb_out[23]_i_1523_n_0\,
      DI(0) => \rgb_out[23]_i_1524_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_942_O_UNCONNECTED\(3 downto 0),
      S(3) => \rgb_out[23]_i_1525_n_0\,
      S(2) => \rgb_out[23]_i_1526_n_0\,
      S(1) => \rgb_out[23]_i_1527_n_0\,
      S(0) => \rgb_out[23]_i_1528_n_0\
    );
\rgb_out_reg[23]_i_946\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_946_n_0\,
      CO(2) => \rgb_out_reg[23]_i_946_n_1\,
      CO(1) => \rgb_out_reg[23]_i_946_n_2\,
      CO(0) => \rgb_out_reg[23]_i_946_n_3\,
      CYINIT => '1',
      DI(3) => \rgb_out[23]_i_1529_n_0\,
      DI(2) => \rgb_out[23]_i_1530_n_0\,
      DI(1) => \REC_D/local_y\(3),
      DI(0) => \rgb_out[23]_i_1531_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_946_O_UNCONNECTED\(3 downto 0),
      S(3) => \rgb_out[23]_i_1532_n_0\,
      S(2) => \rgb_out[23]_i_1533_n_0\,
      S(1) => \rgb_out[23]_i_1534_n_0\,
      S(0) => \rgb_out[23]_i_1535_n_0\
    );
\rgb_out_reg[23]_i_951\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_951_n_0\,
      CO(2) => \rgb_out_reg[23]_i_951_n_1\,
      CO(1) => \rgb_out_reg[23]_i_951_n_2\,
      CO(0) => \rgb_out_reg[23]_i_951_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \rgb_out[23]_i_1536_n_0\,
      DI(1) => \rgb_out[23]_i_1537_n_0\,
      DI(0) => \rgb_out[23]_i_1538_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_951_O_UNCONNECTED\(3 downto 0),
      S(3) => \rgb_out[23]_i_1539_n_0\,
      S(2) => \rgb_out[23]_i_1540_n_0\,
      S(1) => \rgb_out[23]_i_1541_n_0\,
      S(0) => \rgb_out[23]_i_1542_n_0\
    );
\rgb_out_reg[23]_i_955\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_955_n_0\,
      CO(2) => \rgb_out_reg[23]_i_955_n_1\,
      CO(1) => \rgb_out_reg[23]_i_955_n_2\,
      CO(0) => \rgb_out_reg[23]_i_955_n_3\,
      CYINIT => '1',
      DI(3) => \rgb_out[23]_i_1543_n_0\,
      DI(2) => \REC_D/local_y\(5),
      DI(1) => '0',
      DI(0) => \rgb_out[23]_i_1544_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_955_O_UNCONNECTED\(3 downto 0),
      S(3) => \rgb_out[23]_i_1545_n_0\,
      S(2) => \rgb_out[23]_i_1546_n_0\,
      S(1) => \rgb_out[23]_i_1547_n_0\,
      S(0) => \rgb_out[23]_i_1548_n_0\
    );
\rgb_out_reg[23]_i_960\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_960_n_0\,
      CO(2) => \rgb_out_reg[23]_i_960_n_1\,
      CO(1) => \rgb_out_reg[23]_i_960_n_2\,
      CO(0) => \rgb_out_reg[23]_i_960_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \rgb_out[23]_i_1549_n_0\,
      DI(1) => \rgb_out[23]_i_1550_n_0\,
      DI(0) => \rgb_out[23]_i_1551_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_960_O_UNCONNECTED\(3 downto 0),
      S(3) => \rgb_out[23]_i_1552_n_0\,
      S(2) => \rgb_out[23]_i_1553_n_0\,
      S(1) => \rgb_out[23]_i_1554_n_0\,
      S(0) => \rgb_out[23]_i_1555_n_0\
    );
\rgb_out_reg[23]_i_965\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_1516_n_0\,
      CO(3) => \rgb_out_reg[23]_i_965_n_0\,
      CO(2) => \rgb_out_reg[23]_i_965_n_1\,
      CO(1) => \rgb_out_reg[23]_i_965_n_2\,
      CO(0) => \rgb_out_reg[23]_i_965_n_3\,
      CYINIT => '0',
      DI(3) => pixel_x(8),
      DI(2) => '0',
      DI(1 downto 0) => pixel_x(6 downto 5),
      O(3 downto 0) => \REC_D/local_x\(8 downto 5),
      S(3) => \rgb_out[23]_i_1556_n_0\,
      S(2) => pixel_x(7),
      S(1) => \rgb_out[23]_i_1557_n_0\,
      S(0) => \rgb_out[23]_i_1558_n_0\
    );
\rgb_out_reg[23]_i_979\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_979_n_0\,
      CO(2) => \rgb_out_reg[23]_i_979_n_1\,
      CO(1) => \rgb_out_reg[23]_i_979_n_2\,
      CO(0) => \rgb_out_reg[23]_i_979_n_3\,
      CYINIT => '1',
      DI(3) => \rgb_out[23]_i_1559_n_0\,
      DI(2) => \rgb_out[23]_i_1560_n_0\,
      DI(1) => \rgb_out[23]_i_1561_n_0\,
      DI(0) => \rgb_out[23]_i_1562_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_979_O_UNCONNECTED\(3 downto 0),
      S(3) => \rgb_out[23]_i_1563_n_0\,
      S(2) => \rgb_out[23]_i_1564_n_0\,
      S(1) => \rgb_out[23]_i_1565_n_0\,
      S(0) => \rgb_out[23]_i_1566_n_0\
    );
\rgb_out_reg[23]_i_984\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_984_n_0\,
      CO(2) => \rgb_out_reg[23]_i_984_n_1\,
      CO(1) => \rgb_out_reg[23]_i_984_n_2\,
      CO(0) => \rgb_out_reg[23]_i_984_n_3\,
      CYINIT => '1',
      DI(3) => \rgb_out[23]_i_1567_n_0\,
      DI(2) => \rgb_out[23]_i_1568_n_0\,
      DI(1) => \rgb_out[23]_i_1569_n_0\,
      DI(0) => \rgb_out[23]_i_1570_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_984_O_UNCONNECTED\(3 downto 0),
      S(3) => \rgb_out[23]_i_1571_n_0\,
      S(2) => \rgb_out[23]_i_1572_n_0\,
      S(1) => \rgb_out[23]_i_1573_n_0\,
      S(0) => \rgb_out[23]_i_1574_n_0\
    );
\rgb_out_reg[23]_i_989\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_989_n_0\,
      CO(2) => \rgb_out_reg[23]_i_989_n_1\,
      CO(1) => \rgb_out_reg[23]_i_989_n_2\,
      CO(0) => \rgb_out_reg[23]_i_989_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \rgb_out[23]_i_1575_n_0\,
      DI(0) => \rgb_out[23]_i_1576_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_989_O_UNCONNECTED\(3 downto 0),
      S(3) => \rgb_out[23]_i_1577_n_0\,
      S(2) => \rgb_out[23]_i_1578_n_0\,
      S(1) => \rgb_out[23]_i_1579_n_0\,
      S(0) => \rgb_out[23]_i_1580_n_0\
    );
\rgb_out_reg[23]_i_992\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_992_n_0\,
      CO(2) => \rgb_out_reg[23]_i_992_n_1\,
      CO(1) => \rgb_out_reg[23]_i_992_n_2\,
      CO(0) => \rgb_out_reg[23]_i_992_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \rgb_out[23]_i_1581_n_0\,
      DI(0) => \rgb_out[23]_i_1582_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_992_O_UNCONNECTED\(3 downto 0),
      S(3) => \rgb_out[23]_i_1583_n_0\,
      S(2) => \rgb_out[23]_i_1584_n_0\,
      S(1) => \rgb_out[23]_i_1585_n_0\,
      S(0) => \rgb_out[23]_i_1586_n_0\
    );
\rgb_out_reg[23]_i_995\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_995_n_0\,
      CO(2) => \rgb_out_reg[23]_i_995_n_1\,
      CO(1) => \rgb_out_reg[23]_i_995_n_2\,
      CO(0) => \rgb_out_reg[23]_i_995_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \rgb_out[23]_i_1587_n_0\,
      DI(0) => \rgb_out[23]_i_1588_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_995_O_UNCONNECTED\(3 downto 0),
      S(3) => \rgb_out[23]_i_1589_n_0\,
      S(2) => \rgb_out[23]_i_1590_n_0\,
      S(1) => \rgb_out[23]_i_1591_n_0\,
      S(0) => \rgb_out[23]_i_1592_n_0\
    );
\rgb_out_reg[23]_i_997\: unisim.vcomponents.CARRY4
     port map (
      CI => \rgb_out_reg[23]_i_1593_n_0\,
      CO(3) => \rgb_out_reg[23]_i_997_n_0\,
      CO(2) => \NLW_rgb_out_reg[23]_i_997_CO_UNCONNECTED\(2),
      CO(1) => \rgb_out_reg[23]_i_997_n_2\,
      CO(0) => \rgb_out_reg[23]_i_997_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2 downto 0) => pixel_x(11 downto 9),
      O(3) => \NLW_rgb_out_reg[23]_i_997_O_UNCONNECTED\(3),
      O(2 downto 0) => \LAST_U/local_x\(11 downto 9),
      S(3) => '1',
      S(2) => \rgb_out[23]_i_1594_n_0\,
      S(1) => \rgb_out[23]_i_1595_n_0\,
      S(0) => \rgb_out[23]_i_1596_n_0\
    );
\rgb_out_reg[23]_i_999\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \rgb_out_reg[23]_i_999_n_0\,
      CO(2) => \rgb_out_reg[23]_i_999_n_1\,
      CO(1) => \rgb_out_reg[23]_i_999_n_2\,
      CO(0) => \rgb_out_reg[23]_i_999_n_3\,
      CYINIT => \rgb_out[23]_i_1597_n_0\,
      DI(3 downto 1) => B"000",
      DI(0) => \rgb_out[23]_i_1598_n_0\,
      O(3 downto 0) => \NLW_rgb_out_reg[23]_i_999_O_UNCONNECTED\(3 downto 0),
      S(3) => \rgb_out[23]_i_1599_n_0\,
      S(2) => \rgb_out[23]_i_1600_n_0\,
      S(1) => \rgb_out[23]_i_1601_n_0\,
      S(0) => \rgb_out[23]_i_1602_n_0\
    );
end STRUCTURE;
